#!/bin/bash
echo "Apagando sessao antiga (database/Arlequina-QR)..."
rm -rf ./database/Arlequina-QR
mkdir -p ./database/Arlequina-QR
echo "Pronto. Agora rode: bash start.sh cod"
