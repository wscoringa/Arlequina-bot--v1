/*
 Convertido/adaptado para o sistema de plugins da Arlequina Bot.
 Comando original: puxcase (bot antigo monolitico, baseado em switch-case
 dentro de um único arquivo).

 Na Arlequina cada comando é um plugin em arquivo separado (plugins/<categoria>/*.js),
 então em vez de caçar um bloco "case 'x': ... break;" dentro de um index.js gigante,
 esse comando busca o plugin pelo nome/alias no commandManager e devolve o
 conteúdo do arquivo correspondente.
*/
const fs = require('fs')
const path = require('path')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'puxcase',
description: "(Dono) Manda o arquivo completo do código-fonte de um comando/plugin",
category: 'dono',
aliases: ['puxarcase', 'pegarcase'],
async execute({ arlequina, from, info, args, q, reply, prefix, commandManager, isDono }) {

try {
  if (!isDono()) return reply('❌ Apenas o dono pode usar esse comando!')

  const nomeComando = (q || args.join(' ') || '').trim().toLowerCase()
  if (!nomeComando) {
    return reply(`${caixaArlequina("puxcase", `⚠️ Uso correto: ${prefix}puxcase <nome_do_comando>`)}`)
  }

  const plugin = commandManager?.ObterComando(nomeComando)
  if (!plugin || !plugin.file) {
    return reply(`❌ O comando '${nomeComando}' não foi encontrado.`)
  }

  // Trava extra: só deixa ler arquivos que realmente estão dentro da pasta de plugins
  const pluginsDir = path.join(__dirname, '..')
  const filePath = path.resolve(plugin.file)
  if (!filePath.startsWith(pluginsDir)) {
    return reply('❌ Esse comando não pode ser lido por aqui.')
  }

  const nomeArquivo = path.basename(filePath)

  // BUGFIX: antes mandava o código como texto e cortava em 3500
  // caracteres em arquivos grandes ("... cortado, arquivo muito
  // grande"). Agora manda o ARQUIVO DE VERDADE como documento .js — o
  // WhatsApp entrega completo, do tamanho que for, sem cortar nada.
  await arlequina.sendMessage(from, {
    document: fs.readFileSync(filePath),
    fileName: nomeArquivo,
    mimetype: 'text/javascript',
    caption: `🔍 Código de *'${plugin.originalName || plugin.name}'* (${nomeArquivo}) — arquivo completo em anexo.`
  }, { quoted: info })
} catch (e) {
  console.log('❌ ERRO DONO (puxcase):', e?.message)
  await reply('❌ Erro ao tentar ler o arquivo desse comando.')
}

}
}
