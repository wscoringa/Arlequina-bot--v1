const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
/*
 Convertido/adaptado para o sistema de plugins da Arlequina Bot.
 Comando original: addai (bot antigo monolitico, injetava um bloco
 "case 'addai': ... break;" direto dentro do index.js).

 A Arlequina não usa switch-case: cada comando é um arquivo de plugin
 em plugins/<categoria>/*.js. Esse plugin adiciona a Meta AI (bot
 oficial do WhatsApp) ao grupo em que o comando for usado.
*/
module.exports = {
name: 'addai',
description: "(Dono) Adiciona a Meta AI ao grupo",
category: 'dono',
aliases: [],
needBotAdmin: true,
async execute({ isDono, arlequina, from, info, reply, isGroup }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina

try {
  if (!isGroup) {
    return reply(caixaArlequina("addai", `❌ Use esse comando dentro de um grupo.`))
  }

  await sock.groupParticipantsUpdate(
    from,
    ['867051314767696@bot'],
    'add'
  )

  await reply('✅ ᴍᴇᴛᴀ ᴀɪ ꜰᴏɪ ᴀᴅɪᴄɪᴏɴᴀᴅᴀ ᴀᴏ ɢʀᴜᴘᴏ ᴄᴏᴍ sᴜᴄᴇssᴏ.')
} catch (e) {
  console.error('[ADDAI]', e)
  await reply('❌ ɴãᴏ ꜰᴏɪ ᴘᴏssíᴠᴇʟ ᴀᴅɪᴄɪᴏɴᴀʀ ᴀ ᴍᴇᴛᴀ ᴀɪ ᴀᴏ ɢʀᴜᴘᴏ.')
}

}
}
