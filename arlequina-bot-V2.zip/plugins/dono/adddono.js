/*
 !adddono <1-5> <número ou @marcado>
 Adiciona um dono extra num dos 5 slots fixos. Quem tá em qualquer slot
 vira dono de verdade pro bot inteiro (isDono() passa a reconhecer ele
 em todo comando, todo grupo).

 Só o dono PRINCIPAL (o número lá do config.json) pode gerenciar os slots
 — assim um dono extra não consegue se tornar permanente sozinho nem
 adicionar mais gente por conta própria.
*/
const donoState = require('../../arquivos/js/donoState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'adddono',
  description: '👑 Adiciona um dono extra (slot de 1 a 5) — só o dono principal',
  category: 'dono',
  aliases: ['addowner', 'setdono'],

  async execute({ reply, reagir, args, info, sender, config, groupMembers, isGroup }) {
    try {
      const numeroDonoPrincipal = String(config.NumeroDoDono || '').replace(/[^0-9]/g, '')
      const senderPuro = String(sender || '').split('@')[0].replace(/[^0-9]/g, '')

      if (senderPuro !== numeroDonoPrincipal) {
        return reply('❌ Só o dono principal do bot pode gerenciar os donos extras.')
      }

      const slot = parseInt(args[0])
      if (!slot || slot < 1 || slot > 5) {
        const lista = Object.entries(donoState.donosExtras)
          .map(([s, num]) => `┋°‧․ˑ💜🃏⃟⠥ʿ Slot ${s}: ${num ? `+${num}` : '_vazio_'}`)
          .join('\n')
        return reply(caixaArlequina("adddono", `👑💜 *DONOS EXTRAS* 💜👑\n\n${lista}\n\n📌 *Uso:*\n*!adddono 1 5511999999999* — define o slot 1\n*!adddono 1 @marcado* — define o slot 1 marcando alguém\n*!removedono 1* — limpa o slot 1`))
      }

      // Pega o número marcado (@) ou o segundo argumento digitado
      const mencionado = info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
      let numeroAlvo = null

      if (mencionado) {
        // O WhatsApp às vezes manda o @ marcado como "xxxxx@lid" (um ID
        // interno novo), que NÃO é o número de telefone de verdade — foi
        // isso que fazia o adddono salvar um número gigante que não
        // batia com ninguém depois. A lista de participantes do grupo já
        // traz o número de telefone real de cada @lid, então resolvemos
        // por aí antes de salvar.
        if (mencionado.endsWith('@lid') && isGroup) {
          const participante = groupMembers?.find(p => p.id === mencionado)
          if (participante?.phoneNumber) {
            numeroAlvo = participante.phoneNumber.split('@')[0].replace(/[^0-9]/g, '')
          }
        }
        if (!numeroAlvo) {
          numeroAlvo = mencionado.split('@')[0].replace(/[^0-9]/g, '')
        }
      } else {
        numeroAlvo = String(args[1] || '').replace(/[^0-9]/g, '')
      }

      if (!numeroAlvo || numeroAlvo.length < 8) {
        return reply('❌ Não consegui identificar um número válido. Marca alguém direto no grupo ou manda o número completo. Ex: *!adddono 1 5511999999999*')
      }

      if (numeroAlvo === numeroDonoPrincipal) {
        return reply('🤡 Esse número já é o dono principal, não precisa adicionar.')
      }

      const jaTemEsseNumero = Object.values(donoState.donosExtras).some(n => n === numeroAlvo)
      if (jaTemEsseNumero) {
        return reply('⚠️ Esse número já é um dono extra em outro slot.')
      }

      donoState.donosExtras[String(slot)] = numeroAlvo
      donoState.salvar()

      await reagir('👑')
      return reply(caixaArlequina("adddono", `✅👑 *DONO EXTRA ADICIONADO* 👑✅\n\n📌 Slot: *${slot}*\n📱 Número: *+${numeroAlvo}*\n\nEsse número agora tem os mesmos poderes do dono principal em todo o bot.`))

    } catch (e) {
      console.log('❌ ERRO DONO (adddono):', e?.message)
      await reply('❌ Não consegui executar esse comando agora.')
    }
  }
}
