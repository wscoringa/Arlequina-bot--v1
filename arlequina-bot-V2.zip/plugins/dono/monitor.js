const fs = require('fs')
const { dbPath } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'monitor',
  description: '🛡️ Adiciona/remove monitor do grupo',
  category: 'dono',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isDono, prefix, groupMembers, isGroup }) {
    if (!isDono()) return reply(caixaArlequina("monitor", `❌ Apenas o dono pode usar este comando.`))
    try {
      const alvoRaw = info.message?.extendedTextMessage?.contextInfo?.participant || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
      if (!alvoRaw) return reply(`❌ Marque alguém com @\nEx: ${prefix}monitor @pessoa`)

      // BUGFIX: o WhatsApp às vezes manda o @ marcado como "xxxxx@lid"
      // (um ID interno, não o número de telefone de verdade). Se a
      // gente salvar o monitor sob esse ID errado, ele nunca bate com
      // o "sender" resolvido de verdade quando a pessoa usa um comando
      // de admin depois — por isso virava monitor mas os comandos
      // continuavam bloqueados. Resolve pelo número real antes de salvar.
      let alvo = alvoRaw
      if (alvoRaw.endsWith('@lid')) {
        if (global.lidParaNumero?.[alvoRaw]) {
          alvo = global.lidParaNumero[alvoRaw]
        } else {
          const participante = isGroup ? groupMembers?.find(p => p.id === alvoRaw) : null
          if (participante?.phoneNumber) {
            alvo = participante.phoneNumber
            if (!global.lidParaNumero) global.lidParaNumero = {}
            global.lidParaNumero[alvoRaw] = alvo
          } else {
            try {
              const pn = await arlequina.signalRepository?.lidMapping?.getPNForLID(alvoRaw)
              if (pn) {
                alvo = pn.includes('@') ? pn : `${pn}@s.whatsapp.net`
                if (!global.lidParaNumero) global.lidParaNumero = {}
                global.lidParaNumero[alvoRaw] = alvo
              }
            } catch (eLid) {
              console.log('Erro ao resolver LID do marcado (monitor):', eLid?.message)
            }
          }
        }
      }

      const usuarios = fs.existsSync(dbPath) ? JSON.parse(fs.readFileSync(dbPath)) : {}
      if (!usuarios[alvo]) usuarios[alvo] = {}
      const era = !!usuarios[alvo].monitor
      usuarios[alvo].monitor = !era
      fs.writeFileSync(dbPath, JSON.stringify(usuarios, null, 2))

      await reagir('🛡️')
      const frasesOn = [
        '🛡️ Agora tem poder de admin no grupo!',
        '💜 Bem-vindo(a) à equipe de moderação!',
        '🃏 Monitor da Arlequina em ação!',
        '⚔️ Novo braço direito da Arlequina!',
        '😈 Cuidado, agora ele(a) manda também!',
        '👁️ Olho vigiando 24h em todos os grupos!',
        '🔨 O martelo da justiça mudou de mãos!'
      ]
      const frasesOff = [
        '👋 Cargo de monitor encerrado.',
        '📤 Removido(a) da equipe de moderação.',
        '🔻 De volta pra vida de membro comum.',
        '🃏 A Arlequina reassume o controle sozinha.'
      ]
      const texto = !era
        ? `╭─━━─🃏💜「 🛡️💜 *MONITOR* 💜🛡️ 」💜🃏─━━─╮\n┃ ✅ @${alvo.split('@')[0]} agora é\n┃ Monitor!\n┃ Pode usar os comandos de ADM\n┃ em qualquer grupo.\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${frasesOn[Math.floor(Math.random() * frasesOn.length)]}_`
        : `╭─━━─🃏💜「 🛡️💜 *MONITOR* 💜🛡️ 」💜🃏─━━─╮\n┃ ❌ @${alvo.split('@')[0]} não é mais\n┃ Monitor.\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${frasesOff[Math.floor(Math.random() * frasesOff.length)]}_`
      await arlequina.sendMessage(from, {
        text: texto,
        mentions: [alvo]
      }, { quoted: info })
    } catch(e) {
      console.error('ERRO monitor:', e?.message)
      await reply('❌ Erro ao executar.')
    }
  }
}
