/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: backup
*/
const donoState = require('../../arquivos/js/donoState.js')
const adminState = require('../../arquivos/js/adminState.js')
const fs = require('fs')
const { dbPath } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'backup',
description: "Gera um backup do banco de dados",
category: 'dono',
aliases: ['bkp'],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  try {
  
  if (!fs.existsSync(dbPath))
  return reply(caixaArlequina("backup", `❌ Banco de dados não encontrado.`))
  
  await enviar({
  document: fs.readFileSync(dbPath),
  mimetype: 'application/json',
  fileName: `usuarios_${Date.now()}.json`
  }, { quoted: msg })
  
  } catch (e) {
  console.log(e)
  await reply('❌ Erro ao gerar backup.')
  }
} catch (e) {
console.log('❌ ERRO DONO (backup):', e?.message)
await reply('❌ Não consegui executar esse comando.')
}

}
}
