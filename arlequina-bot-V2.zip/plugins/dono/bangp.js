/*
 !bangp / !unbangp (só dono)
 Bane ou desbane o GRUPO inteiro de usar os comandos do bot.
*/
const donoState = require('../../arquivos/js/donoState.js')

module.exports = {
  name: 'bangp',
  description: 'Bane/desbane o grupo de usar os comandos do bot (só dono)',
  category: 'dono',
  aliases: ['unbangp', 'bangr', 'unbangr'],

  async execute({ reply, reagir, prefix, isGroup, isDono, from, command }) {
    try {
      if (!isGroup) return reply('❌ Use esse comando dentro de um grupo.')
      if (!isDono()) return reply('❌ Apenas o dono pode usar esse comando!')

      if (!donoState.botStatus.gruposBanidos)
        donoState.botStatus.gruposBanidos = {}

      const estaBanido = !!donoState.botStatus.gruposBanidos[from]

      const comandoUsado = (command || '').toLowerCase()
      const querBanir = !comandoUsado.includes('un')

      if (querBanir) {
        if (estaBanido)
          return reply('🔒 O grupo já está banido, senhor(a)!')

        donoState.botStatus.gruposBanidos[from] = true
        donoState.salvar()

        await reagir('🔒')

        return reply(`╔════════════════════╗
      🔒 GRUPO BANIDO 🔒
╚════════════════════╝

🃏 Eu sou a *Arlequina*.

Este grupo foi colocado na minha lista negra pelo meu dono.

💀 Não responderei comandos.
🚫 Não obedecerei ninguém.
👑 Minha única autoridade aqui é o meu dono.

❌ Todos os comandos enviados neste grupo serão ignorados.
⚠️ Insistir não vai mudar absolutamente nada.

🔓 Para remover este bloqueio:
➜ *${prefix}unbangp*

💜 Até lá... permaneçam em silêncio.`)

      } else {
        if (!estaBanido)
          return reply('🔓 Este grupo já está desbanido, senhor(a)!')

        delete donoState.botStatus.gruposBanidos[from]
        donoState.salvar()

        await reagir('🔓')

        return reply(`╔════════════════════╗
      🟢 GRUPO LIBERADO 🟢
╚════════════════════╝

🃏 A *Arlequina* recebeu uma ordem do meu dono.

✅ O banimento deste grupo foi removido.
💜 Todos os membros já podem utilizar meus comandos novamente.

👑 Aproveitem e divirtam-se!

🎭 Obrigada, meu dono.

🔓 Sistema de bloqueio desativado com sucesso.`)
      }

    } catch (e) {
      console.log('❌ ERRO DONO (bangp):', e?.message)
      await reply('❌ Não consegui executar esse comando agora.')
    }
  }
}
