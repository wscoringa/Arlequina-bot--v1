/*
 Comando: addaluguel
 Ativa o aluguel da Arlequina no grupo atual por um número de dias.
 Uso: !addaluguel <dias>   (ex: !addaluguel 30)
 Apenas o dono do bot pode usar.
*/
const donoState = require('../../arquivos/js/donoState.js')
const { caixaArlequina, caixaElegante, enviarComBanner } = require('../../arquivos/js/estiloArlequina')

const FRASES_ARLEQUINA = [
'🃏 Mais um grupinho fazendo parte do meu reininho de loucura, hihi~ 💜',
'🃏 Bem-vindos à diversão sem limites, a Arlequina chegou pra ficar! 💜',
'🃏 Agora sim, a festa pode começar de verdade nesse grupo! 💜',
'🃏 Coringa autorizou, e eu aprovei: aluguel liberado! 💜',
'🃏 Esse grupo agora é meu também, cuidado com a bagunça! 💜'
]

function formatarData(timestamp) {
const d = new Date(timestamp)
return d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })
}

module.exports = {
name: 'addaluguel',
description: "Ativa o aluguel da Arlequina no grupo por X dias",
category: 'dono',
aliases: ['addalugar', 'ativaraluguel'],
async execute({ arlequina, from, info, args, reply, reagir, prefix, isGroup, isDono, groupName }) {

try {
  if (!isDono()) return reply('❌ Apenas o dono pode usar este comando!')
  if (!isGroup) return reply('❌ Use esse comando dentro do grupo que vai ser alugado.')

  const dias = Number(args[0])
  if (!args[0] || isNaN(dias) || dias <= 0) {
    return reply(`${caixaArlequina("addaluguel", `❌ Digite quantos dias de aluguel.\n\nEx: ${prefix}addaluguel 30 (ou ${prefix}addaluguel 30 150 pra registrar o valor pago)`)}`)
  }

  const valorInformado = Number(args[1])
  const temValor = args[1] !== undefined && !isNaN(valorInformado) && valorInformado >= 0

  if (!donoState.aluguel.grupos[from]) {
    donoState.aluguel.grupos[from] = { ativo: false, valor: 0, inicio: null, fim: null, interval: null, pago: 0 }
  }

  const data = donoState.aluguel.grupos[from]
  const agora = Date.now()
  const fim = agora + dias * 24 * 60 * 60 * 1000

  data.ativo = true
  data.inicio = agora
  data.fim = fim
  data.dias = dias
  if (temValor) data.valor = valorInformado
  donoState.salvar()

  await reagir('🏠')

  const frase = FRASES_ARLEQUINA[Math.floor(Math.random() * FRASES_ARLEQUINA.length)]

  const linhas = [
    `📦 *Plano:* ${dias} DIAS`,
    `⏰ *Duração:* ${dias} dias`,
    `📅 *Expira em:* ${formatarData(fim)}`,
    `👤 *Grupo:* ${groupName || 'Este grupo'}`,
  ]
  if (data.valor) linhas.push(`💰 *Valor:* R$ ${Number(data.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`)
  linhas.push(`🃏 ✨ ${frase}`)

  return enviarComBanner(arlequina, from, info, caixaElegante('𝐀𝐋𝐔𝐆𝐔𝐄𝐋 𝐀𝐓𝐈𝐕𝐀𝐃𝐎', '✅', linhas))
} catch (e) {
console.log('❌ ERRO (addaluguel):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
}

}
}
