const fs = require('fs')
const donoState = require('../../arquivos/js/donoState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Persiste estado em arquivo
const BN_PATH = './database/modobn.json'

function carregarBN() {
  try {
    if (!fs.existsSync(BN_PATH)) fs.writeFileSync(BN_PATH, JSON.stringify({}))
    return JSON.parse(fs.readFileSync(BN_PATH))
  } catch { return {} }
}
function salvarBN(d) {
  try { fs.writeFileSync(BN_PATH, JSON.stringify(d, null, 2)) } catch {}
}

module.exports = {
  name: 'modobn',
  description: '🎭 Liga/desliga brincadeiras do grupo',
  category: 'dono',
  aliases: ['brincadeirasmode', 'setbn'],
  async execute({ arlequina, from, info, args, reply, reagir, isDono, isAdm, isGroup, groupName }) {
    if (!isDono() && !isAdm) return reply(caixaArlequina("modobn", `❌ Apenas o dono ou ADM podem usar este comando.`))
    if (!isGroup) return reply('❌ Use em grupos!')

    const modo = args[0]
    if (!['0','1'].includes(modo)) return reply(
      `╭━━━━━━━━━━━━━━━━━━━━━━━⬣\n┃ 🎭💜 *MODO BRINCADEIRAS* 💜🎭\n┣━━━━━━━━━━━━━━━━━━━━━━━⬣\n┃ *#modobn 1* — Ativar\n┃ *#modobn 0* — Desativar\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯`
    )

    const dados = carregarBN()
    const ativo = modo === '1'
    dados[from] = ativo
    salvarBN(dados)
    await reagir(ativo ? '🎭' : '❌')

    if (ativo) {
      await arlequina.sendMessage(from, {
        text: `╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n┃ 🎭💜 *BRINCADEIRAS ATIVADAS!* 💜🎭\n┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n┃ ✅ Grupo: *${groupName || 'Grupo'}*\n┃ 🎮 Todos os comandos de brincadeira\n┃ estão liberados neste grupo!\n┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n┃ 🃏 _Arlequina Bot_ 💜😈\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯`
      }, { quoted: info })
    } else {
      await arlequina.sendMessage(from, {
        text: `╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n┃ ❌💜 *BRINCADEIRAS DESATIVADAS!* 💜❌\n┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n┃ 🚫 Grupo: *${groupName || 'Grupo'}*\n┃ 🎭 Comandos de brincadeira bloqueados.\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯`
      }, { quoted: info })
    }
  }
}
