/*
 Comando: addprm (aliases: addprem, addpremiumdias)
 Dá premium pra alguém, com dias opcionais.

 Uso:
 #addprm @pessoa 20      -> premium por 20 dias
 #addprm @pessoa          -> premium permanente (sem data pra acabar)
 (responder/marcar a pessoa em ambos os casos)
*/
const { existsLidData, userLid } = require('../../arquivos/js/userManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'addprm',
  description: '💎 Dá premium pra alguém (com dias opcionais)',
  category: 'dono',
  aliases: ['addprem', 'addpremiumdias'],
  async execute({ from, info, args, reply, reagir, isDono, commandManager, prefix, groupMembers, isGroup }) {
    // BUGFIX SEGURANÇA: isDono chega como FUNÇÃO, tem que chamar isDono().
    if (!isDono()) {
      await reagir('❌')
      return reply('❌ Apenas o dono pode usar este comando!')
    }

    const quoted = info.message?.extendedTextMessage?.contextInfo
    const target = quoted?.participant || quoted?.mentionedJid?.[0]

    if (!target) {
      return reply(caixaArlequina('addprm', `💎 Como usar:\n${prefix}addprm @pessoa <dias opcional>\n\nEx:\n${prefix}addprm @pessoa 20 (20 dias)\n${prefix}addprm @pessoa (permanente)`))
    }

    const diasArg = args.find(a => /^\d+$/.test(a))
    const dias = diasArg ? parseInt(diasArg) : null

    const pegarPhoneNumberReal = (input) => {
      if (!input) return null
      if (input.match(/^\d+$/) && !input.includes('@')) return `${input}@s.whatsapp.net`
      if (input.includes('@s.whatsapp.net') && input.match(/^\d{10,15}@/)) return input

      const lidLimpo = input.replace('@lid', '').split(':')[0]
      if (isGroup && groupMembers?.length) {
        const membro = groupMembers.find(m => m.id === input || m.id === lidLimpo + '@lid' || m.id === lidLimpo)
        if (membro?.phoneNumber) return membro.phoneNumber
      }
      const lidCompleto = lidLimpo + '@lid'
      if (existsLidData(lidCompleto)) {
        const dados = userLid(lidCompleto)
        if (dados?.jid?.match(/^\d{10,15}@s\.whatsapp\.net$/)) return dados.jid
      }
      return null
    }

    const phoneReal = pegarPhoneNumberReal(target)
    if (!phoneReal) {
      await reagir('❌')
      return reply('❌ Não consegui identificar o número dessa pessoa. Marque alguém que esteja no grupo.')
    }

    await reagir('⏳')
    const success = commandManager.addPremium(phoneReal, dias)

    if (success) {
      const numero = phoneReal.split('@')[0]
      const validade = dias ? `⏳ Válido por *${dias} dia(s)*` : '♾️ Premium *permanente*'
      await reagir('✅')
      await reply(caixaArlequina('addprm', `✅ Premium ativado!\n\n📌 Número: ${numero}\n${validade}`))
    } else {
      await reagir('❌')
      await reply('❌ Não consegui ativar o premium pra essa pessoa.')
    }
  }
}
