/*
 !removedono <1-5>
 Limpa um slot de dono extra. Só o dono principal pode usar.
*/
const donoState = require('../../arquivos/js/donoState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'removedono',
  description: '👑 Remove um dono extra de um slot (1 a 5) — só o dono principal',
  category: 'dono',
  aliases: ['removeowner', 'deldono', 'unsetdono'],

  async execute({ isDono, reply, reagir, args, sender, config }) {
  if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')

    try {
      const numeroDonoPrincipal = String(config.NumeroDoDono || '').replace(/[^0-9]/g, '')
      const senderPuro = String(sender || '').split('@')[0].replace(/[^0-9]/g, '')

      if (senderPuro !== numeroDonoPrincipal) {
        return reply('❌ Só o dono principal do bot pode gerenciar os donos extras.')
      }

      const slot = parseInt(args[0])
      if (!slot || slot < 1 || slot > 5) {
        return reply('❌ Informa o slot (1 a 5). Ex: *!removedono 1*')
      }

      if (!donoState.donosExtras[String(slot)]) {
        return reply(`⚠️ O slot ${slot} já está vazio.`)
      }

      const numeroRemovido = donoState.donosExtras[String(slot)]
      donoState.donosExtras[String(slot)] = null
      donoState.salvar()

      await reagir('🔓')
      return reply(caixaArlequina("removedono", `✅🔓 *DONO EXTRA REMOVIDO* 🔓✅\n\n📌 Slot: *${slot}*\n📱 Número removido: *+${numeroRemovido}*`))

    } catch (e) {
      console.log('❌ ERRO DONO (removedono):', e?.message)
      await reply('❌ Não consegui executar esse comando agora.')
    }
  }
}
