/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: bcall
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'bcall',
description: "Envia um broadcast pra todos os contatos",
category: 'dono',
aliases: ['bca'],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const textoAviso = args.join(' ')
  if (!textoAviso) return reply('❌ Digite uma mensagem.\n\nEx: !bcall Bot vai reiniciar')
  
  const grupos = await sock.groupFetchAllParticipating()
  const idsGrupos = Object.keys(grupos)
  const idsUsuarios = Object.keys(usuarios).map(n => `${n}@s.whatsapp.net`)
  
  const todosIds = [...idsGrupos, ...idsUsuarios]
  
  reply(`${caixaArlequina("bcall", `📢 Enviando para ${idsGrupos.length} grupos e ${idsUsuarios.length} usuários...`)}`)
  
  let enviados = 0
  
  for (const id of todosIds) {
  
  try {
  
  await sock.sendMessage(id, {
  text: `
  ╭─━━─🃏💜「 📢 AVISO GERAL 」💜🃏─━━─╮
  
  ${textoAviso}
  
  ━━━━━━━━━━━━━━━
  
  🤡 Bot: 愛ＡＲＬＥＱＵＩＮＡ
  👑 Dono: ${config.nomeDono}
  
  ╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
  `
  })
  
  enviados++
  
  } catch (e) {
  console.log(`Falha ao enviar para ${id}:`, e?.message)
  }
  
  await new Promise(r => setTimeout(r, 1500))
  }
  
  reply(`✅ Aviso enviado para ${enviados}/${todosIds.length} destinos.`)
} catch (e) {
console.log('❌ ERRO (bcall):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
