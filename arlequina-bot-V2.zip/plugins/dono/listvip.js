const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const { listarVips, formatarValidade } = require('../../arquivos/js/vipHelper.js')

module.exports = {
  name: 'listvip',
  description: 'Lista os usuários VIP e validade',
  category: 'dono',
  aliases: ['listavip', 'vips'],

  async execute({ reply, reagir, isDono }) {
    if (!isDono()) {
      return reply(caixaArlequina('LISTVIP', '❌ Só o *dono* pode ver a lista VIP.'))
    }

    const lista = listarVips()
    if (!lista.length) {
      return reply(caixaArlequina('LISTVIP', '📋 Nenhum VIP cadastrado no momento.'))
    }

    await reagir('👑')
    const linhas = lista.map((v, i) =>
      `${i + 1}. ${v.numero}\n   ${formatarValidade(v)}`
    ).join('\n\n')

    return reply(caixaArlequina('LISTVIP', `👑 *VIPs do bot* (${lista.length})\n\n${linhas}`))
  }
}
