/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: manutencao
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'manutencao',
description: "Ativa/desativa o modo manutenção",
category: 'dono',
aliases: ['mnt'],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const modo = args[0]?.toLowerCase()
  
  if (modo === 'on' || modo === '1' || modo === 'ativar') {
  donoState.botStatus.manutencao = true
  return reply('🛠️ Modo manutenção ATIVADO.\n\nApenas o dono pode usar comandos agora.')
  }
  
  if (modo === 'off' || modo === '0' || modo === 'desativar') {
  donoState.botStatus.manutencao = false
  return reply('✅ Modo manutenção DESATIVADO.\n\nO bot está disponível pra todos novamente.')
  }
  
  return reply(`${caixaArlequina("manutencao", `🛠️ Modo manutenção está: ${donoState.botStatus.manutencao ? 'ATIVADO' : 'DESATIVADO'}\n\nUse:\n!manutencao on\n!manutencao off`)}`)
} catch (e) {
console.log('❌ ERRO (manutencao):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
