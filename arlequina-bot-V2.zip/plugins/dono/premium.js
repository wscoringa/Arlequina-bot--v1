const { existsLidData, userLid, saveUserID } = require('../../arquivos/js/userManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'premium',
description: 'Gerencia usuarios premium',
category: 'dono',
aliases: ['addpremium', 'removepremium'],
async execute({ columbina, from, info, args, q, reply, reagir, isDono, commandManager, prefix, sender, groupMembers, isGroup }) {

// BUGFIX SEGURANÇA: "isDono" chega aqui como uma FUNÇÃO (() => isDono(sender)), não como true/false. "if (!isDono)" checava se a FUNÇÃO existia (sempre existe = nunca bloqueava ninguém!) em vez de checar o RESULTADO dela. Isso deixava esse comando de dono liberado pra qualquer pessoa usar. Corrigido chamando isDono().
if (!isDono()) {
await reagir('❌')
return reply('❌ Apenas o dono pode usar este comando!')
}

const quoted = info.message?.extendedTextMessage?.contextInfo
let target = quoted?.participant || quoted?.mentionedJid?.[0]

const subCommand = (args[0] || '').toLowerCase()

const pegarPhoneNumberReal = (input) => {
if (!input) return null

if (input.match(/^\d+$/) && !input.includes('@')) {
return `${input}@s.whatsapp.net`
}

if (input.includes('@s.whatsapp.net') && input.match(/^\d{10,15}@/)) {
return input
}

const lidLimpo = input.replace('@lid', '').split(':')[0]

if (isGroup && groupMembers && groupMembers.length > 0) {
const membro = groupMembers.find(m => 
m.id === input || 
m.id === lidLimpo + '@lid' ||
m.id === lidLimpo
)
if (membro && membro.phoneNumber) {
console.log(`✅ PhoneNumber encontrado no groupMembers: ${membro.phoneNumber}`)
return membro.phoneNumber
}
}

const lidCompleto = lidLimpo + '@lid'
if (existsLidData(lidCompleto)) {
const dados = userLid(lidCompleto)
if (dados && dados.jid && dados.jid.match(/^\d{10,15}@s\.whatsapp\.net$/)) {
console.log(`✅ PhoneNumber encontrado nos dados: ${dados.jid}`)
return dados.jid
}
}

if (isGroup && groupMembers && groupMembers.length > 0) {
for (const membro of groupMembers) {
if (membro.id === input || membro.id === lidLimpo + '@lid') {
if (membro.phoneNumber) {
return membro.phoneNumber
}
}
}
}

return null
}

if (subCommand === 'add') {
if (!target) {
return reply(`${caixaArlequina("premium", `❌ Marque o usuario!\n\nExemplo: ${prefix}premium add @usuario <dias opcional>`)}`)
}

await reagir('⏳')

const phoneReal = pegarPhoneNumberReal(target)

if (!phoneReal) {
await reagir('❌')
return reply(`❌ Não foi possível identificar o número do usuário!\n\nCertifique-se que ele está no grupo.`)
}

const diasArg = args.slice(1).find(a => /^\d+$/.test(a))
const dias = diasArg ? parseInt(diasArg) : null

const success = commandManager.addPremium(phoneReal, dias)
if (success) {
const numeroMostrar = phoneReal.split('@')[0]
const validade = dias ? `⏳ Válido por ${dias} dia(s)` : '♾️ Permanente'
await reagir('✅')
await reply(`✅ Usuario adicionado ao premium!\n\n📌 Número: ${numeroMostrar}\n${validade}`, from, info)
} else {
await reply(`❌ Falha ao adicionar!`, from, info)
}

} else if (subCommand === 'remove') {
if (!target) {
return reply(`❌ Marque o usuario!\n\nExemplo: ${prefix}premium remove @usuario`)
}

const phoneReal = pegarPhoneNumberReal(target)

if (!phoneReal) {
await reagir('❌')
return reply(`❌ Erro ao identificar o usuario!`)
}

const success = commandManager.removePremium(phoneReal)
if (success) {
await reagir('✅')
await reply(`✅ Usuario removido do premium!`, from, info)
} else {
await reply(`❌ Usuario nao estava na lista premium!`, from, info)
}

} else if (subCommand === 'list') {
const users = commandManager.getPremiumUsers()
if (users.length === 0) {
await reply('📊 Nenhum usuario premium cadastrado!')
} else {
let text = '📊 *LISTA DE USUARIOS PREMIUM*\n\n'
text += `Total: ${users.length}\n\n`
const mentions = []
users.forEach((u, i) => {
const numero = u.jid.split('@')[0]
const validade = u.expiraEm
? `⏳ expira em ${new Date(u.expiraEm).toLocaleDateString('pt-BR')}`
: '♾️ permanente'
text += `${i+1}°. @${numero} — ${validade}\n`
mentions.push(u.jid)
})
await columbina.sendMessage(from, { text, mentions }, { quoted: info })
}
await reagir('📋')

} else {
await reply(`❌ COMANDOS PREMIUM:
▸ ${prefix}premium add @usuario <dias opcional>
▸ ${prefix}premium remove @usuario
▸ ${prefix}premium list

Exemplo: ${prefix}premium add @usuario 20 (ou sem dias = permanente)

💡 Também dá pra usar ${prefix}addprm e ${prefix}rmprm direto.`)
}
}
}