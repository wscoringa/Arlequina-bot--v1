/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: modogrupo
*/
const donoState = require('../../arquivos/js/donoState.js')
const adminState = require('../../arquivos/js/adminState.js')
const fs = require('fs')
const { dbPath } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'modogrupo',
description: "Ativa/desativa o modo whitelist de grupos",
category: 'dono',
aliases: [],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  if (!donoState.botStatus) donoState.botStatus = {}
  donoState.botStatus.modoWhitelist = !donoState.botStatus.modoWhitelist
  
  if (donoState.botStatus.modoWhitelist) {
  await reply(caixaArlequina("modogrupo", `🔒 Modo "grupos permitidos" ativado. O bot só vai responder nos grupos da whitelist.\n\nUse ${prefix}addgrupopermitido em cada grupo liberado.`))
  } else {
  await reply('🔓 Modo "grupos permitidos" desativado. O bot responde em qualquer grupo de novo.')
  }
} catch (e) {
console.log('❌ ERRO DONO (modogrupo):', e?.message)
await reply('❌ Não consegui executar esse comando.')
}

}
}
