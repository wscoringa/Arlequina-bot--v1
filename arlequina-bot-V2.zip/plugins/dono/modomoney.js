const donoState = require('../../arquivos/js/donoState.js')

module.exports = {
  name: 'modomoney',
  description: '(Admin/Dono) Liga/desliga o bônus de R$ 500 pra primeira mensagem do dia de cada pessoa NESSE grupo',
  category: 'dono',
  aliases: ['togglemoney', 'moneyday'],
  async execute({ isDono, arlequina, from, info, args, reply, reagir, isGroup }) {
  if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')

    if (!isGroup) return reply('❌ Use esse comando dentro de um grupo — ele liga/desliga só pro grupo atual.')

    if (!donoState.botStatus.modomoney || typeof donoState.botStatus.modomoney !== 'object') {
      donoState.botStatus.modomoney = {}
    }

    const atual = donoState.botStatus.modomoney[from] !== false
    const novo = !atual
    donoState.botStatus.modomoney[from] = novo
    donoState.salvar()
    await reagir(novo ? '💰' : '🔕')
    await arlequina.sendMessage(from, {
      text: `╭─━━─🃏💜「 MODO MONEY 」💜🃏─━━─╮\n\n💰 Bônus diário NESSE GRUPO:\n\n${novo ? '✅ *ATIVADO*' : '❌ *DESATIVADO*'}\n\n${novo ? '💬 Quem mandar a primeira mensagem do dia (qualquer mensagem) ganha *R$ 500!*' : '🔕 Ninguém ganhará bônus por mensagem nesse grupo até ser reativado.'}\n\n╰─━━━━━━━━━━━━━━━━━━━━━━━━─╯`
    }, { quoted: info })
  }
}
