const fs = require('fs')
const path = require('path')
const { exec } = require('child_process')
const { promisify } = require('util')
const execAsync = promisify(exec)
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const REPO = 'https://github.com/wscoringa/Arlequina-bot--v1'
const RAW_PACKAGE = 'https://raw.githubusercontent.com/wscoringa/Arlequina-bot--v1/main/package.json'

function versaoLocal() {
  try {
    return require('../../package.json').version || '2.0.0'
  } catch {
    return '2.0.0'
  }
}

function parseVer(v) {
  return String(v || '0').replace(/^v/i, '').split('.').map(n => parseInt(n, 10) || 0)
}

function comparar(a, b) {
  const A = parseVer(a)
  const B = parseVer(b)
  for (let i = 0; i < Math.max(A.length, B.length); i++) {
    const x = A[i] || 0
    const y = B[i] || 0
    if (x < y) return -1
    if (x > y) return 1
  }
  return 0
}

async function versaoRemota() {
  try {
    const r = await axios.get(RAW_PACKAGE, {
      timeout: 12000,
      headers: { 'User-Agent': 'ArlequinaBot/1.5', Accept: 'application/json' }
    })
    return r.data?.version || null
  } catch {
    return null
  }
}

module.exports = {
  name: 'atualizar',
  description: 'Dono: verifica/atualiza o bot pelo GitHub',
  category: 'dono',
  aliases: ['update', 'updatebot'],

  async execute({ reply, reagir, args, prefix, isDono }) {
    if (!isDono()) {
      return reply(caixaArlequina('ATUALIZAR', '❌ Só o *dono* pode usar.'))
    }

    const local = versaoLocal()
    const confirma = ['sim', 's', 'yes', 'y', '1', 'confirma'].includes(String(args[0] || '').toLowerCase())

    await reagir('🔍')
    const remota = await versaoRemota()

    if (!remota) {
      return reply(caixaArlequina('ATUALIZAR', `📦 Versão atual: *v${local}*

⚠️ Não consegui checar o GitHub agora.

Repo: ${REPO}

Se o bot foi clonado com git:
*${prefix}atualizar sim*
ou *${prefix}gitpull*`))
    }

    const cmp = comparar(local, remota)

    if (!confirma) {
      if (cmp < 0) {
        return reply(caixaArlequina('ATUALIZAR', `📦 *Atualização disponível!*

📍 Sua versão: *v${local}*
🆕 Nova versão: *v${remota}*

Quer atualizar?
Digite: *${prefix}atualizar sim*

Isso roda *git pull* e tenta alinhar os arquivos com o GitHub.`))
      }
      if (cmp === 0) {
        return reply(caixaArlequina('ATUALIZAR', `✅ Você já está na versão mais recente.

📦 Versão atual: *v${local}*

Mesmo assim pode forçar:
*${prefix}atualizar sim*

Repo: ${REPO}`))
      }
      return reply(caixaArlequina('ATUALIZAR', `📦 Sua versão: *v${local}*
🌐 No GitHub: *v${remota}*

Sua pasta parece *mais nova* que o repo (ou o GitHub ainda não foi atualizado).

Forçar pull: *${prefix}atualizar sim*`))
    }

    // confirmação: tenta git pull
    const root = path.join(__dirname, '../..')
    if (!fs.existsSync(path.join(root, '.git'))) {
      return reply(caixaArlequina('ATUALIZAR', `ℹ️ Esta pasta *não é clone git*.

Pra atualizar automático:
1. Suba o código no GitHub
2. Use o bot a partir de:
\`git clone ${REPO}.git\`

Enquanto isso baixe o ZIP:
${REPO}

Versão local: *v${local}*`))
    }

    await reagir('🔄')
    await reply(caixaArlequina('ATUALIZAR', `🔄 Atualizando *v${local}* → *v${remota || '?'}*…`))

    try {
      const { stdout, stderr } = await execAsync('git pull --ff-only', {
        cwd: root,
        timeout: 120000,
        maxBuffer: 8 * 1024 * 1024
      })
      const out = ((stdout || '') + '\n' + (stderr || '')).trim().slice(0, 1200)
      const nova = versaoLocal()
      await reagir('✅')
      return reply(caixaArlequina('ATUALIZAR', `✅ *Atualização concluída*

📦 Versão agora: *v${nova}*

\`\`\`
${out || 'ok'}
\`\`\`

Reinicie o bot pra carregar tudo.`))
    } catch (e) {
      await reagir('❌')
      return reply(caixaArlequina('ATUALIZAR', `❌ Falha no *git pull*.

_${e?.message || 'erro'}_

Tente no terminal:
\`cd pasta-do-bot && git pull\`

Repo: ${REPO}`))
    }
  }
}
