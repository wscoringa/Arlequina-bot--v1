/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: admcmd
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'admcmd',
description: "Restringe um comando só pra admins",
category: 'dono',
aliases: ['admc'],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const groupMetadata = await sock.groupMetadata(from)
  
  const alvoComando = texto?.split(' ')[1]?.toLowerCase()
  
  if (!alvoComando) {
  await reply(`${caixaArlequina("admcmd", `Informe o comando que deseja restringir a admins.\nEx: ${prefix}admcmd figurinha`)}`)
  return
  }
  
  if (!donoState.comandosRestritos) donoState.comandosRestritos = {}
  if (!donoState.comandosRestritos[from]) donoState.comandosRestritos[from] = []
  
  if (donoState.comandosRestritos[from].includes(alvoComando)) {
  await reply(`O comando *${alvoComando}* já está restrito a admins.`)
  return
  }
  
  donoState.comandosRestritos[from].push(alvoComando)
  await reply(`🔒 O comando *${alvoComando}* agora só pode ser usado por admins neste grupo.`)
} catch (e) {
console.log('❌ ERRO (admcmd):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
