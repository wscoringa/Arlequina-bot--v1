/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: leavegrupo, saidogrupo
*/
const donoState = require('../../arquivos/js/donoState.js')
const adminState = require('../../arquivos/js/adminState.js')
const fs = require('fs')
const { dbPath } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'leavegrupo',
description: "Faz o bot sair do grupo atual",
category: 'dono',
aliases: ["saidogrupo"],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  if (!isGrupo)
  return reply(caixaArlequina("leavegrupo", `❌ Use esse comando dentro do grupo.`))
  
  await reply(caixaArlequina('leavegrupo', `👋💜 *ATÉ MAIS!* 💜👋\n\nMe despeço desse grupo por aqui...\nFoi bom enquanto durou! 🃏\n\n_Saindo agora..._`))

  await sock.groupLeave(from)
} catch (e) {
console.log('❌ ERRO DONO (leavegrupo):', e?.message)
await reply('❌ Não consegui executar esse comando.')
}

}
}
