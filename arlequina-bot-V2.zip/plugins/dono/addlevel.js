/*
 Comando: addlevel (dono)
 #addlevel               -> adiciona 1 nível pra você mesmo (dono)
 #addlevel <quantidade>            -> adiciona X níveis pra você mesmo (dono)
 #addlevel <quantidade> @usuario   -> adiciona X níveis pro usuário marcado
 (marcando/respondendo também funciona sem precisar digitar @)
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const { convertWhatsAppUser } = require('../../arquivos/js/userManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'addlevel',
description: 'Adiciona nível(is) a você (dono) ou a um usuário marcado',
category: 'dono',
aliases: ['addlvl', 'addnivel'],
async execute({ isDono, arlequina, columbina, from, info, args, reply, reagir, sender, prefix }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')

const sock = arlequina || columbina

const quoted = info.message?.extendedTextMessage?.contextInfo
const mencionado = quoted?.participant || quoted?.mentionedJid?.[0]
const alvo = mencionado ? convertWhatsAppUser(mencionado, 'jid') : sender

const numArg = args.find(a => /^\d+$/.test(a))
const quantidade = numArg ? parseInt(numArg) : 1

try {
  const usuarios = carregarUsuarios()
  const u = getUsuario(usuarios, alvo)

  for (let i = 0; i < quantidade; i++) {
    u.level++
    u.vidaMax += 20; u.vida = u.vidaMax
    u.manaMax += 10; u.mana = u.manaMax
    u.staminaMax += 10; u.stamina = u.staminaMax
    u.forca += 3; u.defesa += 2; u.agilidade += 2; u.sorte += 1
  }

  salvarUsuarios(usuarios)

  await reagir('🏅')

  const quemMsg = mencionado ? `@${alvo.split('@')[0]}` : 'você'
  const texto = `╭─━━─🃏💜「 🏅💜 *ADD LEVEL* 💜🏅 」💜🃏─━━─╮\n┃ +${quantidade} nível(is) para ${quemMsg}\n┃ 🏅 Level atual: ${u.level}\n┃ ❤️ Vida: ${u.vida}/${u.vidaMax} | 💧 Mana: ${u.mana}/${u.manaMax}\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _Subiu no mundo, literalmente... 😈_`

  await sock.sendMessage(from, { text: texto, mentions: mencionado ? [alvo] : [] }, { quoted: info })
} catch (e) {
  console.log('❌ ERRO addlevel:', e?.message)
  await reply(caixaArlequina("addlevel", `❌ Não consegui adicionar o nível agora.`))
}
}
}
