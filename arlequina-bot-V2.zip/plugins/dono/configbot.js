const fs = require('fs')
const path = require('path')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const CONFIG_PATH = path.resolve('./database/config.json')

function lerConfig() {
  return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'))
}

function salvarConfig(cfg) {
  // Mantém só os campos principais (limpos)
  const limpo = {
    NumeroDoDono: String(cfg.NumeroDoDono || cfg.numeroDono || '').replace(/\D/g, ''),
    NomeDoDono: cfg.NomeDoDono || cfg.nomeDono || '',
    NomeDoBot: cfg.NomeDoBot || cfg.nomeBot || 'Arlequina',
    prefix: cfg.prefix || cfg.prefixo || '!',
    canal: cfg.canal || cfg.linkcanal || ''
  }
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(limpo, null, 2), 'utf8')
  return limpo
}

module.exports = {
  name: 'configbot',
  description: 'Mostra ou altera nome, número do dono, bot e prefixo',
  category: 'dono',
  aliases: ['setconfig', 'cfgbot'],

  async execute({ reply, reagir, args, q, prefix, isDono, config }) {
    if (!isDono()) {
      return reply(caixaArlequina('CONFIG', '❌ Só o *dono* pode usar.'))
    }

    const sub = (args[0] || '').toLowerCase()
    const resto = args.slice(1).join(' ').trim()

    // Sem argumento: mostra
    if (!sub) {
      let cfg
      try { cfg = lerConfig() } catch { cfg = config || {} }
      await reagir('⚙️')
      return reply(caixaArlequina('CONFIG', `⚙️ *Config do bot*

👑 Dono: *${cfg.NomeDoDono || '—'}*
📱 Número: *${cfg.NumeroDoDono || '—'}*
🤖 Bot: *${cfg.NomeDoBot || '—'}*
⚡ Prefixo: *${cfg.prefix || '!'}*
📢 Canal: *${cfg.canal || '—'}*

*Alterar:*
${prefix}configbot dono <nome>
${prefix}configbot numero <55...>
${prefix}configbot bot <nome>
${prefix}configbot prefix <símbolo>
${prefix}configbot canal <link>`))
    }

    let cfg
    try { cfg = lerConfig() } catch (e) {
      return reply(caixaArlequina('CONFIG', '❌ Não li o config.json.'))
    }

    if (sub === 'dono' || sub === 'nomedono') {
      if (!resto) return reply(`Ex: *${prefix}configbot dono Coringa*`)
      cfg.NomeDoDono = resto
      salvarConfig(cfg)
      await reagir('✅')
      return reply(caixaArlequina('CONFIG', `✅ Nome do dono: *${resto}*\n\n_Reinicie o bot se não atualizar na hora._`))
    }

    if (sub === 'numero' || sub === 'numerodono' || sub === 'num') {
      const num = resto.replace(/\D/g, '')
      if (num.length < 10) return reply(`Ex: *${prefix}configbot numero 553193358417*`)
      cfg.NumeroDoDono = num
      salvarConfig(cfg)
      await reagir('✅')
      return reply(caixaArlequina('CONFIG', `✅ Número do dono: *${num}*\n\n_Reinicie o bot pra aplicar 100%._`))
    }

    if (sub === 'bot' || sub === 'nomebot') {
      if (!resto) return reply(`Ex: *${prefix}configbot bot Arlequina*`)
      cfg.NomeDoBot = resto
      salvarConfig(cfg)
      await reagir('✅')
      return reply(caixaArlequina('CONFIG', `✅ Nome do bot: *${resto}*`))
    }

    if (sub === 'prefix' || sub === 'prefixo') {
      const p = resto || args[1]
      if (!p) return reply(`Ex: *${prefix}configbot prefix !*`)
      cfg.prefix = p
      salvarConfig(cfg)
      await reagir('✅')
      return reply(caixaArlequina('CONFIG', `✅ Prefixo: *${p}*\n\n_Reinicie o bot pra aplicar em tudo._`))
    }

    if (sub === 'canal' || sub === 'channel') {
      if (!resto) return reply(`Ex: *${prefix}configbot canal https://whatsapp.com/channel/...*`)
      cfg.canal = resto
      salvarConfig(cfg)
      await reagir('✅')
      return reply(caixaArlequina('CONFIG', `✅ Canal atualizado.`))
    }

    return reply(caixaArlequina('CONFIG', `Opções:
*${prefix}configbot* — ver
*${prefix}configbot dono <nome>*
*${prefix}configbot numero <55...>*
*${prefix}configbot bot <nome>*
*${prefix}configbot prefix <!>*
*${prefix}configbot canal <link>*`))
  }
}
