const fs = require('fs')
const path = require('path')
const { exec } = require('child_process')
const { promisify } = require('util')
const execAsync = promisify(exec)
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const REPO = 'https://github.com/wscoringa/Arlequina-bot--v1'

module.exports = {
  name: 'gitpull',
  description: 'Dono: tenta atualizar o bot pelo GitHub (git pull)',
  category: 'dono',
  aliases: ['atualizar', 'updatebot', 'gitupdate'],

  async execute({ reply, reagir, isDono, prefix }) {
    if (!isDono()) {
      return reply(caixaArlequina('GIT', '❌ Só o *dono* pode atualizar o bot.'))
    }

    const root = path.join(__dirname, '../..')
    const gitDir = path.join(root, '.git')

    if (!fs.existsSync(gitDir)) {
      await reagir('🔗')
      return reply(caixaArlequina('GIT', `ℹ️ Esta pasta *não é um clone git*.

Pra poder usar *${prefix}gitpull*, instale assim:

\`\`\`
git clone ${REPO}.git
cd Arlequina-bot--v1
npm install
sh start.sh cod
\`\`\`

Ou baixe o ZIP no GitHub:
${REPO}`))
    }

    await reagir('🔄')
    await reply(caixaArlequina('GIT', '🔄 Puxando atualização do GitHub…'))

    try {
      const { stdout, stderr } = await execAsync('git pull', {
        cwd: root,
        timeout: 120000,
        maxBuffer: 5 * 1024 * 1024
      })
      const out = ((stdout || '') + '\n' + (stderr || '')).trim().slice(0, 1500)
      await reagir('✅')
      return reply(caixaArlequina('GIT', `✅ *git pull* finalizado

\`\`\`
${out || 'Sem saída'}
\`\`\`

Reinicie o bot se mudou código.`))
    } catch (e) {
      await reagir('❌')
      return reply(caixaArlequina('GIT', `❌ Não consegui atualizar.

_${e?.message || 'erro'}_

Repo: ${REPO}`))
    }
  }
}
