/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: relatoriomod
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'relatoriomod',
description: "Mostra um relatório de moderação",
category: 'dono',
aliases: [],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const groupMetadata = await sock.groupMetadata(from)
  
  const totalAvisos = Object.values(donoState.avisos[from] || {})
  .reduce((acc, v) => acc + v, 0)
  
  const totalMutadosFixo = Object.keys(adminState.mutados[from] || {}).length
  
  const totalMutadosTemp = Object.entries(adminState.muteTemporario[from] || {})
  .filter(([_, exp]) => Date.now() < exp).length
  
  const totalListaNegra = (adminState.listanegra[from] || []).length
  const totalPalavroes = (donoState.palavroesProibidos[from] || []).length
  const totalRegras = (adminState.regras[from] || []).length
  
  await reply(`
  ╭─━━─🃏💜「 🛡️ RELATÓRIO DE MODERAÇÃO 」💜🃏─━━─╮
  
  ⚠️ Total de avisos ativos: ${totalAvisos}
  🔇 Mutados permanentes: ${totalMutadosFixo}
  🔇 Mutados temporários: ${totalMutadosTemp}
  🚫 Na lista negra: ${totalListaNegra}
  🤬 Palavras proibidas: ${totalPalavroes}
  📋 Regras cadastradas: ${totalRegras}
  
  🔗 Antilink: ${adminState.antilink[from] ? 'Ativado' : 'Desativado'}
  🕵️ Antifake: ${adminState.antifake[from] ? 'Ativado' : 'Desativado'}
  🌊 Antiflood: ${adminState.antiflood[from] ? 'Ativado' : 'Desativado'}
  🤖 Antibot: ${adminState.antibot[from] ? 'Ativado' : 'Desativado'}
  👁️ Antiviewonce: ${adminState.antiviewonce[from] ? 'Ativado' : 'Desativado'}
  🗑️ Antidelete: ${adminState.antidelete[from] ? 'Ativado' : 'Desativado'}
  
  ╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
  `)
} catch (e) {
console.log('❌ ERRO (relatoriomod):', e?.message)
await reply(caixaArlequina("relatoriomod", `❌ Não consegui executar esse comando agora.`))
} finally {
salvarUsuarios(usuarios)
}

}
}
