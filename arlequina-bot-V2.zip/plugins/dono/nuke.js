const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
/*
 category: 'dono' -> o dispatcher do index.js já garante que só o
 dono pode usar esse comando. needBotAdmin garante que só roda se a
 Arlequina for admin do grupo (precisa disso pra remover gente).
*/
module.exports = {
name: 'nuke',
description: 'Remove todos os membros do grupo, menos os admins, o dono e a própria Arlequina',
category: 'dono',
aliases: [],
needBotAdmin: true,
async execute({ isDono, arlequina, from, info, args, reply, reagir, isGroup, donoJid, botNumber }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


if (!isGroup) return reply('❌ Use esse comando dentro do grupo.')

if (args[0] !== 'confirmar') {
  return reply(`${caixaArlequina("nuke", `⚠️ *ATENÇÃO!*\n\nIsso vai remover TODOS os membros do grupo, exceto os admins, o dono e eu (a Arlequina).\n\nEssa ação não pode ser desfeita.\n\nPra confirmar, use:\n!nuke confirmar`)}`)
}

try {
  const groupMetadata = await arlequina.groupMetadata(from)
  const botNumeroLimpo = String(botNumber || arlequina.user?.id || '').replace(/[^0-9]/g, '')
  const donoNumeroLimpo = String(donoJid || '').replace(/[^0-9]/g, '')

  const alvos = groupMetadata.participants
    .filter(p => {
      if (p.admin === 'admin' || p.admin === 'superadmin') return false
      const numeroP = String(p.id).split('@')[0]
      if (botNumeroLimpo && numeroP === botNumeroLimpo) return false
      if (donoNumeroLimpo && numeroP === donoNumeroLimpo) return false
      return true
    })
    .map(p => p.id)

  if (alvos.length === 0) {
    return reply('✅ Não sobrou ninguém pra remover — só tem admin, dono e eu no grupo.')
  }

  await reply(`☢️ Iniciando o NUKE... ${alvos.length} membro(s) serão removidos.`)

  let removidos = 0
  for (const alvo of alvos) {
    try {
      await arlequina.groupParticipantsUpdate(from, [alvo], 'remove')
      removidos++
      await new Promise(r => setTimeout(r, 1200))
    } catch (e) {
      console.error('ERRO NUKE em', alvo, e?.message)
    }
  }

  await reagir('☢️')
  await reply(`✅ NUKE concluído. ${removidos}/${alvos.length} membro(s) removido(s).`)
} catch (e) {
  console.log('❌ ERRO DONO (nuke):', e?.message)
  reply('❌ Não consegui executar esse comando.')
}

}
}
