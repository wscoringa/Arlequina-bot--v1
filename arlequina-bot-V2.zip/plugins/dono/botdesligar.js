const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const frasesOff = [
  'Vou tirar uma soneca, não me acordem sem motivo... 😴💜',
  'Modo silêncio ativado, o caos dá uma pausa. 🌑😈',
  'Fechando o picadeiro por hoje... 🃏🌑'
]

module.exports = {
name: 'botoff',
description: 'Desliga o bot (bloqueia comandos para todos exceto o dono)',
category: 'dono',
aliases: ['desligar', 'shutdown'],
async execute({ columbina, from, info, reply, isDono }) {
// BUGFIX SEGURANÇA: "isDono" chega aqui como uma FUNÇÃO (() => isDono(sender)), não como true/false. "if (!isDono)" checava se a FUNÇÃO existia (sempre existe = nunca bloqueava ninguém!) em vez de checar o RESULTADO dela. Isso deixava esse comando de dono liberado pra qualquer pessoa usar. Corrigido chamando isDono().
if (!isDono()) return reply('❌ Apenas o dono pode usar este comando!')
global.botLigado = false

const frase = frasesOff[Math.floor(Math.random() * frasesOff.length)]

await reply(`╭─━━─🃏💜「 🌑💜 *ARLEQUINA OFF* 💜🌑 」💜🃏─━━─╮
┃ ❌ Comandos bloqueados para todos.
┃ Só o dono pode usar agora.
┃ Use \`boton\` pra me reativar (se for vc o dono, né 😏).
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _${frase}_`)

try {
const donoId = columbina.user.id?.split(':')[0] + '@s.whatsapp.net'
await columbina.sendMessage(donoId, {text: `${caixaArlequina("botoff", `🌑💜 *ARLEQUINA HYPOSELENIA V2 OFF* 💜🌑\n\nComandos bloqueados para todos os usuários.\nApenas você pode usar comandos agora.\n\nUse *boton* para reativar.\n\n🃏 _${frase}_`)}`})
} catch(e) {}
}
}
