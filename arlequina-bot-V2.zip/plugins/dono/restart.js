/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: restart, reiniciar
*/
const donoState = require('../../arquivos/js/donoState.js')
const adminState = require('../../arquivos/js/adminState.js')
const fs = require('fs')
const { dbPath } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'restart',
description: "Reinicia o bot",
category: 'dono',
aliases: ["reiniciar"],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, isDono }) {

// BUGFIX: esse comando não checava se quem mandou era o dono — QUALQUER
// pessoa conseguia derrubar o bot com esse comando. Agora só o dono
// pode usar.
if (!isDono()) return reply('❌ Apenas o dono pode reiniciar o bot!')

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  await reagir('🔄')
  // BUGFIX: o reply() daqui não é async de verdade (não espera a
  // mensagem sair de fato), então o process.exit() logo em seguida
  // podia matar o processo ANTES da mensagem chegar no WhatsApp.
  // Agora manda direto pelo sock e espera terminar antes de reiniciar.
  await sock.sendMessage(from, { text: caixaArlequina("restart", `🔄 Reiniciando o bot...\n\n⏳ Volto em alguns segundos!`) }, { quoted: info })

  setTimeout(() => process.exit(0), 1200)
} catch (e) {
console.log('❌ ERRO DONO (restart):', e?.message)
await reply('❌ Não consegui executar esse comando.')
}

}
}
