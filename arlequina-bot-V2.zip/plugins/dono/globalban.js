/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: globalban
*/
const donoState = require('../../arquivos/js/donoState.js')
const adminState = require('../../arquivos/js/adminState.js')
const fs = require('fs')
const { dbPath } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'globalban',
description: "Bane um usuário globalmente (ele não consegue mais usar o bot)",
category: 'dono',
aliases: ['gb'],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const alvo =
  msg.message?.extendedTextMessage?.contextInfo?.participant ||
  msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
  
  if (!alvo)
  return reply('❌ Marque uma pessoa.\n\nEx: !globalban @membro')
  
  const numeroAlvo = alvo.split('@')[0]
  
  if (ehDono(alvo, numeroAlvo))
  return reply('👑 Você não pode banir o dono, seu arrombado!')
  
  donoState.banidosGlobal[numeroAlvo] = true
  
  await enviar({
  text: `${caixaArlequina("globalban", `🚫 @${numeroAlvo} foi banido de usar o bot em qualquer lugar.`)}`,
  mentions: [alvo]
  }, { quoted: msg })
} catch (e) {
console.log('❌ ERRO DONO (globalban):', e?.message)
await reply('❌ Não consegui executar esse comando.')
}

}
}
