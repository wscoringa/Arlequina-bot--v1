/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: banghost, banghosts
*/
const donoState = require('../../arquivos/js/donoState.js')
const adminState = require('../../arquivos/js/adminState.js')
const fs = require('fs')
const { dbPath } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'banghost',
description: "Remove membros inativos do grupo (abaixo de X mensagens)",
category: 'dono',
aliases: ["banghosts"],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  if (!isGrupo) {
  await reply('❌ Use esse comando dentro do grupo.')
  return
  }
  
  const minimo = parseInt(texto?.split(' ')[1])
  if (isNaN(minimo) || minimo < 0) {
  await reply(`${caixaArlequina("banghost", `Informe a quantidade mínima de mensagens.\nEx: ${prefix}banghost 5`)}`)
  return
  }
  
  const groupMetadata = await sock.groupMetadata(from)
  const admins = groupMetadata.participants.filter(p => p.admin).map(p => p.id)
  
  const alvos = groupMetadata.participants
  .filter(p => {
  if (admins.includes(p.id)) return false
  if (p.id === jidReal || p.id === numeroReal + '@s.whatsapp.net') return false
  const msgs = (donoState.ativos && donoState.ativos[p.id]?.mensagens) || 0
  return msgs < minimo
  })
  .map(p => p.id)
  
  if (alvos.length === 0) {
  await reply('Nenhum usuário abaixo da quantidade mínima de mensagens foi encontrado.')
  return
  }
  
  await reply(`🗑️ Iniciando limpeza... ${alvos.length} usuário(s) serão removidos.`)
  
  for (const alvo of alvos) {
  try {
  await sock.groupParticipantsUpdate(from, [alvo], 'remove')
  await new Promise(r => setTimeout(r, 1200))
  } catch (e) {
  console.error('ERRO BANGHOST em', alvo, e)
  }
  }
  
  await reply(`✅ Limpeza concluída. ${alvos.length} usuário(s) removido(s).`)
} catch (e) {
console.log('❌ ERRO DONO (banghost):', e?.message)
await reply('❌ Não consegui executar esse comando.')
}

}
}
