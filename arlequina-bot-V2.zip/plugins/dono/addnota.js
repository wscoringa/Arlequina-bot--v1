/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: addnota
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'addnota',
description: "Adiciona uma nota/anotação interna",
category: 'dono',
aliases: [],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const groupMetadata = await sock.groupMetadata(from)
  
  const alvo =
  msg.message?.extendedTextMessage?.contextInfo?.participant ||
  msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
  
  if (!alvo)
  return reply('❌ Marque uma pessoa.\n\nEx: !addnota @membro Já avisado sobre spam')
  
  const nota = args.slice(1).join(' ')
  
  if (!nota)
  return reply('❌ Digite a nota.\n\nEx: !addnota @membro Já avisado sobre spam')
  
  const numeroAlvo = alvo.split('@')[0]
  
  if (!donoState.historicoMod) donoState.historicoMod = {}
  if (!donoState.historicoMod[from]) donoState.historicoMod[from] = {}
  if (!donoState.historicoMod[from][numeroAlvo]) donoState.historicoMod[from][numeroAlvo] = []
  
  donoState.historicoMod[from][numeroAlvo].push({
  nota,
  hora: Date.now(),
  por: numero
  })
  
  await enviar({
  text: `${caixaArlequina("addnota", `📝 Nota adicionada para @${numeroAlvo}.`)}`,
  mentions: [alvo]
  })
} catch (e) {
console.log('❌ ERRO (addnota):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
