/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: modoaluguel
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'modoaluguel',
description: "Ativa/desativa o modo aluguel",
category: 'dono',
aliases: [],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson, groupName }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  if (!isGrupo) return reply("Só em grupo.")
  
    const modoRaw = (args[0] || '').toLowerCase()
    const modo = ['on', 'ligar', 'ativar', 'true', '1'].includes(modoRaw) ? '1'
      : ['off', 'desligar', 'desativar', 'false', '0'].includes(modoRaw) ? '0'
      : modoRaw
    const grupo = from
  
    if (!donoState.aluguel.grupos[grupo]) {
      donoState.aluguel.grupos[grupo] = {
        ativo: false,
        valor: 2000,
        inicio: null,
        fim: null,
        interval: null,
        pago: 0
      }
    }
  
    const data = donoState.aluguel.grupos[grupo]
  
    // ATIVAR
    if (modo === '1') {
  
      data.ativo = true
      data.inicio = Date.now()
      donoState.salvar()
  
      const inicioFmt = new Date(data.inicio).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })
      const fimFmt = data.fim ? new Date(data.fim).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'Sem prazo definido'
  
      return reply(`╭─━━─🃏💜「 🃏💜 *ARLEQUINA BOT* 💜🃏 」💜🃏─━━─╮
┃ ✅ *ALUGUEL ATIVADO COM SUCESSO!*
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣
┃ 🏠 *Grupo:* ${groupName || 'Este grupo'}
┃ 💰 *Valor:* ${data.valor}
┃ 🕐 *Início:* ${inicioFmt}
┃ 📅 *Até:* ${fimFmt}
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _Arlequina Bot_ 😈`)
    }
  
    // DESATIVAR
    if (modo === '0') {
  
      data.ativo = false
      clearInterval(data.interval)
      donoState.salvar()
  
      return reply(`╭─━━─🃏💜「 🃏💜 *ARLEQUINA BOT* 💜🃏 」💜🃏─━━─╮
┃ ❌ *ALUGUEL DESATIVADO*
┃ 🏠 *Grupo:* ${groupName || 'Este grupo'}
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _Arlequina Bot_ 😈`)
    }
  
    return reply("Use: modoaluguel on (ou 1) / modoaluguel off (ou 0)")
} catch (e) {
console.log('❌ ERRO (modoaluguel):', e?.message)
await reply(caixaArlequina("modoaluguel", `❌ Não consegui executar esse comando agora.`))
} finally {
salvarUsuarios(usuarios)
}

}
}
