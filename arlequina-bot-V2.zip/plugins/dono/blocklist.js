/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: blocklist, listablock
*/
const donoState = require('../../arquivos/js/donoState.js')
const adminState = require('../../arquivos/js/adminState.js')
const fs = require('fs')
const { dbPath } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'blocklist',
description: "Lista os usuários bloqueados",
category: 'dono',
aliases: ["listablock"],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const lista = donoState.banidosGlobal ? Object.keys(donoState.banidosGlobal) : []
  
  if (lista.length === 0) {
  await reply('Nenhum usuário bloqueado no momento.')
  return
  }
  
  await enviar({
  text: `${caixaArlequina("blocklist", `🚫 *Usuários bloqueados:*\n\n${lista.map(id => `• @${id.split('@')[0]}`).join('\n')}`)}`,
  mentions: lista
  }, { quoted: msg })
} catch (e) {
console.log('❌ ERRO DONO (blocklist):', e?.message)
await reply('❌ Não consegui executar esse comando.')
}

}
}
