const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'addmoney',
description: "(Dono) Adiciona dinheiro pra você ou pra quem marcar",
category: 'dono',
aliases: ['addgrana', 'addsaldo'],
async execute({ isDono, arlequina, from, info, args, q, reply, prefix, sender }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const usuarios = carregarUsuarios()

const enviar = async (conteudo) => {
  try { return await sock.sendMessage(from, conteudo, { quoted: info }) }
  catch (e) { return reply(conteudo?.text || '✅') }
}

try {
  // Alvo: pessoa marcada com @ ou o próprio dono
  const mencionado = msg.message?.extendedTextMessage?.contextInfo?.participant || msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
  const alvo = mencionado || sender

  // Valor: primeiro número que aparecer nos args (ignora @ e texto)
  const valor = Number(args.find(a => /^\d+(\.\d+)?$/.test(a)))

  if (!valor || isNaN(valor) || valor <= 0) {
    return reply(`${caixaArlequina("addmoney", `❌ Use: *${prefix}addmoney <valor>*\n\nEx: *${prefix}addmoney 5000*\nOu: *${prefix}addmoney 5000 @membro*`)}`)
  }

  getUsuario(usuarios, alvo)
  usuarios[alvo].saldo += Math.floor(valor)
  salvarUsuarios(usuarios)

  const numAlvo = alvo.split('@')[0]

  if (mencionado) {
    await enviar({
      text: `╭─━━─🃏💜「 *ADDMONEY* 」💜🃏─━━─╮\n\n💰 *+R$ ${Math.floor(valor).toLocaleString('pt-BR')}* adicionado!\n\n👤 Destinatário: @${numAlvo}\n👛 Novo saldo: *R$ ${usuarios[alvo].saldo.toLocaleString('pt-BR')}*\n\n╰─━━━━━━━━━━━━━━━━━━━━━━━━─╯`,
      mentions: [alvo]
    })
  } else {
    await enviar({
      text: `╭─━━─🃏💜「 *ADDMONEY* 」💜🃏─━━─╮\n\n💰 *+R$ ${Math.floor(valor).toLocaleString('pt-BR')}* adicionado!\n\n👤 Destinatário: você mesmo\n👛 Novo saldo: *R$ ${usuarios[alvo].saldo.toLocaleString('pt-BR')}*\n\n╰─━━━━━━━━━━━━━━━━━━━━━━━━─╯`
    })
  }
} catch (e) {
  console.log('❌ ERRO (addmoney):', e?.message)
  await reply('❌ Não consegui executar agora.')
}

}
}
