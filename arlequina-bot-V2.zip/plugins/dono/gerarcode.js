/*
  GERARCODE
  Gerador interativo de comandos - Arlequina Bot

  Local:
  plugins/dono/gerarcode.js

  O comando é exclusivo do dono.
  O dono é puxado do config.js / donoJid.

  O comando pergunta em qual pasta de plugins
  o novo comando deverá ser salvo.
*/

const fs = require('fs')
const path = require('path')

if (!global.gerarcode) {
  global.gerarcode = {}
}

function numero(jid) {
  return String(jid || '')
    .split('@')[0]
    .replace(/\D/g, '')
}

function pegarDono(config, donoJid) {
  let dono =
    config?.donoJid ||
    config?.dono ||
    config?.owner ||
    config?.ownerJid ||
    config?.numeroDono ||
    donoJid

  if (Array.isArray(dono)) dono = dono[0]

  return numero(dono)
}

function limparTexto(texto) {
  return String(texto || '').trim()
}

function escapar(texto) {
  return String(texto || '')
    .replace(/\\/g, '\\\\')
    .replace(/'/g, "\\'")
    .replace(/\r?\n/g, ' ')
}

function escaparTemplate(texto) {
  return String(texto || '')
    .replace(/\\/g, '\\\\')
    .replace(/`/g, '\\`')
    .replace(/\$\{/g, '\\${')
    .replace(/\r?\n/g, ' ')
}

function gerarCodigo(data) {
  const {
    nome,
    tipo,
    descricao,
    funcionalidade,
    resposta
  } = data

  let codigo = `/*
  Comando: ${nome}
  Descrição: ${descricao}
  Funcionalidade: ${funcionalidade}
  Gerado automaticamente pelo GERARCODE
*/

module.exports = {

name: '${nome}',

description: '${escapar(descricao)}',

category: 'geral',

aliases: [],

async execute({
  arlequina,
  from,
  info,
  args,
  q,
  reply,
  reagir,
  prefix,
  sender,
  pushname,
  isGroup,
  donoJid,
  commandManager,
  config
}) {

try {

`

  if (tipo === '1') {
    codigo += `
return reply(
\`╔════════════════════════════════════╗
║          ${nome.toUpperCase()}          ║
╚════════════════════════════════════╝

✅ ${escaparTemplate(resposta)}

👤 @\${String(sender).split('@')[0]}

🕐 \${new Date().toLocaleTimeString('pt-BR')}\`
)

`
  } else if (tipo === '2') {
    codigo += `
const texto = q || args.join(' ')

if (!texto) {
return reply(
\`❌ Use:

\${prefix}${nome} <argumento>\`
)
}

return reply(
\`╔════════════════════════════════════╗
║          ${nome.toUpperCase()}          ║
╚════════════════════════════════════╝

✅ ${escaparTemplate(resposta)}

📝 Argumento:
\${texto}

👤 @\${String(sender).split('@')[0]}\`
)

`
  } else if (tipo === '3') {
    codigo += `
// Verificação do dono usando o config.js

const donoNumero = String(
  config?.donoJid ||
  config?.dono ||
  config?.owner ||
  config?.ownerJid ||
  donoJid ||
  ''
)
.split('@')[0]
.replace(/\\\\D/g, '')

const meuNumero = String(sender || '')
.split('@')[0]
.replace(/\\\\D/g, '')

if (!donoNumero || meuNumero !== donoNumero) {
return reply('❌ Este comando é exclusivo do dono!')
}

return reply(
\`╔════════════════════════════════════╗
║          ${nome.toUpperCase()}          ║
╚════════════════════════════════════╝

👑 Comando autorizado!

✅ ${escaparTemplate(resposta)}

👤 @\${String(sender).split('@')[0]}\`
)

`
  } else if (tipo === '4') {
    codigo += `
if (!global.cooldowns) {
  global.cooldowns = {}
}

if (!global.cooldowns['${nome}']) {
  global.cooldowns['${nome}'] = {}
}

const agora = Date.now()
const tempoCooldown = 5000

if (
  global.cooldowns['${nome}'][sender] &&
  agora < global.cooldowns['${nome}'][sender]
) {
  const restante = Math.ceil(
    (global.cooldowns['${nome}'][sender] - agora) / 1000
  )

  return reply(
    \`⏳ Aguarde \${restante}s antes de usar novamente.\`
  )
}

global.cooldowns['${nome}'][sender] =
  agora + tempoCooldown

return reply(
\`╔════════════════════════════════════╗
║          ${nome.toUpperCase()}          ║
╚════════════════════════════════════╝

✅ ${escaparTemplate(resposta)}

👤 @\${String(sender).split('@')[0]}\`
)

`
  }

  codigo += `
} catch (e) {

console.log(
  '❌ ERRO (${nome}):',
  e?.message
)

return reply(
  '❌ Erro ao executar o comando.'
)

}

}

}
`

  return codigo
}

module.exports = {
  name: 'gerarcode',

  description: 'Gerador interativo de comandos',

  category: 'dono',

  aliases: [
    'gerar',
    'makecode',
    'criarcomando'
  ],

  async execute({
    arlequina,
    from,
    info,
    args,
    q,
    reply,
    reagir,
    prefix,
    sender,
    pushname,
    isGroup,
    donoJid,
    commandManager,
    config
  }) {

    try {
      const donoNumero = pegarDono(config, donoJid)
      const meuNumero = numero(sender)

      if (!donoNumero || meuNumero !== donoNumero) {
        return reply(
          '╔════════════════════════════════════╗\n' +
          '║          🚫 ACESSO NEGADO          ║\n' +
          '╚════════════════════════════════════╝\n\n' +
          '❌ Este comando é exclusivo do dono.'
        )
      }

      const texto = limparTexto(q || args.join(' '))

      if (
        texto.toLowerCase() === 'cancelar' ||
        texto.toLowerCase() === 'cancel'
      ) {
        delete global.gerarcode[sender]
        return reply('❌ GERARCODE cancelado.')
      }

      const estado = global.gerarcode[sender]

      if (estado) {
        if (estado.etapa === 1) {
          let pastaEscolhida = ''

          if (texto === '1') pastaEscolhida = 'cmds'
          else if (texto === '2') pastaEscolhida = 'admin'
          else if (texto === '3') pastaEscolhida = 'dono'
          else if (texto === '4') {
            estado.etapa = 2
            return reply(
              '╔════════════════════════════════════╗\n' +
              '║        📁 PASTA PERSONALIZADA      ║\n' +
              '╚════════════════════════════════════╝\n\n' +
              'Digite o caminho da pasta dentro de *plugins*.\n\n' +
              'Exemplos:\n\n' +
              '```text\n' +
              'downloads\n' +
              'efeitos\n' +
              'inteligencia-ia\n' +
              'rpg\n' +
              'admin/moderacao\n' +
              '```\n\n' +
              '💡 Digite *cancelar* para sair.'
            )
          } else {
            return reply(
              '❌ Opção inválida!\n\n' +
              'Escolha:\n\n' +
              '1️⃣ plugins/cmds\n' +
              '2️⃣ plugins/admin\n' +
              '3️⃣ plugins/dono\n' +
              '4️⃣ Outra pasta\n\n' +
              'Digite *1, 2, 3 ou 4*.'
            )
          }

          estado.pasta = pastaEscolhida
          estado.etapa = 3

          return reply(
            '╔════════════════════════════════════╗\n' +
            '║          🛠️ ETAPA 2/5             ║\n' +
            '╚════════════════════════════════════╝\n\n' +
            `📁 Pasta escolhida:\n*plugins/${pastaEscolhida}*\n\n` +
            '*Qual o tipo de comando?*\n\n' +
            '1️⃣ Simples\n' +
            '2️⃣ Com argumentos\n' +
            '3️⃣ Com permissões\n' +
            '4️⃣ Com cooldown\n\n' +
            'Digite apenas *1, 2, 3 ou 4*.'
          )
        }

        if (estado.etapa === 2) {
          let pasta = texto
            .replace(/^plugins[\\/]/i, '')
            .replace(/^\/+|\/+$/g, '')

          if (
            !pasta ||
            pasta.includes('..') ||
            pasta.includes('\\') ||
            path.isAbsolute(pasta)
          ) {
            return reply(
              '❌ Caminho inválido!\n\n' +
              'A pasta precisa estar dentro de `plugins/`.\n\n' +
              'Exemplo:\n' +
              '`downloads`\n' +
              '`efeitos`\n' +
              '`admin/moderacao`'
            )
          }

          estado.pasta = pasta
          estado.etapa = 3

          return reply(
            '╔════════════════════════════════════╗\n' +
            '║          🛠️ ETAPA 2/5             ║\n' +
            '╚════════════════════════════════════╝\n\n' +
            `📁 Pasta escolhida:\n*plugins/${pasta}*\n\n` +
            '*Qual o tipo de comando?*\n\n' +
            '1️⃣ Simples\n' +
            '2️⃣ Com argumentos\n' +
            '3️⃣ Com permissões\n' +
            '4️⃣ Com cooldown\n\n' +
            'Digite apenas *1, 2, 3 ou 4*.'
          )
        }

        if (estado.etapa === 3) {
          if (!['1', '2', '3', '4'].includes(texto)) {
            return reply('❌ Opção inválida!\n\nDigite *1, 2, 3 ou 4*.')
          }

          estado.tipo = texto
          estado.etapa = 4

          return reply(
            '╔════════════════════════════════════╗\n' +
            '║          📝 ETAPA 3/5             ║\n' +
            '╚════════════════════════════════════╝\n\n' +
            '*Qual é a descrição do comando?*\n\n' +
            'Exemplo:\n' +
            '```text\n' +
            'Ele faz uma imagem\n' +
            '```\n\n' +
            'Digite a descrição.'
          )
        }

        if (estado.etapa === 4) {
          if (texto.length < 5) {
            return reply('❌ A descrição precisa ter pelo menos 5 caracteres.')
          }

          estado.descricao = texto
          estado.etapa = 5

          return reply(
            '╔════════════════════════════════════╗\n' +
            '║          ⚙️ ETAPA 4/5             ║\n' +
            '╚════════════════════════════════════╝\n\n' +
            '*O que o comando deve fazer?*\n\n' +
            'Exemplo:\n' +
            '```text\n' +
            'Gera uma foto\n' +
            '```\n\n' +
            'Digite a funcionalidade.'
          )
        }

        if (estado.etapa === 5) {
          if (texto.length < 5) {
            return reply('❌ A funcionalidade precisa ter pelo menos 5 caracteres.')
          }

          estado.funcionalidade = texto
          estado.etapa = 6

          return reply(
            '╔════════════════════════════════════╗\n' +
            '║          💬 ETAPA 5/6             ║\n' +
            '╚════════════════════════════════════╝\n\n' +
            '*Qual será a resposta do comando?*\n\n' +
            'Exemplo:\n' +
            '```text\n' +
            'Pronto linda\n' +
            '```\n\n' +
            'Digite a resposta.'
          )
        }

        if (estado.etapa === 6) {
          if (!texto) {
            return reply('❌ Digite uma resposta para o comando.')
          }

          estado.resposta = texto

          const codigo = gerarCodigo({
            nome: estado.nome,
            tipo: estado.tipo,
            descricao: estado.descricao,
            funcionalidade: estado.funcionalidade,
            resposta: estado.resposta
          })

          const pastaPlugins = path.resolve(__dirname, '..')
          const pastaDestino = path.resolve(pastaPlugins, estado.pasta)

          const pluginsReal = path.resolve(pastaPlugins)
          const destinoReal = path.resolve(pastaDestino)

          if (
            destinoReal !== pluginsReal &&
            !destinoReal.startsWith(pluginsReal + path.sep)
          ) {
            delete global.gerarcode[sender]
            return reply('❌ Caminho de destino inválido!')
          }

          if (!fs.existsSync(pastaDestino)) {
            fs.mkdirSync(pastaDestino, { recursive: true })
          }

          const arquivo = path.join(
            pastaDestino,
            `${estado.nome}.js`
          )

          fs.writeFileSync(
            arquivo,
            codigo,
            'utf8'
          )

          delete global.gerarcode[sender]

          await reply(
            '╔════════════════════════════════════╗\n' +
            '║       ✅ COMANDO CRIADO            ║\n' +
            '╚════════════════════════════════════╝\n\n' +
            `📦 Nome: *${estado.nome}*\n\n` +
            `📁 Pasta:\n*plugins/${estado.pasta}*\n\n` +
            `📝 Descrição:\n${estado.descricao}\n\n` +
            `⚙️ Função:\n${estado.funcionalidade}\n\n` +
            `💬 Resposta:\n${estado.resposta}\n\n` +
            '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n' +
            '💻 *CÓDIGO GERADO:*\n\n' +
            '```javascript\n' +
            codigo +
            '\n```\n\n' +
            '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n' +
            `📁 Arquivo salvo em:\n` +
            `plugins/${estado.pasta}/${estado.nome}.js\n\n` +
            '🚀 Comando criado com sucesso!'
          )

          return true
        }
      }

      if (!texto) {
        return reply(
          '╔════════════════════════════════════════════╗\n' +
          '║     🤖 GERADOR DE COMANDOS - GERARCODE    ║\n' +
          '╚════════════════════════════════════════════╝\n\n' +
          '👑 Comando exclusivo do dono.\n\n' +
          '*Use:*\n' +
          `${prefix}gerarcode <nome>\n\n` +
          '*Exemplo:*\n' +
          `${prefix}gerarcode samuel\n\n` +
          'Depois você escolherá a pasta onde salvar o comando.\n\n' +
          '💡 Digite *cancelar* para sair.'
        )
      }

      const nome = texto
        .split(/\s+/)[0]
        .toLowerCase()
        .replace(/[^a-z0-9_-]/g, '')

      if (!nome) {
        return reply('❌ Nome de comando inválido!')
      }

      if (nome.length < 2) {
        return reply('❌ O nome precisa ter pelo menos 2 caracteres.')
      }

      global.gerarcode[sender] = {
        nome,
        etapa: 1,
        pasta: null,
        tipo: null,
        descricao: null,
        funcionalidade: null,
        resposta: null,
        iniciadoEm: Date.now()
      }

      return reply(
        '╔════════════════════════════════════╗\n' +
        '║       🛠️ GERARCODE INICIADO       ║\n' +
        '╚════════════════════════════════════╝\n\n' +
        `📦 Comando: *${nome}*\n\n` +
        '*📁 Onde deseja colocar o comando?*\n\n' +
        '1️⃣ `plugins/cmds`\n' +
        '2️⃣ `plugins/admin`\n' +
        '3️⃣ `plugins/dono`\n' +
        '4️⃣ Outra pasta\n\n' +
        'Digite *1, 2, 3 ou 4*.\n\n' +
        '💡 Digite *cancelar* para sair.'
      )

    } catch (e) {
      console.log(
        '❌ ERRO DONO (gerarcode):',
        e?.message
      )

      delete global.gerarcode[sender]

      return reply(
        '❌ Não consegui executar o GERARCODE.\n\n' +
        `Erro: ${e?.message || 'erro desconhecido'}`
      )
    }
  }
}
