/*
 Convertido/adaptado para o sistema de plugins da Arlequina Bot.
 Comando original: getcmd / cmd / getcomando (bot antigo monolitico,
 baseado em pasta "comandos" com "nomes: [...]").

 Na Arlequina cada comando já fica registrado no commandManager (nome +
 aliases + arquivo), então não precisa varrer pastas manualmente.
 Esse comando manda o código formatado usando o mesmo "code block" do
 WhatsApp (botForwardedMessage/richResponseMessage) que o bot antigo usava;
 se o relayMessage falhar (ex: versão do WhatsApp não suporta), cai pra
 um bloco ```javascript normal.
*/
const fs = require('fs')
const path = require('path')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'getcmd',
description: "(Dono) Mostra o código-fonte de um comando em bloco de código",
category: 'dono',
aliases: ['cmd', 'getcomando'],
async execute({ isDono, arlequina, from, args, q, reply, prefix, commandManager }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


try {
  const nomeCmd = (q || args.join(' ') || '').trim().toLowerCase()
  if (!nomeCmd) {
    return reply(`${caixaArlequina("getcmd", `📂 Informe um comando.\n\nExemplo:\n${prefix}getcmd menu`)}`)
  }

  const plugin = commandManager?.ObterComando(nomeCmd)
  if (!plugin || !plugin.file) {
    return reply('❌ Comando não encontrado.')
  }

  const pluginsDir = path.join(__dirname, '..')
  const filePath = path.resolve(plugin.file)
  if (!filePath.startsWith(pluginsDir)) {
    return reply('❌ Esse comando não pode ser lido por aqui.')
  }

  const conteudo = fs.readFileSync(filePath, 'utf8')
  const nomeOriginal = plugin.originalName || plugin.name
  const aliasesTodos = [nomeOriginal, ...(plugin.aliases || [])].filter(Boolean)

  const cabecalho = `📂 Arquivo: ${path.basename(filePath)}\n📍 Local: ${filePath.replace(process.cwd(), '.')}\n🏷️ Aliases: ${aliasesTodos.join(', ')}`

  try {
    const codeBlocks = conteudo.split('\n').map(line => ({
      highlightType: 0,
      codeContent: line + '\n'
    }))

    await arlequina.relayMessage(from, {
      botForwardedMessage: {
        message: {
          richResponseMessage: {
            messageType: 1,
            submessages: [
              { messageType: 2, messageText: cabecalho },
              {
                messageType: 5,
                codeMetadata: {
                  codeLanguage: 'javascript',
                  codeBlocks
                }
              }
            ],
            contextInfo: {
              forwardingScore: 999,
              isForwarded: true,
              forwardOrigin: 4
            }
          }
        }
      }
    }, {})
  } catch (eRelay) {
    // Fallback: WhatsApp não aceitou o formato "rich" -> manda como texto normal
    const MAX = 3500
    const corpo = conteudo.length > MAX ? conteudo.slice(0, MAX) + '\n\n... (cortado, arquivo muito grande)' : conteudo
    await reply(`${cabecalho}\n\n\`\`\`javascript\n${corpo}\n\`\`\``)
  }
} catch (e) {
  console.error('[GETCMD]', e)
  await reply(`❌ Erro:\n${e.message}`)
}

}
}
