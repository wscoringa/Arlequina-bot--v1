/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: joingrupo, entrargrupo
*/
const donoState = require('../../arquivos/js/donoState.js')
const adminState = require('../../arquivos/js/adminState.js')
const fs = require('fs')
const { dbPath } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'joingrupo',
description: "Faz o bot entrar em um grupo via link de convite",
category: 'dono',
aliases: ["entrargrupo"],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const link = args[0]
  
  if (!link)
  return reply(caixaArlequina("joingrupo", `❌ Envie o link de convite do grupo.\n\nEx: !joingrupo https://chat.whatsapp.com/xxxxx`))
  
  const codigo = link.split('https://chat.whatsapp.com/')[1]
  
  if (!codigo)
  return reply('❌ Link inválido.')
  
  try {
  await sock.groupAcceptInvite(codigo)
  await reply('✅ Entrei no grupo!')
  } catch (e) {
  console.log(e)
  await reply('❌ Não consegui entrar no grupo. Link inválido ou expirado.')
  }
} catch (e) {
console.log('❌ ERRO DONO (joingrupo):', e?.message)
await reply('❌ Não consegui executar esse comando.')
}

}
}
