const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
module.exports = {
name: 'getquoted',
description: 'Mostra as informações da mensagem marcada',
category: 'dono',
aliases: ['getinfo','get'],
async execute({ isDono, info, reply }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')

try {
  const contextInfo = info.message?.extendedTextMessage?.contextInfo
  if (!contextInfo || !contextInfo.quotedMessage) {
    return reply(caixaArlequina("getquoted", `❌ Responda (cite) a mensagem que você quer inspecionar e use o comando de novo.`))
  }
  reply(JSON.stringify(contextInfo, null, 3))
} catch (e) {
  reply('Deu erro mano: ' + (e?.message || 'erro desconhecido'))
}
}
}
