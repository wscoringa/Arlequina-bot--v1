/*
 !planoaluguel <semanal|mensal|vitalicio>
 Mostra o plano com um botão "Copiar Chave PIX" de verdade (cta_copy) —
 e o código copiado já é o PIX "copia e cola" completo (com o valor
 certo do plano embutido), não só a chave crua. Assim, ao colar no
 banco, já vem com o valor preenchido sozinho.

 IMPORTANTE (limite real): não tem como o bot saber sozinho que o PIX
 caiu — isso exigiria integração com uma API de pagamento de verdade
 (tipo Mercado Pago, Efí/Gerencianet, PagSeguro etc.) com webhook,
 coisa que precisa de conta/credencial num desses serviços. Sem isso,
 a ativação continua manual: o dono confere o comprovante e libera com
 !addaluguel <dias>, que já existe e funciona.
*/
const { generateWAMessageFromContent, generateMessageIDV2, isJidGroup } = require('@whiskeysockets/baileys')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const CHAVE_PIX = '15297054443' // CPF cadastrado como chave
const NOME_RECEBEDOR = 'Wyllyamberg Santos Rodrig' // nome exatamente como está no banco
const NOME_CRIADOR = 'Wyllyam'

const PLANOS = {
  semanal: { nome: 'Semanal', duracao: '7 dias', valor: 5.00 },
  mensal: { nome: 'Mensal', duracao: '30 dias', valor: 15.00 },
  vitalicio: { nome: 'Vitalício', duracao: 'Acesso vitalício', valor: 30.00 }
}

// ── Gerador de PIX "copia e cola" (padrão EMV/BR Code) ──────────────
function crc16(payload) {
  let crc = 0xFFFF
  for (let i = 0; i < payload.length; i++) {
    crc ^= payload.charCodeAt(i) << 8
    for (let j = 0; j < 8; j++) {
      crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) & 0xFFFF : (crc << 1) & 0xFFFF
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, '0')
}

function montarPixCopiaECola(valor) {
  const valorTexto = valor.toFixed(2)
  const campo26 = `0014br.gov.bcb.pix0111${CHAVE_PIX}`
  const campo59 = NOME_RECEBEDOR.slice(0, 25)
  const campo62 = `05114VRMNS3EX8P`

  const base =
    `000201` +
    `26${String(campo26.length).padStart(2, '0')}${campo26}` +
    `52040000` +
    `5303986` +
    `5802BR` +
    `59${String(campo59.length).padStart(2, '0')}${campo59}` +
    `6001*` +
    `54${String(valorTexto.length).padStart(2, '0')}${valorTexto}` +
    `62${String(campo62.length).padStart(2, '0')}${campo62}`

  const baseComTagCrc = base + '6304'
  return baseComTagCrc + crc16(baseComTagCrc)
}

// Node extra necessário pro WhatsApp desenhar o botão nativo de verdade
function nodeDoBotao(jid) {
  const node = {
    tag: 'biz',
    attrs: {},
    content: [{
      tag: 'interactive',
      attrs: { type: 'native_flow', v: '1' },
      content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }]
    }]
  }
  const nodes = [node]
  if (!isJidGroup(jid)) nodes.push({ tag: 'bot', attrs: { biz_bot: '1' } })
  return nodes
}

module.exports = {
  name: 'planoaluguel',
  description: 'Mostra os planos de aluguel do bot com botão de copiar o PIX (copia e cola)',
  category: 'dono',
  aliases: ['planosemanal', 'planomensal', 'planovitalicio', 'planos'],
  async execute({ isDono, arlequina, columbina, from, info, args, q, reply, reagir, prefix, command }) {
  if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')

    const conn = columbina || arlequina
    try {
      const comando = (command || '').toLowerCase()
      let chave = (q || args[0] || '').toLowerCase()
      if (!chave) {
        if (comando.includes('semanal')) chave = 'semanal'
        else if (comando.includes('mensal')) chave = 'mensal'
        else if (comando.includes('vitalicio')) chave = 'vitalicio'
      }

      const plano = PLANOS[chave]

      await reagir('🎫')

      if (!plano) {
        const lista = Object.entries(PLANOS).map(([k, p]) => `📦 ${p.nome} — R$ ${p.valor.toFixed(2)} (${p.duracao})\n💡 ${prefix}planoaluguel ${k}`).join('\n\n')
        return reply(caixaArlequina('planoaluguel', `🎫 *PLANOS DE ALUGUEL* 🎫\n\n${lista}`))
      }

      const codigoPix = montarPixCopiaECola(plano.valor)

      const corpo = `╭━━━〔 🎫 💜 ALUGUEL DO ARLEQUINA BOT 💜 〕━━━╮

📦 𝐏𝐋𝐀𝐍𝐎: ${plano.nome}
📅 𝐃𝐮𝐫𝐚çã𝐨: ${plano.duracao}
💸 𝐕𝐚𝐥𝐨𝐫: R$ ${plano.valor.toFixed(2)}

━━━━━━━━━━━━━━━━━━━━

👑 𝐂𝐫𝐢𝐚𝐝𝐨𝐫: ${NOME_CRIADOR}

━━━━━━━━━━━━━━━━━━━━

✅ Após realizar o pagamento,
📸 envie o comprovante para o criador.

🔓 Assim que o pagamento for confirmado,
seu aluguel será ativado imediatamente.

━━━━━━━━━━━━━━━━━━━━

💜 Benefícios do aluguel:
🤖 Bot online 24h
⚡ Alta velocidade
🛠️ Suporte do criador
🔄 Atualizações constantes

╰━━━━━━━━━━━━━━━━━━━━━━╯
          🃏 𝐀𝐑𝐋𝐄𝐐𝐔𝐈𝐍𝐀 𝐁𝐎𝐓 💜`

      try {
        const conteudoMensagem = {
          interactiveMessage: {
            contextInfo: {
              stanzaId: info.key.id,
              participant: info.key.participant || info.key.remoteJid,
              quotedMessage: info.message
            },
            body: { text: corpo },
            footer: { text: '🃏 Arlequina Bot 💜' },
            nativeFlowMessage: {
              buttons: [{
                name: 'cta_copy',
                buttonParamsJson: JSON.stringify({
                  display_text: '📋 Copiar código PIX',
                  copy_code: codigoPix
                })
              }]
            }
          }
        }

        const msgGerada = generateWAMessageFromContent(from, conteudoMensagem, {
          userJid: conn.user.id,
          messageId: generateMessageIDV2(conn.user.id)
        })

        await conn.relayMessage(from, msgGerada.message, {
          messageId: msgGerada.key.id,
          additionalNodes: nodeDoBotao(from)
        })
      } catch (eBotao) {
        // Se o botão não for aceito nessa conversa, cai pro texto com o
        // código em bloco monoespaçado (ainda dá pra copiar tocando e segurando).
        console.log('[planoaluguel] botão de copiar falhou, caindo pro texto:', eBotao?.message)
        await reply(`${corpo}\n\n🔑 Código PIX (toque e segure pra copiar):\n\`\`\`${codigoPix}\`\`\``)
      }
    } catch (e) {
      console.log('❌ ERRO planoaluguel:', e?.message)
      await reply('❌ Não consegui mostrar os planos agora.')
    }
  }
}
