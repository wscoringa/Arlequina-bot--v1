/*
 Comando original: listfundos (categoria 'admin' no bot antigo). Mudei pra
 categoria 'dono' porque esse comando lista dados de TODOS os grupos onde
 o bot está, e isso não devia ficar visível pra qualquer admin de um grupo
 específico - só pro dono do bot.
*/
const welcomeDB = require('../../arquivos/js/welcomeDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'listfundos',
description: "(Dono) Lista os grupos com fundo de boas-vindas/saída configurado",
category: 'dono',
aliases: [],
async execute({ isDono, reply }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


try {
  const grupos = welcomeDB.listarComFundo()

  if (grupos.length === 0) {
    return reply('📋 Nenhum grupo com fundo de boas-vindas/saída configurado.')
  }

  const texto = grupos
    .map(([id, cfg]) => {
      const partes = []
      if (cfg.fundoEntrada) partes.push('entrada')
      if (cfg.fundoSaida) partes.push('saída')
      return `• ${id} (${partes.join(', ')})`
    })
    .join('\n')

  return reply(`${caixaArlequina("listfundos", `🖼️ Grupos com fundo configurado:\n\n${texto}`)}`)
} catch (e) {
  console.log('❌ ERRO (listfundos):', e?.message)
  return reply('❌ Não consegui executar esse comando agora.')
}

}
}
