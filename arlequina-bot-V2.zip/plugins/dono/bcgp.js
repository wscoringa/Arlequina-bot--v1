/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: bcgp
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'bcgp',
description: "Envia um broadcast pra todos os grupos",
category: 'dono',
aliases: ['bcg'],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const texto = args.join(' ')
  if (!texto) return reply('❌ Digite uma mensagem.')
  
  const grupos = await sock.groupFetchAllParticipating()
  
  const ids = Object.keys(grupos)
  
  reply(`${caixaArlequina("bcgp", `📢 Enviando para ${ids.length} grupos...`)}`)
  
  for (const id of ids) {
  
  await sock.sendMessage(id, {
  text: `
  ╭─━━─🃏💜「 📢 AVISO GLOBAL 」💜🃏─━━─╮
  
  ${texto}
  
  ━━━━━━━━━━━━━━━
  
  👑 Mensagem do meu dono:
  么ᴡꜱﾠ😈ᴄᴏʀɪɴɢᴀﾠﾠ❤️╰‿╯
  
  🤡 Bot: 愛ＡＲＬＥＱＵＩＮＡ
  `
  })
  
  await new Promise(r => setTimeout(r, 2000))
  }
  
  reply(`✅ Mensagem enviada para ${ids.length} grupos.`)
} catch (e) {
console.log('❌ ERRO (bcgp):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
