const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
/*
 Convertido/adaptado para o sistema de plugins da Arlequina Bot.
 Comando original: channel (bot antigo monolitico, baseado em switch-case)

 Controla o "Ver canal" (aplicarVerCanal / CTX_NL em arquivos/js/verCanal.js)
 que é injetado automaticamente em toda mensagem enviada pelo bot.

 category: 'dono' -> o próprio dispatcher do index.js já bloqueia esse
 comando pra quem não é o dono, então nem precisa checar isDono() aqui.
*/
global.ENABLE_CHANNEL = global.ENABLE_CHANNEL !== undefined ? global.ENABLE_CHANNEL : true
global.CHANNEL_BLOCK_LIST = global.CHANNEL_BLOCK_LIST || []

module.exports = {
name: 'channel',
description: "(Dono) Liga/desliga o 'Ver canal' global ou bloqueia em módulos específicos",
category: 'dono',
aliases: ['vercanal'],
async execute({ args, reply, prefix }) {

try {
  const action = args[0]?.toLowerCase()

  if (!action) {
    return reply(`${caixaArlequina("channel", `[channel system]

status: ${global.ENABLE_CHANNEL ? 'enabled' : 'disabled'}

commands:

${prefix}channel on
-> global channel enable

${prefix}channel off
-> global channel disable

${prefix}channel add <menu>
-> block channel on module

${prefix}channel del <menu>
-> unblock channel on module

${prefix}channel list
-> show blocked modules`)}`)
  }

  if (action === 'on') {
    global.ENABLE_CHANNEL = true
    return reply('✅ Channel ativado em TODO o bot')
  }

  if (action === 'off') {
    global.ENABLE_CHANNEL = false
    return reply('❌ Channel desativado em TODO o bot')
  }

  if (action === 'add') {
    if (!args[1]) return reply('❌ Digite o nome do menu')
    if (!global.CHANNEL_BLOCK_LIST.includes(args[1])) {
      global.CHANNEL_BLOCK_LIST.push(args[1])
    }
    return reply(`🚫 Channel bloqueado no menu: ${args[1]}`)
  }

  if (action === 'del') {
    if (!args[1]) return reply('❌ Digite o nome do menu')
    global.CHANNEL_BLOCK_LIST = global.CHANNEL_BLOCK_LIST.filter(m => m !== args[1])
    return reply(`✅ Channel liberado no menu: ${args[1]}`)
  }

  if (action === 'list') {
    return reply(`📌 MENUS BLOQUEADOS:\n\n${global.CHANNEL_BLOCK_LIST.length ? global.CHANNEL_BLOCK_LIST.join('\n') : 'Nenhum menu bloqueado'}`)
  }

  return reply('❌ Opção inválida. Use: on | off | add | del | list')
} catch (e) {
  console.log('❌ ERRO DONO (channel):', e?.message)
  await reply('❌ Não consegui executar esse comando.')
}

}
}
