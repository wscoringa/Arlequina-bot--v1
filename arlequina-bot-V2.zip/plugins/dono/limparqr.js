const fs = require('fs')
const path = require('path')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'limparqr',
description: 'Limpa arquivos temporários da pasta Arlequina-QR',
category: 'dono',
aliases: ['clearqr', 'cleanqr'],

async execute({ reply, isDono }) {

// BUGFIX SEGURANÇA: "isDono" chega aqui como uma FUNÇÃO (() => isDono(sender)), não como true/false. "if (!isDono)" checava se a FUNÇÃO existia (sempre existe = nunca bloqueava ninguém!) em vez de checar o RESULTADO dela. Isso deixava esse comando de dono liberado pra qualquer pessoa usar. Corrigido chamando isDono().
if (!isDono()) {
return reply('❌ Apenas o dono pode usar este comando!')
}

const caminhoQR = path.join(__dirname, '../../database/Arlequina-QR')

const arquivosParaManter = ['creds.json']

if (!fs.existsSync(caminhoQR)) {
fs.mkdirSync(caminhoQR, { recursive: true })
return reply('⚠️ Pasta qr-code não existia, então ela foi criada.')
}

try {

const arquivos = await fs.promises.readdir(caminhoQR)

let removidos = 0
let mantidos = 0

for (const arquivo of arquivos) {

if (arquivosParaManter.includes(arquivo)) {
mantidos++
continue
}

if (
arquivo.startsWith('pre-key') ||
arquivo.startsWith('sender-key') ||
arquivo.startsWith('session-') ||
arquivo.startsWith('device-list') ||
arquivo.startsWith('lid-mapping') ||
arquivo.startsWith('app-state-sync-key') ||
arquivo.endsWith('.tmp') ||
arquivo.endsWith('.bak') ||
(arquivo.endsWith('.json') && arquivo !== 'creds.json')
) {

const caminhoArquivo = path.join(caminhoQR, arquivo)

try {
await fs.promises.unlink(caminhoArquivo)
removidos++
} catch(e) {}

}
}

await reply(`${caixaArlequina("limparqr", `🌸 *LIMPEZA QR FINALIZADA* 🌸

🗑️ Arquivos removidos: ${removidos}
🔒 Arquivos mantidos: ${mantidos}

✅ Pasta qr-code otimizada com sucesso.`)}`)

} catch (error) {

console.log(error)

await reply(`❌ Erro ao limpar a pasta qr-code:

${error.message}`)

}

}
}