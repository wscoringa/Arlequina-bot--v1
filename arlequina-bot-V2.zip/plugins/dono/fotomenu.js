/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: fotomenu
 Restrito ao dono (category: 'dono' ja garante isso no index.js).
*/
const fs = require('fs')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'fotomenu',
  description: 'Troca a foto exibida no menu principal (somente dono)',
  category: 'dono',
  aliases: [],
  async execute({ isDono, arlequina, from, info, args, q, reply, sender, donoJid, getFileBuffer, prefix }) {
  if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


    const msg = info
    const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

    try {
      const quotedImage = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage
      const imagemMsg = msg.message?.imageMessage || quotedImage

      if (!imagemMsg) {
        return reply(caixaArlequina("fotomenu", `❌ Envie ou marque uma imagem junto com o comando.\n\nEx: marque uma foto e mande ${prefix}fotomenu`))
      }

      const buffer = await baixarMidia(imagemMsg, 'image')

      if (!fs.existsSync('./midias')) fs.mkdirSync('./midias', { recursive: true })
      if (!fs.existsSync('./arquivos/imagem')) fs.mkdirSync('./arquivos/imagem', { recursive: true })
      fs.writeFileSync('./arquivos/imagem/menu.jpg', buffer)
      fs.writeFileSync('./midias/menu.jpg', buffer)

      // Remove o vídeo pra a foto ter prioridade no #menu
      if (fs.existsSync('./midias/menu.mp4')) fs.unlinkSync('./midias/menu.mp4')

      return reply('✅ Foto do menu atualizada com sucesso!')
    } catch (e) {
      console.log('❌ ERRO (fotomenu):', e?.message)
      return reply('❌ Não consegui trocar a foto do menu agora.')
    }
  }
}
