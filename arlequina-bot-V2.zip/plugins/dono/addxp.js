/*
 Comando: addxp (dono)
 #addxp <quantidade>            -> adiciona XP pra você mesmo (dono)
 #addxp <quantidade> @usuario   -> adiciona XP pro usuário marcado
 (marcando/respondendo também funciona sem precisar digitar @)
*/
const { carregarUsuarios, salvarUsuarios, getUsuario, verificarLevel } = require('../../arquivos/js/rpgDB.js')
const { convertWhatsAppUser } = require('../../arquivos/js/userManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'addxp',
description: 'Adiciona XP a você (dono) ou a um usuário marcado',
category: 'dono',
aliases: ['addexp'],
async execute({ isDono, arlequina, columbina, from, info, args, reply, reagir, sender, prefix }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')

const sock = arlequina || columbina

const quoted = info.message?.extendedTextMessage?.contextInfo
const mencionado = quoted?.participant || quoted?.mentionedJid?.[0]
const alvo = mencionado ? convertWhatsAppUser(mencionado, 'jid') : sender

const quantidade = parseInt((args.find(a => /^\d+$/.test(a)) || ''))
if (!quantidade || quantidade <= 0) {
return reply(`${caixaArlequina("addxp", `❗ Use: *${prefix}addxp <quantidade>*\nEx: ${prefix}addxp 500\n\nOu marcando alguém: *${prefix}addxp 500 @usuario*`)}`)
}

try {
  const usuarios = carregarUsuarios()
  const u = getUsuario(usuarios, alvo)
  u.xp += quantidade

  let subiu = 0
  while (verificarLevel(u)) subiu++

  salvarUsuarios(usuarios)

  await reagir('✨')

  const quemMsg = mencionado ? `@${alvo.split('@')[0]}` : 'você'
  let texto = `╭─━━─🃏💜「 ✨💜 *ADD XP* 💜✨ 」💜🃏─━━─╮\n┃ +${quantidade} XP para ${quemMsg}\n┃ 📊 XP atual: ${u.xp}/${u.level * 500}\n┃ 🏅 Level: ${u.level}\n`
  if (subiu > 0) texto += `┃ 🎉 Subiu ${subiu} nível(is) no processo!\n`
  texto += `╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _Presentinho da dona da bagunça... 😈_`

  await sock.sendMessage(from, { text: texto, mentions: mencionado ? [alvo] : [] }, { quoted: info })
} catch (e) {
  console.log('❌ ERRO addxp:', e?.message)
  await reply('❌ Não consegui adicionar o XP agora.')
}
}
}
