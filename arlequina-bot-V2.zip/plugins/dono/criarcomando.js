/*
 Comando: criarcomando (aliases: gerarcomando, iacmd)
 Só o DONO pode usar.

 Cria comando(s) novos usando IA (Gemini), a partir só do NOME — a IA
 lê como os outros plugins do bot são escritos (Baileys via arquivos/js,
 arquitetura de plugins em module.exports {name, execute}, helpers
 como reply/reagir/isDono/caixaArlequina etc.) e escreve o arquivo
 sozinha, já seguindo o padrão do projeto. Depois recarrega os plugins
 na hora, sem precisar reiniciar o bot.

 USO:
   !criarcomando <categoria> <nome1> [nome2] [nome3...] [| instruções extras]

   - categoria: uma das já existentes (admin, dono, cmds-aleatorios,
     resenha, downloads, efeitos, midias, inteligencia-ia, rpg, quiz,
     social, brincadeiras, premium, menu, pesquisas). Se não reconhecer,
     cai em "cmds-aleatorios".
   - nome(s): só o nome do comando — a IA já deduz o que ele deve
     fazer pelo nome (ex: "boton" liga o bot, "botoff" desliga).
   - instruções extras (opcional, depois de "|"): detalha melhor o que
     você quer, se o nome sozinho não for óbvio.

 EXEMPLOS:
   !criarcomando dono boton botoff
   !criarcomando social abraçar | dá um abraço em quem foi marcado, com gif
*/
const fs = require('fs')
const path = require('path')
const axios = require('axios')
const vm = require('vm')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const CATEGORIAS_VALIDAS = ['admin', 'dono', 'cmds-aleatorios', 'resenha', 'downloads', 'efeitos', 'midias', 'inteligencia-ia', 'rpg', 'quiz', 'social', 'brincadeiras', 'premium', 'menu', 'pesquisas']

// Plugin de referência (few-shot) pra IA copiar o estilo/convenção certinho.
const EXEMPLO_PLUGIN = `const donoState = require('../../arquivos/js/donoState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'ligar',
  description: '🔌 Liga o bot (volta a responder comandos)',
  category: 'dono',
  aliases: [],
  async execute({ reply, reagir, isDono }) {
    if (!isDono()) return reply(caixaArlequina('ligar', '❌ Só o dono pode usar este comando.'))
    donoState.botStatus.ligado = true
    try { donoState.salvar() } catch (_) {}
    await reagir('✅')
    return reply(caixaArlequina('ligar', '✅ Bot ligado!'))
  }
}`

function limparCercas(texto) {
  return (texto || '')
    .replace(/```(?:javascript|js)?/gi, '')
    .replace(/```/g, '')
    .trim()
}

async function gerarCodigoPlugin({ nome, categoria, instrucoes, apiKey }) {
  const prompt = `Você é um gerador de código pra um bot de WhatsApp em Node.js, feito com a biblioteca @whiskeysockets/baileys, usando arquitetura de plugins.

REGRAS DO FORMATO (siga à risca):
- Cada plugin é um arquivo .js que faz module.exports = { name, description, category, aliases, async execute(ctx) {...} }
- "ctx" (o objeto recebido no execute) já vem pronto com, entre outras: reply(texto), reagir(emoji), args (array), q (texto completo depois do comando), sender, pushname, from, isGroup, isDono() (função, retorna bool), isAdm (bool), config (objeto com config.json), arlequina (a instância do socket baileys, pra casos avançados como arlequina.sendMessage).
- Use require('../../arquivos/js/estiloArlequina').caixaArlequina(titulo, corpo) pra formatar toda resposta de texto.
- Sempre trate erros com try/catch e responda algo amigável em caso de falha, nunca deixe estourar exceção.
- NÃO invente helpers/arquivos que não existem. Se precisar de estado persistente tipo ligar/desligar algo, use require('../../arquivos/js/donoState.js') (objeto donoState com donoState.botStatus, e donoState.salvar() pra persistir).
- Responda APENAS com o código JavaScript puro do arquivo, sem nenhuma explicação, sem markdown, sem \`\`\`.

EXEMPLO DE PLUGIN VÁLIDO (siga esse estilo):
${EXEMPLO_PLUGIN}

AGORA GERE UM NOVO PLUGIN:
- name: '${nome}'
- category: '${categoria}'
- O que esse comando deve fazer: ${instrucoes || `deduza pelo NOME do comando ("${nome}") o que ele provavelmente deve fazer, seguindo o tom e as convenções do bot`}

Responda só com o código do arquivo.`

  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=${apiKey}`
    const { data } = await axios.post(url, {
      contents: [{ parts: [{ text: prompt }] }]
    }, { timeout: 45000 })

    const texto = data?.candidates?.[0]?.content?.parts?.[0]?.text
    if (!texto) return { erro: true, mensagem: 'A IA não retornou nenhum código.' }
    return { erro: false, codigo: limparCercas(texto) }
  } catch (e) {
    const status = e?.response?.status
    console.log('❌ ERRO criarcomando (IA):', status || e?.code || e?.message)
    if (status === 400) return { erro: true, mensagem: 'Chave da IA inválida ou prompt rejeitado pelo filtro de segurança.' }
    if (status === 429) return { erro: true, mensagem: 'Limite gratuito diário da IA foi atingido.' }
    return { erro: true, mensagem: 'Não consegui falar com a IA agora.' }
  }
}

module.exports = {
  name: 'criarcomando',
  description: '🧠 [DONO] Cria comando(s) novos com IA, só a partir do nome',
  category: 'dono',
  aliases: ['gerarcomando', 'iacmd'],
  async execute({ args, q, reply, reagir, prefix, isDono, config, commandManager }) {
    if (!isDono()) return reply(caixaArlequina('criarcomando', '❌ Só o *dono* pode usar este comando.'))

    if (!config?.GeminiApiKey) {
      return reply(caixaArlequina('criarcomando', `❌ Precisa configurar "GeminiApiKey" no database/config.json primeiro (grátis em https://aistudio.google.com/apikey).`))
    }

    if (!args.length) {
      return reply(caixaArlequina('criarcomando', `🧠 Como usar:\n\n*${prefix}criarcomando <categoria> <nome1> [nome2...] [| instruções]*\n\nCategorias: ${CATEGORIAS_VALIDAS.join(', ')}\n\nExemplos:\n${prefix}criarcomando dono boton botoff\n${prefix}criarcomando social abraçar | dá um abraço em quem for marcado, com gif`))
    }

    // separa "instruções extra" depois do "|", se tiver
    const [ladoNomes, instrucoes] = q.split('|').map(s => s?.trim())
    const partesNomes = ladoNomes.split(/\s+/).filter(Boolean)

    let categoria = partesNomes[0]?.toLowerCase()
    let nomes
    if (CATEGORIAS_VALIDAS.includes(categoria)) {
      nomes = partesNomes.slice(1)
    } else {
      categoria = 'cmds-aleatorios'
      nomes = partesNomes
    }

    nomes = nomes.map(n => n.toLowerCase().replace(/[^a-z0-9çãõáéíóúâêô]/gi, '')).filter(Boolean)

    if (!nomes.length) {
      return reply(caixaArlequina('criarcomando', '❌ Preciso de pelo menos um nome de comando pra gerar. Ex: *!criarcomando dono boton botoff*'))
    }

    await reagir('🧠')
    await reply(caixaArlequina('criarcomando', `🧠 Gerando ${nomes.length} comando(s) com IA: *${nomes.join(', ')}*\n📁 Categoria: *${categoria}*\n\nIsso pode levar alguns segundos...`))

    const relatorio = []

    for (const nome of nomes) {
      const destino = path.join(__dirname, '..', categoria, `${nome}.js`)

      if (fs.existsSync(destino)) {
        relatorio.push(`⚠️ *${nome}* — já existe um arquivo com esse nome, pulei (apague manualmente se quiser sobrescrever).`)
        continue
      }

      const resultado = await gerarCodigoPlugin({ nome, categoria, instrucoes, apiKey: config.GeminiApiKey })
      if (resultado.erro) {
        relatorio.push(`❌ *${nome}* — ${resultado.mensagem}`)
        continue
      }

      // valida sintaxe ANTES de salvar (só compila, não executa)
      try {
        new vm.Script(resultado.codigo, { filename: `${nome}.js` })
      } catch (eSintaxe) {
        relatorio.push(`❌ *${nome}* — a IA gerou código com erro de sintaxe (${eSintaxe.message}). Tenta de novo, às vezes ela erra.`)
        continue
      }

      try {
        fs.writeFileSync(destino, resultado.codigo, 'utf-8')
        relatorio.push(`✅ *${nome}* — criado em plugins/${categoria}/${nome}.js`)
      } catch (eSalvar) {
        relatorio.push(`❌ *${nome}* — não consegui salvar o arquivo: ${eSalvar.message}`)
      }
    }

    // recarrega os plugins pra já poder usar sem reiniciar o bot
    try { commandManager.carregarPlugins() } catch (eReload) {
      relatorio.push(`\n⚠️ Comandos criados, mas houve um erro ao recarregar: ${eReload.message}. Reinicie o bot manualmente.`)
    }

    await reagir('✅')
    return reply(caixaArlequina('criarcomando', `${relatorio.join('\n')}\n\n💜 Testa com *${prefix}${nomes[0]}* — se algo vier estranho, revise o arquivo manualmente ou apague e gere de novo.`))
  }
}
