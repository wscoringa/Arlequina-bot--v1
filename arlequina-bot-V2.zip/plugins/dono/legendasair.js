/*
 Atalho de !bemvindo saida <texto>, agora restrito ao dono.
 Comando original: setbye, legendasair (existiam 2 arquivos duplicados
 com nome/alias trocados - unifiquei em um só).
*/
const welcomeDB = require('../../arquivos/js/welcomeDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'legendasair',
description: "(Dono) Define a legenda de saída (atalho de !bemvindo saida)",
category: 'dono',
aliases: ['setbye', 'legendasaida'],
async execute({ isDono, from, args, q, qOriginal, reply, reagir, isGroup, prefix }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')

const textoBye = qOriginal || q || args.join(' ')

if (!textoBye || !textoBye.trim()) {
  return reply(`${caixaArlequina("legendasair", `❌ Digite a mensagem de saída.\n\nPlaceholders: {usuario} {grupo} {membros}\n\nEx: ${prefix}legendasair Adeus, {usuario}! 👋`)}`)
}

welcomeDB.setConfig(from, { saida: textoBye })
await reagir('✅')
return reply('✅ Mensagem de saída configurada para este grupo.')

}
}
