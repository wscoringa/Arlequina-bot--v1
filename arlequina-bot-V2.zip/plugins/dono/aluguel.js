/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: aluguel
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'aluguel',
description: "Ativa o aluguel do bot pra um grupo",
category: 'dono',
aliases: [],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  if (!isGrupo) return reply("Só em grupo.")
  
    const valor = Number(args[0])
  
    if (!args[0] || isNaN(valor) || valor <= 0)
      return reply('❌ Digite um valor válido.\n\nEx: !aluguel 2000')
  
    const grupo = from
  
    if (!donoState.aluguel.grupos[grupo]) {
      donoState.aluguel.grupos[grupo] = {
        ativo: false,
        valor: 2000,
        inicio: null,
        fim: null,
        interval: null,
        pago: 0
      }
    }
  
    donoState.aluguel.grupos[grupo].valor = valor
  
    return reply(`${caixaArlequina("aluguel", `💰 Valor atualizado: ${valor}`)}`)
} catch (e) {
console.log('❌ ERRO (aluguel):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
