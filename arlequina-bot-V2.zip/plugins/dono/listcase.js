/*
 Convertido/adaptado para o sistema de plugins da Arlequina Bot.
 Comando original: listcase (bot antigo monolitico, lia entre as
 marcações // INICIO_CASES e // FIM_CASES do index.js).

 Como a Arlequina não usa switch-case, cada comando criado com !addcase
 vira um arquivo em plugins/cmds-aleatorios/ marcado com o comentário
 "// ADDCASE_DINAMICO". Esse comando varre essa pasta e lista só os
 arquivos com essa marca (ou seja, só os comandos criados dinamicamente,
 não os comandos nativos do bot que também moram nessa mesma categoria).
*/
const fs = require('fs')
const path = require('path')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'listcase',
description: "(Dono) Lista os comandos criados dinamicamente com !addcase",
category: 'dono',
aliases: ['casesativas', 'listacase'],
async execute({ isDono, reply, prefix }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


try {
  const pastaDestino = path.join(__dirname, '..', 'cmds-aleatorios')

  if (!fs.existsSync(pastaDestino)) {
    return reply('📂 Nenhuma case adicionada até o momento.')
  }

  const arquivos = fs.readdirSync(pastaDestino).filter(f => f.endsWith('.js'))
  const casesList = []

  for (const arquivo of arquivos) {
    try {
      const full = path.join(pastaDestino, arquivo)
      const conteudo = fs.readFileSync(full, 'utf8')

      if (!conteudo.includes('ADDCASE_DINAMICO')) continue

      const nomeMatch = conteudo.match(/name\s*:\s*['"`]([^'"`]+)['"`]/)
      const nome = nomeMatch ? nomeMatch[1] : path.basename(arquivo, '.js')

      casesList.push(`• ${prefix}${nome}`)
    } catch (_e) {
      continue
    }
  }

  if (casesList.length === 0) {
    return reply('📂 Nenhuma case adicionada até o momento.')
  }

  return reply(`${caixaArlequina("listcase", `📂 *Comandos Criados:*\n\n${casesList.join('\n')}`)}`)
} catch (e) {
  console.error('[LISTCASE]', e)
  await reply('❌ Erro ao listar as cases.')
}

}
}
