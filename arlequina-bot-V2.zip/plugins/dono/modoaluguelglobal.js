/*
 Comando: modoaluguelglobal (aliases: aluguelglobal)

 ON  -> LIGA a exigência de aluguel em todos os grupos (comportamento
        normal: cada grupo precisa ter aluguel próprio ativo; só o
        dono sempre pode usar o bot em qualquer grupo).
 OFF -> DESLIGA a exigência globalmente: o bot passa a funcionar em
        TODOS os grupos, registrados ou não, até ligar de novo.
*/
const donoState = require('../../arquivos/js/donoState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'modoaluguelglobal',
  description: '🌐 Liga/desliga a exigência de aluguel em TODOS os grupos de uma vez',
  category: 'dono',
  aliases: ['aluguelglobal', 'aluguelmodoglobal'],
  async execute({ isDono, args, reply, reagir, prefix }) {
  if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')

    try {
      const opcao = (args[0] || '').toLowerCase()

      if (!['on', 'off', '1', '0', 'ligar', 'desligar'].includes(opcao)) {
        const statusAtual = donoState.aluguel.modoGlobalDesativado
          ? '❌ OFF — aluguel desligado globalmente (bot livre em todos os grupos)'
          : '✅ ON — exigência normal (cada grupo precisa do próprio aluguel)'
        return reply(caixaArlequina('modoaluguelglobal',
`🌐 Status atual: ${statusAtual}

Uso:
${prefix}modoaluguelglobal on — liga a exigência normal (padrão)
${prefix}modoaluguelglobal off — desliga a exigência em TODOS os grupos de uma vez (bot livre pra todo mundo)`))
      }

      const ligar = ['on', '1', 'ligar'].includes(opcao)
      // ON = exigência ligada (modoGlobalDesativado = false)
      // OFF = exigência desligada globalmente (modoGlobalDesativado = true)
      donoState.aluguel.modoGlobalDesativado = !ligar
      if (typeof donoState.salvar === 'function') donoState.salvar()

      await reagir(ligar ? '✅' : '❌')
      await reply(caixaArlequina('modoaluguelglobal',
        ligar
          ? '✅ Exigência de aluguel LIGADA normalmente.\n\nCada grupo precisa ter o próprio aluguel ativo de novo (via #modoaluguel ou #addaluguel). Você (dono) sempre pode usar em qualquer grupo.'
          : '❌ Exigência de aluguel DESLIGADA globalmente!\n\nO bot agora funciona em TODOS os grupos, registrados ou não, até você ligar de novo com este comando.'
      ))
    } catch (e) {
      console.log('❌ ERRO modoaluguelglobal:', e?.message)
      reply('❌ Não consegui mudar essa configuração agora.')
    }
  }
}
