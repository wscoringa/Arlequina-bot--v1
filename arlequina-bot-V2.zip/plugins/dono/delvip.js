const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const { delVip } = require('../../arquivos/js/vipHelper.js')

module.exports = {
  name: 'delvip',
  description: 'Remove VIP de um usuário',
  category: 'dono',
  aliases: ['rmvip', 'removervip'],

  async execute({ arlequina, from, info, reply, reagir, prefix, isDono }) {
    if (!isDono()) {
      return reply(caixaArlequina('DELVIP', '❌ Só o *dono* pode remover VIP.'))
    }

    const alvo =
      info.message?.extendedTextMessage?.contextInfo?.participant ||
      info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]

    if (!alvo) {
      return reply(caixaArlequina('DELVIP', `📌 Use: *${prefix}delvip @usuario*`))
    }

    const numeroAlvo = String(alvo).split('@')[0].replace(/[^0-9]/g, '')
    const ok = delVip(numeroAlvo)

    await reagir(ok ? '✅' : '⚠️')
    await arlequina.sendMessage(from, {
      text: caixaArlequina('DELVIP', ok
        ? `✅ @${numeroAlvo} *não* é mais VIP.`
        : `⚠️ @${numeroAlvo} não estava na lista VIP.`),
      mentions: [alvo]
    }, { quoted: info })
  }
}
