const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: idgp
*/
module.exports = {
name: 'idgp',
description: "(Dono) Mostra o ID (JID) do grupo atual",
category: 'dono',
aliases: [],
async execute({ isDono, arlequina, from, isGroup, reply }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


try {
  if (!isGroup) return reply('Esse comando só funciona em grupos!')

  const metadata = await arlequina.groupMetadata(from)
  const idGp = metadata?.id || from || 'Desconhecido'

  return reply(`${caixaArlequina("idgp", `${idGp}`)}`)
} catch (e) {
  console.log('❌ ERRO DONO (idgp):', e?.message)
  await reply('❌ Não consegui pegar o ID desse grupo.')
}

}
}
