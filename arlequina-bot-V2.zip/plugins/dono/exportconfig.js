/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: exportconfig
*/
const donoState = require('../../arquivos/js/donoState.js')
const adminState = require('../../arquivos/js/adminState.js')
const welcomeDB = require('../../arquivos/js/welcomeDB.js')
const fs = require('fs')
const { dbPath } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'exportconfig',
description: "Exporta um resumo das configurações do bot em JSON",
category: 'dono',
aliases: [],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const resumo = {
  botStatus: donoState.botStatus,
  vips: donoState.vips,
  banidosGlobal: donoState.banidosGlobal,
  aluguelGrupos: Object.keys(donoState.aluguel.grupos),
  welcomeGrupos: Object.keys(welcomeDB.carregar()),
  regrasGrupos: Object.keys(adminState.regras),
  mensagens: donoState.mensagens
  }
  
  await enviar({
  document: Buffer.from(JSON.stringify(resumo, null, 2)),
  mimetype: 'application/json',
  fileName: `config_${Date.now()}.json`
  }, { quoted: msg })
} catch (e) {
console.log('❌ ERRO DONO (exportconfig):', e?.message)
await reply(caixaArlequina("exportconfig", `❌ Não consegui executar esse comando.`))
}

}
}
