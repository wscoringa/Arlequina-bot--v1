/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: aluguelinfo
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'aluguelinfo',
description: "Mostra informações do aluguel de um grupo",
category: 'dono',
aliases: [],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  if (!isGrupo)
  return reply(caixaArlequina("aluguelinfo", `❌ Use esse comando dentro do grupo.`))
  
  const data = donoState.aluguel.grupos[from]
  
  if (!data)
  return reply('📋 Este grupo não está no sistema de aluguel.')
  
  const tempo = data.inicio ? Date.now() - data.inicio : 0
  const horas = Math.floor(tempo / 3600000)
  const minutos = Math.floor((tempo % 3600000) / 60000)
  
  await reply(`
  ╭─━━─🃏💜「 🏠 ALUGUEL DESTE GRUPO 」💜🃏─━━─╮
  
  💰 Valor/hora: ${data.valor}
  🔥 Ativo: ${data.ativo ? 'Sim' : 'Não'}
  💵 Pago: ${data.pago}
  ⏳ Tempo ativo: ${horas}h ${minutos}m
  
  ╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
  `)
} catch (e) {
console.log('❌ ERRO (aluguelinfo):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
