/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: ignorar
*/
const donoState = require('../../arquivos/js/donoState.js')
const adminState = require('../../arquivos/js/adminState.js')
const fs = require('fs')
const { dbPath } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'ignorar',
description: "Ignora silenciosamente um usuário",
category: 'dono',
aliases: ['ign'],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const alvo = msg.message?.extendedTextMessage?.contextInfo?.participant || msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
  
  if (!alvo) {
  await reply('Marque o usuário (@) que deseja ignorar.')
  return
  }
  
  if (!donoState.ignorados) donoState.ignorados = {}
  donoState.ignorados[alvo] = true
  
  await enviar({
  text: `${caixaArlequina("ignorar", `🔇 @${alvo.split('@')[0]} foi ignorado. O bot não vai mais responder essa pessoa.`)}`,
  mentions: [alvo]
  }, { quoted: msg })
} catch (e) {
console.log('❌ ERRO DONO (ignorar):', e?.message)
await reply('❌ Não consegui executar esse comando.')
}

}
}
