/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: listgrupos
*/
const donoState = require('../../arquivos/js/donoState.js')
const adminState = require('../../arquivos/js/adminState.js')
const fs = require('fs')
const { dbPath } = require('../../arquivos/js/rpgDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'listgrupos',
description: "Lista todos os grupos que o bot está",
category: 'dono',
aliases: [],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const grupos = await sock.groupFetchAllParticipating()
  const lista = Object.values(grupos)
  
  if (lista.length === 0)
  return reply('📋 O bot não está em nenhum grupo.')
  
  const texto = lista
  .map((g, i) => `${i + 1}. ${g.subject} (${g.participants.length} membros)`)
  .join('\n')
  
  await reply(`${caixaArlequina("listgrupos", `📋 Grupos (${lista.length}):\n\n${texto}`)}`)
} catch (e) {
console.log('❌ ERRO DONO (listgrupos):', e?.message)
await reply('❌ Não consegui executar esse comando.')
}

}
}
