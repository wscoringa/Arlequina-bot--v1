/*
 Convertido/adaptado para o sistema de plugins da Arlequina Bot.
 Comando original: addcase (bot antigo monolitico, injetava um bloco
 "case 'x': ... break;" direto dentro do index.js usando uma marcação
 // FIM_CASES).

 A Arlequina não usa switch-case: cada comando é um arquivo de plugin
 em plugins/<categoria>/*.js. Então, em vez de escrever dentro do
 index.js (o que nem existe mais aqui e ainda dispararia o watcher de
 arquivo crítico e reiniciaria o bot), esse comando gera um novo
 arquivo de plugin simples (só resposta de texto fixo) dentro de
 plugins/cmds-aleatorios/ e recarrega os plugins na hora.
*/
const fs = require('fs')
const path = require('path')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'addcase',
description: "(Dono) Cria um novo comando simples de resposta de texto",
category: 'dono',
aliases: [],
async execute({ isDono, q, qOriginal, reply, prefix, commandManager }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


try {
  const texto = qOriginal || q || ''
  if (!texto.includes('|')) {
    return reply(`${caixaArlequina("addcase", `⚠️ Uso correto: ${prefix}addcase nome_da_case | Mensagem de resposta`)}`)
  }

  const partes = texto.split('|')
  const caseNameRaw = partes[0].trim().toLowerCase()
  const caseReply = partes.slice(1).join('|').trim()

  if (!caseNameRaw) return reply('⚠️ Informe um nome pro comando.')
  if (!caseReply) return reply('⚠️ Informe a mensagem de resposta.')

  // Sanitiza o nome pra virar um comando/arquivo válido (evita path traversal etc)
  const caseName = caseNameRaw.replace(/[^a-z0-9_-]/g, '')
  if (!caseName) return reply('⚠️ Nome de comando inválido.')

  if (commandManager?.ObterComando(caseName)) {
    return reply(`❌ Já existe um comando chamado '${caseName}'. Escolha outro nome.`)
  }

  const pastaDestino = path.join(__dirname, '..', 'cmds-aleatorios')
  if (!fs.existsSync(pastaDestino)) fs.mkdirSync(pastaDestino, { recursive: true })

  const arquivoDestino = path.join(pastaDestino, `${caseName}.js`)
  if (fs.existsSync(arquivoDestino)) {
    return reply(`❌ Já existe um arquivo pra esse comando. Escolha outro nome.`)
  }

  const conteudoArquivo = `/*
 Comando criado dinamicamente com !addcase por um dono da Arlequina.
 // ADDCASE_DINAMICO
*/
module.exports = {
name: ${JSON.stringify(caseName)},
description: "Comando criado com addcase",
category: 'cmds-aleatorios',
aliases: [],
async execute({ reply }) {
  return reply(${JSON.stringify(caseReply)})
}
}
`

  fs.writeFileSync(arquivoDestino, conteudoArquivo, 'utf8')

  // Recarrega os plugins na hora, sem precisar esperar o watcher/reiniciar
  try { commandManager?.carregarPlugins?.() } catch (_e) {}

  return reply(`✅ Case '${caseName}' adicionada com sucesso!\n\nUse: ${prefix}${caseName}`)
} catch (e) {
  console.error('[ADDCASE]', e)
  await reply(`❌ Erro ao criar o comando:\n${e.message}`)
}

}
}
