const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const frasesOn = [
  'Voltei e já sinto saudade da bagunça... 🃏💜',
  'Acordei, gatinhos! Bora ativar o caos de novo? 😈',
  'A palhaça tá de volta ao trabalho! 🌕💜'
]

module.exports = {
name: 'boton',
description: 'Liga o bot (reativa comandos para todos)',
category: 'dono',
aliases: ['ligar', 'start'],
async execute({ columbina, from, info, reply, isDono }) {
// BUGFIX SEGURANÇA: "isDono" chega aqui como uma FUNÇÃO (() => isDono(sender)), não como true/false. "if (!isDono)" checava se a FUNÇÃO existia (sempre existe = nunca bloqueava ninguém!) em vez de checar o RESULTADO dela. Isso deixava esse comando de dono liberado pra qualquer pessoa usar. Corrigido chamando isDono().
if (!isDono()) return reply('❌ Apenas o dono pode usar este comando!')
global.botLigado = true

const frase = frasesOn[Math.floor(Math.random() * frasesOn.length)]

await reply(`╭─━━─🃏💜「 🌕💜 *ARLEQUINA ON* 💜🌕 」💜🃏─━━─╮
┃ ✅ Operando novamente!
┃ Comandos liberados pra todo mundo.
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _${frase}_`)

try {
const donoId = columbina.user.id?.split(':')[0] + '@s.whatsapp.net'
await columbina.sendMessage(donoId, {text: `${caixaArlequina("boton", `🌕💜 *ARLEQUINA HYPOSELENIA V2 OPERANDO NORMALMENTE* 💜🌕\n\nComandos reativados para todos os usuários.\n\n🃏 _${frase}_`)}`})
} catch(e) {}
}
}
