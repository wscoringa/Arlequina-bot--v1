const donoState = require('../../arquivos/js/donoState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'menubotoes',
  description: '🔘 Liga/desliga os botões interativos do !menu (fica só imagem/vídeo + texto)',
  category: 'dono',
  aliases: ['togglebotoes', 'botoesmenu'],
  async execute({ reply, reagir, args, isDono }) {
    if (!isDono()) return reply(caixaArlequina("menubotoes", `❌ Apenas o dono pode usar este comando.`))

    const modo = args[0]?.toLowerCase()
    if (!['on', 'off', '1', '0'].includes(modo)) {
      return reply(caixaArlequina("menubotoes", `🔘💜 *BOTÕES DO MENU* 💜🔘\n\nStatus atual: *${donoState.menuBotoesOn ? 'Ligado ✅' : 'Desligado ❌'}*\n\n*!menubotoes on* — Ativa os botões interativos\n*!menubotoes off* — Desativa (manda só imagem/vídeo + texto)`))
    }

    const ligar = modo === 'on' || modo === '1'
    donoState.menuBotoesOn = ligar
    if (typeof donoState.salvar === 'function') donoState.salvar()

    await reagir(ligar ? '🔘' : '❌')
    return reply(caixaArlequina("menubotoes", ligar
      ? `✅ Botões interativos do *!menu* ativados!`
      : `❌ Botões interativos do *!menu* desativados.\n📋 Agora o menu manda só imagem/vídeo + texto.`))
  }
}
