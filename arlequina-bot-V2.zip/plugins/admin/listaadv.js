const { listarAvisos } = require('../../arquivos/js/avisosManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'listaadv',
description: 'Lista as advertências manuais registradas no grupo',
category: 'admin',
aliases: ['listadv', 'advs'],
async execute({ columbina, from, info, reply, reagir, isGroup, isAdm, isDono, isMonitor }) {
if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const avisos = listarAvisos(from)
const jids = Object.keys(avisos)
if (!jids.length) {
await reagir('✅')
return reply('✅ Nenhuma advertência registrada neste grupo.')
}

await reagir('⚠️')
const lista = jids.map(j => `• @${j.split('@')[0]} — *${avisos[j]}* advertência(s)`).join('\n')
await columbina.sendMessage(from, {
text: `${caixaArlequina("listaadv", `⚠️💜 *ADVERTÊNCIAS DO GRUPO* 💜⚠️\n\n${lista}`)}`,
mentions: jids
}, { quoted: info })
}
}
