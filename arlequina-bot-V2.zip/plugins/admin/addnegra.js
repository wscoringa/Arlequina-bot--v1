/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: addnegra
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'addnegra',
description: "Adiciona uma palavra/usuário à lista negra",
category: 'admin',
aliases: ['blacklist'],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const groupMetadata = await sock.groupMetadata(from)
  
  const alvo =
  msg.message?.extendedTextMessage?.contextInfo?.participant ||
  msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
  
  if (!alvo)
  return reply(`${caixaArlequina("addnegra", `❌ Marque uma pessoa.\n\nEx: ${prefix}addnegra @membro`)}`)
  
  if (ehDono(alvo, alvo.split('@')[0]))
  return reply('👑 Você não pode colocar meu dono na lista negra, seu arrombado!')
  
  const numeroAlvo = alvo.split('@')[0]
  
  if (!adminState.listanegra[from]) adminState.listanegra[from] = []
  
  if (!adminState.listanegra[from].includes(numeroAlvo)) {
  adminState.listanegra[from].push(numeroAlvo)
  }
  
  await enviar({
  text: `🚫 @${numeroAlvo} foi adicionado à lista negra deste grupo.\n\nSe entrar novamente, será removido automaticamente.`,
  mentions: [alvo]
  })
} catch (e) {
console.log('❌ ERRO (addnegra):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
