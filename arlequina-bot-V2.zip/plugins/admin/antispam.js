/*
 Antispam de verdade: apaga quando a MESMA mensagem é repetida 3+
 vezes seguidas pelo mesmo usuário em menos de 30s. Diferente do
 antiflood (que olha quantidade de mensagens, não o conteúdo).
*/
const adminState = require('../../arquivos/js/adminState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'antispam',
  description: 'Ativa/desativa remoção de mensagens repetidas em sequência',
  category: 'admin',
  aliases: ['as'],
  async execute({ arlequina, from, info, args, reply, reagir, isGroup, isAdm, isDono }) {
    if (!isGroup) return reply('❌ Use em grupos!')
    if (!isAdm && !isDono()) return reply('❌ Apenas admins!')

    const modo = args[0]?.toLowerCase()

    if (modo === 'on' || modo === '1' || modo === 'ativar') {
      adminState.antispam[from] = true
      await reagir('✅')
      return reply(`${caixaArlequina("antispam", `🚫 *ANTISPAM ATIVADO!*\n\nQuem mandar a mesma mensagem 3x seguidas em menos de 30s tem a mensagem apagada.`)}`)
    }

    if (modo === 'off' || modo === '0' || modo === 'desativar') {
      adminState.antispam[from] = false
      await reagir('❌')
      return reply(`${caixaArlequina("antispam", `🚫 *ANTISPAM DESATIVADO!*`)}`)
    }

    return reply(`🚫 Antispam está: ${adminState.antispam[from] ? '✅ ATIVADO' : '❌ DESATIVADO'}\n\nUse:\n!antispam on\n!antispam off`)
  }
}
