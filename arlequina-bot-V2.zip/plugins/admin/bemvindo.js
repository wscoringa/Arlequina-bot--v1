/*
 Painel principal do sistema de Boas-vindas / Saída da Arlequina Bot.
 Unifica o que antes eram 2 sistemas incompatíveis (welkon.json/legendas.json
 x adminState.welcome) em cima de arquivos/js/welcomeDB.js.

 Comandos:
 !bemvindo on / off          -> liga/desliga o sistema no grupo
 !bemvindo foto on / off     -> manda a legenda junto com foto, ou só texto
 !bemvindo legenda <texto>   -> define a legenda de ENTRADA (mesmo que !setwelcome)
 !bemvindo saida <texto>     -> define a legenda de SAÍDA (mesmo que !legendasair)
 !bemvindo test entrada      -> testa a mensagem de entrada
 !bemvindo test saida        -> testa a mensagem de saída
 !bemvindo status            -> mostra a configuração atual
 !bemvindo reset             -> limpa toda a configuração (mesmo que !resetwelcome)

 Placeholders aceitos na legenda: {usuario}  {grupo}  {membros}
 (também aceita os tokens antigos @usuario e @grupo)
*/
const welcomeDB = require('../../arquivos/js/welcomeDB.js')
const boasVindasHandler = require('../../arquivos/js/boasVindasHandler.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'bemvindo',
description: 'Ativa/desativa e configura o sistema de boas-vindas/saída do grupo',
category: 'admin',
aliases: ['welcome', 'boasvindas', 'w'],
async execute({ arlequina, from, info, args, q, qOriginal, reply, reagir, isGroup, isAdm, isDono, isMonitor, prefix }) {

if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const sub = (args[0] || '').toLowerCase()
const cfg = welcomeDB.getConfig(from)

async function pegarNumeroTeste() {
  const testJid = info.key.participant || info.key.remoteJid
  return testJid
}

async function montarPreview(tipo) {
  const groupMetadata = await arlequina.groupMetadata(from).catch(() => null)
  const nomeGrupo = groupMetadata?.subject || 'este grupo'
  const totalMembros = groupMetadata?.participants?.length || 0
  const testJid = await pegarNumeroTeste()
  const numeroUsuario = String(testJid).split('@')[0]

  const bruta = tipo === 'entrada'
    ? (cfg.entrada || welcomeDB.LEGENDA_ENTRADA_PADRAO)
    : (cfg.saida || welcomeDB.LEGENDA_SAIDA_PADRAO)

  const legenda = welcomeDB.renderizarLegenda(bruta, { numeroUsuario, nomeGrupo, totalMembros })
  return { legenda, testJid }
}

if (sub === 'on' || sub === '1' || sub === 'ativar') {
  if (cfg.ativo) return reply('🌕 Sistema de boas-vindas já está ATIVO neste grupo!')
  welcomeDB.setConfig(from, { ativo: true })
  await reagir('✅')
  return reply(`${caixaArlequina("bemvindo", `🌕 SISTEMA DE BOAS-VINDAS ATIVADO!

🎐 Mensagem de boas-vindas será enviada quando alguém entrar.
🎐 Mensagem de despedida será enviada quando alguém sair.

Já vai usar as legendas de exemplo. Pra personalizar:
▸ ${prefix}bemvindo legenda <texto>
▸ ${prefix}bemvindo saida <texto>
▸ ${prefix}bemvindo foto on/off`)}`)
}

if (sub === 'off' || sub === '0' || sub === 'desativar') {
  if (!cfg.ativo) return reply('❄️ Sistema de boas-vindas já está DESATIVADO neste grupo!')
  welcomeDB.setConfig(from, { ativo: false })
  await reagir('✅')
  return reply('❄️ SISTEMA DE BOAS-VINDAS DESATIVADO!\n\nNão vou mais mandar mensagem de entrada/saída aqui.')
}

if (sub === 'foto') {
  const opc = (args[1] || '').toLowerCase()
  if (opc === 'on' || opc === '1' || opc === 'ativar') {
    welcomeDB.setConfig(from, { comFoto: true })
    await reagir('✅')
    return reply('🖼️ Agora a legenda vai ser enviada JUNTO com a foto.\n\nSe o grupo não tiver fundo configurado (!fundobv / !fundosair), uso a FOTO DE PERFIL de quem entrou/saiu.')
  }
  if (opc === 'off' || opc === '0' || opc === 'desativar') {
    welcomeDB.setConfig(from, { comFoto: false })
    await reagir('✅')
    return reply('📝 Agora vou mandar só o TEXTO da legenda, sem foto.')
  }
  return reply(`Use: ${prefix}bemvindo foto on  ou  ${prefix}bemvindo foto off`)
}

if (sub === 'legenda' || sub === 'entrada' || sub === 'set' || sub === 'definir') {
  const novaMsg = (qOriginal || q || '').replace(/^\S+\s*/, '')

  if (!novaMsg || !novaMsg.trim()) {
    welcomeDB.setConfig(from, { entrada: null })
    await reagir('✅')
    return reply(`📝 Legenda de ENTRADA voltou pro padrão de exemplo.\n\nPadrão atual:\n"${welcomeDB.LEGENDA_ENTRADA_PADRAO}"`)
  }

  welcomeDB.setConfig(from, { entrada: novaMsg })
  await reagir('✅')
  return reply(`📝 LEGENDA DE ENTRADA DEFINIDA!\n\n"${novaMsg}"\n\nPlaceholders disponíveis: {usuario} {grupo} {membros}`)
}

if (sub === 'saida' || sub === 'sair' || sub === 'bye') {
  const novaMsg = (qOriginal || q || '').replace(/^\S+\s*/, '')

  if (!novaMsg || !novaMsg.trim()) {
    welcomeDB.setConfig(from, { saida: null })
    await reagir('✅')
    return reply(`📝 Legenda de SAÍDA voltou pro padrão de exemplo.\n\nPadrão atual:\n"${welcomeDB.LEGENDA_SAIDA_PADRAO}"`)
  }

  welcomeDB.setConfig(from, { saida: novaMsg })
  await reagir('✅')
  return reply(`📝 LEGENDA DE SAÍDA DEFINIDA!\n\n"${novaMsg}"\n\nPlaceholders disponíveis: {usuario} {grupo} {membros}`)
}

if (sub === 'test' || sub === 'testar') {
  // usa exatamente a mesma lógica do envio de verdade:
  // fundo configurado > foto de perfil de quem testou > imagem padrão
  const arg = (args[1] || 'entrada').toLowerCase()
  const tipoTeste = arg.includes('sa') || arg.startsWith('rem') || arg.includes('ban') ? 'saida' : 'entrada'
  const testeRemovido = arg.startsWith('rem') || arg.includes('ban')

  const groupMetadata = await arlequina.groupMetadata(from).catch(() => null)
  const testJid = info.key.participant || info.key.remoteJid

  try {
    const { content, origem } = await boasVindasHandler.montarConteudo(arlequina, {
      cfg,
      tipo: tipoTeste,
      removido: testeRemovido,
      pessoa: testJid,
      jid: testJid,
      adminJid: testeRemovido ? testJid : null,
      nomeGrupo: groupMetadata?.subject || 'este grupo',
      totalMembros: groupMetadata?.participants?.length || 0
    })
    await boasVindasHandler.enviar(arlequina, from, content)
    await reagir('✅')
    if (cfg.comFoto) await reply(`🖼️ Imagem usada neste teste: *${origem}*`)
  } catch (e) {
    console.log('❌ ERRO no teste de boas-vindas:', e?.message)
    return reply('❌ Não consegui montar o teste: ' + (e?.message || 'erro'))
  }
  return
}

if (sub === 'reset') {
  welcomeDB.resetConfig(from)
  await reagir('✅')
  return reply('🧹 Configuração de boas-vindas/saída deste grupo foi resetada (voltou tudo pro padrão).')
}

if (sub === 'status') {
  const ativo = cfg.ativo ? '✅ ATIVADO' : '❌ DESATIVADO'
  const foto = cfg.comFoto ? '🖼️ Com foto' : '📝 Só texto'
  return reply(`📊 STATUS DO SISTEMA DE BOAS-VINDAS

🔘 Estado: ${ativo}
${foto}
🎨 Fundo de entrada: ${cfg.fundoEntrada ? 'personalizado' : 'padrão'}
🎨 Fundo de saída: ${cfg.fundoSaida ? 'personalizado' : 'padrão'}
📝 Legenda de entrada: "${cfg.entrada || welcomeDB.LEGENDA_ENTRADA_PADRAO}"
📝 Legenda de saída: "${cfg.saida || welcomeDB.LEGENDA_SAIDA_PADRAO}"

COMANDOS:
▸ ${prefix}bemvindo on / off
▸ ${prefix}bemvindo foto on / off
▸ ${prefix}bemvindo legenda <texto>
▸ ${prefix}bemvindo saida <texto>
▸ ${prefix}bemvindo test entrada / saida / removido
▸ ${prefix}bemvindo reset
▸ ${prefix}fundobv (marcando uma imagem) - define o fundo de entrada
▸ ${prefix}fundosair (marcando uma imagem) - define o fundo de saída`)
}

return reply(`🌕 SISTEMA DE BOAS-VINDAS

Status: ${cfg.ativo ? 'ATIVADO' : 'DESATIVADO'}

📌 COMANDOS:
▸ ${prefix}bemvindo on - Ativar
▸ ${prefix}bemvindo off - Desativar
▸ ${prefix}bemvindo foto on/off - Manda com foto ou só texto
▸ ${prefix}bemvindo legenda <texto> - Legenda de entrada
▸ ${prefix}bemvindo saida <texto> - Legenda de saída
▸ ${prefix}bemvindo test entrada/saida/removido - Testar
▸ ${prefix}bemvindo status - Ver tudo
▸ ${prefix}bemvindo reset - Limpar configuração
▸ ${prefix}fundobv / ${prefix}fundosair - Definir imagem de fundo (marque uma foto)

Placeholders na legenda: {usuario} {grupo} {membros}
Exemplo: ${prefix}bemvindo legenda Seja bem-vindo(a) {usuario} ao {grupo}! 🌸`)

}
}
