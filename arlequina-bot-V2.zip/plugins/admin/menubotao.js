/*
 Comando: menubotao (aliases: togglemenubotao)
 Liga/desliga o modo de menu com botão interativo (carrossel).

 OFF (padrão): manda o menu como vídeo/imagem + legenda de texto —
 formato estável, funciona em qualquer WhatsApp.
 ON: tenta o menu com botão clicável — visual mais bonito, mas é um
 recurso não-oficial que pode não abrir em algumas versões do
 WhatsApp (aparece "sua versão não é compatível" pra quem não suporta).
*/
const donoState = require('../../arquivos/js/donoState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'menubotao',
  description: '🔘 Liga/desliga o menu com botão interativo (ON = visual bonito mas instável / OFF = estável)',
  category: 'admin',
  aliases: ['togglemenubotao', 'botaomenu'],
  async execute({ args, reply, reagir, prefix }) {
    try {
      const opcao = (args[0] || '').toLowerCase()

      if (!['on', 'off', 'ligar', 'desligar', '1', '0'].includes(opcao)) {
        const statusAtual = donoState.botStatus.menuBotoes ? '✅ LIGADO (com botão)' : '❌ DESLIGADO (modo estável)'
        return reply(caixaArlequina('menubotao',
`🔘 Status atual: ${statusAtual}

Uso:
${prefix}menubotao on — ativa o menu com botão (visual bonito, mas pode não abrir em algumas versões do WhatsApp)
${prefix}menubotao off — usa o modo estável (vídeo/imagem + texto, funciona em qualquer WhatsApp)`))
      }

      const ligar = ['on', 'ligar', '1'].includes(opcao)
      donoState.botStatus.menuBotoes = ligar
      if (typeof donoState.salvar === 'function') donoState.salvar()

      await reagir(ligar ? '✅' : '❌')
      await reply(caixaArlequina('menubotao',
        ligar
          ? '✅ Menu com botão ATIVADO.\n\n⚠️ Esse formato pode não abrir em algumas versões do WhatsApp ("sua versão não é compatível"). Se isso acontecer com vocês ou membros do grupo, desligue de novo com este comando.'
          : '❌ Menu com botão DESATIVADO.\n\nAgora o #menu usa o formato estável (vídeo/imagem + texto), que funciona em qualquer WhatsApp.'
      ))
    } catch (e) {
      console.log('❌ ERRO menubotao:', e?.message)
      reply('❌ Não consegui mudar essa configuração agora.')
    }
  }
}
