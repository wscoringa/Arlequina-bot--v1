/*
 Comando: desmute
 #desmute @membro -> remove o silêncio, seja permanente ou temporário.
 Junta o que antes era "desmute" + "forcardesmute" num só comando.
*/
const adminState = require('../../arquivos/js/adminState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'desmute',
description: "Tira o silêncio de um membro (permanente ou temporário)",
category: 'admin',
aliases: ['dm', 'unmute', 'forcardesmute'],
needBotAdmin: true,
async execute({ arlequina, columbina, from, info, reply, reagir, prefix, groupMembers }) {

const sock = arlequina || columbina
const msg = info

const enviar = async (conteudo) => {
try {
  return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
  return reply(conteudo?.text || '🔊')
}
}

try {
  const alvoRaw =
  msg.message?.extendedTextMessage?.contextInfo?.participant ||
  msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]

  if (!alvoRaw)
  return reply(`${caixaArlequina("desmute", `❌ Marque uma pessoa.\n\nEx: ${prefix}desmute @membro`)}`)

  // BUGFIX: mesmo problema do !mute — o WhatsApp às vezes manda o @
  // marcado como "xxxxx@lid" (ID interno), diferente do número real
  // sob o qual o mute foi salvo. Sem resolver isso aqui também, o
  // !desmute apagava a chave errada e a pessoa continuava mutada.
  let alvo = alvoRaw
  if (alvoRaw.endsWith('@lid')) {
    if (global.lidParaNumero?.[alvoRaw]) {
      alvo = global.lidParaNumero[alvoRaw]
    } else {
      const participante = groupMembers?.find(p => p.id === alvoRaw)
      if (participante?.phoneNumber) {
        alvo = participante.phoneNumber
        if (!global.lidParaNumero) global.lidParaNumero = {}
        global.lidParaNumero[alvoRaw] = alvo
      } else {
        try {
          const pn = await arlequina.signalRepository?.lidMapping?.getPNForLID(alvoRaw)
          if (pn) {
            alvo = pn.includes('@') ? pn : `${pn}@s.whatsapp.net`
            if (!global.lidParaNumero) global.lidParaNumero = {}
            global.lidParaNumero[alvoRaw] = alvo
          }
        } catch (eLid) {
          console.log('Erro ao resolver LID do marcado (desmute):', eLid?.message)
        }
      }
    }
  }

  const numeroAlvo = String(alvo || '').split('@')[0].replace(/[^0-9]/g, '')

  if (adminState.mutados[from]) delete adminState.mutados[from][numeroAlvo]
  if (adminState.muteTemporario[from]) delete adminState.muteTemporario[from][numeroAlvo]

  await reagir('🔊')
  await enviar({
    text: `╭─━━─🃏💜「 🔊💜 *DESMUTE* 💜🔊 」💜🃏─━━─╮\n┃ ✅ @${numeroAlvo} pode falar de novo!\n┃ (silêncio permanente e temporário removidos)\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _Liberdade de expressão restaurada... 💜_`,
    mentions: [alvo]
  })
} catch (e) {
console.log('❌ ERRO ADMIN (desmute):', e?.message)
await reply('❌ Não consegui executar esse comando. Verifique se sou admin do grupo.')
}

}
}
