/*
 Comando: statusgrupo (aliases: statusgp2, configsgrupo)

 Mostra ✅/❌ de TODAS as proteções e modos que o grupo tem ligado,
 num card único no estilo visual da Arlequina. Só lista o que
 REALMENTE existe e funciona no bot (nada inventado) — cada linha
 aqui lê direto do mesmo estado que os comandos !antilink, !modorpg,
 !modo18 etc. usam pra decidir o que fazer.
*/
const adminState = require('../../arquivos/js/adminState.js')
const antipyDB = require('../../arquivos/js/antipyDB.js')
const donoState = require('../../arquivos/js/donoState.js')
const welcomeDB = require('../../arquivos/js/welcomeDB.js')
const parceirosDB = require('../../arquivos/js/parceirosDB.js')

function on(v) { return v ? '✅' : '❌' }

module.exports = {
  name: 'statusgrupo',
  description: '🃏 Mostra ✅/❌ de todas as proteções e modos ligados no grupo',
  category: 'admin',
  aliases: ['statusgp2', 'configsgrupo'],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    try {
      if (!isGroup) return reply('❌ Use esse comando dentro de um grupo.')

      await reagir('🃏')

      const welcomeAtivo = !!welcomeDB.getConfig(from)?.ativo
      const aluguelAtivo = !!donoState.aluguel?.grupos?.[from]?.ativo
      const eventoRpgAuto = !donoState.botStatus?.eventorpgAutoOff?.[from] // invertido: default ligado

      const linhas = [
        ['BEM-VINDO', welcomeAtivo],
        ['ANTI-LINK', Object.values(adminState.antilink[from] || {}).some(v => v === true)],
        ['ANTI-BOT', !!adminState.antibot[from]],
        ['ANTI-FAKE', !!adminState.antifake[from]],
        ['ANTI-FLOOD', !!adminState.antiflood[from]?.ligado],
        ['ANTI-VIEWONCE', !!adminState.antiviewonce[from]],
        ['ANTI-DELETE', !!adminState.antidelete[from]],
        ['ANTI-PY (pagamento/fantasma)', !!(adminState.antipagamento[from]?.ativo || antipyDB.getConfig(from).ativo)],
        ['ANTI-DOCUMENTO', !!adminState.antidoc[from]],
        ['ANTI-IMAGEM', !!adminState.antiimagem[from]],
        ['ANTI-CONTATO', !!adminState.anticontato[from]],
        ['ANTI-NOTA', !!adminState.antinota[from]],
        ['ANTI-LOCALIZAÇÃO', !!adminState.antiloc[from]],
        ['ANTI-PALAVRÃO', !!adminState.antipalavra[from]?.ligado],
        ['ANTI-SPAM', !!adminState.antispam[from]],
        ['ANTI-SPAM CMD', !!adminState.antispamcmd[from]?.ligado],
        ['ALUGUEL', aluguelAtivo],
        ['MODO 18+', !!donoState.modo18Grupos?.[from]],
        ['MODO RPG', !!donoState.botStatus?.rpgGrupos?.[from]],
        ['MODO BRINCADEIRA', !!donoState.botStatus?.brincadeiraGrupos?.[from]],
        ['MODO VISUAL', !!donoState.botStatus?.modoVisualGrupos?.[from]],
        ['AUTO-FIGURINHA', !!donoState.botStatus?.autoStickerGrupos?.[from]],
        ['SÓ ADM USA O BOT', !!donoState.botStatus?.soAdmGrupos?.[from]],
        ['SÓ DONO USA O BOT', !!donoState.botStatus?.soDonoGrupos?.[from]],
        ['EVENTO POKÉMON AUTO', eventoRpgAuto],
        ['GRUPO BANIDO', !!donoState.botStatus?.gruposBanidos?.[from]],
      ]

      const corpo = linhas.map(([nome, ativo]) => `│╎𖤛 ${nome}⧽ ${on(ativo)}`).join('\n')
      const totalParceiros = parceirosDB.listarParceiros(from).length
      const limiteLinkParceiro = parceirosDB.getLimiteLink(from)

      const texto =
`╭━✰°❀•°✮•| ⊱🃏⊰ |•°•❀°✾✰━╮
┣⋆⃟ۣۜ᭪➮ 𖡦 𝐒𝐓𝐀𝐓𝐔𝐒 𝐃𝐎 𝐆𝐑𝐔𝐏𝐎 💜
╰━✰°❀•°✮•| ⊱🃏⊰ |•°•❀°✾✰━╯
│╭━━───────━━╮
${corpo}
╰━━━✰°❀•°✮°•❀°✾✰━━━╯
🤝 Parceiros: ${totalParceiros} (limite de link: ${limiteLinkParceiro ? limiteLinkParceiro : 'sem limite'})
🃏 Arlequina Bot 💜😈`

      await reply(texto)
    } catch (e) {
      console.log('❌ ERRO (statusgrupo):', e?.message)
      await reply('❌ Não consegui montar o status do grupo agora.')
    }
  }
}
