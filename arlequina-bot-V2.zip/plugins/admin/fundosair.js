/*
 Comando original: fundosair. Reescrito pra gravar em arquivos/js/welcomeDB.js
 (mesmo motivo do fundobv.js - adminState nunca era lido de verdade).
*/
const welcomeDB = require('../../arquivos/js/welcomeDB.js')
const fs = require('fs')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'fundosair',
description: "Define a imagem de fundo da mensagem de saída (marque uma imagem)",
category: 'admin',
aliases: ['fundosaida', 'fundobye'],
async execute({ info, from, reply, reagir, isGroup, isAdm, isDono, isMonitor, getFileBuffer, prefix }) {

if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

try {
  const quotedImage = info.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage
  const imagemMsg = info.message?.imageMessage || quotedImage

  if (!imagemMsg) return reply(`${caixaArlequina("fundosair", `❌ Envie ou marque (responda) uma imagem com o comando ${prefix}fundosair.`)}`)

  const buffer = await getFileBuffer(imagemMsg, 'image')

  welcomeDB.garantirPastaFundos()
  const caminho = `${welcomeDB.fundosDir}/sair_${from.replace('@g.us', '')}.jpg`
  fs.writeFileSync(caminho, buffer)

  welcomeDB.setConfig(from, { fundoSaida: caminho })

  await reagir('✅')
  return reply(`✅ Imagem de fundo de saída definida!\n\nUse ${prefix}bemvindo test saida para ver como ficou.`)
} catch (e) {
  console.log('❌ ERRO (fundosair):', e?.message)
  return reply('❌ Erro ao salvar a imagem.')
}

}
}
