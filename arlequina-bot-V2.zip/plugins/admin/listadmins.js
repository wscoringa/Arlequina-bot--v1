/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: listadmins
*/
const adminState = require('../../arquivos/js/adminState.js')
const { parseTempo } = require('../../arquivos/js/parseTempo.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'listadmins',
description: "Lista os administradores do grupo",
category: 'admin',
aliases: ['adms'],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, getFileBuffer, commandManager }) {

const sock = arlequina
const msg = info
const jid = sender
const isGrupo = isGroup
const nome = pushname

const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  
  if (!isGrupo)
  return reply('❌ Use esse comando dentro do grupo.')
  
  const metadata = await sock.groupMetadata(from)
  
  const admins = metadata.participants.filter(p => p.admin)
  
  if (admins.length === 0)
  return reply('❌ Nenhum admin encontrado.')
  
  const lista = admins.map(p => `• @${p.id.split('@')[0]}`).join('\n')
  
  await enviar({
  text: `${caixaArlequina("listadmins", `👑 Administradores do grupo:\n\n${lista}`)}`,
  mentions: admins.map(p => p.id)
  }, { quoted: msg })
} catch (e) {
console.log('❌ ERRO ADMIN (listadmins):', e?.message)
await reply('❌ Não consegui executar esse comando. Verifique se sou admin do grupo.')
}

}
}
