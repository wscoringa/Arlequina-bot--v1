const { definirAbertura, obterAgenda, validarHorario } = require('../../arquivos/js/agendaGrupoManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'abrirgp',
  description: 'Agenda a abertura automática do grupo todo dia num horário fixo',
  category: 'admin',
  aliases: ['abrirgpauto', 'agendarabrir'],
  needBotAdmin: true,
  async execute({ from, args, reply, reagir, prefix, isGroup }) {
    if (!isGroup) return reply('❌ Use em grupos!')
    try {
      const arg = (args[0] || '').toLowerCase()

      if (!arg) {
        const atual = obterAgenda(from)
        return reply(caixaArlequina('abrirgp', `⏰ *Abertura automática:* ${atual.abrir ? `*${atual.abrir}*` : '_desativada_'}\n\n💡 Pra definir: ${prefix}abrirgp HH:MM\n💡 Pra desativar: ${prefix}abrirgp off`))
      }

      if (['off', 'desativar', 'cancelar', 'remover'].includes(arg)) {
        definirAbertura(from, null)
        await reagir('❌')
        return reply(caixaArlequina('abrirgp', `✅ Abertura automática *desativada* nesse grupo.`))
      }

      const horario = validarHorario(args[0])
      if (!horario) {
        return reply(caixaArlequina('abrirgp', `❗ Horário inválido.\n\n💡 Use: ${prefix}abrirgp HH:MM\nEx: ${prefix}abrirgp 9:40\nEx: ${prefix}abrirgp 07:00`))
      }

      definirAbertura(from, horario)
      await reagir('🔓')
      return reply(caixaArlequina('abrirgp', `⏰ Prontinho! O grupo vai abrir automaticamente *todo dia às ${horario}*.\n\n💡 Pra desativar: ${prefix}abrirgp off`))
    } catch (e) {
      console.error('ERRO abrirgp:', e?.message)
      await reply('❌ Não consegui agendar agora, tenta de novo.')
    }
  }
}
