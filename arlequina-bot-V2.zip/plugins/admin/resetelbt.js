const { resetarLembretes } = require('../../arquivos/js/lembretesManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'resetelbt',
description: 'Cancela todos os lembretes ativos do grupo',
category: 'admin',
aliases: ['clearlembrete'],
async execute({ from, reply, reagir, isGroup, isAdm, isDono, isMonitor }) {
if (!isGroup) return reply(caixaArlequina("resetelbt", `❌ Este comando só pode ser usado em grupos!`))
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const total = resetarLembretes(from)
await reagir('🧹')
await reply(total > 0 ? `✅ ${total} lembrete(s) cancelado(s).` : '✅ Não havia lembretes ativos neste grupo.')
}
}
