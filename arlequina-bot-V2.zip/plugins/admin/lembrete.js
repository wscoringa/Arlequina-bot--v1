const { parseTempo } = require('../../arquivos/js/parseTempo.js')
const { addLembrete } = require('../../arquivos/js/lembretesManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'lembrete',
description: 'Cria um lembrete que a Arlequina envia no grupo após um tempo',
category: 'admin',
aliases: ['lembretegp'],
async execute({ columbina, from, info, args, q, reply, reagir, isGroup, isAdm, isDono, isMonitor, sender, prefix }) {
if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const tempoTexto = args[0]
const ms = parseTempo(tempoTexto)
if (!ms) {
return reply(`${caixaArlequina("lembrete", `❗ Use: *${prefix}lembrete <tempo> <mensagem>*\n\nEx: *${prefix}lembrete 30m Reunião do grupo!*\n(tempo: s = segundos, m = minutos, h = horas, d = dias)`)}`)
}

const texto = args.slice(1).join(' ') || q
if (!texto) return reply('❗ Escreva a mensagem do lembrete!')

addLembrete(from, texto, sender, ms, async () => {
await columbina.sendMessage(from, {
text: `⏰💜 *LEMBRETE!*\n\n${texto}\n\n_Criado por @${sender.split('@')[0]}_`,
mentions: [sender]
})
})

await reagir('⏰')
await reply(`✅ Lembrete criado! Vou avisar em *${tempoTexto}*.`)
}
}
