/*
 Comando original: resetwelcome. Reescrito pra usar welcomeDB (também apaga
 as imagens de fundo customizadas do disco, se existirem).
*/
const welcomeDB = require('../../arquivos/js/welcomeDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'resetwelcome',
description: "Reseta a configuração de boas-vindas/saída do grupo",
category: 'admin',
aliases: ['resetbemvindo'],
async execute({ from, reply, reagir, isGroup, isAdm, isDono, isMonitor }) {

if (!isGroup) return reply(caixaArlequina("resetwelcome", `❌ Este comando só pode ser usado em grupos!`))
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

try {
  welcomeDB.resetConfig(from)
  await reagir('✅')
  return reply('🧹 Configurações de boas-vindas/saída deste grupo foram limpas.')
} catch (e) {
  console.log('❌ ERRO ADMIN (resetwelcome):', e?.message)
  return reply('❌ Não consegui executar esse comando agora.')
}

}
}
