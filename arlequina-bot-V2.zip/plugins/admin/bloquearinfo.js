/*
 Comando: bloquearinfo (aliases: travarinfo, lockinfo)
 Trava a edição de nome/foto/descrição do grupo pra só ADM poder mexer
 (usa a configuração 'locked' do WhatsApp via Baileys).
*/
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'bloquearinfo',
  description: '🔒 Trava nome/foto/descrição do grupo pra só ADM editar',
  category: 'admin',
  aliases: ['travarinfo', 'lockinfo'],
  async execute({ arlequina, from, reply, reagir, isGroup }) {
    try {
      if (!isGroup) return reply('🔒 Esse comando só funciona em grupos.')
      await arlequina.groupSettingUpdate(from, 'locked')
      await reagir('🔒')
      await reply(caixaArlequina('bloquearinfo', '🔒 Só ADM pode editar nome, foto e descrição do grupo agora.'))
    } catch (e) {
      console.log('❌ ERRO bloquearinfo:', e?.message)
      reply('❌ Não consegui travar isso. Confere se eu sou admin do grupo.')
    }
  }
}
