const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
module.exports = {
name: 'pstatus',
description: 'Mostra o recado (status/about) de um membro marcado/respondido',
category: 'admin',
aliases: ['recado'],
async execute({ columbina, from, info, args, reply, reagir, isGroup, isAdm, isDono, isMonitor, sender }) {
if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const quoted = info.message?.extendedTextMessage?.contextInfo
let alvo = quoted?.participant || quoted?.mentionedJid?.[0]
if (!alvo && args[0]) alvo = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
if (!alvo) alvo = sender

try {
const res = await columbina.fetchStatus(alvo)
const statusTexto = res?.status || res?.[0]?.status || null
if (!statusTexto) {
await reagir('❌')
return reply(`${caixaArlequina("pstatus", `📄 @${alvo.split('@')[0]} não tem recado definido (ou está privado).`)}`)
}
await columbina.sendMessage(from, {
text: `📄 *Recado de @${alvo.split('@')[0]}:*\n\n_${statusTexto}_`,
mentions: [alvo]
}, { quoted: info })
} catch (e) {
await reagir('❌')
await reply('❌ Não consegui buscar o recado desse usuário.')
}
}
}
