const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const parceirosDB = require('../../arquivos/js/parceirosDB.js')

module.exports = {
  name: 'listaparceiros',
  description: '📋 Lista os parceiros cadastrados no grupo',
  category: 'admin',
  aliases: ['parceiros'],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply('❌ Use em grupos!')

    try {
      await reagir('📋')
      const lista = parceirosDB.listarParceiros(from)
      const limite = parceirosDB.getLimiteLink(from)

      if (!lista.length) {
        return reply(caixaArlequina('listaparceiros', '📋 Nenhum parceiro cadastrado nesse grupo ainda.'))
      }

      const linhas = lista.map((p, i) => {
        const usoTxt = limite ? ` (${p.linksUsados || 0}/${limite} links usados)` : ''
        return `${i + 1} - @${p.numero}${usoTxt}`
      }).join('\n')

      const texto = caixaArlequina('listaparceiros',
        `🤝 *Lista de Parceiros do Grupo*\n\n${linhas}\n\n🔢 Limite de link por parceiro: ${limite ? `${limite}` : 'sem limite (ilimitado)'}`)

      return arlequina.sendMessage(from, { text: texto, mentions: lista.map(p => `${p.numero}@s.whatsapp.net`) }, { quoted: info })
    } catch (e) {
      console.log('❌ ERRO (listaparceiros):', e?.message)
      await reply('❌ Não consegui listar os parceiros agora.')
    }
  }
}
