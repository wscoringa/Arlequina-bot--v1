/*
 Comando: fixar (aliases: pin, fixarmsg)
 Fixa a mensagem marcada/respondida no topo do grupo, usando a API de
 pin do WhatsApp (via Baileys).

 OBS: essa é uma função menos comum do Baileys — confirmei a forma
 certa de chamar direto nos tipos da lib (sock.sendMessage com
 { pin: chaveDaMensagem, type: 1, time }), mas não tem como eu testar
 isso de ponta a ponta sem uma conexão real do WhatsApp aqui. Se der
 algum erro estranho quando vocês testarem, me avisem com a mensagem
 de erro exata que aparecer no console.
*/
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const TEMPOS = { '24h': 86400, '7d': 604800, '30d': 2592000 }

module.exports = {
  name: 'fixar',
  description: '📌 Fixa a mensagem marcada no topo do grupo',
  category: 'admin',
  aliases: ['pin', 'fixarmsg'],
  async execute({ arlequina, from, info, args, reply, reagir, isGroup, prefix }) {
    try {
      if (!isGroup) {
        return reply('📌 Esse comando só funciona em grupos.')
      }

      const contextInfo = info.message?.extendedTextMessage?.contextInfo
      const quotedKey = contextInfo?.stanzaId

      if (!quotedKey) {
        return reply(caixaArlequina('fixar', `📌 Marque/responda a mensagem que quer fixar.\n\nEx: responda uma mensagem com ${prefix}fixar\n\n💡 Duração opcional: ${prefix}fixar 7d (padrão: 24h. Opções: 24h, 7d, 30d)`))
      }

      const duracaoArg = (args[0] || '24h').toLowerCase()
      const tempo = TEMPOS[duracaoArg] || TEMPOS['24h']

      const participanteOriginal = contextInfo.participant || from
      const souEuMesmo = participanteOriginal === arlequina.user?.id?.split(':')[0] + '@s.whatsapp.net'

      const chaveMensagem = {
        remoteJid: from,
        id: quotedKey,
        fromMe: souEuMesmo,
        participant: souEuMesmo ? undefined : participanteOriginal
      }

      await arlequina.sendMessage(from, { pin: chaveMensagem, type: 1, time: tempo })

      await reagir('📌')
      await reply(caixaArlequina('fixar', `📌 Mensagem fixada por ${duracaoArg}!`))
    } catch (e) {
      console.log('❌ ERRO fixar:', e?.message)
      reply('❌ Não consegui fixar essa mensagem. (Pode ser que essa função precise de uma versão mais nova do Baileys — veja o log do console pra mais detalhes.)')
    }
  }
}
