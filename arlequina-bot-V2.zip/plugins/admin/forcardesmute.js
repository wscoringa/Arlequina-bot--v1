/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: forcardesmute
*/
const adminState = require('../../arquivos/js/adminState.js')
const { parseTempo } = require('../../arquivos/js/parseTempo.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'forcardesmute',
description: "Força a remoção do silêncio de um membro",
category: 'admin',
aliases: [],
needBotAdmin: true,
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, getFileBuffer, commandManager }) {

const sock = arlequina
const msg = info
const jid = sender
const isGrupo = isGroup
const nome = pushname

const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  
  const groupMetadata = await sock.groupMetadata(from)
  
  const alvo =
  msg.message?.extendedTextMessage?.contextInfo?.participant ||
  msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
  
  if (!alvo)
  return reply('❌ Marque uma pessoa.\n\nEx: !forcardesmute @membro')
  
  const numeroAlvo = alvo.split('@')[0]
  
  if (adminState.mutados[from]) delete adminState.mutados[from][numeroAlvo]
  if (adminState.muteTemporario[from]) delete adminState.muteTemporario[from][numeroAlvo]
  
  await enviar({
  text: `${caixaArlequina("forcardesmute", `🔊 @${numeroAlvo} foi desmutado completamente (permanente e temporário).`)}`,
  mentions: [alvo]
  })
} catch (e) {
console.log('❌ ERRO ADMIN (forcardesmute):', e?.message)
await reply('❌ Não consegui executar esse comando. Verifique se sou admin do grupo.')
}

}
}
