/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: antiviewonce
*/
const adminState = require('../../arquivos/js/adminState.js')
const { parseTempo } = require('../../arquivos/js/parseTempo.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'antiviewonce',
description: "Ativa/desativa reenvio automático de mídias de visualização única",
category: 'admin',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, getFileBuffer, commandManager }) {

const sock = arlequina
const msg = info
const jid = sender
const isGrupo = isGroup
const nome = pushname

const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  
  const groupMetadata = await sock.groupMetadata(from)
  
  const modo = args[0]?.toLowerCase()
  
  const frasesOn = ['👁️ Nenhuma "visualização única" escapa de mim!', '💜 Vou reenviar tudo, nada se esconde aqui!', '🃏 Segredo? Aqui não existe!']
  const frasesOff = ['😌 Beleza, deixei os segredos em paz.', '🙈 Parei de espiar as visualizações únicas.']
  
  if (modo === 'on' || modo === '1' || modo === 'ativar') {
  adminState.antiviewonce[from] = true
  return reply(`╭─━━─🃏💜「 👁️💜 *ANTIVIEWONCE* 💜👁️ 」💜🃏─━━─╮\n┃ ✅ ATIVADO neste grupo!
┃ Mídias de visualização única serão
┃ reenviadas automaticamente.\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${frasesOn[Math.floor(Math.random() * frasesOn.length)]}_`)
  }
  
  if (modo === 'off' || modo === '0' || modo === 'desativar') {
  adminState.antiviewonce[from] = false
  return reply(`╭─━━─🃏💜「 👁️💜 *ANTIVIEWONCE* 💜👁️ 」💜🃏─━━─╮\n┃ ❌ DESATIVADO neste grupo!\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${frasesOff[Math.floor(Math.random() * frasesOff.length)]}_`)
  }
  
  return reply(`👁️ Antiviewonce está: ${adminState.antiviewonce[from] ? '✅ ATIVADO' : '❌ DESATIVADO'}\n\nUse:\n${prefix}antiviewonce on\n${prefix}antiviewonce off`)
} catch (e) {
console.log('❌ ERRO ADMIN (antiviewonce):', e?.message)
await reply(caixaArlequina("antiviewonce", `❌ Não consegui executar esse comando. Verifique se sou admin do grupo.`))
}

}
}
