/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: avisar
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'avisar',
description: "Dá um aviso/advertência a um membro",
category: 'admin',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const groupMetadata = await sock.groupMetadata(from)
  
  const alvo =
  msg.message?.extendedTextMessage?.contextInfo?.participant ||
  msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
  
  if (!alvo)
  return reply(`${caixaArlequina("avisar", `❌ Marque uma pessoa.\n\nEx: ${prefix}avisar @membro Pare de spammar`)}`)
  
  if (ehDono(alvo, alvo.split('@')[0]))
  return reply('👑 Você não pode avisar meu dono, seu arrombado!')
  
  const numeroAlvo = alvo.split('@')[0]
  const motivo = args.slice(1).join(' ') || 'Sem motivo especificado.'
  const maxAvisos = donoState.avisosMaximo[from] || 3
  
  if (!donoState.avisos[from]) donoState.avisos[from] = {}
  if (!donoState.avisos[from][numeroAlvo]) donoState.avisos[from][numeroAlvo] = 0
  
  donoState.avisos[from][numeroAlvo]++
  
  const total = donoState.avisos[from][numeroAlvo]
  
  await enviar({
  text: `⚠️ @${numeroAlvo} recebeu um aviso! (${total}/${maxAvisos})\n\n📋 Motivo: ${motivo}`,
  mentions: [alvo]
  })
  
  if (total >= maxAvisos) {
  
  try {
  await sock.groupParticipantsUpdate(from, [alvo], 'remove')
  await enviar({
  text: `🚫 @${numeroAlvo} atingiu ${maxAvisos} avisos e foi removido do grupo.`,
  mentions: [alvo]
  })
  donoState.avisos[from][numeroAlvo] = 0
  } catch (e) {
  console.log(e)
  }
  
  }
} catch (e) {
console.log('❌ ERRO (avisar):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
