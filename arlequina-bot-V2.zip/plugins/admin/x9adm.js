const { listarAvisos } = require('../../arquivos/js/avisosManager.js')
const { getAtividadeUsuario } = require('../../arquivos/js/atividadeManager.js')
const fs = require('fs')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'x9adm',
description: 'Dossiê completo de um membro: advertências, atividade e status (só ADM)',
category: 'admin',
aliases: ['x9', 'dossie'],
async execute({ arlequina, from, info, args, reply, reagir, isGroup, isAdm, isDono, isMonitor, sender, groupAdmins, prefix }) {
if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Esse comando é só pra ADM, Monitor ou Dono! 🕵️')

const quoted = info.message?.extendedTextMessage?.contextInfo
let alvo = quoted?.participant || quoted?.mentionedJid?.[0]
if (!alvo && args[0]) alvo = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
if (!alvo) return reply(`${caixaArlequina("x9adm", `❗ Marque ou responda a pessoa que você quer investigar!\n\nEx: *${prefix}x9adm @pessoa*`)}`)

await reagir('🕵️')

try {
  const avisos = listarAvisos(from)
  const totalAvisos = avisos[alvo] || 0

  const atividade = getAtividadeUsuario(from, alvo)

  let naListaNegra = false
  try {
    const negraPath = './database/listanegra.json'
    const negra = fs.existsSync(negraPath) ? JSON.parse(fs.readFileSync(negraPath, 'utf-8')) : {}
    naListaNegra = !!negra[from]?.includes?.(alvo) || !!negra[from]?.[alvo]
  } catch (e) {}

  const ehAdmin = (groupAdmins || []).some(a => (a.id || a.jid || a) === alvo)

  const texto =
`╭─━━─🃏💜「 🕵️💜 *DOSSIÊ X9* 💜🕵️ 」💜🃏─━━─╮
┃ 👤 Alvo: @${alvo.split('@')[0]}
┃
┃ ⚠️ Advertências: *${totalAvisos}*
┃ 💬 Mensagens: *${atividade.msgs}*
┃ 🤖 Comandos usados: *${atividade.cmds}*
┃ 🎭 Figurinhas: *${atividade.stickers}*
┃ 📈 Atividade total: *${atividade.total}*
┃ 👑 É admin? *${ehAdmin ? 'Sim' : 'Não'}*
┃ 🚫 Lista negra? *${naListaNegra ? 'Sim' : 'Não'}*
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _A Arlequina vê tudo... 😈_`

  await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
} catch (e) {
  console.error('ERRO x9adm:', e?.message)
  await reply('❌ Não consegui montar o dossiê agora, tenta de novo.')
}
}
}
