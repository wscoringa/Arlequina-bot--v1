/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: setdescgrupo
*/
const adminState = require('../../arquivos/js/adminState.js')
const { parseTempo } = require('../../arquivos/js/parseTempo.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'setdescgrupo',
description: "Muda a descrição do grupo",
category: 'admin',
aliases: [],
needBotAdmin: true,
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, getFileBuffer, commandManager }) {

const sock = arlequina
const msg = info
const jid = sender
const isGrupo = isGroup
const nome = pushname

const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  
  const groupMetadata = await sock.groupMetadata(from)
  
  const novaDesc = args.join(' ')
  
  if (!novaDesc)
  return reply(`${caixaArlequina("setdescgrupo", `❌ Digite a nova descrição do grupo.\n\nEx: ${prefix}setdescgrupo Grupo oficial da Arlequina`)}`)
  
  try {
  await sock.groupUpdateDescription(from, novaDesc)
  await reply('✅ Descrição do grupo atualizada!')
  } catch (e) {
  console.log(e)
  await reply('❌ Não consegui alterar a descrição. Verifique se sou admin.')
  }
} catch (e) {
console.log('❌ ERRO ADMIN (setdescgrupo):', e?.message)
await reply('❌ Não consegui executar esse comando. Verifique se sou admin do grupo.')
}

}
}
