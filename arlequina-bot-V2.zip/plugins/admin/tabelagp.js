const { getTabela } = require('../../arquivos/js/tabelasGpManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'tabelagp',
description: 'Mostra a tabela/lista personalizada do grupo',
category: 'admin',
aliases: ['vertabela'],
async execute({ from, reply, reagir, isGroup, isAdm, isDono, isMonitor, prefix }) {
if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const tabela = getTabela(from)
if (!tabela) {
return reply(`${caixaArlequina("tabelagp", `❌ Não há nenhuma tabela criada neste grupo.\n\n💡 Use *${prefix}criartabelagp* para criar uma.`)}`)
}

await reagir('📋')
const lista = tabela.itens.length
? tabela.itens.map((item, i) => `${i + 1}. ${item}`).join('\n')
: '_Sem itens cadastrados._'

await reply(`📋💜 *${tabela.titulo}* 💜📋\n\n${lista}`)
}
}
