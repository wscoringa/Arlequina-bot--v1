const donoState = require('../../arquivos/js/donoState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'modovisual',
  description: 'Marca mensagens como lidas no grupo sem aparecer online',
  category: 'admin',
  aliases: [],

  async execute({ from, args, reply, reagir, prefix, isGroup, isDono }) {
    if (!isGroup) return reply(caixaArlequina('MODO VISUAL', '❌ Só funciona em *grupos*.'))
    if (!isDono()) return reply(caixaArlequina('MODO VISUAL', '❌ Só o *dono* pode usar este comando.'))

    if (!donoState.botStatus.modoVisualGrupos) donoState.botStatus.modoVisualGrupos = {}

    const modo = (args[0] || '').toLowerCase()

    if (modo === '1' || modo === 'on' || modo === 'ligar' || modo === 'ativar') {
      donoState.botStatus.modoVisualGrupos[from] = true
      try { donoState.salvar() } catch (_) {}
      await reagir('👁️')
      return reply(caixaArlequina('MODO VISUAL', `✅ *Ligado* neste grupo.

O bot marca as mensagens como *vistas* aqui
sem mudar o status online do bot.

*${prefix}modovisual 0* — desliga`))
    }

    if (modo === '0' || modo === 'off' || modo === 'desligar' || modo === 'desativar') {
      delete donoState.botStatus.modoVisualGrupos[from]
      try { donoState.salvar() } catch (_) {}
      await reagir('🙈')
      return reply(caixaArlequina('MODO VISUAL', `❌ *Desligado* neste grupo.

O bot parou de marcar as mensagens como vistas.`))
    }

    const on = !!donoState.botStatus.modoVisualGrupos[from]
    return reply(caixaArlequina('MODO VISUAL', `👁️ Status: ${on ? '✅ LIGADO' : '❌ DESLIGADO'}

*${prefix}modovisual 1* — liga
*${prefix}modovisual 0* — desliga

Só vale *neste grupo*.`))
  }
}
