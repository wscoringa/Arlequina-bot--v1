const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
module.exports = {
name: 'limpar',
description: 'Limpa a tela do chat enviando uma mensagem com várias linhas em branco',
category: 'admin',
aliases: ['clear', 'limpachat', 'clean', 'lc'],
async execute({ arlequina, from, info, reply, reagir, isGroup }) {

if (!isGroup) return reply(caixaArlequina("limpar", `❌ Este comando só pode ser usado em grupos!`))

const LINHAS = 400
const VEZES = 3

try {
  await reagir('🧹')

  const texto = '‎' + '\n'.repeat(LINHAS)
  for (let i = 0; i < VEZES; i++) {
    await arlequina.sendMessage(from, { text: texto }, { quoted: info })
  }

  await reagir('✅')
} catch (e) {
  console.log('❌ ERRO limpar:', e?.message)
  reply('❌ Não consegui limpar o chat agora.')
}

}
}
