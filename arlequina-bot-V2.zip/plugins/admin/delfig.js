/*
 !delfig
 Remove o atalho de uma figurinha registrada (responda a figurinha).
*/
const { remover } = require('../../arquivos/js/figComandos.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'delfig',
  description: '🗑️ Remove o atalho de comando de uma figurinha (só o dono)',
  category: 'admin',
  aliases: ['removerfig', 'unrgfig'],
  async execute({ info, reply, reagir, prefix, isDono }) {
    try {
      if (!isDono()) return reply(caixaArlequina('delfig', `❌ Apenas o dono pode usar este comando.`))

      const stickerMsg = info.message?.extendedTextMessage?.contextInfo?.quotedMessage?.stickerMessage
      if (!stickerMsg) {
        return reply(caixaArlequina('delfig', `⭐ *MENCIONE A FIGURINHA*\n\nResponda (marque) a figurinha que quer remover o atalho com *${prefix}delfig*`))
      }

      const comandoRemovido = remover(stickerMsg)
      if (!comandoRemovido) {
        return reply(caixaArlequina('delfig', `❌ Essa figurinha não tinha nenhum comando registrado.`))
      }

      await reagir('🗑️')
      return reply(caixaArlequina('delfig', `✅ *FIGURINHA REMOVIDA COM SUCESSO* 👋\n\nO atalho pro comando *${comandoRemovido}* foi apagado dessa figurinha.`))
    } catch (e) {
      console.log('❌ ERRO ADMIN (delfig):', e?.message)
      await reply('❌ Não consegui remover essa figurinha agora.')
    }
  }
}
