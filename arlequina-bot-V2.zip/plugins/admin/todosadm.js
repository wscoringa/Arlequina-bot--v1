/*
 Comando: todosadm (aliases: marcaradm, chamaradm)
 Marca só os ADMs do grupo de forma invisível (igual o #hidetag, mas
 só pros administradores, não todo mundo).
*/
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'todosadm',
  description: '🛡️ Marca só os administradores do grupo (invisível), com uma mensagem opcional',
  category: 'admin',
  aliases: ['marcaradm', 'chamaradm'],
  async execute({ arlequina, from, info, q, reply, reagir, isGroup, prefix }) {
    try {
      if (!isGroup) return reply('🛡️ Esse comando só funciona em grupos.')

      await reagir('🛡️')
      const metadata = await arlequina.groupMetadata(from)
      const admins = metadata.participants.filter(p => p.admin).map(p => p.id)

      if (!admins.length) {
        return reply('❌ Não encontrei nenhum admin nesse grupo.')
      }

      const texto = caixaArlequina('todosadm',
`🛡️ Chamando os administradores!

${q ? `💬 ${q}` : '_(sem mensagem)_'}`)

      await arlequina.sendMessage(from, { text: texto, mentions: admins }, { quoted: info })
    } catch (e) {
      console.log('❌ ERRO todosadm:', e?.message)
      reply('❌ Não consegui marcar os admins agora.')
    }
  }
}
