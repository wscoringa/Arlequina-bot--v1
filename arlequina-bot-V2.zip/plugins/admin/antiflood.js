/*
 !antiflood on [mensagens] [segundos] [advertencias]
 Ex: !antiflood on 6 10 3
   -> mais de 6 mensagens (ou figurinhas) em 10 segundos = 1 advertência
   -> ao completar 3 advertências, a pessoa é banida automaticamente
 Valores são opcionais — sem eles usa o padrão (6 msgs / 10s / 3 avisos).
 !antiflood off
*/
const adminState = require('../../arquivos/js/adminState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const PADRAO = { maxMsgs: 6, janelaSeg: 10, maxAdvertencias: 3 }

module.exports = {
  name: 'antiflood',
  description: "Ativa/desativa proteção contra flood (mensagem ou figurinha em excesso), com advertência até banir",
  category: 'admin',
  aliases: [],
  async execute({ from, args, reply, reagir, prefix, isGroup, isAdm, isDono }) {
    if (!isGroup) return reply('❌ Use em grupos!')
    if (!isAdm && !isDono()) return reply('❌ Apenas admins!')

    try {
      const modo = args[0]?.toLowerCase()

      if (modo === 'on' || modo === '1' || modo === 'ativar') {
        const maxMsgs = parseInt(args[1]) || PADRAO.maxMsgs
        const janelaSeg = parseInt(args[2]) || PADRAO.janelaSeg
        const maxAdvertencias = parseInt(args[3]) || PADRAO.maxAdvertencias

        adminState.antiflood[from] = { ligado: true, maxMsgs, janelaSeg, maxAdvertencias }

        await reagir('🌊')
        return reply(`╭─━━─🃏💜「 🌊💜 *ANTIFLOOD* 💜🌊 」💜🃏─━━─╮
┃ ✅ ATIVADO neste grupo!
┃ 📨 Mais de ${maxMsgs} mensagens/figurinhas
┃ em ${janelaSeg}s = 1 advertência
┃ ⚠️ ${maxAdvertencias} advertências = banimento
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _Ordem no grupo, do jeito que a Arlequina gosta!_

📝 Pra mudar: ${prefix}antiflood on <msgs> <segundos> <advertencias>`)
      }

      if (modo === 'off' || modo === '0' || modo === 'desativar') {
        adminState.antiflood[from] = { ligado: false }
        await reagir('❌')
        return reply(`╭─━━─🃏💜「 🌊💜 *ANTIFLOOD* 💜🌊 」💜🃏─━━─╮\n┃ ❌ DESATIVADO neste grupo!\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯`)
      }

      const cfg = adminState.antiflood[from]
      return reply(caixaArlequina('antiflood', `🌊 *ANTIFLOOD*\n\nStatus: *${cfg?.ligado ? 'Ligado ✅' : 'Desligado ❌'}*${cfg?.ligado ? `\n📨 Limite: ${cfg.maxMsgs} msgs/${cfg.janelaSeg}s\n⚠️ Advertências até banir: ${cfg.maxAdvertencias}` : ''}\n\n📝 *Como usar:*\n*${prefix}antiflood on* — ativa com padrão (6 msgs/10s, 3 avisos)\n*${prefix}antiflood on 8 15 5* — 8 msgs em 15s, banir com 5 avisos\n*${prefix}antiflood off* — desativa`))
    } catch (e) {
      console.log('❌ ERRO ADMIN (antiflood):', e?.message)
      await reply(caixaArlequina("antiflood", `❌ Não consegui executar esse comando.`))
    }
  }
}
