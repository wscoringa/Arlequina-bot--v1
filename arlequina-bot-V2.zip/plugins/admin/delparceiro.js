const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const parceirosDB = require('../../arquivos/js/parceirosDB.js')

module.exports = {
  name: 'delparceiro',
  description: '🤝 Remove alguém da lista de parceiros do grupo',
  category: 'admin',
  aliases: ['removeparceiro', 'delparceria'],
  async execute({ from, info, reply, reagir, isGroup, isAdm, isDono, prefix }) {
    if (!isGroup) return reply('❌ Use em grupos!')
    if (!isAdm && !isDono()) return reply('❌ Apenas admins!')

    try {
      const mentioned = info.message?.extendedTextMessage?.contextInfo?.mentionedJid
      const quotedParticipant = info.message?.extendedTextMessage?.contextInfo?.participant
      const alvo = quotedParticipant || mentioned?.[0] || null

      if (!alvo) {
        return reply(caixaArlequina('delparceiro', `❌ Marque a pessoa com @.\n\nEx: *${prefix}delparceiro @pessoa*`))
      }

      const removeu = parceirosDB.delParceiro(from, alvo)
      await reagir(removeu ? '✅' : '❌')
      return reply(removeu
        ? caixaArlequina('delparceiro', `✅ Parceiro removido!\n\n👤 Número: ${parceirosDB.normalizarNumero(alvo)}`)
        : '❌ Essa pessoa não estava na lista de parceiros.')
    } catch (e) {
      console.log('❌ ERRO (delparceiro):', e?.message)
      await reply('❌ Não consegui remover esse parceiro agora.')
    }
  }
}
