const adminState = require('../../arquivos/js/adminState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'antiloc',
  description: '📍 Liga/desliga o antilocalização (apaga localizações compartilhadas no grupo)',
  category: 'admin',
  aliases: ['antilocation', 'antilocalizacao'],
  async execute({ from, reply, reagir, args, isGroup, isAdm, isDono, prefix }) {
    if (!isGroup) return reply('❌ Use em grupos!')
    if (!isAdm && !isDono()) return reply('❌ Apenas admins!')

    const modo = (args[0] || '').toLowerCase()
    if (!['on', 'off'].includes(modo)) {
      return reply(caixaArlequina('antiloc', `📍 *ANTILOC*\n\nStatus: *${adminState.antiloc[from] ? 'Ligado ✅' : 'Desligado ❌'}*\n\n*${prefix}antiloc on* — apaga localização automaticamente\n*${prefix}antiloc off* — desliga`))
    }
    adminState.antiloc[from] = modo === 'on'
    await reagir('📍')
    return reply(caixaArlequina('antiloc', modo === 'on'
      ? `✅ Antiloc ativado! Localizações compartilhadas serão apagadas automaticamente.`
      : `❌ Antiloc desativado.`))
  }
}
