/*
 !limitelinkparceiro <número>
 Define quantos links (grupo/canal) cada parceiro pode mandar antes
 de passar a cair no !antilink normalmente, igual qualquer outra
 pessoa. Sem configurar nada, o padrão é SEM LIMITE (parceiro sempre
 pode mandar link).

 !limitelinkparceiro 0        → remove o limite (ilimitado)
 !limitelinkparceiro reset    → zera a contagem de uso de todo mundo
*/
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const parceirosDB = require('../../arquivos/js/parceirosDB.js')

module.exports = {
  name: 'limitelinkparceiro',
  description: '🔢 Define quantos links cada parceiro pode mandar sem cair no antilink',
  category: 'admin',
  aliases: ['limitelinkparceiros'],
  async execute({ from, reply, reagir, args, isGroup, isAdm, isDono, prefix }) {
    if (!isGroup) return reply('❌ Use em grupos!')
    if (!isAdm && !isDono()) return reply('❌ Apenas admins!')

    try {
      const arg = (args[0] || '').toLowerCase()

      if (!arg) {
        const atual = parceirosDB.getLimiteLink(from)
        return reply(caixaArlequina('limitelinkparceiro',
          `🔢 Limite atual: *${atual ? atual : 'sem limite (ilimitado)'}*\n\n*${prefix}limitelinkparceiro <número>* — define o limite\n*${prefix}limitelinkparceiro 0* — remove o limite\n*${prefix}limitelinkparceiro reset* — zera o uso de todo mundo`))
      }

      if (arg === 'reset') {
        parceirosDB.resetarCotas(from)
        await reagir('🔄')
        return reply(caixaArlequina('limitelinkparceiro', '🔄 Contagem de uso de todos os parceiros foi zerada!'))
      }

      const numero = parseInt(arg)
      if (isNaN(numero) || numero < 0) return reply('❌ Manda um número válido (0 pra ilimitado).')

      parceirosDB.setLimiteLink(from, numero === 0 ? null : numero)
      await reagir('🔢')
      return reply(caixaArlequina('limitelinkparceiro', numero === 0
        ? '✅ Limite removido! Parceiros podem mandar link sem restrição.'
        : `✅ Limite definido: cada parceiro pode mandar *${numero}* link(s) antes de cair no antilink normal.`))
    } catch (e) {
      console.log('❌ ERRO (limitelinkparceiro):', e?.message)
      await reply('❌ Não consegui configurar o limite agora.')
    }
  }
}
