const { zerarAtividade } = require('../../arquivos/js/atividadeManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'zerarativo',
  description: 'Zera o ranking de atividade do grupo',
  category: 'admin',
  aliases: ['resetarativo', 'zerarrank'],
  async execute({ arlequina, from, info, reply, reagir, isGroup, isAdm, isDono }) {
    if (!isGroup) return reply(caixaArlequina("zerarativo", `❌ Só funciona em grupos.`))
    if (!isAdm && !isDono()) return reply('❌ Apenas administradores podem usar este comando.')
    await reagir('🗑️')
    try {
      zerarAtividade(from)
      await reply('✅ Ranking de atividade zerado com sucesso!')
    } catch (e) {
      await reply('❌ Erro ao zerar atividade.')
    }
  }
}
