/*
 !addparceiro @pessoa
 Marca alguém como "parceiro" do grupo — parceiros podem mandar link
 de grupo/canal sem cair no !antilink (até o limite configurado com
 !limitelinkparceiro, se houver).
*/
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const parceirosDB = require('../../arquivos/js/parceirosDB.js')

module.exports = {
  name: 'addparceiro',
  description: '🤝 Marca alguém como parceiro (pode mandar link sem cair no antilink)',
  category: 'admin',
  aliases: ['addparceria'],
  async execute({ from, info, reply, reagir, isGroup, isAdm, isDono, sender, prefix }) {
    if (!isGroup) return reply('❌ Use em grupos!')
    if (!isAdm && !isDono()) return reply('❌ Apenas admins!')

    try {
      const mentioned = info.message?.extendedTextMessage?.contextInfo?.mentionedJid
      const quotedParticipant = info.message?.extendedTextMessage?.contextInfo?.participant
      const alvo = quotedParticipant || mentioned?.[0] || null

      if (!alvo) {
        return reply(caixaArlequina('addparceiro', `❌ Marque a pessoa com @.\n\nEx: *${prefix}addparceiro @pessoa*`))
      }

      parceirosDB.addParceiro(from, alvo, sender)
      await reagir('🤝')
      return reply(caixaArlequina('addparceiro', `🤝 Usuário adicionado como parceiro!\n\n👤 Número: ${parceirosDB.normalizarNumero(alvo)}\n\n💡 Parceiros não caem no !antilink ao mandar link de grupo/canal (a não ser que atinjam o limite, se tiver algum configurado).`))
    } catch (e) {
      console.log('❌ ERRO (addparceiro):', e?.message)
      await reply('❌ Não consegui adicionar esse parceiro agora.')
    }
  }
}
