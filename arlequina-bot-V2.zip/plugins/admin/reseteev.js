const { getEvento, resetarEvento } = require('../../arquivos/js/eventosManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'reseteev',
description: 'Encerra o evento ativo do grupo e mostra a lista final',
category: 'admin',
aliases: ['fecharevento'],
async execute({ columbina, from, info, reply, reagir, isGroup, isAdm, isDono, isMonitor }) {
if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const evento = getEvento(from)
if (!evento) return reply('❌ Não há nenhum evento ativo neste grupo.')

const lista = evento.participantes.length
? evento.participantes.map((j, i) => `${i + 1}. @${j.split('@')[0]}`).join('\n')
: '_Ninguém entrou na lista._'

resetarEvento(from)
await reagir('🏁')
await columbina.sendMessage(from, {
text: `${caixaArlequina("reseteev", `🏁💜 *EVENTO ENCERRADO: ${evento.nome}*\n\n👥 *Lista final (${evento.participantes.length}):*\n${lista}`)}`,
mentions: evento.participantes
}, { quoted: info })
}
}
