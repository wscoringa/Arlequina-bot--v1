const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
module.exports = {
name: 'id',
description: 'Mostra o ID (JID) do grupo, seu ou de um membro marcado/respondido',
category: 'admin',
aliases: [],
async execute({ columbina, from, info, args, reply, isGroup, isAdm, isDono, isMonitor }) {
if (!isGroup) return reply(caixaArlequina("id", `❌ Este comando só pode ser usado em grupos!`))
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const quoted = info.message?.extendedTextMessage?.contextInfo
let alvo = quoted?.participant || quoted?.mentionedJid?.[0]
if (!alvo && args[0]) alvo = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'

let texto = `🆔 *ID DO GRUPO*\n${from}`
if (alvo) {
texto += `\n\n🆔 *ID DO MEMBRO*\n@${alvo.split('@')[0]} → ${alvo}`
return columbina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
}
await reply(texto)
}
}
