/*
 !dominio on/off — ativa/desativa TODAS as proteções do grupo de uma vez.
*/
const adminState = require('../../arquivos/js/adminState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const TIPOS_LINK = ['grupo', 'canal', 'youtube', 'instagram', 'tiktok', 'twitter', 'facebook', 'geral']

function initLinkCfg(from) {
  if (!adminState.antilink[from] || typeof adminState.antilink[from] === 'boolean') {
    adminState.antilink[from] = {
      grupo: false, canal: false, youtube: false, instagram: false,
      tiktok: false, twitter: false, facebook: false, geral: false,
      acao: 'adv', maxAdv: 3
    }
  }
}

function ligarTudo(from) {
  // antilink — todos os tipos
  initLinkCfg(from)
  for (const t of TIPOS_LINK) adminState.antilink[from][t] = true
  adminState.antilink[from].acao = 'adv'
  adminState.antilink[from].maxAdv = 3

  // booleanos simples
  adminState.antibot[from] = true
  adminState.antifake[from] = true
  adminState.antispam[from] = true
  adminState.antidelete[from] = true
  adminState.antiviewonce[from] = true
  adminState.antidoc[from] = true
  adminState.antiloc[from] = true
  adminState.antiimagem[from] = true
  adminState.anticontato[from] = true
  adminState.antinota[from] = true

  // antiflood (esse é objeto, não booleano — sem isso ele "liga" na
  // tela mas não funciona de verdade)
  adminState.antiflood[from] = {
    ligado: true,
    maxMsgs: adminState.antiflood[from]?.maxMsgs || 6,
    janelaSeg: adminState.antiflood[from]?.janelaSeg || 10,
    maxAdvertencias: adminState.antiflood[from]?.maxAdvertencias || 3
  }

  // antipagamento
  if (!adminState.antipagamento[from]) {
    adminState.antipagamento[from] = { ativo: false, acao: 'adv', maxAdv: 3 }
  }
  adminState.antipagamento[from].ativo = true
  adminState.antipagamento[from].acao = 'adv'
  adminState.antipagamento[from].maxAdv = 3

  // antipalavra (liga o filtro; lista de palavras continua a do grupo)
  if (!adminState.antipalavra[from]) {
    adminState.antipalavra[from] = { ligado: false, palavras: [], maxAdvertencias: 3 }
  }
  adminState.antipalavra[from].ligado = true

  // antispamcmd
  if (!adminState.antispamcmd[from]) {
    adminState.antispamcmd[from] = { ligado: false, limite: 5, registro: {} }
  }
  adminState.antispamcmd[from].ligado = true
}

function desligarTudo(from) {
  delete adminState.antilink[from]
  adminState.antibot[from] = false
  adminState.antifake[from] = false
  adminState.antiflood[from] = { ligado: false }
  adminState.antispam[from] = false
  adminState.antidelete[from] = false
  adminState.antiviewonce[from] = false
  adminState.antidoc[from] = false
  adminState.antiloc[from] = false
  adminState.antiimagem[from] = false
  adminState.anticontato[from] = false
  adminState.antinota[from] = false

  if (adminState.antipagamento[from]) adminState.antipagamento[from].ativo = false
  if (adminState.antipalavra[from]) adminState.antipalavra[from].ligado = false
  if (adminState.antispamcmd[from]) adminState.antispamcmd[from].ligado = false
}

module.exports = {
  name: 'dominio',
  description: '🛡️ Ativa/desativa TODAS as proteções do grupo de uma vez',
  category: 'admin',
  aliases: ['expandir', 'expansaodedominio2', 'modoexpansao', 'defesatotal'],

  async execute({ arlequina, from, info, args, reply, reagir, isGroup, isAdm, isDono, sender, prefix }) {
    if (!isGroup) return reply('❌ Use em grupos!')
    if (!isAdm && !isDono()) return reply('❌ Apenas admins e o dono podem usar esse comando!')

    const modo = args[0]?.toLowerCase()

    if (modo === 'on' || modo === '1' || modo === 'ativar') {
      ligarTudo(from)
      await reagir('🛡️')
      return arlequina.sendMessage(from, {
        text:
`╭━━━〔 🛡️ *EXPANSÃO DE DOMÍNIO* 〕━━━╮

⚠️ *MODO DEFESA TOTAL ATIVADO*

🔒 Anti-Link (todos) — ON
🤖 Anti-Bot — ON *(ban em bot detectado)*
👤 Anti-Fake — ON
📢 Anti-Flood — ON
🚫 Anti-Spam — ON
🗑️ Anti-Delete — ON
👁️ Anti-ViewOnce — ON
📄 Anti-Doc — ON
📍 Anti-Loc — ON
🖼️ Anti-Imagem — ON
📇 Anti-Contato — ON
🎤 Anti-Nota — ON
💳 Anti-Pagamento — ON
🔤 Anti-Palavra — ON
⌨️ Anti-SpamCmd — ON

🛡️ Proteção máxima habilitada.
👑 Ativado por: @${String(sender).split('@')[0]}

╰━━━━━━━━━━━━━━━━━━━━━━╯`,
        mentions: [sender]
      }, { quoted: info })
    }

    if (modo === 'off' || modo === '0' || modo === 'desativar') {
      desligarTudo(from)
      await reagir('🔓')
      return arlequina.sendMessage(from, {
        text:
`╭━━━〔 🛡️ *EXPANSÃO DE DOMÍNIO* 〕━━━╮

🔓 *MODO DEFESA DESATIVADO*

Todas as proteções acima foram desligadas.

👑 Desativado por: @${String(sender).split('@')[0]}

╰━━━━━━━━━━━━━━━━━━━━━━╯`,
        mentions: [sender]
      }, { quoted: info })
    }

    return reply(caixaArlequina('dominio', `🛡️ *Como usar:*

*${prefix}dominio on* — ativa **todas** as proteções
*${prefix}dominio off* — desativa todas

Também: *${prefix}expandir on/off*`))
  }
}
