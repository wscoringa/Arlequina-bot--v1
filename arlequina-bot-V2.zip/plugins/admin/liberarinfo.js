/*
 Comando: liberarinfo (aliases: destravarinfo, unlockinfo)
 Libera a edição de nome/foto/descrição do grupo pra qualquer membro.
*/
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'liberarinfo',
  description: '🔓 Libera nome/foto/descrição do grupo pra qualquer membro editar',
  category: 'admin',
  aliases: ['destravarinfo', 'unlockinfo'],
  async execute({ arlequina, from, reply, reagir, isGroup }) {
    try {
      if (!isGroup) return reply('🔓 Esse comando só funciona em grupos.')
      await arlequina.groupSettingUpdate(from, 'unlocked')
      await reagir('🔓')
      await reply(caixaArlequina('liberarinfo', '🔓 Qualquer membro pode editar nome, foto e descrição do grupo agora.'))
    } catch (e) {
      console.log('❌ ERRO liberarinfo:', e?.message)
      reply('❌ Não consegui liberar isso. Confere se eu sou admin do grupo.')
    }
  }
}
