const { criarEvento } = require('../../arquivos/js/eventosManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'evento',
description: 'Cria um evento no grupo para os membros entrarem na lista',
category: 'admin',
aliases: [],
async execute({ from, info, args, q, reply, reagir, isGroup, isAdm, isDono, isMonitor, sender, prefix }) {
if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const nome = args.join(' ') || q
if (!nome) return reply(`${caixaArlequina("evento", `❗ Use: *${prefix}evento <nome do evento>*\n\nEx: *${prefix}evento Sorteio de sexta-feira*`)}`)

criarEvento(from, nome, sender)
await reagir('🎉')
await reply(
`🎉💜 *EVENTO CRIADO!*\n\n📌 *${nome}*\n\n` +
`Use *${prefix}entrarnalista* para participar!\n` +
`Use *${prefix}reseteev* para encerrar o evento.`
)
}
}
