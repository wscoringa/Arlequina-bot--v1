/*
 Comando: mute
 #mute @membro       -> muta permanentemente
 #mute @membro 10m   -> muta temporariamente (aceita s/m/h/d)
 Junta o que antes era "mute" + "mutartemp" num só comando.
*/
const adminState = require('../../arquivos/js/adminState.js')
const { extrairTempo } = require('../../arquivos/js/parseTempo.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'mute',
description: "Silencia um membro (permanente ou por tempo determinado)",
category: 'admin',
aliases: ['m', 'mutartemp'],
needBotAdmin: true,
async execute({ arlequina, columbina, from, info, args, reply, reagir, donoJid, prefix, groupMembers }) {

const sock = arlequina || columbina
const msg = info

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const enviar = async (conteudo) => {
try {
  return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
  return reply(conteudo?.text || '🔇')
}
}

try {
  const alvoRaw =
  msg.message?.extendedTextMessage?.contextInfo?.participant ||
  msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]

  if (!alvoRaw)
  return reply(`${caixaArlequina("mute", `❌ Marque uma pessoa.\n\nEx: ${prefix}mute @membro\nEx: ${prefix}mute @membro 10m`)}`)

  // BUGFIX: o WhatsApp às vezes manda o @ marcado como "xxxxx@lid" (um
  // ID interno, não o número de telefone de verdade). Se a gente salvar
  // o mute sob esse ID errado, ele NUNCA bate com o número real que
  // aparece quando a pessoa manda mensagem de verdade depois — por
  // isso o mute "não funcionava" e a pessoa continuava conseguindo
  // falar normalmente. Resolve pelo número real antes de tudo.
  let alvo = alvoRaw
  if (alvoRaw.endsWith('@lid')) {
    if (global.lidParaNumero?.[alvoRaw]) {
      alvo = global.lidParaNumero[alvoRaw]
    } else {
      const participante = groupMembers?.find(p => p.id === alvoRaw)
      if (participante?.phoneNumber) {
        alvo = participante.phoneNumber
        if (!global.lidParaNumero) global.lidParaNumero = {}
        global.lidParaNumero[alvoRaw] = alvo
      } else {
        try {
          const pn = await arlequina.signalRepository?.lidMapping?.getPNForLID(alvoRaw)
          if (pn) {
            alvo = pn.includes('@') ? pn : `${pn}@s.whatsapp.net`
            if (!global.lidParaNumero) global.lidParaNumero = {}
            global.lidParaNumero[alvoRaw] = alvo
          }
        } catch (eLid) {
          console.log('Erro ao resolver LID do marcado (mute):', eLid?.message)
        }
      }
    }
  }

  const numeroAlvo = String(alvo || '').split('@')[0].replace(/[^0-9]/g, '')

  if (ehDono(alvo, numeroAlvo))
  return reply('👑 Você não pode mutar meu dono!')

  const { tempoMs, tempoTexto } = extrairTempo(args)

  if (tempoMs) {
    if (!adminState.muteTemporario[from]) adminState.muteTemporario[from] = {}
    adminState.muteTemporario[from][numeroAlvo] = Date.now() + tempoMs

    await reagir('🔇')
    await enviar({
      text: `╭─━━─🃏💜「 🔇💜 *MUTE* 💜🔇 」💜🃏─━━─╮\n┃ 🚫 @${numeroAlvo} foi silenciado(a)\n┃ ⏱️ Duração: ${tempoTexto}\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _Fica de castigo por um tempinho... 😈_`,
      mentions: [alvo]
    })
  } else {
    if (!adminState.mutados[from]) adminState.mutados[from] = {}
    adminState.mutados[from][numeroAlvo] = true

    await reagir('🔇')
    await enviar({
      text: `╭─━━─🃏💜「 🔇💜 *MUTE* 💜🔇 」💜🃏─━━─╮\n┃ 🚫 @${numeroAlvo} foi silenciado(a)\n┃ ⏱️ Duração: permanente\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _Agora é só olhar, sem falar... 😈_`,
      mentions: [alvo]
    })
  }
} catch (e) {
console.log('❌ ERRO ADMIN (mute):', e?.message)
await reply('❌ Não consegui executar esse comando. Verifique se sou admin do grupo.')
}

}
}
