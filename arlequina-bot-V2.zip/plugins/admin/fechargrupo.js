/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: fechargrupo
*/
const adminState = require('../../arquivos/js/adminState.js')
const { parseTempo } = require('../../arquivos/js/parseTempo.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'fechargrupo',
description: "Fecha o grupo (somente admins falam)",
category: 'admin',
aliases: ['fcg', 'chat_off'],
needBotAdmin: true,
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, getFileBuffer, commandManager }) {

const sock = arlequina
const msg = info
const jid = sender
const isGrupo = isGroup
const nome = pushname

const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  
  const groupMetadata = await sock.groupMetadata(from)
  
  try {
  await sock.groupSettingUpdate(from, 'announcement')
  await reply(`╭─━━─🃏💜「 🔒💜 *GRUPO FECHADO* 💜🔒 」💜🃏─━━─╮\n┃ ❌ Só administradores podem\n┃ enviar mensagens agora.\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${['🔒 Silêncio, o grupo é só dos admins agora!', '🛡️ Cadeado colocado pela Arlequina!', '🃏 Modo VIP dos admins ativado!'][Math.floor(Math.random() * 3)]}_`)
  } catch (e) {
  console.log(e)
  await reply(caixaArlequina("fechargrupo", `❌ Não consegui fechar o grupo. Verifique se sou admin.`))
  }
} catch (e) {
console.log('❌ ERRO ADMIN (fechargrupo):', e?.message)
await reply('❌ Não consegui executar esse comando. Verifique se sou admin do grupo.')
}

}
}
