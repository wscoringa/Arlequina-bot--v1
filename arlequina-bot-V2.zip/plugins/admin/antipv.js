/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: antipv
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'antipv',
description: "Ativa/desativa bloqueio de mensagens privadas",
category: 'admin',
aliases: [],
async execute({ isDono, arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {
if (!isDono()) return reply('❌ Este comando é exclusivo do dono do bot!')


const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  if (!donoState.botStatus) donoState.botStatus = {}
  
  donoState.botStatus.antipv = !donoState.botStatus.antipv
  
  if (donoState.botStatus.antipv) {
  const frasesOn = ['😈 Só o dono tem esse privilégio!', '🔐 Privado trancado pra maioria!', '🃏 A Arlequina só fala com o chefe agora!']
  await reply(`╭─━━─🃏💜「 ♨️💜 *ANTI PV* 💜♨️ 」💜🃏─━━─╮\n┃ ✅ ATIVADO!\n┃ Só o dono pode falar no\n┃ privado do bot agora.\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${frasesOn[Math.floor(Math.random() * frasesOn.length)]}_`)
  } else {
  const frasesOff = ['😇 Todo mundo pode chamar de novo!', '📲 Privado liberado geral!']
  await reply(`╭─━━─🃏💜「 🚿💜 *ANTI PV* 💜🚿 」💜🃏─━━─╮\n┃ ❌ DESATIVADO!\n┃ Qualquer pessoa pode falar\n┃ no privado do bot.\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${frasesOff[Math.floor(Math.random() * frasesOff.length)]}_`)
  }
} catch (e) {
console.log('❌ ERRO (antipv):', e?.message)
await reply(caixaArlequina("antipv", `❌ Não consegui executar esse comando agora.`))
} finally {
salvarUsuarios(usuarios)
}

}
}
