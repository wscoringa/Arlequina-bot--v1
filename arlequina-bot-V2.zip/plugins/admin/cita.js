/*
 !cita <texto>
 → envia o texto marcando todo mundo do grupo.

 !cita
 → respondendo a uma mensagem, reenvia a mensagem marcando todo mundo.

 Exemplos:

 !cita bom dia
 !cita atenção pessoal
 !cita @todos
*/

const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Desembrulha mensagens temporárias / view-once
function desembrulhar(msg) {
  let atual = msg
  let seguranca = 0

  while (atual && seguranca < 5) {

    if (atual.ephemeralMessage?.message) {
      atual = atual.ephemeralMessage.message
      seguranca++
      continue
    }

    if (atual.viewOnceMessageV2?.message) {
      atual = atual.viewOnceMessageV2.message
      seguranca++
      continue
    }

    if (atual.viewOnceMessageV2Extension?.message) {
      atual = atual.viewOnceMessageV2Extension.message
      seguranca++
      continue
    }

    if (atual.viewOnceMessage?.message) {
      atual = atual.viewOnceMessage.message
      seguranca++
      continue
    }

    break
  }

  return atual || {}
}

module.exports = {
  name: 'cita',

  description:
    '📢 !cita <texto> ou responda uma mensagem para marcar todo mundo',

  category: 'admin',

  aliases: ['citar', 'marcarmsg'],

  async execute({
    arlequina,
    from,
    info,
    args,
    q,
    reply,
    reagir,
    isGroup,
    getFileBuffer
  }) {

    // =====================================================
    // SOMENTE GRUPO
    // =====================================================

    if (!isGroup) {
      return reply('❌ Esse comando só funciona em grupos.')
    }

    const sock = arlequina

    try {

      // =====================================================
      // MENSAGEM ATUAL
      // =====================================================

      const msg = desembrulhar(info?.message || {})

      // =====================================================
      // CONTEXTO DA RESPOSTA
      // =====================================================

      const contexto =
        msg.extendedTextMessage?.contextInfo ||
        msg.imageMessage?.contextInfo ||
        msg.videoMessage?.contextInfo ||
        msg.stickerMessage?.contextInfo ||
        msg.audioMessage?.contextInfo ||
        msg.documentMessage?.contextInfo ||
        msg.conversation?.contextInfo ||
        null

      /*
       * IMPORTANTE:
       *
       * Não faça:
       *
       * const quotedMsg = desembrulhar(contexto?.quotedMessage)
       *
       * porque, quando não existe resposta, isso vira {}.
       *
       * Agora só criamos quotedMsg se realmente existir
       * uma mensagem respondida.
       */

      const quotedRaw = contexto?.quotedMessage

      const quotedMsg = quotedRaw
        ? desembrulhar(quotedRaw)
        : null

      // =====================================================
      // TEXTO DIGITADO
      // =====================================================

      let textoDigitado = ''

      if (Array.isArray(args) && args.length) {
        textoDigitado = args.join(' ').trim()
      }

      // Caso o sistema do bot use q em vez de args
      if (!textoDigitado && q) {
        textoDigitado = String(q).trim()
      }

      // =====================================================
      // PEGAR PARTICIPANTES
      // =====================================================

      const groupMetadata = await sock.groupMetadata(from)

      const participantes = (groupMetadata?.participants || [])
        .map(p => p.id || p.jid || p.lid)
        .filter(Boolean)

      if (!participantes.length) {
        return reply('❌ Não consegui encontrar os participantes do grupo.')
      }

      // =====================================================
      // MODO 1
      // TEXTO NORMAL
      //
      // !cita bom dia
      // =====================================================

      if (textoDigitado) {

        await reagir('📢')

        await sock.sendMessage(
          from,
          {
            text: textoDigitado,
            mentions: participantes
          },
          {
            quoted: info
          }
        )

        return
      }

      // =====================================================
      // MODO 2
      // RESPONDEU UMA MENSAGEM
      //
      // !cita
      // =====================================================

      if (quotedMsg) {

        await reagir('📢')

        // -------------------------------------------------
        // FOTO
        // -------------------------------------------------

        const imageMsg = quotedMsg.imageMessage

        if (imageMsg) {

          const buffer = await getFileBuffer(
            imageMsg,
            'image'
          )

          await sock.sendMessage(
            from,
            {
              image: buffer,
              caption: imageMsg.caption || '📢',
              mentions: participantes
            },
            {
              quoted: info
            }
          )

          return
        }

        // -------------------------------------------------
        // VÍDEO
        // -------------------------------------------------

        const videoMsg = quotedMsg.videoMessage

        if (videoMsg) {

          const buffer = await getFileBuffer(
            videoMsg,
            'video'
          )

          await sock.sendMessage(
            from,
            {
              video: buffer,
              caption: videoMsg.caption || '📢',
              mentions: participantes,
              gifPlayback: !!videoMsg.gifPlayback
            },
            {
              quoted: info
            }
          )

          return
        }

        // -------------------------------------------------
        // DOCUMENTO
        // -------------------------------------------------

        const documentMsg = quotedMsg.documentMessage

        if (documentMsg) {

          const buffer = await getFileBuffer(
            documentMsg,
            'document'
          )

          await sock.sendMessage(
            from,
            {
              document: buffer,
              mimetype:
                documentMsg.mimetype ||
                'application/octet-stream',

              fileName:
                documentMsg.fileName ||
                'arquivo',

              caption:
                documentMsg.caption ||
                '📢',

              mentions: participantes
            },
            {
              quoted: info
            }
          )

          return
        }

        // -------------------------------------------------
        // FIGURINHA
        // -------------------------------------------------

        const stickerMsg = quotedMsg.stickerMessage

        if (stickerMsg) {

          const buffer = await getFileBuffer(
            stickerMsg,
            'sticker'
          )

          await sock.sendMessage(
            from,
            {
              sticker: buffer
            },
            {
              quoted: info
            }
          )

          // Marca todo mundo separadamente
          await sock.sendMessage(
            from,
            {
              text: '📢',
              mentions: participantes
            }
          )

          return
        }

        // -------------------------------------------------
        // ÁUDIO
        // -------------------------------------------------

        const audioMsg = quotedMsg.audioMessage

        if (audioMsg) {

          const buffer = await getFileBuffer(
            audioMsg,
            'audio'
          )

          await sock.sendMessage(
            from,
            {
              audio: buffer,

              mimetype:
                audioMsg.mimetype ||
                'audio/ogg; codecs=opus',

              ptt: !!audioMsg.ptt
            },
            {
              quoted: info
            }
          )

          // Marca todo mundo separadamente
          await sock.sendMessage(
            from,
            {
              text: '📢',
              mentions: participantes
            }
          )

          return
        }

        // -------------------------------------------------
        // TEXTO
        // -------------------------------------------------

        const textoCitado =
          quotedMsg.conversation ||
          quotedMsg.extendedTextMessage?.text ||
          quotedMsg.imageMessage?.caption ||
          quotedMsg.videoMessage?.caption

        if (textoCitado) {

          await sock.sendMessage(
            from,
            {
              text: textoCitado,
              mentions: participantes
            },
            {
              quoted: info
            }
          )

          return
        }

        // -------------------------------------------------
        // TIPO NÃO SUPORTADO
        // -------------------------------------------------

        return reply(
          caixaArlequina(
            'cita',
            '❌ Não consigo reenviar esse tipo de mensagem ainda.'
          )
        )
      }

      // =====================================================
      // NADA FOI INFORMADO
      // =====================================================

      return reply(
        caixaArlequina(
          'cita',
          `📢 *COMANDO CITA*

Use assim:

➜ *!cita bom dia*
➜ *!cita atenção pessoal*
➜ *!cita mensagem importante*

Ou responda uma mensagem com:

➜ *!cita*

📸 Foto
🎥 Vídeo
🎵 Áudio
📄 Documento
🎭 Figurinha
💬 Texto`
        )
      )

    } catch (e) {

      console.log(
        '❌ ERRO ADMIN (cita):',
        e
      )

      return reply(
        caixaArlequina(
          'cita',
          `❌ Não consegui executar o comando.

⚠️ Erro: ${e?.message || 'erro desconhecido'}`
        )
      )
    }
  }
}
