const { rmAviso } = require('../../arquivos/js/avisosManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'rmadv',
description: 'Remove uma advertência manual de um membro',
category: 'admin',
aliases: ['removeadv', 'tiraradv'],
async execute({ columbina, from, info, args, reply, reagir, isGroup, isAdm, isDono, isMonitor }) {
if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const quoted = info.message?.extendedTextMessage?.contextInfo
let alvo = quoted?.participant || quoted?.mentionedJid?.[0]
if (!alvo && args[0] && args[0].startsWith('@')) alvo = args[0].replace('@', '') + '@s.whatsapp.net'
if (!alvo) return reply('❗ Marque ou responda a pessoa para remover uma advertência!')

const restante = rmAviso(from, alvo)
await reagir('✅')
await columbina.sendMessage(from, {
text: `${caixaArlequina("rmadv", `✅ Uma advertência removida de @${alvo.split('@')[0]}.\n📊 Advertências restantes: *${restante}*`)}`,
mentions: [alvo]
}, { quoted: info })
}
}
