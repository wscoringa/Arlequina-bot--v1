/*
 Atalho de !bemvindo saida <texto>. Comando original: setbye, legendasair
 (existiam DOIS arquivos duplicados com nome/alias trocados - unifiquei em um só).
*/
const welcomeDB = require('../../arquivos/js/welcomeDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'legendasair',
description: "Define a legenda de saída (atalho de !bemvindo saida)",
category: 'admin',
aliases: ['setbye', 'legendasaida'],
async execute({ from, args, q, reply, reagir, isGroup, isAdm, isDono, isMonitor, prefix }) {

if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const textoBye = q || args.join(' ')

if (!textoBye || !textoBye.trim()) {
  return reply(`${caixaArlequina("legendasair", `❌ Digite a mensagem de saída.\n\nPlaceholders: {usuario} {grupo} {membros}\n\nEx: ${prefix}legendasair Adeus, {usuario}! 👋`)}`)
}

welcomeDB.setConfig(from, { saida: textoBye })
await reagir('✅')
return reply('✅ Mensagem de saída configurada para este grupo.')

}
}
