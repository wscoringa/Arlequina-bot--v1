/*
 !rgfig <comando>
 Registra a figurinha (marcada/respondida, ou mandada direto com a
 legenda... obs: figurinha não tem legenda, então SEMPRE precisa
 responder a figurinha) pra virar atalho daquele comando. Depois, toda
 vez que alguém mandar aquela MESMA figurinha no grupo, o bot executa
 o comando sozinho — tipo mandar uma figurinha de "banir" e o bot já
 executa !ban em quem for mencionado/citado junto.
*/
const { registrar, idDaFigurinha } = require('../../arquivos/js/figComandos.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'rgfig',
  description: '⭐ Registra uma figurinha como atalho de um comando (só o dono)',
  category: 'admin',
  aliases: ['registrarfig', 'figcomando'],
  async execute({ info, args, reply, reagir, prefix, isDono }) {
    try {
      if (!isDono()) return reply(caixaArlequina('rgfig', `❌ Apenas o dono pode usar este comando.`))

      const comando = (args[0] || '').toLowerCase().replace(new RegExp(`^\\${prefix}`), '')
      if (!comando) {
        return reply(caixaArlequina('rgfig', `⭐ *Como usar:*\nResponda uma figurinha com *${prefix}rgfig <comando>*\n\n📝 Exemplo: *${prefix}rgfig ban*`))
      }

      const stickerMsg = info.message?.extendedTextMessage?.contextInfo?.quotedMessage?.stickerMessage
      if (!stickerMsg) {
        return reply(caixaArlequina('rgfig', `⭐ *MENCIONE A FIGURINHA*\n\nResponda (marque) a figurinha que quer registrar, junto com o comando.\n\n📝 Exemplo: responda a figurinha com *${prefix}rgfig ${comando}*`))
      }

      const id = registrar(stickerMsg, comando)
      if (!id) return reply('❌ Não consegui ler essa figurinha. Tenta com outra.')

      await reagir('⭐')
      return reply(caixaArlequina('rgfig', `✅💜 *FIGURINHA REGISTRADA* 💜✅\n\n👋 Certo, mestre! Acabei de adicionar esse comando no meu banco de dados.\n\n🖐️ Comando: *${comando}*\n✨ ID: ${id.slice(0, 40)}...\n\nAgora, toda vez que alguém mandar essa figurinha, eu executo *${prefix}${comando}* sozinha.`))
    } catch (e) {
      console.log('❌ ERRO ADMIN (rgfig):', e?.message)
      await reply('❌ Não consegui registrar essa figurinha agora.')
    }
  }
}
