const adminState = require('../../arquivos/js/adminState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const { carregarAdvertencias, salvarAdvertencias } = require('../../arquivos/js/protecoes.js')

function initCfg(from) {
  if (!adminState.antilink[from] || typeof adminState.antilink[from] === 'boolean') {
    adminState.antilink[from] = {
      grupo: false, canal: false, telegram: false, youtube: false, instagram: false,
      tiktok: false, twitter: false, facebook: false, geral: false,
      acao: 'adv', maxAdv: 3
    }
  }
  if (!adminState.antilink[from].acao) adminState.antilink[from].acao = 'adv'
  if (!adminState.antilink[from].maxAdv) adminState.antilink[from].maxAdv = 3
}

const TIPOS = ['grupo','canal','telegram','youtube','instagram','tiktok','twitter','facebook','geral']

module.exports = {
  name: 'antilink',
  description: '🔗 Configura antilink do grupo',
  category: 'admin',
  aliases: ['al'],
  async execute({ arlequina, from, info, args, reply, reagir, isGroup, isAdm, isDono, prefix }) {
    if (!isGroup) return reply('❌ Use em grupos!')
    if (!isAdm && !isDono()) return reply('❌ Apenas admins!')

    initCfg(from)
    const cfg = adminState.antilink[from]
    const modo = args[0]?.toLowerCase()
    const param = args[1]?.toLowerCase()

    // ── #antilink ban ──────────────────────────────
    if (modo === 'ban') {
      cfg.acao = 'ban'
      await reagir('🔨')
      return reply(
        `╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n` +
        `┃ 🔗🔨 *ANTILINK — MODO BAN* 🔨🔗\n` +
        `┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n` +
        `┃ ✅ Quem mandar link será *BANIDO*!\n` +
        `╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯`
      )
    }

    // ── #antilink adv <N> ──────────────────────────
    if (modo === 'adv') {
      cfg.acao = 'adv'
      const num = parseInt(param)
      cfg.maxAdv = (num > 0) ? num : 3
      await reagir('⚠️')
      return reply(
        `╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n` +
        `┃ 🔗⚠️ *ANTILINK — MODO ADV* ⚠️🔗\n` +
        `┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n` +
        `┃ ⚠️ Quem mandar link recebe *ADV*\n` +
        `┃ 🔨 Ao *${cfg.maxAdv}ª* advertência: *BAN!*\n` +
        `┃ 💡 Ex: *${prefix}antilink adv 5*\n` +
        `╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯`
      )
    }

    // ── #antilink on [tipo] ────────────────────────
    if (modo === 'on' || modo === '1' || modo === 'ativar') {
      if (!param || param === 'todos' || param === 'all') {
        for (const t of TIPOS) cfg[t] = true
        await reagir('✅')
        return reply(
          `╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n` +
          `┃ 🔗✅ *ANTILINK TOTAL ATIVADO*\n` +
          `┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n` +
          `┃ Todos os links bloqueados!\n` +
          `┃ Ação: *${cfg.acao === 'ban' ? '🔨 BAN direto' : `⚠️ ADV (ban no ${cfg.maxAdv}º)`}*\n` +
          `╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯`
        )
      }
      if (TIPOS.includes(param)) {
        cfg[param] = true
        await reagir('✅')
        return reply(`✅ Antilink de *${param}* ativado!\nAção: *${cfg.acao === 'ban' ? 'BAN direto' : `ADV (ban no ${cfg.maxAdv}º)`}*`)
      }
      return reply('❌ Tipo inválido. Use: grupo, canal, youtube, instagram, tiktok, twitter, facebook, geral, todos')
    }

    // ── #antilink off [tipo] ───────────────────────
    if (modo === 'off' || modo === '0' || modo === 'desativar') {
      if (!param || param === 'todos') {
        delete adminState.antilink[from]
        await reagir('❌')
        return reply('✅ Antilink *completamente desativado*.')
      }
      if (TIPOS.includes(param)) {
        cfg[param] = false
        await reagir('❌')
        return reply(`${caixaArlequina("antilink", `✅ Antilink de *${param}* desativado!`)}`)
      }
    }

    // ── #antilink advslist ─────────────────────────
    if (modo === 'advslist' || modo === 'listaradv') {
      const advs = carregarAdvertencias()
      const gAdv = advs[from] || {}
      if (!Object.keys(gAdv).length) return reply('✅ Nenhuma advertência registrada.')
      const lista = Object.entries(gAdv).map(([num, qtd]) => `┃ 📱 ${num}: *${qtd}/${cfg.maxAdv}* adv`).join('\n')
      return reply(`╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n┃ ⚠️ *ADVERTÊNCIAS DO GRUPO*\n┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n${lista}\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯`)
    }

    // ── #antilink limparadv ────────────────────────
    if (modo === 'limparadv' || modo === 'clearadv') {
      const advs = carregarAdvertencias()
      if (advs[from]) { delete advs[from]; salvarAdvertencias(advs) }
      await reagir('🧹')
      return reply('✅ Advertências do grupo limpas!')
    }

    // ── Status atual (sem args) ────────────────────
    const linhas = TIPOS.map(t => `┃ ${cfg[t] ? '✅' : '❌'} *${t}*`).join('\n')
    return reply(
      `╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n` +
      `┃ 🔗💜 *ANTILINK — STATUS* 💜🔗\n` +
      `┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n` +
      `${linhas}\n` +
      `┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n` +
      `┃ 🎯 *Ação:* ${cfg.acao === 'ban' ? '🔨 BAN direto' : `⚠️ ADV (ban no ${cfg.maxAdv}º)`}\n` +
      `┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n` +
      `┃ *${prefix}antilink on* <tipo/todos>\n` +
      `┃ *${prefix}antilink off* <tipo/todos>\n` +
      `┃ *${prefix}antilink ban* — banir direto\n` +
      `┃ *${prefix}antilink adv* <N> — advertência\n` +
      `┃ *${prefix}antilink advslist* — ver advs\n` +
      `┃ *${prefix}antilink limparadv* — limpar\n` +
      `╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯`
    )
  }
}
