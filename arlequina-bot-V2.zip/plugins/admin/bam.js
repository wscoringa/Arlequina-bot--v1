const { getMemberName } = require('../../arquivos/js/exports.js')
const { convertWhatsAppUser } = require('../../arquivos/js/userManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'bam',
  description: 'Finge que baniu um membro do grupo (brincadeira, não remove ninguém de verdade)',
  category: 'admin',
  aliases: ['bamfake', 'fakeban', 'bam'],

  async execute({ arlequina, from, info, args, reply, reagir, isGroup, groupMembers }) {

    if (!isGroup) return reply('🃏 Esse comando só funciona em grupos, pudinzinho!')

    const quoted = info.message?.extendedTextMessage?.contextInfo
    let target = quoted?.participant || quoted?.mentionedJid?.[0]

    if (!target && args[0]) {
      target = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    }

    if (!target) return reply('🎭 Marca ou responde a mensagem de quem vai levar o *BAM*!')

    const targetJid = convertWhatsAppUser(target, 'jid')
    const nomeAlvo = getMemberName(targetJid, groupMembers) || `@${targetJid.split('@')[0]}`

    try {
      await reagir('⚠️')

      await arlequina.sendMessage(from, {
        text: `${caixaArlequina("bam", `⚠️ *ATENÇÃO!*\n\n🃏 ${nomeAlvo} entrou na mira da Arlequina...\n⏳ Preparando o martelo...`)}`,
        mentions: [targetJid]
      }, { quoted: info })

      await new Promise(r => setTimeout(r, 10000))

      await reagir('🔨')

      await arlequina.sendMessage(from, {
        text: `🔨 *BAM!* 🔨

🚫 ${nomeAlvo} foi expulso do grupo!

😂 HA HA HA HA!

💜 Calma, pudinzinho...
Ainda não foi dessa vez.

A Arlequina só resolveu brincar um pouquinho. 😈🃏

Mas continua aprontando pra ver se da próxima eu não aperto o botão de verdade! 🔨💥`,
        mentions: [targetJid]
      }, { quoted: info })

    } catch (e) {
      console.log('❌ ERRO banfake:', e?.message)
      reply('💔 O martelo da Arlequina travou... tenta de novo daqui a pouco! 🃏')
    }

  }
}
