const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
module.exports = {
name: 'getperfil',
description: 'Pega a foto de perfil de um membro marcado/respondido',
category: 'admin',
aliases: ['fotoperfil'],
async execute({ columbina, from, info, args, reply, reagir, isGroup, isAdm, isDono, isMonitor, sender }) {
if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const quoted = info.message?.extendedTextMessage?.contextInfo
let alvo = quoted?.participant || quoted?.mentionedJid?.[0]
if (!alvo && args[0]) alvo = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
if (!alvo) alvo = sender

try {
const url = await columbina.profilePictureUrl(alvo, 'image')
await columbina.sendMessage(from, {
image: { url },
caption: `${caixaArlequina("getperfil", `🖼️ Foto de perfil de @${alvo.split('@')[0]}`)}`,
mentions: [alvo]
}, { quoted: info })
} catch (e) {
await reagir('❌')
await reply('❌ Esse usuário não tem foto de perfil visível (ou está com a privacidade restrita).')
}
}
}
