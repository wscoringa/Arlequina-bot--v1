const adminState = require('../../arquivos/js/adminState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'antinota',
  description: '🎤 Liga/desliga o antinota (apaga notas de voz/áudio mandados no grupo)',
  category: 'admin',
  aliases: ['antiaudio'],
  async execute({ from, reply, reagir, args, isGroup, isAdm, isDono, prefix }) {
    if (!isGroup) return reply('❌ Use em grupos!')
    if (!isAdm && !isDono()) return reply('❌ Apenas admins!')

    const modo = (args[0] || '').toLowerCase()
    if (!['on', 'off'].includes(modo)) {
      return reply(caixaArlequina('antinota', `🎤 *ANTINOTA*\n\nStatus: *${adminState.antinota[from] ? 'Ligado ✅' : 'Desligado ❌'}*\n\n*${prefix}antinota on* — apaga notas de voz/áudio automaticamente\n*${prefix}antinota off* — desliga`))
    }
    adminState.antinota[from] = modo === 'on'
    await reagir('🎤')
    return reply(caixaArlequina('antinota', modo === 'on'
      ? `✅ Antinota ativado! Notas de voz/áudios serão apagados automaticamente.`
      : `❌ Antinota desativado.`))
  }
}
