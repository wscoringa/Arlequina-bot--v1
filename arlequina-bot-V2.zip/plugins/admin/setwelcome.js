/*
 Atalho de !bemvindo legenda <texto>. Mantido como comando separado porque
 já existia no bot antigo (comando original: setwelcome, bemvindo, legendabv).
 A aliás 'bemvindo' foi removida daqui pra não colidir com o comando
 principal plugins/admin/bemvindo.js (que já tem esse nome).
*/
const welcomeDB = require('../../arquivos/js/welcomeDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'setwelcome',
description: "Define a legenda de entrada (atalho de !bemvindo legenda)",
category: 'admin',
aliases: ['legendabv', 'legendaentrada'],
async execute({ from, args, q, reply, reagir, isGroup, isAdm, isDono, isMonitor, prefix }) {

if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const textoWelcome = q || args.join(' ')

if (!textoWelcome || !textoWelcome.trim()) {
  return reply(`${caixaArlequina("setwelcome", `❌ Digite a mensagem de boas-vindas.\n\nPlaceholders: {usuario} {grupo} {membros}\n\nEx: ${prefix}setwelcome Bem-vindo(a) {usuario} ao {grupo}! 🤡`)}`)
}

welcomeDB.setConfig(from, { entrada: textoWelcome })
await reagir('✅')
return reply('✅ Mensagem de boas-vindas configurada para este grupo.')

}
}
