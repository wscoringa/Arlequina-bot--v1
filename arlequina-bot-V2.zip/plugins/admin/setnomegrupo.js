/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: setnomegrupo
*/
const adminState = require('../../arquivos/js/adminState.js')
const { parseTempo } = require('../../arquivos/js/parseTempo.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'setnomegrupo',
description: "Muda o nome do grupo",
category: 'admin',
aliases: [],
needBotAdmin: true,
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, getFileBuffer, commandManager }) {

const sock = arlequina
const msg = info
const jid = sender
const isGrupo = isGroup
const nome = pushname

const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  
  const groupMetadata = await sock.groupMetadata(from)
  
  const novoNome = args.join(' ')
  
  if (!novoNome)
  return reply(`${caixaArlequina("setnomegrupo", `❌ Digite o novo nome do grupo.\n\nEx: ${prefix}setnomegrupo Galera Top`)}`)
  
  try {
  await sock.groupUpdateSubject(from, novoNome)
  await reply(`✅ Nome do grupo alterado para: ${novoNome}`)
  } catch (e) {
  console.log(e)
  await reply('❌ Não consegui alterar o nome. Verifique se sou admin.')
  }
} catch (e) {
console.log('❌ ERRO ADMIN (setnomegrupo):', e?.message)
await reply('❌ Não consegui executar esse comando. Verifique se sou admin do grupo.')
}

}
}
