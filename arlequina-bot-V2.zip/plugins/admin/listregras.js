/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: listregras
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'listregras',
description: "Lista as regras do grupo",
category: 'admin',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const grupos = Object.entries(adminState.regras)
  .filter(([id, lista]) => lista.length > 0)
  
  if (grupos.length === 0)
  return reply('📋 Nenhum grupo com regras cadastradas.')
  
  const texto = grupos
  .map(([id, lista]) => `• ${id} (${lista.length} regra(s))`)
  .join('\n')
  
  await reply(`${caixaArlequina("listregras", `📋 Grupos com regras:\n\n${texto}`)}`)
} catch (e) {
console.log('❌ ERRO (listregras):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
