const donoState = require('../../arquivos/js/donoState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'modo18',
  description: 'Ativa/desativa o modo +18 no grupo (conteúdo enviado no PV)',
  category: 'admin',
  aliases: ['modonsfw', 'modoadulto'],
  async execute({ reply, reagir, prefix, args, isAdm, isDono, from, isGroup }) {
    if (!isGroup) return reply(caixaArlequina('modo18', '❌ Esse comando só funciona em *grupos*!'))
    if (!isAdm && !isDono()) return reply(caixaArlequina('modo18', '❌ Apenas *administradores* podem usar este comando!'))

    const modo = (args[0] || '').toLowerCase().trim()

    if (!modo || !['1', '0', 'on', 'off', 'ativar', 'desativar'].includes(modo)) {
      const status = donoState.modo18Grupos?.[from] ? '✅ *ATIVADO*' : '❌ *DESATIVADO*'
      return reply(caixaArlequina('modo18', `🔞 *MODO +18*\n\nStatus atual: ${status}\n\n*Como usar:*\n• ${prefix}modo18 1  → ativar\n• ${prefix}modo18 0  → desativar\n\nQuando ativado, os conteúdos +18 são enviados no *PV* da pessoa (não no grupo).`))
    }

    const ativar = ['1', 'on', 'ativar'].includes(modo)

    if (!donoState.modo18Grupos) donoState.modo18Grupos = {}
    donoState.modo18Grupos[from] = ativar
    if (typeof donoState.salvar === 'function') donoState.salvar()

    await reagir(ativar ? '🔞' : '✅')
    return reply(caixaArlequina('modo18', ativar
      ? `✅ *Modo +18 ATIVADO* neste grupo!\n\nAgora os conteúdos (+18) serão enviados no *privado* de quem pedir.\nUse *${prefix}menu18* pra ver as categorias.`
      : `❌ *Modo +18 DESATIVADO* neste grupo.\n\nConteúdos +18 não serão mais enviados enquanto estiver desligado.`))
  }
}
