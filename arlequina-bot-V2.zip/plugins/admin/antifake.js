/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: antifake
*/
const adminState = require('../../arquivos/js/adminState.js')
const { parseTempo } = require('../../arquivos/js/parseTempo.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'antifake',
description: "Ativa/desativa remoção automática de números de fora do Brasil",
category: 'admin',
aliases: ['af'],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, getFileBuffer, commandManager }) {

const sock = arlequina
const msg = info
const jid = sender
const isGrupo = isGroup
const nome = pushname

const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  
  const groupMetadata = await sock.groupMetadata(from)
  
  const modo = args[0]?.toLowerCase()
  
  const frasesOn = ['🚨 Fica de olho, número estranho não passa aqui!', '🕵️ Ninguém de fora entra sem eu ver!', '🔍 Modo detetive ativado!']
  const frasesOff = ['😌 Beleza, relaxei a vigilância.', '🙈 Tá liberado, vou ficar de boa.']

  if (modo === 'on' || modo === '1' || modo === 'ativar') {
  adminState.antifake[from] = true
  return reply(`╭─━━─🃏💜「 🕵️💜 *ANTIFAKE* 💜🕵️ 」💜🃏─━━─╮\n┃ ✅ ATIVADO neste grupo!
┃ Números de fora do Brasil (DDI
┃ diferente de 55) serão removidos
┃ automaticamente ao entrar.\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${frasesOn[Math.floor(Math.random() * frasesOn.length)]}_`)
  }
  
  if (modo === 'off' || modo === '0' || modo === 'desativar') {
  adminState.antifake[from] = false
  return reply(`╭─━━─🃏💜「 🕵️💜 *ANTIFAKE* 💜🕵️ 」💜🃏─━━─╮\n┃ ❌ DESATIVADO neste grupo!\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${frasesOff[Math.floor(Math.random() * frasesOff.length)]}_`)
  }
  
  return reply(`🕵️ Antifake está: ${adminState.antifake[from] ? '✅ ATIVADO' : '❌ DESATIVADO'}\n\nUse:\n${prefix}antifake on\n${prefix}antifake off`)
} catch (e) {
console.log('❌ ERRO ADMIN (antifake):', e?.message)
await reply(caixaArlequina("antifake", `❌ Não consegui executar esse comando. Verifique se sou admin do grupo.`))
}

}
}
