/*
 Comando original: fundobv. Reescrito pra gravar em arquivos/js/welcomeDB.js
 (antes gravava em adminState, que é só em memória e nunca era lido por
 ninguém de verdade - a imagem configurada nunca aparecia).
*/
const welcomeDB = require('../../arquivos/js/welcomeDB.js')
const fs = require('fs')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'fundobv',
description: "Define a imagem de fundo da mensagem de boas-vindas (marque uma imagem)",
category: 'admin',
aliases: ['fundoentrada', 'fundowelcome'],
async execute({ info, from, reply, reagir, isGroup, isAdm, isDono, isMonitor, getFileBuffer, prefix }) {

if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

try {
  const quotedImage = info.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage
  const imagemMsg = info.message?.imageMessage || quotedImage

  if (!imagemMsg) return reply(`${caixaArlequina("fundobv", `❌ Envie ou marque (responda) uma imagem com o comando ${prefix}fundobv.`)}`)

  const buffer = await getFileBuffer(imagemMsg, 'image')

  welcomeDB.garantirPastaFundos()
  const caminho = `${welcomeDB.fundosDir}/bv_${from.replace('@g.us', '')}.jpg`
  fs.writeFileSync(caminho, buffer)

  welcomeDB.setConfig(from, { fundoEntrada: caminho })

  await reagir('✅')
  return reply(`✅ Imagem de fundo das boas-vindas definida!\n\nUse ${prefix}bemvindo test entrada para ver como ficou.`)
} catch (e) {
  console.log('❌ ERRO (fundobv):', e?.message)
  return reply('❌ Erro ao salvar a imagem.')
}

}
}
