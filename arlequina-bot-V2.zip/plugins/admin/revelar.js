const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
module.exports = {
name: 'revelar',
description: 'Revela uma mídia de visualização única (respondendo a ela)',
category: 'admin',
aliases: ['rev'],
async execute({ columbina, from, info, reply, reagir, isGroup, isAdm, isDono, isMonitor, getFileBuffer }) {
if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const quotedMsg = info.message?.extendedTextMessage?.contextInfo?.quotedMessage
if (!quotedMsg) return reply('❗ Responda a uma mídia de visualização única para revelar!')

// Desembrulha viewOnceMessage / viewOnceMessageV2 / viewOnceMessageV2Extension
const conteudo =
quotedMsg.viewOnceMessageV2Extension?.message ||
quotedMsg.viewOnceMessageV2?.message ||
quotedMsg.viewOnceMessage?.message ||
quotedMsg

const imageMsg = conteudo.imageMessage
const videoMsg = conteudo.videoMessage

if (!imageMsg && !videoMsg) {
return reply('❌ A mensagem respondida não é uma mídia de visualização única (ou já foi revelada).')
}

try {
await reagir('👁️')
if (imageMsg) {
const buffer = await getFileBuffer(imageMsg, 'image')
await columbina.sendMessage(from, { image: buffer, caption: '👁️ Mídia revelada!' }, { quoted: info })
} else {
const buffer = await getFileBuffer(videoMsg, 'video')
await columbina.sendMessage(from, { video: buffer, caption: '👁️ Mídia revelada!' }, { quoted: info })
}
} catch (e) {
await reagir('❌')
await reply(`${caixaArlequina("revelar", `❌ Não consegui revelar essa mídia: ${e.message}`)}`)
}
}
}
