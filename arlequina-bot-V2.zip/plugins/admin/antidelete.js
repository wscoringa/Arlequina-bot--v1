/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: antidelete
*/
const adminState = require('../../arquivos/js/adminState.js')
const { parseTempo } = require('../../arquivos/js/parseTempo.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'antidelete',
description: "Ativa/desativa aviso de mensagens apagadas",
category: 'admin',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, getFileBuffer, commandManager }) {

const sock = arlequina
const msg = info
const jid = sender
const isGrupo = isGroup
const nome = pushname

const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  
  const groupMetadata = await sock.groupMetadata(from)
  
  const modo = args[0]?.toLowerCase()
  
  const frasesOn = ['🗑️ Apagou? Eu já vi e vou contar!', '💜 Nada apagado passa despercebido por mim!', '🃏 Tentou esconder, mas eu sou mais esperta!']
  const frasesOff = ['😌 Beleza, deixei as mensagens apagadas em paz.', '🙈 Parei de vigiar o que é deletado.']
  
  if (modo === 'on' || modo === '1' || modo === 'ativar') {
  adminState.antidelete[from] = true
  return reply(`╭─━━─🃏💜「 🗑️💜 *ANTIDELETE* 💜🗑️ 」💜🃏─━━─╮\n┃ ✅ ATIVADO neste grupo!
┃ Se alguém apagar uma mensagem,
┃ eu aviso o que era.\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${frasesOn[Math.floor(Math.random() * frasesOn.length)]}_`)
  }
  
  if (modo === 'off' || modo === '0' || modo === 'desativar') {
  adminState.antidelete[from] = false
  return reply(`╭─━━─🃏💜「 🗑️💜 *ANTIDELETE* 💜🗑️ 」💜🃏─━━─╮\n┃ ❌ DESATIVADO neste grupo!\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${frasesOff[Math.floor(Math.random() * frasesOff.length)]}_`)
  }
  
  return reply(`🗑️ Antidelete está: ${adminState.antidelete[from] ? '✅ ATIVADO' : '❌ DESATIVADO'}\n\nUse:\n${prefix}antidelete on\n${prefix}antidelete off`)
} catch (e) {
console.log('❌ ERRO ADMIN (antidelete):', e?.message)
await reply(caixaArlequina("antidelete", `❌ Não consegui executar esse comando. Verifique se sou admin do grupo.`))
}

}
}
