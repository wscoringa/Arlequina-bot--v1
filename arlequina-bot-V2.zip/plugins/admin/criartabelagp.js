const { criarTabela } = require('../../arquivos/js/tabelasGpManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'criartabelagp',
description: 'Cria uma tabela/lista personalizada para o grupo',
category: 'admin',
aliases: ['tabelacriar'],
async execute({ from, args, q, reply, reagir, isGroup, isAdm, isDono, isMonitor, sender, prefix }) {
if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const textoCompleto = args.join(' ') || q
if (!textoCompleto) {
return reply(`${caixaArlequina("criartabelagp", `❗ Use: *${prefix}criartabelagp <título> | <item1, item2, item3>*\n\nEx: *${prefix}criartabelagp Escala da semana | Segunda, Terça, Quarta*`)}`)
}

const [tituloRaw, itensRaw] = textoCompleto.split('|')
const titulo = (tituloRaw || 'Tabela do Grupo').trim()
const itens = (itensRaw || '').split(',').map(i => i.trim()).filter(Boolean)

criarTabela(from, titulo, itens, sender)
await reagir('📋')
await reply(
`📋 Tabela *"${titulo}"* criada com ${itens.length} item(ns)!\n\nUse *${prefix}tabelagp* para visualizar.`
)
}
}
