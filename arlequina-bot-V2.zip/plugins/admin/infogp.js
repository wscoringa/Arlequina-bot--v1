/*
 Comando: infogp (aliases: infogrupo2, dadosgp)
 Mostra quem criou o grupo, quando foi criado, e lista os admins
 (diferente do #infogrupo, que foca mais nas configurações do bot).
*/
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'infogp',
  description: '📋 Mostra quem criou o grupo, data de criação e lista de admins',
  category: 'admin',
  aliases: ['dadosgp'],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    try {
      if (!isGroup) {
        return reply(caixaArlequina('infogp', '❌ Use esse comando dentro de um grupo.'))
      }

      await reagir('📋')
      const metadata = await arlequina.groupMetadata(from)

      const criador = metadata.owner
        ? `@${metadata.owner.split('@')[0]}`
        : '_Não disponível (grupo antigo ou criado antes da atualização do WhatsApp)_'

      const criadoEm = metadata.creation
        ? new Date(metadata.creation * 1000).toLocaleString('pt-BR', { dateStyle: 'long', timeStyle: 'short' })
        : '_Não disponível_'

      const admins = metadata.participants.filter(p => p.admin)
      const listaAdmins = admins.length
        ? admins.map((a, i) => `${i + 1}. @${a.id.split('@')[0]}${a.admin === 'superadmin' ? ' 👑' : ''}`).join('\n')
        : '_Nenhum admin encontrado_'

      const mentions = [
        ...(metadata.owner ? [metadata.owner] : []),
        ...admins.map(a => a.id)
      ]

      const texto = caixaArlequina('infogp',
`📛 *Grupo:* ${metadata.subject}
👑 *Criado por:* ${criador}
📅 *Criado em:* ${criadoEm}
👥 *Membros:* ${metadata.participants.length}

🛡️ *Admins (${admins.length}):*
${listaAdmins}`)

      await arlequina.sendMessage(from, { text: texto, mentions }, { quoted: info })
    } catch (e) {
      console.log('❌ ERRO infogp:', e?.message)
      reply('❌ Não consegui buscar as informações do grupo. Confere se eu sou admin.')
    }
  }
}
