/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: infogrupo
*/
const adminState = require('../../arquivos/js/adminState.js')
const { parseTempo } = require('../../arquivos/js/parseTempo.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'infogrupo',
description: "Mostra informações e configurações do grupo",
category: 'admin',
aliases: ['descgp'],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, getFileBuffer, commandManager }) {

const sock = arlequina
const msg = info
const jid = sender
const isGrupo = isGroup
const nome = pushname

const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  
  if (!isGrupo)
  return reply(caixaArlequina("infogrupo", `❌ Use esse comando dentro do grupo.`))
  
  const metadata = await sock.groupMetadata(from)
  
  const totalAdmins = metadata.participants.filter(p => p.admin).length
  const descricao = metadata.desc || '_Sem descrição definida_'
  
  await reply(`
  ╭─━━─🃏💜「 ℹ️ INFO DO GRUPO 」💜🃏─━━─╮
  
  📛 Nome: ${metadata.subject}
  🆔 ID: ${metadata.id}
  👥 Membros: ${metadata.participants.length}
  👑 Admins: ${totalAdmins}
  📝 Descrição: ${descricao}
  📋 Regras cadastradas: ${(adminState.regras[from] || []).length}
  🔗 Antilink: ${adminState.antilink[from] ? 'Ativado' : 'Desativado'}
  🕵️ Antifake: ${adminState.antifake[from] ? 'Ativado' : 'Desativado'}
  🌊 Antiflood: ${adminState.antiflood[from] ? 'Ativado' : 'Desativado'}
  🤖 Antibot: ${adminState.antibot[from] ? 'Ativado' : 'Desativado'}
  👁️ Antiviewonce: ${adminState.antiviewonce[from] ? 'Ativado' : 'Desativado'}
  🗑️ Antidelete: ${adminState.antidelete[from] ? 'Ativado' : 'Desativado'}
  🔇 Mutados: ${Object.keys(adminState.mutados[from] || {}).length}
  
  ╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
  `)
} catch (e) {
console.log('❌ ERRO ADMIN (infogrupo):', e?.message)
await reply('❌ Não consegui executar esse comando. Verifique se sou admin do grupo.')
}

}
}
