/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: kick, remover
*/
const adminState = require('../../arquivos/js/adminState.js')
const { parseTempo } = require('../../arquivos/js/parseTempo.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'kick',
description: "Remove um membro do grupo",
category: 'admin',
aliases: ["remover", "k"],
needBotAdmin: true,
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, getFileBuffer, commandManager }) {

const sock = arlequina
const msg = info
const jid = sender
const isGrupo = isGroup
const nome = pushname

const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  
  const groupMetadata = await sock.groupMetadata(from)
  
  const alvo =
  msg.message?.extendedTextMessage?.contextInfo?.participant ||
  msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
  
  if (!alvo)
  return reply('❌ Marque uma pessoa.\n\nEx: !kick @membro')
  
  if (ehDono(alvo, alvo.split('@')[0]))
  return reply('👑 Você não pode remover meu dono, seu arrombado!')
  
  try {
  await sock.groupParticipantsUpdate(from, [alvo], 'remove')
  await enviar({
  text: `${caixaArlequina("kick", `👋 @${alvo.split('@')[0]} foi removido do grupo.`)}`,
  mentions: [alvo]
  })
  } catch (e) {
  console.log(e)
  await reply('❌ Não consegui remover. Verifique se sou admin.')
  }
} catch (e) {
console.log('❌ ERRO ADMIN (kick):', e?.message)
await reply('❌ Não consegui executar esse comando. Verifique se sou admin do grupo.')
}

}
}
