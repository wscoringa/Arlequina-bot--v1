const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const { resolverJidReal } = require('../../arquivos/js/lidHelper.js')
const { ehMensagemPagamento } = require('../../arquivos/js/protecoes.js')
const { sleep } = require('../../arquivos/js/exports.js')

/*
  BUGFIX: antes só olhava pra info.message.extendedTextMessage.contextInfo.
  Isso funciona quando a resposta é um texto puro, mas mensagens do tipo
  "convite de pagamento" (as que os bots de spam tipo Titanium usam pra
  disfarçar o link) às vezes fazem o cliente do WhatsApp mandar a
  resposta dentro de outro contêiner (ex: um contextInfo dentro de outra
  chave, não de extendedTextMessage) — então o comando achava que não
  tinha resposta nenhuma e nunca chegava a tentar apagar. Essa função
  procura o contextInfo em QUALQUER subtipo da mensagem.
*/
function acharContextInfo(message) {
  if (!message || typeof message !== 'object') return null
  for (const valor of Object.values(message)) {
    if (valor && typeof valor === 'object' && valor.contextInfo?.stanzaId) {
      return valor.contextInfo
    }
  }
  return null
}

module.exports = {
name: 'apagar',
description: 'Apaga uma mensagem do grupo',
category: 'admin',
aliases: ['del', 'delete', 'd', 'deletar'],
async execute({ columbina, from, info, reply, reagir, isGroup, isAdm, isBotAdm, isDono, isMonitor }) {
if (!isGroup) return reply(caixaArlequina("apagar", `❌ Este comando só pode ser usado em grupos!`))
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')
if (!isBotAdm) return reply('❌ O bot precisa ser administrador para isso!')

const quoted = acharContextInfo(info.message)

if (!quoted) return reply('❌ Responda a mensagem que deseja apagar!')

// BUGFIX: o "participant" da mensagem citada às vezes vem com o
// sufixo de dispositivo (:0) ou como LID em vez do número normal —
// isso fazia o WhatsApp recusar o apagar (a mesma raiz do bug que já
// corrigimos no !namorar/!casar). Normaliza antes de mandar.
const participantReal = await resolverJidReal(columbina, quoted.participant)

// MELHORIA: mensagem de "convite de pagamento" (usada como disfarce
// pelo spam tipo Titanium) não sai só com um delete comum — o
// WhatsApp costuma ignorar. O jeito que funciona é: manda uma
// mensagem vazia (só pra gerar um ID nosso), "edita" ela forçando o
// ID a ser o mesmo da mensagem de pagamento (nocauteia o conteúdo
// original) e só DEPOIS apaga os dois. Fazemos isso só quando a
// mensagem marcada realmente é do tipo pagamento; qualquer outra
// mensagem continua indo pelo apagar normal (mais simples e rápido).
if (ehMensagemPagamento(quoted.quotedMessage)) {
  try {
    const msgVazia = await columbina.sendMessage(from, { text: '' })
    const idEditada = msgVazia?.key?.id
    if (!idEditada) throw new Error('falha ao gerar ID auxiliar')

    await columbina.sendMessage(from, {
      text: '🗑️ Mensagem de pagamento removida',
      edit: { id: idEditada }
    }, { messageId: quoted.stanzaId })

    await sleep(500)

    await columbina.sendMessage(from, {
      delete: {
        remoteJid: from,
        id: quoted.stanzaId,
        fromMe: false,
        participant: participantReal
      }
    })

    await sleep(500)

    try {
      await columbina.sendMessage(from, { delete: { remoteJid: from, id: idEditada, fromMe: true } })
    } catch (_e1) {
      try {
        await columbina.sendMessage(from, { delete: { remoteJid: from, id: idEditada, fromMe: false, participant: columbina.user.id } })
      } catch (eLimpeza) {
        console.log('⚠️ Não consegui limpar a mensagem auxiliar do apagar:', eLimpeza?.message)
      }
    }

    await reagir('🗑️')
  } catch (e) {
    console.log('❌ ERRO !apagar (mensagem de pagamento):', e?.message)
    reply(`❌ Não foi possível apagar a mensagem de pagamento! (${e?.message || 'erro desconhecido'})`)
  }
  return
}

try {
await columbina.sendMessage(from, {
delete: {
remoteJid: from,
fromMe: false,
id: quoted.stanzaId,
participant: participantReal
}})
await reagir('🗑️')
} catch (e) {
console.log('❌ ERRO !apagar:', e?.message)
reply(`❌ Não foi possível apagar a mensagem! (${e?.message || 'erro desconhecido'})`)
}}}
