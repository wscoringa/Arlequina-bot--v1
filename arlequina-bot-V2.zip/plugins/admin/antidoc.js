const adminState = require('../../arquivos/js/adminState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'antidoc',
  description: '📄 Liga/desliga o antidocumento (apaga arquivos/documentos mandados no grupo)',
  category: 'admin',
  aliases: ['antidocumento'],
  async execute({ from, reply, reagir, args, isGroup, isAdm, isDono, prefix }) {
    if (!isGroup) return reply('❌ Use em grupos!')
    if (!isAdm && !isDono()) return reply('❌ Apenas admins!')

    const modo = (args[0] || '').toLowerCase()
    if (!['on', 'off'].includes(modo)) {
      return reply(caixaArlequina('antidoc', `📄 *ANTIDOC*\n\nStatus: *${adminState.antidoc[from] ? 'Ligado ✅' : 'Desligado ❌'}*\n\n*${prefix}antidoc on* — apaga documentos automaticamente\n*${prefix}antidoc off* — desliga`))
    }
    adminState.antidoc[from] = modo === 'on'
    await reagir('📄')
    return reply(caixaArlequina('antidoc', modo === 'on'
      ? `✅ Antidoc ativado! Documentos/arquivos serão apagados automaticamente.`
      : `❌ Antidoc desativado.`))
  }
}
