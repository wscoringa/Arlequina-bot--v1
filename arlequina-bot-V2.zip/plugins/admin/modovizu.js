/*
 Comando: modovizu (era !modovisual, mas por-grupo — agora é GLOBAL)

 Liga/desliga em TODAS as conversas de uma vez: marca as mensagens
 como lidas sem deixar o bot aparecer "online".

 BUGFIX/DESCOBERTA: marcar como lida no código (readMessages) só faz
 o "✔✔ azul" aparecer pra OUTRA pessoa se a configuração de
 privacidade "Confirmações de leitura" da CONTA do bot no WhatsApp
 estiver LIGADA. Se estiver desligada, o Baileys manda um "read-self"
 (só conta como lido pra você mesmo, ninguém mais vê) — por isso o
 comando parecia "não fazer nada de verdade". Agora, ao ligar o
 modovizu, o próprio bot já ativa essa configuração de privacidade
 sozinho, e avisa se algo impedir isso.
*/
const donoState = require('../../arquivos/js/donoState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'modovizu',
  description: '👁️ Marca mensagens como lidas em TUDO (global), sem aparecer online',
  category: 'admin',
  aliases: ['modovisual', 'modovisualglobal'],

  async execute({ args, reply, reagir, prefix, isDono, arlequina, columbina }) {
    if (!isDono()) return reply(caixaArlequina('MODOVIZU', '❌ Só o *dono* pode usar este comando.'))

    const sock = arlequina || columbina
    const modo = (args[0] || '').toLowerCase()

    if (modo === '1' || modo === 'on' || modo === 'ligar' || modo === 'ativar') {
      donoState.botStatus.modoVisualGlobal = true
      try { donoState.salvar() } catch (_) {}

      // Tenta ligar a confirmação de leitura da conta automaticamente —
      // sem isso o "visto" não é enviado pra ninguém, só fica marcado
      // localmente (o famoso "lido só pra mim").
      let avisoPrivacidade = ''
      try {
        await sock.updateReadReceiptsPrivacy('all')
        const check = await sock.fetchPrivacySettings(true)
        if (check?.readreceipts !== 'all') {
          avisoPrivacidade = '\n\n⚠️ Tentei ativar, mas o WhatsApp não confirmou. Verifique manualmente: *Configurações do WhatsApp > Privacidade > Confirmações de leitura* e deixe LIGADO nesse número que o bot usa.'
        }
      } catch (ePriv) {
        avisoPrivacidade = `\n\n⚠️ Não consegui checar/ativar a privacidade automaticamente (${ePriv?.message || 'erro desconhecido'}). Confira manualmente em *Configurações do WhatsApp > Privacidade > Confirmações de leitura*.`
      }

      await reagir('👁️')
      return reply(caixaArlequina('MODOVIZU', `✅ *Ligado globalmente!*\n\nO bot agora marca as mensagens como *vistas* em todas as conversas (grupos e privado), sem mudar o status online.${avisoPrivacidade}\n\n*${prefix}modovizu 0* — desliga`))
    }

    if (modo === '0' || modo === 'off' || modo === 'desligar' || modo === 'desativar') {
      donoState.botStatus.modoVisualGlobal = false
      try { donoState.salvar() } catch (_) {}
      await reagir('🙈')
      return reply(caixaArlequina('MODOVIZU', `❌ *Desligado globalmente.*\n\nO bot parou de marcar as mensagens como vistas automaticamente.`))
    }

    const on = !!donoState.botStatus.modoVisualGlobal
    let statusPrivacidade = ''
    try {
      const check = await sock.fetchPrivacySettings(true)
      statusPrivacidade = `\n🔒 Confirmação de leitura da conta: ${check?.readreceipts === 'all' ? '✅ ativada' : '❌ desativada (o "visto" não aparece pra quem manda mensagem!)'}`
    } catch (_e) {}

    return reply(caixaArlequina('MODOVIZU', `👁️ Status: ${on ? '✅ LIGADO (global)' : '❌ DESLIGADO'}${statusPrivacidade}\n\n*${prefix}modovizu 1* — liga em tudo\n*${prefix}modovizu 0* — desliga\n\nVale pra *todas* as conversas, não só um grupo.`))
  }
}
