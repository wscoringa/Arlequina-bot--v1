/*
  Este arquivo antes era um PEDAÇO DE CÓDIGO solto (não era um comando de
  verdade) e dava erro ao carregar. Agora ele é só um atalho: !antipagamento
  faz a mesma coisa que !antipy. A detecção de verdade fica em
  arquivos/js/antipyHandler.js (chamada pelo index.js).
*/
const antipy = require('./antipy.js')

module.exports = {
  name: 'antipagamento',
  description: antipy.description,
  category: 'admin',
  aliases: [],
  execute: (ctx) => antipy.execute(ctx)
}
