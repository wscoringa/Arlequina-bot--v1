/*
 !kurokami @pessoa (aliases: deusnegro)
 "Amaldiçoa" a pessoa marcada por 1min30s: toda mensagem que ela mandar
 nesse tempo é apagada e a Arlequina responde no lugar com uma frase
 boba aleatória. Precisa que a Arlequina seja admin do grupo (pra apagar).
 Categoria "admin" = só admin/dono podem usar.
*/
const { ativar } = require('../../arquivos/js/kurokamiState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'kurokami',
  description: '👹 Amaldiçoa alguém por 1min30s: toda mensagem dela é apagada e substituída',
  category: 'admin',
  aliases: ['deusnegro'],
  async execute({ arlequina, from, info, reply, reagir, isGroup, isBotAdm, groupMembers }) {
    if (!isGroup) return reply('❌ Esse comando só funciona em grupos.')
    try {
      const mencionadoRaw = info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] ||
        info.message?.extendedTextMessage?.contextInfo?.participant

      if (!mencionadoRaw) {
        return reply(caixaArlequina('kurokami', `👹 Marque quem vai receber a maldição!\n\n📌 Ex: *!kurokami @pessoa*`))
      }

      if (!isBotAdm) {
        return reply('❌ Eu preciso ser administradora do grupo pra conseguir apagar as mensagens.')
      }

      // BUGFIX: o WhatsApp às vezes manda o @ marcado como "xxxxx@lid"
      // (um ID interno, não o número de telefone de verdade). Se a
      // gente ativar a maldição sob esse ID errado, ela nunca bate com
      // o número de verdade que aparece quando a pessoa manda mensagem
      // de novo — por isso a maldição "não fazia nada". Resolve pelo
      // número real antes de ativar.
      let mencionado = mencionadoRaw
      if (mencionadoRaw.endsWith('@lid')) {
        if (global.lidParaNumero?.[mencionadoRaw]) {
          mencionado = global.lidParaNumero[mencionadoRaw]
        } else {
          const participante = groupMembers?.find(p => p.id === mencionadoRaw)
          if (participante?.phoneNumber) {
            mencionado = participante.phoneNumber
            if (!global.lidParaNumero) global.lidParaNumero = {}
            global.lidParaNumero[mencionadoRaw] = mencionado
          } else {
            try {
              const pn = await arlequina.signalRepository?.lidMapping?.getPNForLID(mencionadoRaw)
              if (pn) {
                mencionado = pn.includes('@') ? pn : `${pn}@s.whatsapp.net`
                if (!global.lidParaNumero) global.lidParaNumero = {}
                global.lidParaNumero[mencionadoRaw] = mencionado
              }
            } catch (eLid) {
              console.log('Erro ao resolver LID do marcado (kurokami):', eLid?.message)
            }
          }
        }
      }

      const numero = String(mencionado || '').split('@')[0].replace(/[^0-9]/g, '')
      ativar(from, numero)

      await reagir('👹')
      await arlequina.sendMessage(from, {
        text: caixaArlequina('kurokami', `👹🖤 *KUROKAMI INVOCADO* 🖤👹\n\n@${numero} foi amaldiçoado(a)!\n\nPor 1 minuto e 30 segundos, toda mensagem dela vai ser apagada e substituída. 😈\n\n_Que o deus negro tenha piedade..._`),
        mentions: [mencionado]
      }, { quoted: info })
    } catch (e) {
      console.log('❌ ERRO ADMIN (kurokami):', e?.message)
      await reply('❌ Não consegui ativar a maldição agora.')
    }
  }
}
