const adminState = require('../../arquivos/js/adminState.js')
const antipyDB = require('../../arquivos/js/antipyDB.js')
const antipyHandler = require('../../arquivos/js/antipyHandler.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina.js')

module.exports = {
  name: 'antipy',

  description:
    '👻 Anti mensagem de pagamento/fantasma/invisível: detectou (ou alguém responde o spam) = apaga, bane quem mandou e marca',

  category: 'admin',

  aliases: ['antipix', 'antipagamento', 'anti-py'],

  async execute({ from, args, info, reply, reagir, isGroup, isAdm, isDono, isBotAdm, prefix, columbina, groupMembers }) {
    if (!isGroup) return reply('❌ Use esse comando em grupos!')
    if (!isAdm && !isDono()) return reply('❌ Apenas admins podem configurar o Anti-PY!')

    const modo = String(args[0] || '').toLowerCase()
    const opc = String(args[1] || '').toLowerCase()
    const ligar = ['on', '1', 'sim', 'ativar'].includes(opc)
    const desligar = ['off', '0', 'nao', 'não', 'desativar'].includes(opc)

    if (modo === 'on' || modo === 'ativar' || modo === '1') {
      const jaEstava = antipyDB.getConfig(from).ativo
      antipyDB.ligarTudo(from)
      // compatibilidade com quem ainda lê o estado antigo em memória
      if (!adminState.antipy) adminState.antipy = {}
      adminState.antipy[from] = { ativo: true }

      await reagir('👻')
      return reply(
        caixaArlequina(
          'antipy',
          `👻 *ANTI-PY ${jaEstava ? 'REATIVADO' : 'ATIVADO'}*\n\n` +
            `Contra mensagem de *pagamento / fantasma / invisível*, agora ligado:\n\n` +
            `✅ *AUTOMÁTICO* — o bot detectou, já bane direto\n` +
            `✅ *RESPONDENDO* — qualquer pessoa responde a mensagem de spam e o bot bane quem mandou\n` +
            `✅ *ADM TAMBÉM* — rebaixa e bane (${prefix}antipy adm off para poupar)\n\n` +
            `🧹 Sempre: *APAGA* a mensagem, *BANE* e *MARCA* a pessoa\n` +
            `🛡️ Não afeta: dono do bot e criador do grupo\n` +
            `ℹ️ Só a mensagem *confirmada como spam* leva ação. Não existe atalho "." — responder um ponto sozinho NÃO bane ninguém.\n\n` +
            (isBotAdm
              ? `✅ Sou ADM do grupo: tudo pronto.\n\n`
              : `⚠️ *ATENÇÃO:* eu NÃO sou ADM deste grupo. Sem ser ADM não consigo apagar nem banir — me promova!\n\n`) +
            `💡 Para desligar: *${prefix}antipy off*\n` +
            `💜 *ARLEQUINA SECURITY ATIVA*`
        )
      )
    }

    if (modo === 'off' || modo === 'desativar' || modo === '0') {
      antipyDB.setAtivo(from, false)
      if (!adminState.antipy) adminState.antipy = {}
      adminState.antipy[from] = { ativo: false }

      await reagir('❌')
      return reply(caixaArlequina('antipy', `👻 *ANTI-PY DESATIVADO*\n\n❌ A proteção foi desligada neste grupo.`))
    }

    if (modo === 'adm' || modo === 'admin' || modo === 'admins') {
      if (ligar) {
        antipyDB.setBanirAdmins(from, true)
        await reagir('✅')
        return reply('👑 *ANTI-PY* — o bot também *rebaixa e bane ADM* que mandar spam detectado. (O dono do bot e o criador do grupo não são afetados.)')
      }
      if (desligar) {
        antipyDB.setBanirAdmins(from, false)
        await reagir('✅')
        return reply('👑 *ANTI-PY* — ADM agora fica *de fora* (só membros comuns são banidos).')
      }
      return reply(`Use: *${prefix}antipy adm on* (bane ADM também) ou *${prefix}antipy adm off* (poupa ADM).\nAgora: ${antipyDB.getConfig(from).banirAdmins ? 'bane ADM também ✅' : 'poupa ADM ❌'}`)
    }

    if (modo === 'responder' || modo === 'denuncia' || modo === 'denúncia') {
      if (ligar) {
        antipyDB.setDenuncia(from, true)
        await reagir('✅')
        return reply('📣 *ANTI-PY* — LIGADO: qualquer pessoa responde a mensagem de spam (com qualquer texto) e o bot apaga + bane quem mandou.')
      }
      if (desligar) {
        antipyDB.setDenuncia(from, false)
        await reagir('✅')
        return reply('📣 *ANTI-PY* — responder mensagem de spam DESLIGADO. Só o automático continua agindo.')
      }
      return reply(`Use: *${prefix}antipy responder on* ou *${prefix}antipy responder off*.\nAgora: ${antipyDB.getConfig(from).denuncia !== false ? 'ligado ✅' : 'desligado ❌'}`)
    }

    // DIAGNÓSTICO DO AMBIENTE: confere tudo que o Anti-PY precisa para funcionar neste grupo
    if (modo === 'teste' || modo === 'testar' || modo === 'check') {
      const cfg = antipyDB.getConfig(from)
      const amostra = { requestPaymentMessage: { noteMessage: { extendedTextMessage: { text: 'x' } } } }
      const idsBot = columbina?.user ? [columbina.user.id, columbina.user.lid].filter(Boolean) : []
      const num = (j) => String(j || '').split('@')[0].split(':')[0]
      const membroBot = (groupMembers || []).find((m) => [m?.id, m?.jid, m?.lid, m?.phoneNumber].filter(Boolean).some((x) => idsBot.some((b) => num(b) === num(x))))
      const botAdmPelaLista = !!membroBot && (membroBot.admin === 'admin' || membroBot.admin === 'superadmin')
      const k = info?.key || {}
      return reply(
        `🔧 *ANTI-PY — TESTE DO AMBIENTE*\n\n` +
          `${cfg.ativo ? '✅' : '❌'} Ligado neste grupo: ${cfg.ativo ? 'sim' : 'NÃO (use ' + prefix + 'antipy on)'}\n` +
          `${(isBotAdm || botAdmPelaLista) ? '✅' : '❌'} Bot é ADM: ${(isBotAdm || botAdmPelaLista) ? 'sim' : 'NÃO — promova o bot a ADM'} (index: ${isBotAdm ? 'sim' : 'não'} | lista do grupo: ${botAdmPelaLista ? 'sim' : 'não'})\n` +
          `${antipyHandler.detectarSpam(amostra) ? '✅' : '❌'} Detector reconhece mensagem de pagamento: ${antipyHandler.detectarSpam(amostra) ? 'sim' : 'NÃO'}\n` +
          `👑 ADM também é banido: ${cfg.banirAdmins ? 'sim' : 'não'}\n\n` +
          `📨 Sua mensagem chegou assim:\n` +
          `   participant: ${k.participant || '(vazio)'}\n` +
          `   participantAlt: ${k.participantAlt || '(vazio)'}\n` +
          `${k.participantAlt ? '' : 'ℹ️ Sem participantAlt (normal em alguns grupos) — o Anti-PY já lida com isso.\n'}\n` +
          `Se tudo estiver ✅ e o spam ainda passar, responda ele com *${prefix}antipy debug* e me mande o resultado.`
      )
    }

    // Responda a mensagem suspeita com !antipy debug: mostra o que o WhatsApp entregou e,
    // se for mesmo spam, JÁ APAGA + BANE + MARCA na hora (não depende do automático).
    if (modo === 'debug') {
      const ci = info?.message?.extendedTextMessage?.contextInfo
      if (!ci?.quotedMessage) {
        return reply(`Responda a mensagem suspeita com *${prefix}antipy debug* que eu mostro o que o WhatsApp entregou. Se for spam de verdade, eu já apago e bane na hora.`)
      }
      let resultado
      try {
        resultado = await antipyHandler.agirSobreCitada(columbina, {
          ci, from, groupMembers,
          isBotGroupAdmins: isBotAdm,
          ehDono: (jid) => { try { return isDono(jid) } catch (_e) { return false } },
        })
      } catch (e) {
        console.log('❌ ERRO antipy debug (agirSobreCitada):', e?.message)
        return reply(`⚠️ Deu erro ao tentar agir: ${e?.message || 'erro desconhecido'}\n\nSegue o diagnóstico:\n\nTipos: ${Object.keys(ci.quotedMessage).join(', ')}`)
      }
      const estrutura = JSON.stringify(antipyHandler.resumirEstrutura(ci.quotedMessage), null, 1).slice(0, 2200)
      if (resultado.motivo) {
        // agirSobreCitada já mandou a mensagem de apagou/baniu/marcou — só complementa com o diagnóstico
        return reply(
          `🔎 *DIAGNÓSTICO*\n\nReconhecida como spam: ✅ SIM (${resultado.motivo})\nTipos: ${Object.keys(ci.quotedMessage).join(', ')}\n\n` +
            '```' + estrutura + '```'
        )
      }
      return reply(
        `🔎 *ANTI-PY — DEBUG*\n\n` +
          `Reconhecida como spam: ❌ NÃO\n` +
          `Tipos: ${Object.keys(ci.quotedMessage).join(', ')}\n\n` +
          '```' + estrutura + '```'
      )
    }

    const cfg = antipyDB.getConfig(from)
    return reply(
      caixaArlequina(
        'antipy',
        `👻 *ANTI-PY — STATUS*\n\n` +
          `${cfg.ativo ? '✅ ATIVADO' : '❌ DESATIVADO'}\n` +
          `${isBotAdm ? '✅ Sou ADM do grupo' : '⚠️ NÃO sou ADM (preciso ser para banir)'}\n\n` +
          `💳 Pagamento/fantasma: *DETECTA*\n` +
          `👻 Mensagem invisível: *DETECTA*\n` +
          `📣 Responder o spam (qualquer um): *${cfg.denuncia !== false ? 'SIM' : 'NÃO'}*\n` +
          `👑 ADM também: *${cfg.banirAdmins ? 'SIM (rebaixa e bane)' : 'NÃO (poupado)'}*\n` +
          `🧹 Ação: *APAGA + BAN DIRETO + marca a pessoa*\n` +
          `ℹ️ Não existe atalho ".": só mensagem confirmada como spam leva ação\n\n` +
          `━━━━━━━━━━━━━━━━━━\n\n` +
          `💡 *${prefix}antipy on* / *off*\n` +
          `💡 *${prefix}antipy adm on* / *off*\n` +
          `💡 *${prefix}antipy responder on* / *off*\n` +
          `💡 *${prefix}antipy teste* (confere se está tudo certo)\n` +
          `💡 responda uma mensagem com *${prefix}antipy debug*`
      )
    )
  }
}
