/*
 Comando: x9grupo
 Liga/desliga o "modo x9" no grupo: quando ativo, a Arlequina denuncia
 em tempo real toda ação de moderação feita por um ADM (banimento,
 promoção, rebaixamento, entrada aprovada/adicionada), mesmo quando a
 ação é feita direto pelo WhatsApp, fora dos comandos da bot.
*/
const modLogDB = require('../../arquivos/js/modLogDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const frasesOn = [
  'Agora nada passa por mim sem eu saber... 🕵️‍♀️💜',
  'Modo fofoqueira ativado, ninguém se esconde de mim! 😈',
  'Toda movimentação vai ser denunciada aqui no grupo. 🃏'
]

const frasesOff = [
  'Tá bom, vou fingir que não vi nada... 🙈',
  'Modo discreta ativado, parei de contar as fofocas. 💤'
]

module.exports = {
name: 'x9gp',
description: 'Ativa/desativa o log de atividades do grupo (denuncia ações dos ADMs em tempo real)',
category: 'admin',
aliases: ['logadm', 'modlog', 'logativ', 'x9log'],
async execute({ from, args, reply, reagir, prefix, isGroup }) {

if (!isGroup) return reply(caixaArlequina("x9grupo", `❌ Este comando só pode ser usado em grupos!`))

const modo = (args[0] || '').toLowerCase()

if (modo === 'on' || modo === '1' || modo === 'ativar') {
  modLogDB.setAtivo(from, true)
  await reagir('🕵️')
  return reply(`╭─━━─🃏💜「 🕵️💜 *LOG DE ATIVIDADES* 💜🕵️ 」💜🃏─━━─╮
┃ ✅ ATIVADO neste grupo!
┃ Vou avisar aqui sempre que um ADM:
┃ ▸ banir/remover alguém
┃ ▸ promover ou rebaixar alguém
┃ ▸ aprovar ou adicionar um novo membro
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _${frasesOn[Math.floor(Math.random() * frasesOn.length)]}_`)
}

if (modo === 'off' || modo === '0' || modo === 'desativar') {
  modLogDB.setAtivo(from, false)
  await reagir('🕵️')
  return reply(`╭─━━─🃏💜「 🕵️💜 *LOG DE ATIVIDADES* 💜🕵️ 」💜🃏─━━─╮
┃ ❌ DESATIVADO neste grupo!
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _${frasesOff[Math.floor(Math.random() * frasesOff.length)]}_`)
}

const statusAtual = modLogDB.isAtivo(from) ? '✅ ATIVADO' : '❌ DESATIVADO'
return reply(`╭─━━─🃏💜「 🕵️💜 *LOG DE ATIVIDADES* 💜🕵️ 」💜🃏─━━─╮
┃ Status atual: ${statusAtual}
┃
┃ ➜ ${prefix}x9grupo on — liga
┃ ➜ ${prefix}x9grupo off — desliga
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _A Arlequina vê tudo... 😈_`)

}
}
