/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: resetuser
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'resetuser',
description: "Reseta os dados de um usuário",
category: 'admin',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const alvo =
  msg.message?.extendedTextMessage?.contextInfo?.participant ||
  msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
  
  if (!alvo)
  return reply(`${caixaArlequina("resetuser", `❌ Marque uma pessoa.\n\nEx: ${prefix}resetuser @membro`)}`)
  
  const numeroAlvo = alvo.split('@')[0]
  
  if (!usuarios[numeroAlvo])
  return reply('❌ Esse usuário não está registrado.')
  
  usuarios[numeroAlvo] = {
  saldo: 0,
  banco: 0,
  xp: 0,
  level: 1,
  forca: 10,
  defesa: 5,
  vida: 100,
  ouro: 0,
  vitorias: 0,
  derrotas: 0,
  bosses: 0,
  classe: 'Aventureiro',
  arma: '🪵 Madeira',
  inventario: [],
  nomeBanco: null,
  pix: null,
  lastDaily: 0,
  preso: false,
  tempoPreso: 0,
  presoPor: null,
  policial: false
  }
  
  fs.writeFileSync(dbPath, JSON.stringify(usuarios, null, 2))
  
  await enviar({
  text: `♻️ Dados de @${numeroAlvo} foram resetados.`,
  mentions: [alvo]
  }, { quoted: msg })
} catch (e) {
console.log('❌ ERRO (resetuser):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
