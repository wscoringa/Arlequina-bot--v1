const adminState = require('../../arquivos/js/adminState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'antiimagem',
  description: '🖼️ Liga/desliga o antiimagem (apaga fotos mandadas no grupo)',
  category: 'admin',
  aliases: ['antifoto'],
  async execute({ from, reply, reagir, args, isGroup, isAdm, isDono, prefix }) {
    if (!isGroup) return reply('❌ Use em grupos!')
    if (!isAdm && !isDono()) return reply('❌ Apenas admins!')

    const modo = (args[0] || '').toLowerCase()
    if (!['on', 'off'].includes(modo)) {
      return reply(caixaArlequina('antiimagem', `🖼️ *ANTIIMAGEM*\n\nStatus: *${adminState.antiimagem[from] ? 'Ligado ✅' : 'Desligado ❌'}*\n\n*${prefix}antiimagem on* — apaga fotos automaticamente\n*${prefix}antiimagem off* — desliga`))
    }
    adminState.antiimagem[from] = modo === 'on'
    await reagir('🖼️')
    return reply(caixaArlequina('antiimagem', modo === 'on'
      ? `✅ Antiimagem ativado! Fotos serão apagadas automaticamente.`
      : `❌ Antiimagem desativado.`))
  }
}
