/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: abrirgrupo
*/
const adminState = require('../../arquivos/js/adminState.js')
const { parseTempo } = require('../../arquivos/js/parseTempo.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'abrirgrupo',
description: "Abre o grupo (todos podem falar)",
category: 'admin',
aliases: ['abg', 'chat_on'],
needBotAdmin: true,
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, getFileBuffer, commandManager }) {

const sock = arlequina
const msg = info
const jid = sender
const isGrupo = isGroup
const nome = pushname

const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  
  const groupMetadata = await sock.groupMetadata(from)
  
  try {
  await sock.groupSettingUpdate(from, 'not_announcement')
  await reply(`╭─━━─🃏💜「 🔓💜 *GRUPO ABERTO* 💜🔓 」💜🃏─━━─╮\n┃ ✅ Todos podem enviar mensagens\n┃ agora!\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${['🔓 Portas abertas, chegou todo mundo!', '🎉 Liberdade total pra conversar!', '🃏 Grupo liberado pela Arlequina!'][Math.floor(Math.random() * 3)]}_`)
  } catch (e) {
  console.log(e)
  await reply(caixaArlequina("abrirgrupo", `❌ Não consegui abrir o grupo. Verifique se sou admin.`))
  }
} catch (e) {
console.log('❌ ERRO ADMIN (abrirgrupo):', e?.message)
await reply('❌ Não consegui executar esse comando. Verifique se sou admin do grupo.')
}

}
}
