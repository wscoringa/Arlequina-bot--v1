/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: listfundos
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'listfundos',
description: "Lista os fundos disponíveis",
category: 'admin',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const grupos = Object.entries(adminState.welcome)
  .filter(([id, cfg]) => cfg.fundoEntrada || cfg.fundoSaida)
  
  if (grupos.length === 0)
  return reply('📋 Nenhum grupo com fundo de boas-vindas/saída configurado.')
  
  const texto = grupos
  .map(([id, cfg]) => {
  const partes = []
  if (cfg.fundoEntrada) partes.push('entrada')
  if (cfg.fundoSaida) partes.push('saída')
  return `• ${id} (${partes.join(', ')})`
  })
  .join('\n')
  
  await reply(`${caixaArlequina("listfundos", `🖼️ Grupos com fundo configurado:\n\n${texto}`)}`)
} catch (e) {
console.log('❌ ERRO (listfundos):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
