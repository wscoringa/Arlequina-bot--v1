/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: antibot
*/
const adminState = require('../../arquivos/js/adminState.js')
const { parseTempo } = require('../../arquivos/js/parseTempo.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'antibot',
description: "Ativa/desativa proteção contra outros bots no grupo",
category: 'admin',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, getFileBuffer, commandManager }) {

const sock = arlequina
const msg = info
const jid = sender
const isGrupo = isGroup
const nome = pushname

const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  
  const groupMetadata = await sock.groupMetadata(from)
  
  const modo = args[0]?.toLowerCase()
  
  const frasesOn = ['🤖 Outro bot aqui? Nem pensar!', '🛡️ Zona livre de robôs concorrentes!', '⚡ Só a Arlequina manda aqui!']
  const frasesOff = ['😌 Beleza, deixei os robôs em paz.', '🙈 Vigilância de bots relaxada.']

  if (modo === 'on' || modo === '1' || modo === 'ativar') {
  adminState.antibot[from] = true
  return reply(`╭─━━─🃏💜「 🤖💜 *ANTIBOT* 💜🤖 」💜🃏─━━─╮\n┃ ✅ ATIVADO neste grupo!
┃ Detecta menus/respostas de outros bots
┃ e *bane* o remetente do grupo.
┃ (moldura, lista de comandos, etc.)\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${frasesOn[Math.floor(Math.random() * frasesOn.length)]}_`)
  }
  
  if (modo === 'off' || modo === '0' || modo === 'desativar') {
  adminState.antibot[from] = false
  return reply(`╭─━━─🃏💜「 🤖💜 *ANTIBOT* 💜🤖 」💜🃏─━━─╮\n┃ ❌ DESATIVADO neste grupo!\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${frasesOff[Math.floor(Math.random() * frasesOff.length)]}_`)
  }
  
  return reply(`🤖 Antibot está: ${adminState.antibot[from] ? '✅ ATIVADO' : '❌ DESATIVADO'}\n\nUse:\n${prefix}antibot on\n${prefix}antibot off`)
} catch (e) {
console.log('❌ ERRO ADMIN (antibot):', e?.message)
await reply(caixaArlequina("antibot", `❌ Não consegui executar esse comando. Verifique se sou admin do grupo.`))
}

}
}
