const { definirFechamento, obterAgenda, validarHorario } = require('../../arquivos/js/agendaGrupoManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'fechagp',
  description: 'Agenda o fechamento automático do grupo todo dia num horário fixo',
  category: 'admin',
  aliases: ['fechargpauto', 'agendarfechar'],
  needBotAdmin: true,
  async execute({ from, args, reply, reagir, prefix, isGroup }) {
    if (!isGroup) return reply('❌ Use em grupos!')
    try {
      const arg = (args[0] || '').toLowerCase()

      if (!arg) {
        const atual = obterAgenda(from)
        return reply(caixaArlequina('fechagp', `⏰ *Fechamento automático:* ${atual.fechar ? `*${atual.fechar}*` : '_desativado_'}\n\n💡 Pra definir: ${prefix}fechagp HH:MM\n💡 Pra desativar: ${prefix}fechagp off`))
      }

      if (['off', 'desativar', 'cancelar', 'remover'].includes(arg)) {
        definirFechamento(from, null)
        await reagir('❌')
        return reply(caixaArlequina('fechagp', `✅ Fechamento automático *desativado* nesse grupo.`))
      }

      const horario = validarHorario(args[0])
      if (!horario) {
        return reply(caixaArlequina('fechagp', `❗ Horário inválido.\n\n💡 Use: ${prefix}fechagp HH:MM\nEx: ${prefix}fechagp 12:00\nEx: ${prefix}fechagp 9:40`))
      }

      definirFechamento(from, horario)
      await reagir('🔒')
      return reply(caixaArlequina('fechagp', `⏰ Prontinho! O grupo vai fechar automaticamente *todo dia às ${horario}*.\n\n💡 Pra desativar: ${prefix}fechagp off`))
    } catch (e) {
      console.error('ERRO fechagp:', e?.message)
      await reply('❌ Não consegui agendar agora, tenta de novo.')
    }
  }
}
