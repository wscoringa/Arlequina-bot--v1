/*
 Comando: modorpg
 Liga (1) ou desliga (0) TODOS os comandos da categoria "rpg" dentro do
 grupo. Quando desligado, ninguém além do dono/ADM consegue usar esses
 comandos no grupo até ligar de novo. Mesma lógica do modobn, aplicada
 aos comandos de RPG.
*/
const donoState = require('../../arquivos/js/donoState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const frasesOn = [
  'Que comecem os jogos! 🎲💜',
  'RPG liberado, que vença o mais forte! ⚔️😈',
  'Arena aberta! Bora upar, gente! 🃏'
]

const frasesOff = [
  'Modo RPG hibernando por enquanto... 😴',
  'Guardei os dados, chega de aventura por hoje. 🎲💤'
]

module.exports = {
name: 'modorpg',
description: 'Liga (1) ou desliga (0) os comandos de RPG no grupo',
category: 'admin',
aliases: ['rpgmode', 'modorpggrupo'],
async execute({ from, args, reply, reagir, prefix, isGroup }) {

try {
  if (!isGroup) return reply(caixaArlequina("modorpg", `❌ Este comando só funciona em grupos.`))

  const modo = (args[0] || '').toLowerCase()

  if (!donoState.botStatus.rpgGrupos) donoState.botStatus.rpgGrupos = {}

  if (modo === '1' || modo === 'on' || modo === 'ligar') {
    donoState.botStatus.rpgGrupos[from] = true
    donoState.salvar()
    await reagir('🎲')
    return reply(`╭─━━─🃏💜「 🎲💜 *MODO RPG* 💜🎲 」💜🃏─━━─╮
┃ ✅ LIGADO neste grupo!
┃ Os comandos de RPG (batalha, caça,
┃ clã, banco e etc.) já podem ser usados.
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _${frasesOn[Math.floor(Math.random() * frasesOn.length)]}_`)
  }

  if (modo === '0' || modo === 'off' || modo === 'desligar') {
    donoState.botStatus.rpgGrupos[from] = false
    donoState.salvar()
    await reagir('🎲')
    return reply(`╭─━━─🃏💜「 🎲💜 *MODO RPG* 💜🎲 」💜🃏─━━─╮
┃ ❌ DESLIGADO neste grupo!
┃ Os comandos de RPG ficam bloqueados
┃ até usarem ${prefix}modorpg 1 de novo.
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _${frasesOff[Math.floor(Math.random() * frasesOff.length)]}_`)
  }

  const statusAtual = donoState.botStatus.rpgGrupos[from] === false ? '❌ DESLIGADO' : '✅ LIGADO'

  return reply(`╭─━━─🃏💜「 🎲💜 *MODO RPG* 💜🎲 」💜🃏─━━─╮
┃ Status atual: ${statusAtual}
┃
┃ ➜ ${prefix}modorpg 1 — liga
┃ ➜ ${prefix}modorpg 0 — desliga
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _Arlequina Bot_ 😈`)
} catch (e) {
console.log('❌ ERRO ADMIN (modorpg):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
}

}
}
