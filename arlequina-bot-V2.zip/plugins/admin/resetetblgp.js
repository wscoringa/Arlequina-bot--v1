const { resetarTabela } = require('../../arquivos/js/tabelasGpManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'resetetblgp',
description: 'Apaga a tabela/lista personalizada do grupo',
category: 'admin',
aliases: ['limpartabela'],
async execute({ from, reply, reagir, isGroup, isAdm, isDono, isMonitor }) {
if (!isGroup) return reply(caixaArlequina("resetetblgp", `❌ Este comando só pode ser usado em grupos!`))
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const existia = resetarTabela(from)
await reagir('🧹')
await reply(existia ? '✅ Tabela do grupo apagada!' : '✅ Não havia nenhuma tabela criada.')
}
}
