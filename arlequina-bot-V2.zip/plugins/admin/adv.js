const { addAviso, resetAviso } = require('../../arquivos/js/avisosManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const { resolverJidReal } = require('../../arquivos/js/lidHelper.js')

const MAX_AVISOS = 3

module.exports = {
name: 'adv',
description: 'Dá uma advertência manual a um membro (bane automático na 3ª)',
category: 'admin',
aliases: ['advertir'],
needBotAdmin: true,
async execute({ columbina, from, info, args, q, reply, reagir, isGroup, isAdm, isBotAdm, isDono, isMonitor, sender }) {
if (!isGroup) return reply(caixaArlequina("adv", `❌ Este comando só pode ser usado em grupos!`))
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const quoted = info.message?.extendedTextMessage?.contextInfo
let alvo = quoted?.participant || quoted?.mentionedJid?.[0]
if (!alvo && args[0] && args[0].startsWith('@')) alvo = args[0].replace('@', '') + '@s.whatsapp.net'
if (!alvo) return reply('❗ Marque ou responda a pessoa que vai receber a advertência!')

// BUGFIX: mesmo problema de LID/sufixo de dispositivo (:0) que já
// corrigimos em outros comandos — sem isso, a contagem de advertência
// podia ficar "espalhada" em chaves diferentes pra mesma pessoa.
alvo = await resolverJidReal(columbina, alvo)

const motivo = (quoted ? args.join(' ') : args.slice(1).join(' ')) || q || 'Não especificado'

const { total, atingiuLimite } = addAviso(from, alvo, MAX_AVISOS)
await reagir('⚠️')

let texto = `⚠️ @${alvo.split('@')[0]} recebeu uma advertência!\n\n` +
`📝 Motivo: ${motivo}\n` +
`📊 Advertências: *${total}/${MAX_AVISOS}*`

if (atingiuLimite) {
  // MELHORIA: antes só avisava "use ban" e não fazia nada sozinho.
  // Agora, ao bater o limite, o bot já bane automaticamente.
  try {
    await columbina.groupParticipantsUpdate(from, [alvo], 'remove')
    resetAviso(from, alvo)
    texto += `\n\n🔨 *Limite atingido!* @${alvo.split('@')[0]} foi *removido(a) automaticamente* do grupo.`
    await reagir('🔨')
  } catch (eBan) {
    console.log('❌ ERRO ao banir automaticamente (adv):', eBan?.message)
    texto += `\n\n⚠️ *Limite atingido*, mas não consegui remover automaticamente (confira se sou admin ou se a pessoa também é admin). Use *!ban* manualmente.`
  }
}

await columbina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
}
}
