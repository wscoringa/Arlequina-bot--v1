/*
 category: 'admin' -> só ADM do grupo, dono ou monitor conseguem usar
 (o dispatcher já garante isso). needBotAdmin: true porque só admin do
 grupo pode ver/aprovar a lista de pedidos de entrada.

 Uso:
 #aceita              -> aceita TODOS os pedidos pendentes
 #aceita 5511999999999 -> aceita só o pedido desse número específico
*/
const modLogDB = require('../../arquivos/js/modLogDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'aceita',
description: 'Aceita os pedidos de entrada pendentes no grupo (aprovação de membros)',
category: 'admin',
aliases: ['aceitar', 'aceitartodos'],
needBotAdmin: true,
async execute({ arlequina, from, info, args, reply, reagir, isGroup }) {

if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')

try {
  const pendentes = await arlequina.groupRequestParticipantsList(from)

  if (!pendentes || pendentes.length === 0) {
    return reply('✅ Não tem ninguém esperando aprovação pra entrar no grupo agora.')
  }

  const quoted = info.message?.extendedTextMessage?.contextInfo
  let alvoEspecifico = quoted?.participant || quoted?.mentionedJid?.[0]

  if (!alvoEspecifico && args[0]) {
    alvoEspecifico = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  }

  const jids = alvoEspecifico
    ? pendentes.filter(p => p.jid === alvoEspecifico).map(p => p.jid)
    : pendentes.map(p => p.jid)

  if (jids.length === 0) {
    return reply('❌ Esse número não está na lista de pedidos pendentes.')
  }

  for (const jid of jids) modLogDB.marcarAcaoBot(from, jid, 'add')
  const resultado = await arlequina.groupRequestParticipantsUpdate(from, jids, 'approve')
  const aprovados = resultado.filter(r => r.status === '200').length

  await reagir('✅')
  await reply(`${caixaArlequina("aceita", `✅ ${aprovados} pedido(s) de entrada aceito(s) com sucesso! 🎉`)}`)
} catch (e) {
  console.log('❌ ERRO aceita:', e?.message)
  reply('❌ Não consegui aceitar os pedidos agora. Confere se a aprovação de membros está ativada no grupo.')
}

}
}
