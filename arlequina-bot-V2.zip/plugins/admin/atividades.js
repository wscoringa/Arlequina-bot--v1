const { getAtividadeUsuario } = require('../../arquivos/js/atividadeManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'atividades',
description: 'Mostra as estatísticas de atividade de um membro no grupo',
category: 'admin',
aliases: ['atividade'],
async execute({ columbina, from, info, args, reply, reagir, isGroup, isAdm, isDono, isMonitor, sender }) {
if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const quoted = info.message?.extendedTextMessage?.contextInfo
let alvo = quoted?.participant || quoted?.mentionedJid?.[0]
if (!alvo && args[0]) alvo = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
if (!alvo) alvo = sender

await reagir('📊')
const d = getAtividadeUsuario(from, alvo)

const texto = caixaArlequina("atividades", `📊💜 *ATIVIDADE DE @${alvo.split('@')[0]}* 💜📊\n\n`) +
`💬 Mensagens: *${d.msgs}*\n` +
`🤖 Comandos: *${d.cmds}*\n` +
`🎭 Figurinhas: *${d.stickers}*\n` +
`📈 Total: *${d.total}*`

await columbina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
}
}
