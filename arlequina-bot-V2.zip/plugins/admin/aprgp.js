const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
module.exports = {
name: 'aprgp',
description: 'Aprova pedidos de entrada pendentes do grupo (aprovação por admissão)',
category: 'admin',
aliases: ['aprovar'],
needBotAdmin: true,
async execute({ columbina, from, info, args, reply, reagir, isGroup, isAdm, isDono, isMonitor }) {
if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

try {
const pendentes = await columbina.groupRequestParticipantsList(from)
if (!pendentes || !pendentes.length) {
await reagir('❌')
return reply('✅ Não há pedidos de entrada pendentes neste grupo.')
}

let alvos
if (args[0]) {
const numeros = args.map(a => a.replace(/[^0-9]/g, ''))
alvos = pendentes.filter(p => numeros.includes(p.jid.split('@')[0])).map(p => p.jid)
if (!alvos.length) return reply('❌ Nenhum dos números informados está na lista de pendentes.')
} else {
alvos = pendentes.map(p => p.jid)
}

await columbina.groupRequestParticipantsUpdate(from, alvos, 'approve')
await reagir('✅')
await columbina.sendMessage(from, {
text: `✅ *${alvos.length}* pedido(s) de entrada aprovado(s)!`,
mentions: alvos
}, { quoted: info })
} catch (e) {
await reagir('❌')
await reply(`${caixaArlequina("aprgp", `❌ Não consegui aprovar os pedidos: ${e.message}\n\n💡 Isso só funciona se o modo "aprovação de membros" estiver ativado no grupo.`)}`)
}
}
}
