/*
 Comando: modobn
 Liga/desliga TODOS os comandos da categoria "brincadeiras" (etiquetas,
 ranks, ações) dentro do grupo. Quando desligado (0), ninguém além do
 dono consegue usar esses comandos no grupo até ligar de novo (1).
*/
const donoState = require('../../arquivos/js/donoState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'modobn',
description: "Liga (1) ou desliga (0) os comandos de brincadeira no grupo",
category: 'admin',
aliases: ['modobrincadeira', 'bnmode'],
async execute({ arlequina, from, info, args, reply, reagir, prefix, isGroup }) {

try {
  if (!isGroup) return reply(caixaArlequina("modobn", `❌ Este comando só funciona em grupos.`))

  const modo = (args[0] || '').toLowerCase()

  if (!donoState.botStatus.brincadeiraGrupos) donoState.botStatus.brincadeiraGrupos = {}

  if (modo === '1' || modo === 'on' || modo === 'ligar') {
    donoState.botStatus.brincadeiraGrupos[from] = true
    donoState.salvar()
    await reagir('🃏')
    return reply(`╭─━━─🃏💜「 🃏💜 *MODO BRINCADEIRA* 💜🃏 」💜🃏─━━─╮
┃ ✅ LIGADO neste grupo!
┃ Os comandos de etiqueta, rank
┃ e ações já podem ser usados.
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _Arlequina Bot_ 😈`)
  }

  if (modo === '0' || modo === 'off' || modo === 'desligar') {
    donoState.botStatus.brincadeiraGrupos[from] = false
    donoState.salvar()
    await reagir('🃏')
    return reply(`╭─━━─🃏💜「 🃏💜 *MODO BRINCADEIRA* 💜🃏 」💜🃏─━━─╮
┃ ❌ DESLIGADO neste grupo!
┃ Os comandos de etiqueta, rank
┃ e ações ficam bloqueados até
┃ usarem ${prefix}modobn 1 de novo.
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _Arlequina Bot_ 😈`)
  }

  const statusAtual = donoState.botStatus.brincadeiraGrupos[from] === false ? '❌ DESLIGADO' : '✅ LIGADO'

  return reply(`╭─━━─🃏💜「 🃏💜 *MODO BRINCADEIRA* 💜🃏 」💜🃏─━━─╮
┃ Status atual: ${statusAtual}
┃
┃ ➜ ${prefix}modobn 1 — liga
┃ ➜ ${prefix}modobn 0 — desliga
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
💜🃏 _Arlequina Bot_ 😈`)
} catch (e) {
console.log('❌ ERRO ADMIN (modobn):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
}

}
}
