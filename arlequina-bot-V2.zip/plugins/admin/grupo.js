const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
/*
 Comando: grupo
 #grupo a (ou abrir) -> abre o grupo (todos podem falar)
 #grupo f (ou fechar) -> fecha o grupo (só admins falam)
 Junta o que antes era "grupo" + "abrirgrupo" + "fechargrupo" num só comando.
*/
module.exports = {
name: 'grupo',
description: 'Abre ou fecha o grupo (só admins enviam mensagens)',
category: 'admin',
aliases: ['group', 'gp'],
needBotAdmin: true,
async execute({ arlequina, columbina, from, args, reply, reagir, isGroup, isBotAdm, prefix }) {
const sock = arlequina || columbina

if (!isGroup) return reply(caixaArlequina("grupo", `❌ Este comando só pode ser usado em grupos!`))
if (!isBotAdm) return reply('❌ A Arlequina precisa ser administradora do grupo pra fazer isso!')

const modo = (args[0] || '').toLowerCase()

try {
  if (modo === 'a' || modo === 'abrir') {
    await sock.groupSettingUpdate(from, 'not_announcement')
    await reagir('🔓')
    return reply(`╭─━━─🃏💜「 🔓💜 *GRUPO ABERTO* 💜🔓 」💜🃏─━━─╮\n┃ ✅ Todos podem enviar mensagens\n┃ agora!\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${['🔓 Portas abertas, chegou todo mundo!', '🎉 Liberdade total pra conversar!', '🃏 Grupo liberado pela Arlequina!'][Math.floor(Math.random() * 3)]}_`)
  }

  if (modo === 'f' || modo === 'fechar') {
    await sock.groupSettingUpdate(from, 'announcement')
    await reagir('🔒')
    return reply(`╭─━━─🃏💜「 🔒💜 *GRUPO FECHADO* 💜🔒 」💜🃏─━━─╮\n┃ ❌ Só administradores podem\n┃ enviar mensagens agora.\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${['🔒 Silêncio, o grupo é só dos admins agora!', '🛡️ Cadeado colocado pela Arlequina!', '🃏 Modo VIP dos admins ativado!'][Math.floor(Math.random() * 3)]}_`)
  }

  return reply(`❔ Use: *${prefix}grupo a* (abrir) ou *${prefix}grupo f* (fechar)`)
} catch (e) {
  console.log('❌ ERRO ADMIN (grupo):', e?.message)
  await reply('❌ Não consegui executar esse comando. Verifique se sou admin do grupo.')
}
}
}
