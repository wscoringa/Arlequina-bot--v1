/*
 Comando: banirtemp
 Bane um membro do grupo por um tempo determinado. Aceita o tempo em
 qualquer formato/posição: "30m", "1 hora", "5segundos", não importa se
 veio antes ou depois da menção, nem se sobrou espaço digitado errado.

 Quando o tempo acaba, a Arlequina chama a pessoa de volta pro grupo
 sozinha (não precisa ninguém aprovar de novo).
*/
const adminState = require('../../arquivos/js/adminState.js')
const { extrairTempo } = require('../../arquivos/js/parseTempo.js')
const modLogDB = require('../../arquivos/js/modLogDB.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const frasesBanirtemp = [
  'Fica de castigo lá fora um pouquinho... 🃏😈',
  'Suspensão temporária, comportamento manda voltar mais cedo! 💜🌑',
  'Vai refletir sobre a vida aí fora... 🚫🃏'
]

const frasesRetorno = [
  'O castigo acabou, pode voltar! 🃏💜',
  'Cumpriu a pena, tá liberado(a) de novo! 😈💜',
  'A Arlequina é rígida, mas justa... bem-vindo(a) de volta! 🌕🃏'
]

module.exports = {
name: 'banirtemp',
description: "Bane um membro temporariamente (e chama de volta sozinho quando o tempo acaba)",
category: 'admin',
aliases: ['bantemp'],
needBotAdmin: true,
async execute({ arlequina, columbina, from, info, args, reply, reagir, donoJid, prefix }) {

const sock = arlequina || columbina
const msg = info

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

try {
  const alvo =
  msg.message?.extendedTextMessage?.contextInfo?.participant ||
  msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]

  if (!alvo)
  return reply(`${caixaArlequina("banirtemp", `❌ Marque uma pessoa.\n\nEx: ${prefix}banirtemp @membro 30m\nEx: ${prefix}banirtemp @membro 1 hora`)}`)

  const numeroAlvo = alvo.split('@')[0]

  if (ehDono(alvo, numeroAlvo))
  return reply('👑 Você não pode banir meu dono!')

  const { tempoMs, tempoTexto } = extrairTempo(args)

  if (!tempoMs)
  return reply(`❌ Não entendi o tempo. Use algo como:\n\n${prefix}banirtemp @membro 30s\n${prefix}banirtemp @membro 10m\n${prefix}banirtemp @membro 1h\n${prefix}banirtemp @membro 1d\n${prefix}banirtemp @membro 1 hora`)

  if (!adminState.listanegra[from]) adminState.listanegra[from] = []
  if (!adminState.listanegra[from].includes(numeroAlvo)) {
    adminState.listanegra[from].push(numeroAlvo)
  }

  await reagir('🚫')

  modLogDB.marcarAcaoBot(from, alvo, 'remove')
  try {
    await sock.groupParticipantsUpdate(from, [alvo], 'remove')
  } catch (e) {
    console.log('⚠️ Não consegui remover pro banirtemp:', e?.message)
  }

  const fraseBan = frasesBanirtemp[Math.floor(Math.random() * frasesBanirtemp.length)]
  await sock.sendMessage(from, {
    text: `╭─━━─🃏💜「 🚫💜 *BAN TEMPORÁRIO* 💜🚫 」💜🃏─━━─╮\n┃ 👤 @${numeroAlvo}\n┃ ⏱️ Tempo: ${tempoTexto}\n┃ 🔄 Volta sozinho(a) quando o tempo acabar\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${fraseBan}_`,
    mentions: [alvo]
  }, { quoted: info })

  setTimeout(async () => {
    if (adminState.listanegra[from]) {
      adminState.listanegra[from] = adminState.listanegra[from].filter(n => n !== numeroAlvo)
    }

    try {
      modLogDB.marcarAcaoBot(from, alvo, 'add')
      await sock.groupParticipantsUpdate(from, [alvo], 'add')
      const fraseVolta = frasesRetorno[Math.floor(Math.random() * frasesRetorno.length)]
      await sock.sendMessage(from, {
        text: `╭─━━─🃏💜「 🌕💜 *DE VOLTA AO GRUPO* 💜🌕 」💜🃏─━━─╮\n┃ ✅ @${numeroAlvo} voltou automaticamente!\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${fraseVolta}_`,
        mentions: [alvo]
      })
    } catch (e) {
      // BUGFIX: o WhatsApp tem uma proteção anti-abuso que bloqueia
      // readicionar alguém logo depois de ser removido do grupo — isso
      // não é algo que dá pra contornar por código, é uma trava do
      // próprio WhatsApp. Como alternativa, manda o link de convite do
      // grupo direto no privado da pessoa, pra ela voltar com 1 toque.
      console.log('⚠️ Não consegui readicionar após banirtemp (bloqueio do WhatsApp):', e?.message)
      try {
        const codigoConvite = await sock.groupInviteCode(from)
        const linkConvite = `https://chat.whatsapp.com/${codigoConvite}`
        await sock.sendMessage(alvo, {
          text: `🌕 Seu banimento temporário acabou! O WhatsApp não deixa eu te adicionar de volta automaticamente, mas aqui está o link pra você voltar com 1 toque:\n\n${linkConvite}`
        })
        await sock.sendMessage(from, {
          text: `⚠️ O tempo de banimento de @${numeroAlvo} acabou. O WhatsApp não deixa eu adicionar de volta automaticamente, mas já mandei o link do grupo no privado da pessoa pra ela voltar sozinha.`,
          mentions: [alvo]
        })
      } catch (e2) {
        console.log('⚠️ Também não consegui mandar o link de convite no privado:', e2?.message)
        try {
          await sock.sendMessage(from, {
            text: `⚠️ O tempo de banimento de @${numeroAlvo} acabou, mas não consegui adicionar de volta nem mandar convite (talvez ela tenha bloqueado o bot ou as msgs de desconhecidos estejam restritas). Peça pra ela entrar pelo link do grupo manualmente.`,
            mentions: [alvo]
          })
        } catch (e3) {}
      }
    }
  }, tempoMs)

} catch (e) {
console.log('❌ ERRO ADMIN (banirtemp):', e?.message)
await reply('❌ Não consegui executar esse comando. Verifique se sou admin do grupo.')
}

}
}
