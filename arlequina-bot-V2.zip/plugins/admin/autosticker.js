/*
 !autosticker on/off
 Enquanto ligado NESSE GRUPO, toda foto ou vídeo mandado no grupo vira
 figurinha automaticamente, sem precisar digitar comando nenhum.
 Categoria "admin" = só admin/dono podem ligar/desligar.
*/
const donoState = require('../../arquivos/js/donoState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'autosticker',
  description: '🎭 Liga/desliga a conversão automática de foto/vídeo em figurinha nesse grupo',
  category: 'admin',
  aliases: ['autofigurinha', 'autofig'],
  async execute({ reply, reagir, args, from, isGroup, prefix }) {
    if (!isGroup) return reply('❌ Esse comando só funciona em grupos.')
    try {
      const ativoAqui = !!donoState.botStatus.autoStickerGrupos[from]
      const modo = (args[0] || '').toLowerCase()

      if (!['on', 'off', '1', '0', 'ligar', 'desligar'].includes(modo)) {
        return reply(caixaArlequina('autosticker', `🎭💜 *AUTO FIGURINHA* 💜🎭\n\nStatus aqui: *${ativoAqui ? 'Ligado ✅' : 'Desligado ❌'}*\n\n*${prefix}autosticker on* — toda foto/vídeo vira figurinha sozinho\n*${prefix}autosticker off* — volta ao normal (precisa usar ${prefix}sticker)`))
      }

      const ligar = modo === 'on' || modo === '1' || modo === 'ligar'

      if (ligar && ativoAqui) return reply('🎭 O auto figurinha já está ligado nesse grupo!')
      if (!ligar && !ativoAqui) return reply('🔓 O auto figurinha já está desligado nesse grupo!')

      if (ligar) donoState.botStatus.autoStickerGrupos[from] = true
      else delete donoState.botStatus.autoStickerGrupos[from]
      donoState.salvar()

      await reagir(ligar ? '🎭' : '🔓')
      return reply(caixaArlequina('autosticker', ligar
        ? `🎭💜 *AUTO FIGURINHA ATIVADO* 💜🎭\n\n✅ Agora toda foto ou vídeo mandado nesse grupo já vira figurinha automaticamente!\n\nPra desligar: *${prefix}autosticker off*`
        : `🔓💜 *AUTO FIGURINHA DESATIVADO* 💜🔓\n\nFoto e vídeo não viram figurinha sozinho mais — use *${prefix}sticker* normalmente.`))
    } catch (e) {
      console.log('❌ ERRO ADMIN (autosticker):', e?.message)
      await reply('❌ Não consegui executar esse comando agora.')
    }
  }
}
