const { topInativos } = require('../../arquivos/js/atividadeManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'baninativos',
description: 'Bane membros sem nenhuma interação registrada no grupo',
category: 'admin',
aliases: [],
needBotAdmin: true,
async execute({ columbina, from, info, args, reply, reagir, isGroup, isAdm, isDono, isMonitor, isBotAdm, groupMembers, botNumber, donoJid }) {
if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')
if (!isBotAdm) return reply('❌ A Arlequina precisa ser administradora para isso!')

const limite = parseInt(args[0]) || 0
const confirmar = args.includes('confirmar')

const botJid = (botNumber || '').replace(/[^0-9]/g, '') + '@s.whatsapp.net'
const donoJidLimpo = (donoJid || '').replace(/[^0-9]/g, '') + '@s.whatsapp.net'
const ignorar = [botJid, donoJidLimpo]

const membros = (groupMembers || []).filter(m => !m.admin)
const inativos = topInativos(from, membros, 500, ignorar).filter(u => u.total <= limite)

if (!inativos.length) {
await reagir('✅')
return reply(`${caixaArlequina("baninativos", `✅ Nenhum membro com atividade ≤ ${limite} encontrado.`)}`)
}

if (!confirmar) {
const lista = inativos.slice(0, 30).map(u => `• @${u.jid.split('@')[0]} (${u.total} interações)`).join('\n')
return columbina.sendMessage(from, {
text: `⚠️ *${inativos.length}* membro(s) serão banidos (atividade ≤ ${limite}):\n\n${lista}${inativos.length > 30 ? `\n... e mais ${inativos.length - 30}` : ''}\n\n💡 Confirme com: *baninativos ${limite} confirmar*`,
mentions: inativos.slice(0, 30).map(u => u.jid)
}, { quoted: info })
}

await reagir('⚠️')
let removidos = 0
for (const u of inativos) {
try {
await columbina.groupParticipantsUpdate(from, [u.jid], 'remove')
removidos++
await new Promise(r => setTimeout(r, 800))
} catch (e) {}
}
await reagir('✅')
await reply(`✅ ${removidos} de ${inativos.length} membro(s) inativo(s) removido(s).`)
}
}
