const { topInativos } = require('../../arquivos/js/atividadeManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'rankinativo',
description: 'Rank dos membros menos ativos do grupo',
category: 'admin',
aliases: ['rankinativos', 'maisinativos'],
async execute({ columbina, from, info, reply, reagir, isGroup, isAdm, isDono, isMonitor, groupMembers, botNumber, donoJid }) {
if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

await reagir('📉')
try {
const botJid = (botNumber || '').replace(/[^0-9]/g, '') + '@s.whatsapp.net'
const donoJidLimpo = (donoJid || '').replace(/[^0-9]/g, '') + '@s.whatsapp.net'
const ignorar = [botJid, donoJidLimpo]

const membros = (groupMembers || []).filter(m => !m.admin)
const lista = topInativos(from, membros, 10, ignorar)

if (!lista.length) return reply('📉 Não há membros suficientes para gerar esse rank.')

let texto = `📉💜 *RANK DE MENOS ATIVOS* 💜📉\n\n`
lista.forEach((u, i) => {
texto += `${i + 1}° @${u.jid.split('@')[0]} — *${u.total}* interações\n`
})
texto += `\n💡 Use *baninativos* para remover quem estiver zerado.`

await columbina.sendMessage(from, { text: texto, mentions: lista.map(u => u.jid) }, { quoted: info })
} catch (e) {
await reply(`${caixaArlequina("rankinativo", `❌ Erro ao buscar dados de atividade: ${e.message}`)}`)
}
}
}
