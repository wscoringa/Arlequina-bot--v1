const adminState = require('../../arquivos/js/adminState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'anticontato',
  description: '📇 Liga/desliga o anticontato (apaga contatos/cartões de visita mandados no grupo)',
  category: 'admin',
  aliases: ['antivcard'],
  async execute({ from, reply, reagir, args, isGroup, isAdm, isDono, prefix }) {
    if (!isGroup) return reply('❌ Use em grupos!')
    if (!isAdm && !isDono()) return reply('❌ Apenas admins!')

    const modo = (args[0] || '').toLowerCase()
    if (!['on', 'off'].includes(modo)) {
      return reply(caixaArlequina('anticontato', `📇 *ANTICONTATO*\n\nStatus: *${adminState.anticontato[from] ? 'Ligado ✅' : 'Desligado ❌'}*\n\n*${prefix}anticontato on* — apaga contatos automaticamente\n*${prefix}anticontato off* — desliga`))
    }
    adminState.anticontato[from] = modo === 'on'
    await reagir('📇')
    return reply(caixaArlequina('anticontato', modo === 'on'
      ? `✅ Anticontato ativado! Contatos/cartões de visita serão apagados automaticamente.`
      : `❌ Anticontato desativado.`))
  }
}
