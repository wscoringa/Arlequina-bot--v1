/*
 !antipalavra on [advertencias] — liga o filtro (padrão: 3 advertências até banir)
 !antipalavra off — desliga
 !antipalavra add <palavra> — adiciona palavra à lista negra
 !antipalavra remove <palavra> — remove da lista
 !antipalavra lista — mostra as palavras banidas
*/
const adminState = require('../../arquivos/js/adminState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const MAX_ADVERTENCIAS_PADRAO = 3

function initCfg(from) {
  if (!adminState.antipalavra[from]) {
    adminState.antipalavra[from] = { ligado: false, palavras: [], maxAdvertencias: MAX_ADVERTENCIAS_PADRAO }
  }
}

module.exports = {
  name: 'antipalavra',
  description: '🚫 Filtro de palavras banidas — apaga e dá advertência, banindo após X avisos',
  category: 'admin',
  aliases: ['antiword', 'antitoxic'],
  async execute({ from, reply, reagir, args, q, isGroup, isAdm, isDono, prefix }) {
    if (!isGroup) return reply('❌ Use em grupos!')
    if (!isAdm && !isDono()) return reply('❌ Apenas admins!')

    initCfg(from)
    const cfg = adminState.antipalavra[from]
    const modo = (args[0] || '').toLowerCase()

    if (modo === 'on' || modo === 'off') {
      cfg.ligado = modo === 'on'
      if (modo === 'on') cfg.maxAdvertencias = parseInt(args[1]) || MAX_ADVERTENCIAS_PADRAO
      await reagir('🚫')
      return reply(caixaArlequina('antipalavra', cfg.ligado
        ? `✅ Antipalavra ativado! ${cfg.palavras.length} palavra(s) na lista.\n⚠️ ${cfg.maxAdvertencias} advertências até banir.`
        : `❌ Antipalavra desativado.`))
    }

    if (modo === 'add') {
      const palavra = (q || args.slice(1).join(' ')).toLowerCase().trim()
      if (!palavra) return reply(`❌ Digite a palavra. Ex: ${prefix}antipalavra add xingamento`)
      if (cfg.palavras.includes(palavra)) return reply('⚠️ Essa palavra já está na lista.')
      cfg.palavras.push(palavra)
      await reagir('✅')
      return reply(caixaArlequina('antipalavra', `✅ "${palavra}" adicionada à lista negra.\n📋 Total: ${cfg.palavras.length} palavra(s).`))
    }

    if (modo === 'remove' || modo === 'del') {
      const palavra = (q || args.slice(1).join(' ')).toLowerCase().trim()
      const idx = cfg.palavras.indexOf(palavra)
      if (idx === -1) return reply('❌ Essa palavra não está na lista.')
      cfg.palavras.splice(idx, 1)
      await reagir('🗑️')
      return reply(caixaArlequina('antipalavra', `🗑️ "${palavra}" removida da lista negra.`))
    }

    if (modo === 'lista' || modo === 'list') {
      if (!cfg.palavras.length) return reply(caixaArlequina('antipalavra', `📋 Lista vazia.\n\nAdicione com: ${prefix}antipalavra add <palavra>`))
      return reply(caixaArlequina('antipalavra', `📋 *PALAVRAS BANIDAS* (${cfg.palavras.length})\n\n${cfg.palavras.map((p, i) => `${i + 1}. ${p}`).join('\n')}`))
    }

    return reply(caixaArlequina('antipalavra', `🚫 *ANTIPALAVRA*\n\nStatus: *${cfg.ligado ? 'Ligado ✅' : 'Desligado ❌'}*\n📋 Palavras na lista: ${cfg.palavras.length}\n⚠️ Advertências até banir: ${cfg.maxAdvertencias}\n\n*${prefix}antipalavra on [advertencias]* — liga (ex: on 5)\n*${prefix}antipalavra off* — desliga\n*${prefix}antipalavra add <palavra>* — adiciona\n*${prefix}antipalavra remove <palavra>* — remove\n*${prefix}antipalavra lista* — mostra a lista`))
  }
}
