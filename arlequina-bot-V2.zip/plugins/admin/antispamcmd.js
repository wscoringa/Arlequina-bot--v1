/*
 !antispamcmd on/off — liga/desliga com o padrão (8 comandos/minuto)
 !antispamcmd <número> — liga com esse limite de comandos por minuto
                          (ex: !antispamcmd 5 → 5 comandos/minuto)
 !antispamcmd <número>s — modo COOLDOWN: precisa esperar esse tanto de
                          SEGUNDOS entre um comando e outro
                          (ex: !antispamcmd 3s)
 !antispamcmd <número>m — igual acima, mas em MINUTOS
                          (ex: !antispamcmd 3m)
*/
const adminState = require('../../arquivos/js/adminState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const LIMITE_PADRAO = 8 // comandos por minuto (modo janela, padrão)

function textoConfigAtual(cfg, prefix) {
  if (!cfg?.ligado) {
    return `⏱️ *ANTISPAMCMD*\n\nStatus: *Desligado ❌*\n\n*${prefix}antispamcmd on* — ativa (padrão: ${LIMITE_PADRAO} comandos/min)\n*${prefix}antispamcmd <número>* — ativa com limite por minuto (ex: ${prefix}antispamcmd 5)\n*${prefix}antispamcmd <número>s* — ativa em modo cooldown por segundos (ex: ${prefix}antispamcmd 3s)\n*${prefix}antispamcmd <número>m* — igual, mas em minutos (ex: ${prefix}antispamcmd 3m)\n*${prefix}antispamcmd off* — desativa`
  }
  if (cfg.modo === 'cooldown') {
    const unidadeTxt = cfg.unidade === 'm' ? 'minuto(s)' : 'segundo(s)'
    return `⏱️ *ANTISPAMCMD*\n\nStatus: *Ligado ✅ (modo cooldown)*\n🔢 Precisa esperar *${cfg.valorOriginal}* ${unidadeTxt} entre um comando e outro.`
  }
  return `⏱️ *ANTISPAMCMD*\n\nStatus: *Ligado ✅ (modo janela)*\n🔢 Limite: ${cfg.limite || LIMITE_PADRAO} comandos por minuto.`
}

module.exports = {
  name: 'antispamcmd',
  description: '⏱️ Liga/desliga o limite de comandos (por minuto ou cooldown em segundos/minutos)',
  category: 'admin',
  aliases: [],
  async execute({ from, reply, reagir, args, isGroup, isAdm, isDono, prefix }) {
    if (!isGroup) return reply('❌ Use em grupos!')
    if (!isAdm && !isDono()) return reply('❌ Apenas admins!')

    const argRaw = (args[0] || '').toLowerCase()

    // !antispamcmd <número>s ou <número>m — modo cooldown
    const matchCooldown = argRaw.match(/^(\d+)(s|m)$/)
    if (matchCooldown) {
      const valor = parseInt(matchCooldown[1])
      const unidade = matchCooldown[2]
      if (valor <= 0) return reply('❌ Manda um número maior que zero. Ex: !antispamcmd 3s')

      const cooldownMs = unidade === 'm' ? valor * 60000 : valor * 1000
      adminState.antispamcmd[from] = {
        ligado: true, modo: 'cooldown', cooldownMs, valorOriginal: valor, unidade,
        ultimoUso: adminState.antispamcmd[from]?.ultimoUso || {}
      }
      await reagir('⏱️')
      return reply(caixaArlequina('antispamcmd', `✅ Antispamcmd ativado em modo *cooldown*! Cada pessoa precisa esperar *${valor} ${unidade === 'm' ? 'minuto(s)' : 'segundo(s)'}* entre um comando e outro.`))
    }

    // !antispamcmd <número> (sem letra) — modo janela clássico (N por minuto)
    const numero = parseInt(argRaw)
    if (!isNaN(numero) && numero > 0 && !/[a-z]/.test(argRaw)) {
      adminState.antispamcmd[from] = {
        ligado: true, modo: 'janela', limite: numero,
        registro: adminState.antispamcmd[from]?.registro || {}
      }
      await reagir('⏱️')
      return reply(caixaArlequina('antispamcmd', `✅ Antispamcmd ativado! Máximo *${numero}* comandos por minuto por pessoa.`))
    }

    if (!['on', 'off'].includes(argRaw)) {
      return reply(caixaArlequina('antispamcmd', textoConfigAtual(adminState.antispamcmd[from], prefix)))
    }

    if (argRaw === 'off') {
      if (adminState.antispamcmd[from]) adminState.antispamcmd[from].ligado = false
      await reagir('⏱️')
      return reply(caixaArlequina('antispamcmd', '❌ Antispamcmd desativado.'))
    }

    // on — se já tinha uma config (janela ou cooldown), só reativa ela; senão usa o padrão
    if (!adminState.antispamcmd[from]) {
      adminState.antispamcmd[from] = { ligado: false, modo: 'janela', limite: LIMITE_PADRAO, registro: {} }
    }
    adminState.antispamcmd[from].ligado = true
    await reagir('⏱️')
    return reply(caixaArlequina('antispamcmd', textoConfigAtual(adminState.antispamcmd[from], prefix)))
  }
}
