const { getEvento, entrarEvento } = require('../../arquivos/js/eventosManager.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'entrarnalista',
description: 'Entra na lista de participantes do evento ativo no grupo',
category: 'admin',
aliases: ['entrarlista'],
async execute({ columbina, from, info, reply, reagir, isGroup, isAdm, isDono, isMonitor, sender }) {
if (!isGroup) return reply('❌ Este comando só pode ser usado em grupos!')
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const evento = getEvento(from)
if (!evento) return reply('❌ Não há nenhum evento ativo neste grupo no momento.')

const res = entrarEvento(from, sender)
if (!res.ok && res.motivo === 'ja_esta') {
await reagir('❗')
return reply('❗ Você já está na lista desse evento!')
}

await reagir('✅')
await columbina.sendMessage(from, {
text: `${caixaArlequina("entrarnalista", `✅ @${sender.split('@')[0]} entrou na lista de *${evento.nome}*!\n\n👥 Participantes: *${res.evento.participantes.length}*`)}`,
mentions: [sender]
}, { quoted: info })
}
}
