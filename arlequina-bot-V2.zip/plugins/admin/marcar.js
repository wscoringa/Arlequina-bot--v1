const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const fraseMarcar = [
  'A Arlequina convocou todo mundo pro picadeiro! 🃏💜',
  'Ninguém escapa da chamada da Arlequina... 😈🔔',
  'Todo mundo na roda, o show vai começar! 🎪💜'
]

module.exports = {
name: 'marcar',
description: 'Marca todos os membros do grupo',
category: 'admin',
aliases: ['tagall', 'todos', 'tg', 'totag'],
async execute({ columbina, arlequina, from, info, args, q, reply, reagir, isGroup, isAdm, isDono, isMonitor, groupMembers, sender, prefix }) {
const sock = arlequina || columbina

if (!isGroup) return reply(caixaArlequina("marcar", `❌ Este comando só pode ser usado em grupos!`))
if (!isAdm && !isDono() && !isMonitor) return reply('❌ Apenas administradores podem usar este comando!')

const membros = groupMembers.filter(m => !m.admin).map(m => m.id || m.jid || m.lid)
if (!membros.length) return reply('❌ O grupo só possui administradores!')

const frase = fraseMarcar[Math.floor(Math.random() * fraseMarcar.length)]
const lista = membros.map(u => `┃ 🃏 @${u?.split('@')[0] || u}`).join('\n')

let texto = `╭─━━─🃏💜「 🔔💜 *MARCAÇÃO GERAL* 💜🔔 」💜🃏─━━─╮\n`
if (q) texto += `┃ 📝 Mensagem: ${q}\n┃\n`
texto += `${lista}\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n💜🃏 _${frase}_`

await reagir('🔔')
await sock.sendMessage(from, { text: texto, mentions: membros }, { quoted: info })
}
}
