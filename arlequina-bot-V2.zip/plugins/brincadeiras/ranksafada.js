const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/5T0SlSWqF'

module.exports = {
  name: 'ranksafada',
  description: 'RANK SAFADA DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("ranksafada", `❌ Este comando só funciona em grupos.`))
    await reagir('😏')
    try {
      await enviarRank(arlequina, from, info, 'RANK SAFADA DO GRUPO', '😏', 'ranksafada', 'As 5 mais safadas do grupo!', LINK_FOTO)
    } catch (e) {
      console.error('ERRO ranksafada:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
