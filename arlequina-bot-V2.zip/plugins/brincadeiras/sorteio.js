/*
 Comando: sorteio (aliases: roleta, sortear)

 Sorteia um vencedor entre nomes digitados, com efeito de roleta de
 verdade — a mensagem vai mudando de nome (editando ela mesma, sem
 lotar o chat) até desacelerar e parar no vencedor.

 Uso:
 !sorteio <prêmio>: nome1, nome2, nome3...
   Ex: !sorteio Celular: Gabriel, Rafaela, João, Marcela

 !sorteio nome1, nome2, nome3...
   (sem prêmio definido, mostra "Sorteio" genérico)

 !sorteio <prêmio>
   (sem nenhum nome digitado) → sorteia entre os membros de VERDADE do
   grupo, igual antes.
*/
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const { revelarComEdicoes } = require('../../arquivos/js/roletaEdit.js')

const EMOJIS_ROLETA = ['🎰', '🎲', '🎡', '🍀', '✨', '🔮', '🎯']

function emojiAleatorio() {
  return EMOJIS_ROLETA[Math.floor(Math.random() * EMOJIS_ROLETA.length)]
}

module.exports = {
  name: 'sorteio',
  description: '🎰 Sorteia um vencedor entre nomes digitados (ou membros do grupo), com roleta de verdade',
  category: 'brincadeiras',
  aliases: ['sortear'],
  async execute({ arlequina, from, info, args, q, reply, reagir, isGroup, prefix }) {
    try {
      const textoCompleto = (q || args.join(' ')).trim()

      let premio = 'Sorteio'
      let listaTexto = ''

      if (textoCompleto.includes(':')) {
        const idx = textoCompleto.indexOf(':')
        premio = textoCompleto.slice(0, idx).trim() || 'Sorteio'
        listaTexto = textoCompleto.slice(idx + 1).trim()
      } else {
        listaTexto = textoCompleto
      }

      let nomes = listaTexto.split(/,|\n/).map(n => n.trim()).filter(Boolean)
      let mentions = []

      // ── Sem nomes digitados: sorteia entre os membros de verdade do grupo ──
      if (nomes.length < 2) {
        if (!isGroup) {
          return reply(caixaArlequina('sorteio', `❌ Digite os nomes separados por vírgula, ou use em um grupo pra sortear entre os membros.\n\n📝 Ex: *${prefix}sorteio Celular: Gabriel, Rafaela, João*`))
        }
        const groupMetadata = await arlequina.groupMetadata(from)
        const participantes = groupMetadata.participants.map(p => p.id).filter(id => id !== arlequina.user.id)
        if (participantes.length < 2) {
          return reply('❌ Não há participantes suficientes no grupo pra sortear.')
        }
        nomes = participantes.map(jid => `@${jid.split('@')[0]}`)
        mentions = participantes
        if (!textoCompleto.includes(':')) premio = textoCompleto || 'Sorteio'
      }

      if (nomes.length < 2) {
        return reply(caixaArlequina('sorteio', `❌ Preciso de pelo menos 2 participantes.\n\n📝 Ex: *${prefix}sorteio Celular: Gabriel, Rafaela, João*`))
      }

      await reagir('🎰')

      // ── Monta os "frames" da roleta: nomes girando, desacelerando, até o vencedor ──
      const vencedor = nomes[Math.floor(Math.random() * nomes.length)]
      const RODADAS = Math.min(10, Math.max(6, nomes.length + 3))

      const frames = []
      for (let i = 0; i < RODADAS; i++) {
        const candidato = i === RODADAS - 1 ? vencedor : nomes[Math.floor(Math.random() * nomes.length)]
        frames.push(caixaArlequina('sorteio', `${emojiAleatorio()} *SORTEIO: ${premio}*\n\n🎡 Girando...\n\n👉 *${candidato}* 👈`))
      }

      // Frame final: resultado de verdade
      frames.push(caixaArlequina('sorteio',
`🎉🏆 *SORTEIO: ${premio}* 🏆🎉

👥 Participantes: ${nomes.join(', ')}

🎊 A roleta parou em...

✨ *${vencedor}* ✨

🎁 Parabéns!`))

      await revelarComEdicoes(arlequina, from, info, frames, { delayMinMs: 400, delayMaxMs: 1000, mentions })
    } catch (e) {
      console.log('❌ ERRO (sorteio):', e?.message)
      await reply('❌ Não consegui fazer o sorteio agora.')
    }
  }
}
