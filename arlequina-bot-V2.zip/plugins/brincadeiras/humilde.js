const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'humilde',
  emoji: '🙏',
  titulo: 'É humilde',
  frases: ["mesmo podendo se gabar, prefere ficar quieto! 🙏", "trata todo mundo igual, sem se achar! 💜", "dá valor até nas coisas pequenas! 🌱"]
})
