const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/3Dpw2lZel'

module.exports = {
  name: 'pobre',
  description: 'TESTE DE POBRE',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('💸')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["💰 Rico igual Scrooge!", "💎 Dinheiro sobrando.", "🏦 Conta no azul.", "✨ Financeiro no topo.", "🤑 Poderia pagar o grupo inteiro.", "💵 Carteira sempre recheada.", "🏖️ Já tá planejando a próxima viagem.", "📈 Investimentos rendendo bem."]
      const frasesAltas = ["💸 Pix negado!", "😭 Saldo devedor.", "💀 Nem no delivery consegue.", "😅 Rico de espírito.", "🥲 Mês de 40 dias.", "🛒 Carrinho do mercado vazio.", "🪙 Contando moeda pra passagem.", "📉 Saldo no negativo desde cedo."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('pobre', LINK_FOTO)
      const texto = caixaArlequina("pobre", `💸 *TESTE DE POBRE* 💸\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO pobre:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
