const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/YyPAF1byj'

module.exports = {
  name: 'rankgay',
  description: 'RANK GAY DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankgay", `❌ Este comando só funciona em grupos.`))
    await reagir('🌈')
    try {
      await enviarRank(arlequina, from, info, 'RANK GAY DO GRUPO', '🌈', 'rankgay', 'Orgulho total! 🏳️‍🌈', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankgay:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
