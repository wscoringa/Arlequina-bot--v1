const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/4iaBLMd76'

module.exports = {
  name: 'inteligente',
  description: 'TESTE DE INTELIGENTE',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🧠')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["😅 QI em modo econômico.", "💀 Deixa o Google pensar.", "🤦 Confundiu fácil.", "😬 Perguntou o óbvio.", "🥴 O cérebro tá de folga.", "🌀 Hoje a mente tá no modo turbo lento.", "📵 Esqueceu até o próprio nome.", "😶 Pergunta simples, resposta impossível."]
      const frasesAltas = ["🧠 Gênio detectado!", "📚 Einstein do grupo!", "💡 Ideia brilhante!", "🎓 Nível PhD!", "🏆 Inteligência absurda!", "🔬 Científico no grupo!", "🧪 Resolveria qualquer enigma.", "📖 Lê e já decora na hora.", "🛰️ Raciocínio nível NASA."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('inteligente', LINK_FOTO)
      const texto = caixaArlequina("inteligente", `🧠 *TESTE DE INTELIGENTE* 🧠\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO inteligente:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
