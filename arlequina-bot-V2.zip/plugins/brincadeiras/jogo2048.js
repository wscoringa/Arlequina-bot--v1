const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'jogo2048',
  description: 'Jogo 2048 interativo',
  category: 'jogos',
  aliases: ['2048', 'vintequarentaoito'],

  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🧩')
      const html = `<!DOCTYPE html>
<html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{background:linear-gradient(#faf8ef,#bbada0);font-family:Arial,sans-serif;color:#776e65;padding:12px;touch-action:none}
h1{text-align:center;font-size:22px;color:#776e65}
.sub{text-align:center;font-size:11px;margin:4px 0 8px}
#score{text-align:center;font-weight:bold;margin-bottom:8px}
#grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;max-width:300px;margin:0 auto;background:#bbada0;padding:8px;border-radius:10px}
.cell{aspect-ratio:1;background:#cdc1b4;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:bold;color:#776e65}
button{display:block;margin:10px auto;padding:10px 16px;border:0;border-radius:8px;background:#8f7a66;color:#fff;font-weight:bold}
#msg{text-align:center;font-size:12px;margin-top:6px}
</style></head><body>
<h1>🧩 2048</h1>
<div class="sub">Deslize pra juntar os números</div>
<div id="score">Score: 0</div>
<div id="grid"></div>
<div id="msg"></div>
<button id="novo">🔄 Novo jogo</button>
<script>
let g,score=0,size=4;
const colors={0:'#cdc1b4',2:'#eee4da',4:'#ede0c8',8:'#f2b179',16:'#f59563',32:'#f67c5f',64:'#f65e3b',128:'#edcf72',256:'#edcc61',512:'#edc850',1024:'#edc53f',2048:'#edc22e'};
function empty(){g=Array.from({length:size},()=>Array(size).fill(0));score=0;add();add();draw()}
function add(){const e=[];for(let r=0;r<size;r++)for(let c=0;c<size;c++)if(!g[r][c])e.push([r,c]);if(!e.length)return;const[r,c]=e[Math.floor(Math.random()*e.length)];g[r][c]=Math.random()<0.9?2:4}
function draw(){
  const el=document.getElementById('grid');el.innerHTML='';
  for(let r=0;r<size;r++)for(let c=0;c<size;c++){
    const v=g[r][c],d=document.createElement('div');d.className='cell';
    d.textContent=v||'';d.style.background=colors[v]||'#3c3a32';d.style.color=v>4?'#f9f6f2':'#776e65';
    el.appendChild(d);
  }
  document.getElementById('score').textContent='Score: '+score;
}
function slide(row){
  let arr=row.filter(v=>v);for(let i=0;i<arr.length-1;i++){if(arr[i]===arr[i+1]){arr[i]*=2;score+=arr[i];arr[i+1]=0}}
  arr=arr.filter(v=>v);while(arr.length<size)arr.push(0);return arr;
}
function move(dir){
  const old=JSON.stringify(g);
  if(dir==='L')g=g.map(r=>slide(r));
  if(dir==='R')g=g.map(r=>slide(r.slice().reverse()).reverse());
  if(dir==='U'){let t=g[0].map((_,c)=>g.map(r=>r[c]));t=t.map(r=>slide(r));g=t[0].map((_,c)=>t.map(r=>r[c]))}
  if(dir==='D'){let t=g[0].map((_,c)=>g.map(r=>r[c]));t=t.map(r=>slide(r.slice().reverse()).reverse());g=t[0].map((_,c)=>t.map(r=>r[c]))}
  if(JSON.stringify(g)!==old){add();draw();check()}
}
function check(){
  if(g.some(r=>r.includes(2048)))document.getElementById('msg').textContent='🏆 2048!';
  const moves=[['L'],['R'],['U'],['D']];
  // simple stuck check
  let free=g.some(r=>r.includes(0));
  if(free)return;
  for(let r=0;r<size;r++)for(let c=0;c<size;c++){
    if(c+1<size&&g[r][c]===g[r][c+1])return;
    if(r+1<size&&g[r][c]===g[r+1][c])return;
  }
  document.getElementById('msg').textContent='💀 Fim de jogo';
}
let sx=0,sy=0;
document.body.addEventListener('touchstart',e=>{sx=e.touches[0].clientX;sy=e.touches[0].clientY},{passive:true});
document.body.addEventListener('touchend',e=>{
  const dx=e.changedTouches[0].clientX-sx,dy=e.changedTouches[0].clientY-sy;
  if(Math.abs(dx)<20&&Math.abs(dy)<20)return;
  if(Math.abs(dx)>Math.abs(dy))move(dx>0?'R':'L');else move(dy>0?'D':'U');
},{passive:true});
document.addEventListener('keydown',e=>{
  const m={ArrowLeft:'L',ArrowRight:'R',ArrowUp:'U',ArrowDown:'D'};
  if(m[e.key]){e.preventDefault();move(m[e.key])}
});
document.getElementById('novo').onclick=()=>{document.getElementById('msg').textContent='';empty()};
empty();
</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'jogo2048-interativo',
        titulo: '2048',
        texto: '> 2048 interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro jogo2048:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
