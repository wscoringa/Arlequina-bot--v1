const { enviarRank } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Mesmo link do comando base (baiano.js)
const LINK_FOTO = 'https://pin.it/a7KTAQC5c'

module.exports = {
  name: 'rankbaiano',
  description: 'RANK BAIANO DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankbaiano", `❌ Este comando só funciona em grupos.`))
    await reagir('🌴')
    try {
      await enviarRank(arlequina, from, info, 'RANK BAIANO DO GRUPO', '🌴', 'rankbaiano', 'Top 5 mais baiano do grupo!', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankbaiano:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
