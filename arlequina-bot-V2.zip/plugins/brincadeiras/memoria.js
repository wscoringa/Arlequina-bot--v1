const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'memoria',
  description: 'Jogo da memória interativo',
  category: 'jogos',
  aliases: ['jogomemoria', 'memory'],

  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🧠')
      const html = `<!DOCTYPE html>
<html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{background:linear-gradient(#2d1b4e,#1a0a2e);font-family:Arial,sans-serif;color:#fff;padding:12px}
h1{text-align:center;font-size:18px}
.sub{text-align:center;font-size:11px;opacity:.85;margin:4px 0 10px}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;max-width:320px;margin:0 auto}
.card{aspect-ratio:1;border-radius:10px;background:#4a2c7a;display:flex;align-items:center;justify-content:center;font-size:28px;cursor:pointer;border:2px solid #9b59b6;user-select:none}
.card.on{background:#f1c40f;color:#222}
.card.done{background:#27ae60;border-color:#2ecc71;opacity:.85}
#info{text-align:center;margin-top:10px;font-size:13px}
button{display:block;margin:10px auto 0;padding:10px 18px;border:0;border-radius:8px;background:#9b59b6;color:#fff;font-weight:bold}
</style></head><body>
<h1>🧠 MEMÓRIA</h1>
<div class="sub">Ache os pares</div>
<div class="grid" id="g"></div>
<div id="info">Jogadas: 0</div>
<button id="rst">🔄 Reiniciar</button>
<script>
const emojis=['💜','🃏','🎱','🎹','🐍','⭐','🔥','💎'];
let deck,open,lock,moves,found;
function shuffle(a){for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function start(){
  deck=shuffle([...emojis,...emojis].map((e,i)=>({e,id:i,done:false})));
  open=[];lock=false;moves=0;found=0;
  document.getElementById('info').textContent='Jogadas: 0';
  const g=document.getElementById('g');g.innerHTML='';
  deck.forEach((c,i)=>{
    const d=document.createElement('div');d.className='card';d.dataset.i=i;d.textContent='❓';
    d.onclick=()=>flip(i,d);g.appendChild(d);
  });
}
function flip(i,el){
  const c=deck[i];if(lock||c.done||open.find(o=>o.i===i))return;
  el.textContent=c.e;el.classList.add('on');open.push({i,el,e:c.e});
  if(open.length<2)return;
  moves++;document.getElementById('info').textContent='Jogadas: '+moves;
  lock=true;
  if(open[0].e===open[1].e){
    open.forEach(o=>{deck[o.i].done=true;o.el.classList.add('done');o.el.classList.remove('on')});
    found++;open=[];lock=false;
    if(found===emojis.length)document.getElementById('info').textContent='🏆 Zerou em '+moves+' jogadas!';
  } else {
    setTimeout(()=>{open.forEach(o=>{o.el.textContent='❓';o.el.classList.remove('on')});open=[];lock=false},650);
  }
}
document.getElementById('rst').onclick=start;start();
</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'memoria-interativo',
        titulo: 'Memória',
        texto: '> Memória interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro memoria:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
