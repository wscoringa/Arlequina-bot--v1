const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'invasores',
  description: 'Invasores espaciais interativo',
  category: 'jogos',
  aliases: ['tiro', 'spaceinvaders', 'nave'],

  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🚀')
      const html = `<!DOCTYPE html>
<html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{background:#0a0a1a;font-family:Arial,sans-serif;color:#fff;padding:10px;touch-action:none}
h1{text-align:center;font-size:18px}
.sub{text-align:center;font-size:11px;opacity:.8;margin:4px 0 8px}
canvas{display:block;width:100%;max-width:320px;margin:0 auto;background:#111;border-radius:10px;border:2px solid #333}
#hud{text-align:center;margin-top:8px;font-size:13px}
button{display:block;margin:10px auto;padding:10px 16px;border:0;border-radius:8px;background:#9b59b6;color:#fff;font-weight:bold}
</style></head><body>
<h1>🚀 INVASORES</h1>
<div class="sub">Arraste pra mover • toque pra atirar</div>
<canvas id="c" width="280" height="360"></canvas>
<div id="hud">Score: 0</div>
<button id="start">▶ Começar</button>
<script>
const cv=document.getElementById('c'),ctx=cv.getContext('2d');
let ship,bullets,enemies,score,run,cooldown;
function reset(){
  ship={x:130,y:330,w:28,h:16};bullets=[];enemies=[];score=0;cooldown=0;run=true;
  for(let r=0;r<3;r++)for(let c=0;c<6;c++)enemies.push({x:20+c*42,y:30+r*28,w:24,h:16,alive:true});
  document.getElementById('hud').textContent='Score: 0';loop();
}
function loop(){
  if(!run)return;
  ctx.fillStyle='#0a0a1a';ctx.fillRect(0,0,280,360);
  // ship
  ctx.fillStyle='#2ecc71';ctx.fillRect(ship.x,ship.y,ship.w,ship.h);
  // bullets
  ctx.fillStyle='#f1c40f';
  for(let i=bullets.length-1;i>=0;i--){const b=bullets[i];b.y-=7;ctx.fillRect(b.x,b.y,3,10);if(b.y<0)bullets.splice(i,1)}
  // enemies
  let allDead=true;
  for(const e of enemies){
    if(!e.alive)continue;allDead=false;
    e.x+=Math.sin(Date.now()/500+e.y)*0.3;
    ctx.fillStyle='#e74c3c';ctx.fillRect(e.x,e.y,e.w,e.h);
    for(let i=bullets.length-1;i>=0;i--){
      const b=bullets[i];
      if(b.x>e.x&&b.x<e.x+e.w&&b.y>e.y&&b.y<e.y+e.h){e.alive=false;bullets.splice(i,1);score+=10;document.getElementById('hud').textContent='Score: '+score}
    }
  }
  if(allDead){run=false;document.getElementById('hud').textContent='🏆 Score: '+score}
  if(cooldown>0)cooldown--;
  requestAnimationFrame(loop);
}
cv.addEventListener('pointermove',e=>{
  if(!run)return;const r=cv.getBoundingClientRect();
  ship.x=Math.max(0,Math.min(252,(e.clientX-r.left)*(280/r.width)-14));
});
cv.addEventListener('pointerdown',e=>{
  if(!run)return;
  if(cooldown<=0){bullets.push({x:ship.x+13,y:ship.y});cooldown=12}
});
document.getElementById('start').onclick=reset;
ctx.fillStyle='#111';ctx.fillRect(0,0,280,360);
ctx.fillStyle='#fff';ctx.font='14px Arial';ctx.textAlign='center';ctx.fillText('Toque ▶ Começar',140,180);
</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'invasores-interativo',
        titulo: 'INVASORES',
        texto: '> INVASORES interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro invasores:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
