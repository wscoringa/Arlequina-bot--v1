const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'cobrinha',
  description: 'Jogo da cobrinha interativo',
  category: 'jogos',
  aliases: ['snake', 'jogocobra'],

  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🐍')
      const html = `<!DOCTYPE html>
<html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{background:linear-gradient(#1a1a2e,#16213e);font-family:Arial,sans-serif;color:#fff;padding:12px}
h1{text-align:center;font-size:18px}
.sub{text-align:center;font-size:11px;opacity:.85;margin:4px 0 8px}
#c{display:block;margin:0 auto;background:#0f3460;border:3px solid #e94560;border-radius:8px;width:100%;max-width:320px;touch-action:none}
.row{display:flex;gap:6px;justify-content:center;margin-top:8px;flex-wrap:wrap}
button{padding:12px 16px;border:0;border-radius:8px;background:#e94560;color:#fff;font-weight:bold;font-size:14px;min-width:48px}
#sc{text-align:center;margin-top:8px;font-size:13px}
</style></head><body>
<h1>🐍 COBRINHA</h1>
<div class="sub">Use os botões ou deslize na tela</div>
<canvas id="c" width="300" height="300"></canvas>
<div id="sc">Pontos: 0</div>
<div class="row">
<button id="u">⬆️</button>
</div>
<div class="row">
<button id="l">⬅️</button>
<button id="d">⬇️</button>
<button id="r">➡️</button>
</div>
<div class="row"><button id="go">▶️ Começar / Reiniciar</button></div>
<script>
const cv=document.getElementById('c'),ctx=cv.getContext('2d');
const N=15,S=300/N;let snake,dir,food,score,loop,alive;
function reset(){
  snake=[{x:7,y:7}];dir={x:1,y:0};score=0;alive=true;place();
  document.getElementById('sc').textContent='Pontos: 0';
  clearInterval(loop);loop=setInterval(tick,140);
}
function place(){
  do{food={x:Math.floor(Math.random()*N),y:Math.floor(Math.random()*N)}}
  while(snake.some(s=>s.x===food.x&&s.y===food.y));
}
function tick(){
  if(!alive)return;
  const h={x:snake[0].x+dir.x,y:snake[0].y+dir.y};
  if(h.x<0||h.y<0||h.x>=N||h.y>=N||snake.some(s=>s.x===h.x&&s.y===h.y)){
    alive=false;document.getElementById('sc').textContent='💀 Game Over! Pontos: '+score;return;
  }
  snake.unshift(h);
  if(h.x===food.x&&h.y===food.y){score++;document.getElementById('sc').textContent='Pontos: '+score;place()}
  else snake.pop();
  draw();
}
function draw(){
  ctx.fillStyle='#0f3460';ctx.fillRect(0,0,300,300);
  ctx.fillStyle='#e94560';ctx.fillRect(food.x*S,food.y*S,S-1,S-1);
  snake.forEach((s,i)=>{ctx.fillStyle=i? '#0ead69':'#f9c74f';ctx.fillRect(s.x*S,s.y*S,S-1,S-1)});
}
function setDir(x,y){if(snake.length>1&&dir.x===-x&&dir.y===-y)return;dir={x,y}}
document.getElementById('u').onclick=()=>setDir(0,-1);
document.getElementById('d').onclick=()=>setDir(0,1);
document.getElementById('l').onclick=()=>setDir(-1,0);
document.getElementById('r').onclick=()=>setDir(1,0);
document.getElementById('go').onclick=reset;
let sx,sy;
cv.addEventListener('touchstart',e=>{const t=e.touches[0];sx=t.clientX;sy=t.clientY},{passive:true});
cv.addEventListener('touchend',e=>{
  const t=e.changedTouches[0];const dx=t.clientX-sx,dy=t.clientY-sy;
  if(Math.abs(dx)<20&&Math.abs(dy)<20)return;
  if(Math.abs(dx)>Math.abs(dy))setDir(dx>0?1:-1,0);else setDir(0,dy>0?1:-1);
});
reset();
</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'cobrinha-interativo',
        titulo: 'Cobrinha',
        texto: '> Cobrinha interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro cobrinha:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
