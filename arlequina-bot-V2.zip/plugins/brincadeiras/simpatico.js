const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'simpatico',
  emoji: '😄',
  titulo: 'É simpático(a)',
  frases: ["cai bem em qualquer roda de conversa! 😄", "faz amizade em qualquer lugar! 🤝", "tem aquele sorriso fácil de dar bom dia! ☀️"]
})
