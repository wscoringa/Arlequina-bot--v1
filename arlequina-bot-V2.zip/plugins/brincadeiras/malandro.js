const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'malandro',
  emoji: '🕶️',
  titulo: 'É malandro(a)',
  frases: ["sempre dá um jeitinho em qualquer perrengue! 🕶️", "sabe escapar de qualquer situação! 🐍", "tira onda até sem querer! 😏"]
})
