/*
 Comando: roletaimg (aliases: roletadecisao, girarroleta)
 Gera uma imagem de roleta com as opções que a pessoa digitar, separadas
 por vírgula, usando a API systemzone.store/api/canvas/roleta.

 OBS: testei esse endpoint com vários formatos (texto simples, separado
 por vírgula, por barra) e ele sempre voltou erro 400 (parâmetro que
 essa API espera deve ser diferente de só "text", ou o formato da lista
 é outro). Deixei o comando chamando a API exatamente como especificado,
 mas com um FALLBACK: se a API falhar, o comando ainda sorteia uma opção
 localmente e manda o resultado em texto, pra nunca ficar sem resposta.
*/
const axios = require('axios')
const { baixarBufferUrl } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const HEADERS_PADRAO = {
  'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0 Mobile Safari/537.36'
}

module.exports = {
  name: 'roletaimg',
  description: '🎡 Roleta com imagem — sorteia entre as opções que você digitar',
  category: 'brincadeiras',
  aliases: ['roletadecisao', 'girarroleta'],
  async execute({ arlequina, from, info, q, args, reply, reagir, prefix }) {
    const textoCompleto = (q || args.join(' ')).trim()
    const opcoes = textoCompleto.split(',').map(o => o.trim()).filter(Boolean)

    if (opcoes.length < 2) {
      return reply(caixaArlequina('roletaimg', `🎡 Como usar:\n${prefix}roletaimg opção1, opção2, opção3\n\nEx: ${prefix}roletaimg pizza, hambúrguer, sushi`))
    }

    const sorteada = opcoes[Math.floor(Math.random() * opcoes.length)]

    try {
      await reagir('🎡')
      const url = `https://systemzone.store/api/canvas/roleta?text=${encodeURIComponent(textoCompleto)}`
      const { data } = await axios.get(url, { timeout: 20000, headers: HEADERS_PADRAO })
      const imagemUrl = data?.imagem || data?.image || data?.url

      if (imagemUrl) {
        const buffer = await baixarBufferUrl(imagemUrl)
        return await arlequina.sendMessage(from, {
          image: buffer,
          caption: caixaArlequina('roletaimg', `🎡 A roleta parou em:\n\n🎯 *${sorteada}*`)
        }, { quoted: info })
      }
      throw new Error('API não retornou imagem')
    } catch (e) {
      console.log('❌ ERRO roletaimg (usando fallback local):', e?.response?.status || e?.code || e?.message)
      // Fallback: sem imagem, mas ainda sorteia e responde.
      await reply(caixaArlequina('roletaimg', `🎡 A roleta parou em:\n\n🎯 *${sorteada}*\n\n_(imagem da roleta indisponível agora)_`))
    }
  }
}
