const { imagemDeLink, imagemDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/48g6VDNOA'

module.exports = {
  name: 'beta',
  description: 'TESTE DE BETA',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🐑')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["😎 Nada de beta hoje.", "🔥 Postura de alfa detectada.", "💪 Não depende de ninguém.", "🙅 Zero traço de beta."]
      const frasesAltas = ["🐑 Beta puro!", "📉 Sempre pedindo aprovação.", "😅 Depende da opinião alheia.", "🫠 Postura totalmente submissa.", "📲 Vive validando os outros."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('beta', LINK_FOTO)
      const texto = caixaArlequina("beta", `🐑 *TESTE DE BETA* 🐑\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO beta:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
