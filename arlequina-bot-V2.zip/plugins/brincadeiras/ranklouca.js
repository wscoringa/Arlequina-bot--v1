const { enviarRank } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Mesmo link do comando base (louca.js)
const LINK_FOTO = 'https://pin.it/52iPjMyUK'

module.exports = {
  name: 'ranklouca',
  description: 'RANK LOUCA DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("ranklouca", `❌ Este comando só funciona em grupos.`))
    await reagir('🤪')
    try {
      await enviarRank(arlequina, from, info, 'RANK LOUCA DO GRUPO', '🤪', 'ranklouca', 'Top 5 mais loucas do grupo!', LINK_FOTO)
    } catch (e) {
      console.error('ERRO ranklouca:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
