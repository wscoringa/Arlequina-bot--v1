const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/2V01GapDo'

module.exports = {
  name: 'ranklindo',
  description: 'RANK LINDO DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("ranklindo", `❌ Este comando só funciona em grupos.`))
    await reagir('🤴')
    try {
      await enviarRank(arlequina, from, info, 'RANK LINDO DO GRUPO', '🤴', 'ranklindo', 'Os 5 mais lindos do grupo!', LINK_FOTO)
    } catch (e) {
      console.error('ERRO ranklindo:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
