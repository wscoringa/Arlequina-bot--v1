const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/5DOYOamyU'

module.exports = {
  name: 'capeta',
  description: 'TESTE DE CAPETA',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('😈')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["😇 Hoje tá bem bonzinho.", "🕊️ Anjo disfarçado.", "💤 Maldade em modo off.", "🥲 Capeta de brincadeira.", "🫶 Coração mole hoje.", "🌼 Hoje só espalha flor.", "🍼 Inocência em pessoa.", "🐑 Manso igual cordeirinho."]
      const frasesAltas = ["😈 Capeta raiz!", "🔥 Maldade no sangue!", "💀 Nem o diabo segura!", "🃏 Arlequina ficou com medo!", "👿 Perigo total no grupo!", "⚡ Maldade no nível máximo!", "🔥 Já reservou lugar no inferno.", "😏 Maldade calculada e silenciosa.", "🧨 Plantou a discórdia e saiu rindo."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('capeta', LINK_FOTO)
      const texto = caixaArlequina("capeta", `😈 *TESTE DE CAPETA* 😈\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO capeta:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
