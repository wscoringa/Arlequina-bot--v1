const { enviarRank } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Mesmo link do comando base (otaku.js)
const LINK_FOTO = 'https://pin.it/5iahH114l'

module.exports = {
  name: 'rankotaku',
  description: 'RANK OTAKU DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankotaku", `❌ Este comando só funciona em grupos.`))
    await reagir('🎌')
    try {
      await enviarRank(arlequina, from, info, 'RANK OTAKU DO GRUPO', '🎌', 'rankotaku', 'Top 5 mais otaku do grupo!', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankotaku:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
