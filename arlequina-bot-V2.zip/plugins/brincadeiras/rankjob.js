const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (recomendo uma imagem bem safada +18)
const LINK_FOTO = 'https://pin.it/4N9XFNsQz' // Troque por uma foto bem pesada

module.exports = {
  name: 'rankjob',
  description: 'RANK JOB +18 DO GRUPO',
  category: 'brincadeiras',
  aliases: ['rankboquete', 'rankbj', 'rankjob18'],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankjob", `❌ Este comando só funciona em grupos.`))

    await reagir('🍆')

    try {
      await enviarRank(
        arlequina, 
        from, 
        info, 
        '🔥 RANK JOB +18 DO GRUPO 🔥', 
        '💦', 
        'rankjob', 
        'Os 5 que mais chupam e engolem no grupo! 😈', 
        LINK_FOTO
      )
    } catch (e) {
      console.error('ERRO rankjob +18:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
