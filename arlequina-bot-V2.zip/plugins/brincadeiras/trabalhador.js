const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'trabalhador',
  emoji: '💼',
  titulo: 'É trabalhador(a)',
  frases: ["tá na ativa antes até do sol nascer! ☀️", "não larga o serviço nem no fim de semana! 💼", "é o tipo que nunca tira férias de verdade! 📈"]
})
