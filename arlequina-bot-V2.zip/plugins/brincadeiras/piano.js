
module.exports = {
  name: 'piano',
  description: 'Abre um piano interativo',
  category: 'jogos',
  aliases: ['jogopiano'],

  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🎹')

      const html = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
  <style>
    * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
    html, body {
      margin: 0;
      padding: 0;
      background: linear-gradient(#5c94fc, #8fc4ff);
      font-family: Arial, sans-serif;
      overflow-x: hidden;
    }
    body { padding: 20px 0; }
    .title { text-align: center; color: #fff; font-size: 22px; font-weight: bold; }
    .sub { text-align: center; color: #fff; font-size: 13px; margin: 6px 0 25px; }
    .piano-wrap { width: 100%; padding: 0 12px; }
    .piano {
      position: relative;
      width: 100%;
      height: 52vw;
      max-height: 260px;
      min-height: 170px;
      display: flex;
      touch-action: none;
    }
    .white {
      position: relative;
      width: 12.5%;
      flex: 1 1 12.5%;
      height: 100%;
      padding: 0 0 14px;
      margin: 0;
      background: #fff;
      border: 1px solid #222;
      border-radius: 0 0 8px 8px;
      color: #222;
      font-size: 11px;
      font-weight: bold;
      display: flex;
      align-items: flex-end;
      justify-content: center;
      box-shadow: 0 5px 0 #aaa;
      z-index: 1;
    }
    .white:first-child { border-radius: 10px 0 0 10px; }
    .white:last-child { border-radius: 0 10px 10px 0; }
    .white:active, .white.active {
      background: #ddd;
      transform: translateY(5px);
      box-shadow: 0 1px 0 #888;
    }
    .black {
      position: absolute;
      top: 0;
      width: 9%;
      height: 58%;
      padding: 0 0 10px;
      margin: 0;
      background: linear-gradient(90deg, #111, #333, #050505);
      border: 2px solid #000;
      border-radius: 0 0 6px 6px;
      color: #fff;
      font-size: 9px;
      font-weight: bold;
      display: flex;
      align-items: flex-end;
      justify-content: center;
      box-shadow: 0 6px 5px rgba(0,0,0,.5);
      z-index: 5;
    }
    .black:active, .black.active {
      background: #555;
      transform: translateY(4px);
      box-shadow: 0 2px 3px rgba(0,0,0,.5);
    }
    .b1 { left: 7.8%; }
    .b2 { left: 20.3%; }
    .b3 { left: 45.3%; }
    .b4 { left: 57.8%; }
    .b5 { left: 70.3%; }
    #note {
      text-align: center;
      color: #fff;
      font-size: 22px;
      font-weight: bold;
      margin-top: 25px;
    }
  </style>
</head>
<body>
  <div class="title">PIANO</div>
  <div class="sub">Do - Re - Mi - Fa - Sol - La - Si - Do</div>

  <div class="piano-wrap">
    <div class="piano">
      <button class="white" data-freq="261.63" data-name="Do">Do</button>
      <button class="white" data-freq="293.66" data-name="Re">Re</button>
      <button class="white" data-freq="329.63" data-name="Mi">Mi</button>
      <button class="white" data-freq="349.23" data-name="Fa">Fa</button>
      <button class="white" data-freq="392.00" data-name="Sol">Sol</button>
      <button class="white" data-freq="440.00" data-name="La">La</button>
      <button class="white" data-freq="493.88" data-name="Si">Si</button>
      <button class="white" data-freq="523.25" data-name="Do">Do</button>

      <button class="black b1" data-freq="277.18" data-name="Do#">Do#</button>
      <button class="black b2" data-freq="311.13" data-name="Re#">Re#</button>
      <button class="black b3" data-freq="369.99" data-name="Fa#">Fa#</button>
      <button class="black b4" data-freq="415.30" data-name="Sol#">Sol#</button>
      <button class="black b5" data-freq="466.16" data-name="La#">La#</button>
    </div>
  </div>

  <div id="note">Toque o piano</div>

  <script>
    let audioContext = null;

    function initAudio() {
      if (!audioContext) {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (!AudioContext) {
          document.getElementById('note').textContent = 'Áudio não suportado';
          return null;
        }
        audioContext = new AudioContext();
      }
      if (audioContext.state === 'suspended') audioContext.resume();
      return audioContext;
    }

    function playPiano(freq) {
      const ctx = initAudio();
      if (!ctx) return;

      const now = ctx.currentTime;
      const master = ctx.createGain();
      master.gain.setValueAtTime(0, now);
      master.gain.linearRampToValueAtTime(0.5, now + 0.015);
      master.gain.exponentialRampToValueAtTime(0.001, now + 1.2);
      master.connect(ctx.destination);

      [
        { type: 'triangle', multiplier: 1, volume: 1 },
        { type: 'sine', multiplier: 2, volume: 0.22 },
        { type: 'sine', multiplier: 3, volume: 0.08 }
      ].forEach(({ type, multiplier, volume }) => {
        const oscillator = ctx.createOscillator();
        const gain = ctx.createGain();
        oscillator.type = type;
        oscillator.frequency.value = freq * multiplier;
        gain.gain.value = volume;
        oscillator.connect(gain);
        gain.connect(master);
        oscillator.start(now);
        oscillator.stop(now + 1.3);
      });
    }

    document.querySelectorAll('.white, .black').forEach((key) => {
      const press = (event) => {
        event.preventDefault();
        key.classList.add('active');
        document.getElementById('note').textContent = key.dataset.name;
        playPiano(Number(key.dataset.freq));
      };
      const release = () => key.classList.remove('active');
      key.addEventListener('pointerdown', press);
      key.addEventListener('pointerup', release);
      key.addEventListener('pointercancel', release);
      key.addEventListener('pointerleave', release);
    });
  </script>
</body>
</html>`

      await columbina.relayMessage(
        from,
        {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          botForwardedMessage: {
            message: {
              richResponseMessage: {
                messageType: 1,
                submessages: [
                  {
                    messageType: 2,
                    messageText: 'PIANO INTERATIVO'
                  }
                ],
                unifiedResponse: {
                  data: Buffer.from(JSON.stringify({
                    response_id: 'piano-interativo',
                    sections: [
                      {
                        view_model: {
                          primitive: {
                            text: '> Piano interativo</>',
                            __typename: 'GenAIMarkdownTextUXPrimitive'
                          },
                          __typename: 'GenAISingleLayoutViewModel'
                        }
                      }
                    ],
                    embedded_screens: [
                      {
                        title: 'PIANO',
                        content: [
                          {
                            __typename: 'FOAIDNixelButtonSheets',
                            tabs: [
                              {
                                id: 'tab_0',
                                tab_header: 'Piano',
                                sections: [
                                  {
                                    __typename: 'GenAIUnifiedResponseSection',
                                    view_model: {
                                      __typename: 'GenAISingleLayoutViewModel',
                                      primitive: {
                                        __typename: 'GenAIaeacdsnwHtmlPrimitive',
                                        payload: html,
                                        trusted_sources: ['columbina-apis.onrender.com']
                                      }
                                    }
                                  }
                                ]
                              }
                            ]
                          }
                        ]
                      }
                    ]
                  })).toString('base64')
                },
                contextInfo: {
                  forwardingScore: 1,
                  isForwarded: true,
                  forwardedAiBotMessageInfo: {
                    botJid: '867051314767696@bot'
                  },
                  forwardOrigin: 4
                }
              }
            }
          }
        },
        {}
      )
    } catch (error) {
      console.error('Erro ao abrir o piano:', error)
      await reply('Não foi possível abrir o piano agora.')
    }
  }
}
