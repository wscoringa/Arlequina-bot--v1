const { enviarRank } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Mesmo link do comando base (sigma.js)
const LINK_FOTO = 'https://pin.it/10WRTQlrg'

module.exports = {
  name: 'ranksigma',
  description: 'RANK SIGMA DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("ranksigma", `❌ Este comando só funciona em grupos.`))
    await reagir('🗿')
    try {
      await enviarRank(arlequina, from, info, 'RANK SIGMA DO GRUPO', '🗿', 'ranksigma', 'Top 5 mentalidade sigma do grupo!', LINK_FOTO)
    } catch (e) {
      console.error('ERRO ranksigma:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
