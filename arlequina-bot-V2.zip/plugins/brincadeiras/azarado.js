const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/5fhhaD8uO'

module.exports = {
  name: 'azarado',
  description: 'TESTE DE AZARADO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🍀')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["🍀 Tá na maré boa hoje!", "✨ Sorte sobrando!", "🌟 Dia abençoado!", "🎯 Nada vai dar errado!", "💫 Sortudo da vez!", "🌈 Sorte em todos os cantos!", "🎰 Ganharia até na loteria!", "🍯 Tudo doce hoje."]
      const frasesAltas = ["💀 Azar em estado crítico!", "😭 Melhor ficar em casa.", "🪦 Até o guarda-chuva furou.", "🎲 Nunca ganha na sorte.", "⚠️ Perigo: azar contagioso!", "🌧️ Choveu só em cima.", "🔮 Até o horóscopo desistiu.", "🧹 Vassoura voadora pra fugir do azar.", "📉 Recorde de mau momento."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('azarado', LINK_FOTO)
      const texto = caixaArlequina("azarado", `🍀 *TESTE DE AZARADO* 🍀\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO azarado:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
