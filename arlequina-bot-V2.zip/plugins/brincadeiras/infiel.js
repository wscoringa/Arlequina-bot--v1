const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/6McCUJtT2'

module.exports = {
  name: 'infiel',
  description: 'TESTE DE INFIEL',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('💔')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["❤️ Fidelidade no sangue!", "🔒 Compromisso sagrado.", "💪 Nunca traiu, nunca vai.", "🕊️ Amor verdadeiro.", "🌹 Parceiro(a) dos sonhos.", "🔐 Lealdade inquebrável.", "💍 Compromisso é compromisso.", "🌷 Relação tranquila e sólida."]
      const frasesAltas = ["💔 Infiel confirmado(a)!", "😈 Não resiste à tentação.", "😬 O grupo já sabe de tudo.", "💀 Álibis fracos hoje.", "🚨 Sinal vermelho no relacionamento.", "📱 Dois chips, duas histórias.", "🎭 Mestre do \"foi só uma vez\".", "🚩 Bandeira vermelha gigante."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('infiel', LINK_FOTO)
      const texto = caixaArlequina("infiel", `💔 *TESTE DE INFIEL* 💔\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO infiel:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
