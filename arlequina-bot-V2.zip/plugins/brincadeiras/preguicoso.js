const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/6yY9a2D89'

module.exports = {
  name: 'preguicoso',
  description: 'TESTE DE PREGUIÇOSO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🦥')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["⚡ Produtividade a mil!", "🏃 Não para nem um segundo.", "💪 Energia infinita.", "🌟 Fez tudo antes do prazo.", "☀️ Levantou cedo e mandou ver.", "🧹 Casa impecável antes do meio-dia.", "📋 Lista de tarefas zerada.", "🐝 Modo abelha ativado."]
      const frasesAltas = ["🦥 Preguiça raiz!", "💀 O sofá tem sua forma.", "😴 Adia até o amanhã do amanhã.", "🛏️ Cama é o lar.", "😂 Cansou de pensar em levantar.", "🛋️ Sofá já tem nome registrado.", "📴 Desligou o despertador sem culpa.", "🍕 Pediu delivery pra não levantar."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('preguicoso', LINK_FOTO)
      const texto = caixaArlequina("preguicoso", `🦥 *TESTE DE PREGUIÇOSO* 🦥\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO preguicoso:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
