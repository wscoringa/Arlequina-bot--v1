const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'macho',
  emoji: '🦍',
  titulo: 'Tá no papel de "brabo" hoje',
  frases: ["se acha o mais durão do grupo! 🦍", "levanta peso só pra postar story! 📸", "fala grosso mas foge de barata! 😅"]
})
