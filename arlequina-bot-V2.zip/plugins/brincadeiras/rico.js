const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/7DcchB6Vw'

module.exports = {
  name: 'rico',
  description: 'TESTE DE RICO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('💰')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["💸 Conta no vermelho.", "😭 Pix bloqueado.", "🥲 Rico de espirito.", "😅 Mês de 40 dias.", "💀 Faxina pra pagar o boleto.", "🪙 Contando centavo pro fim do mês.", "📉 Saldo pedindo socorro.", "🛒 Lista de compras cortada na metade."]
      const frasesAltas = ["💰 Rico geral!", "🏦 Conta estourando!", "💎 Poderia comprar o grupo!", "🤑 Milionário confirmado!", "✨ Financeiro no topo!", "💳 Limite do cartão é só formalidade.", "🏝️ Já tem casa de praia reservada.", "🚗 Garagem cheia de novidade."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('rico', LINK_FOTO)
      const texto = caixaArlequina("rico", `💰 *TESTE DE RICO* 💰\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO rico:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
