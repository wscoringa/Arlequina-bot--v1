const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/5F1pkbbUm'

module.exports = {
  name: 'corno',
  description: 'TESTE DE CORNO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🐄')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["💪 Fiel como nunca!", "❤️ Relacionamento sagrado.", "🕊️ Zero traição por aqui.", "✨ Parceiro(a) sortudo(a).", "🔒 Fidelidade máxima.", "🛡️ Blindado contra traição.", "💍 Relação a prova de dúvidas.", "🌹 Parceiro(a) de confiança plena."]
      const frasesAltas = ["🐄 Fez aniversário de corno.", "💀 Tá sabendo de nada.", "😬 O grupo sabe mais que você.", "😭 Dói só de ver.", "⚠️ Sinal de fumaça no relacionamento.", "📸 Print já tá circulando.", "🙈 O grupo inteiro sabia antes.", "🎭 Último a saber, como sempre."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('corno', LINK_FOTO)
      const texto = caixaArlequina("corno", `🐄 *TESTE DE CORNO* 🐄\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO corno:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
