const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/5fhhaD8uO'

module.exports = {
  name: 'rankazarado',
  description: 'RANK AZARADO DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankazarado", `❌ Este comando só funciona em grupos.`))
    await reagir('🍀')
    try {
      await enviarRank(arlequina, from, info, 'RANK AZARADO DO GRUPO', '🍀', 'rankazarado', 'Esses 5 estão com o azar em dia hoje...', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankazarado:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
