const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'fraco',
  emoji: '🍃',
  titulo: 'É fraco',
  frases: ["nem abre saquinho de salgadinho! 😅", "cansa só de pensar em malhar! 🛋️", "perde pro vento em queda de braço! 🍃"]
})
