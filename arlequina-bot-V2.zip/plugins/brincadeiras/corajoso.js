const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'corajoso',
  emoji: '🦁',
  titulo: 'É corajoso(a)',
  frases: ["encara qualquer barata de peito aberto! 🦁", "não tem medo nem de segunda-feira! 🔥", "seria o primeiro a entrar no filme de terror! 🎬"]
})
