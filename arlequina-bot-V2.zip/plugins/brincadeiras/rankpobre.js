const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/4PPycyq0N'

module.exports = {
  name: 'rankpobre',
  description: 'RANK POBRE DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankpobre", `❌ Este comando só funciona em grupos.`))
    await reagir('💸')
    try {
      await enviarRank(arlequina, from, info, 'RANK POBRE DO GRUPO', '💸', 'rankpobre', 'Esses 5 tão precisando de um pix.', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankpobre:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
