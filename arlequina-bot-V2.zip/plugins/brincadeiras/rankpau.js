const { imagemFixaDoRank, medalha } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque pelo link do Pinterest que você quiser)
const LINK_FOTO = 'https://pin.it/gRIdCXBGB'

module.exports = {
  name: 'rankpau',
  description: 'RANK DE TAMANHO DO GRUPO (cm)',
  category: 'brincadeiras',
  aliases: ['ranktamanho'],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankpau", `❌ Este comando só funciona em grupos.`))
    await reagir('📏')
    try {
      const metadata = await arlequina.groupMetadata(from)
      const participantes = metadata.participants
        .map(p => p.id)
        .sort(() => Math.random() - 0.5)
        .slice(0, 5)

      // Gera os cm e ordena do maior pro menor (2 a 27 cm, igual o !pau)
      const lista = participantes.map(id => ({
        id,
        cm: Math.floor(Math.random() * 26) + 2
      })).sort((a, b) => b.cm - a.cm)

      const frasesBaixas = ["🥲 Foi mal.", "🙈 Precisa de régua melhor.", "💀 Sentimos muito.", "😴 Modo econômico."]
      const frasesMedias = ["😌 Na média.", "🙂 Passável.", "😏 Dá pro gasto."]
      const frasesAltas = ["🔥 Monstro!", "💪 Assustador!", "🏆 Recorde!", "👑 Ninguém chega perto!"]
      const fraseParaCm = (cm) => cm <= 9
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : cm <= 18
        ? frasesMedias[Math.floor(Math.random() * frasesMedias.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      let corpo = ''
      lista.forEach(({ id, cm }, i) => {
        corpo += `${medalha(i)} @${id.split('@')[0]}\n`
        corpo += `📐 ${cm} cm — ${fraseParaCm(cm)}\n\n`
      })
      corpo += `\n✨ Top 5 do grupo!`
      const texto = caixaArlequina("rankpau", corpo.trim())

      const imgBuffer = await imagemFixaDoRank('rankpau', LINK_FOTO)
      const mentions = lista.map(l => l.id)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO rankpau:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
