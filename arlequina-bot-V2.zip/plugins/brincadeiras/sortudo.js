const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/3RjUxXBxd'

module.exports = {
  name: 'sortudo',
  description: 'TESTE DE SORTUDO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🍀')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["💀 Azar em dia.", "😭 Nem na raspadinha.", "🪦 Choveu só em cima.", "🎲 Nunca ganha na sorte.", "⚠️ Perigo: azar contagioso!", "🌧️ Só chove em cima mesmo.", "🎲 Dado sempre no número errado.", "🍂 Sorte tirando férias."]
      const frasesAltas = ["🍀 Sortudo raiz!", "✨ Maré boa hoje!", "🌟 Dia abençoado!", "🎯 Tudo dando certo!", "💫 Sorte ativada!", "🎰 Ganhou sem nem precisar tentar.", "🌠 Estrela cadente trabalhando pra você.", "🪄 Tudo se resolve magicamente."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('sortudo', LINK_FOTO)
      const texto = caixaArlequina("sortudo", `🍀 *TESTE DE SORTUDO* 🍀\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO sortudo:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
