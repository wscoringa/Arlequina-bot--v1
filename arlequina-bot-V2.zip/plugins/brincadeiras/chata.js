const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/bhW1pUH8E'

module.exports = {
  name: 'chata',
  description: 'TESTE DE CHATA',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('😤')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["😊 Bem animada hoje!", "🎉 Alegria do grupo!", "✨ Tá divertida hoje.", "🎭 Entretenimento em dia.", "🥳 Todo mundo gosta!", "🎈 Companhia leve e gostosa.", "💬 Conversa que flui fácil.", "🌻 Energia agradável hoje."]
      const frasesAltas = ["😤 Chata profissional!", "💀 Ninguém aguenta mais.", "🥱 Deu sono de ler.", "📵 Querem tirar do grupo.", "😑 Silêncio seria melhor.", "🔁 Repete o mesmo assunto sem parar.", "📢 Fala mais que recado de igreja.", "🙉 Já causou surdez seletiva no grupo."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('chata', LINK_FOTO)
      const texto = caixaArlequina("chata", `😤 *TESTE DE CHATA* 😤\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO chata:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
