const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando
const LINK_FOTO = 'https://pin.it/3YS7rSEGE'

module.exports = {
  name: 'narcisista',
  description: 'TESTE DE NARCISISMO',
  category: 'brincadeiras',
  aliases: ['narciso'],

  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')

    await reagir('👑')

    try {
      const contexto =
        info.message?.extendedTextMessage?.contextInfo ||
        info.message?.imageMessage?.contextInfo ||
        info.message?.videoMessage?.contextInfo ||
        {}

      // 1. Se respondeu alguém
      // 2. Se marcou alguém
      // 3. Caso contrário, usa quem executou
      const alvo =
        contexto.participant ||
        contexto.mentionedJid?.[0] ||
        sender

      // Porcentagem de 0 a 100
      const pct = Math.floor(Math.random() * 101)

      const frasesBaixas = [
        '🥲 Nem um pouco narcisista.',
        '😅 O ego está bem tranquilo.',
        '😇 Narcisismo praticamente inexistente.',
        '🤏 Tem quase nada de ego por aqui.',
        '😂 O espelho não está recebendo muita atenção.',
        '😴 O ego tirou folga hoje.',
        '📉 Nível de narcisismo baixíssimo.',
        '🙈 Hoje não está se achando muito.',
        '😌 Bem longe de ser narcisista.',
        '🫥 O ego está quase invisível.'
      ]

      const frasesMedias = [
        '👀 Já está começando a se achar.',
        '😏 Um pouquinho de ego apareceu.',
        '😂 O espelho já começou a virar amigo.',
        '🃏 Narcisismo moderado detectado.',
        '🤨 Está gostando demais de si mesmo.',
        '😎 O ego está crescendo.',
        '📊 Nível médio de narcisismo.',
        '👑 Já está se sentindo importante.'
      ]

      const frasesAltas = [
        '🔥 Ego nas alturas!',
        '👑 Se acha uma verdadeira lenda!',
        '🚨 NARCISISMO ALTÍSSIMO DETECTADO!',
        '😂 O espelho já virou seu fã-clube!',
        '💥 O ego não cabe mais no grupo!',
        '😈 Está se achando demais!',
        '🏆 Se considera o protagonista de tudo!',
        '🚨 Alerta de ego elevado ativado!'
      ]

      const frasesMaximas = [
        '💀 100% DE NARCISISMO! O ego tomou conta!',
        '👑 NARCISISMO NO MÁXIMO! O espelho virou fã-clube!',
        '🚨 ALERTA MÁXIMO DE EGO!',
        '🔥 100% DE EGO! Essa pessoa se acha uma lenda!',
        '😂 O ego já ocupa mais espaço que a própria pessoa!',
        '🃏💜 ARLEQUINA DETECTOU NARCISISMO ABSURDO!'
      ]

      let frase

      if (pct <= 30) {
        frase = frasesBaixas[
          Math.floor(Math.random() * frasesBaixas.length)
        ]
      } else if (pct <= 60) {
        frase = frasesMedias[
          Math.floor(Math.random() * frasesMedias.length)
        ]
      } else if (pct <= 90) {
        frase = frasesAltas[
          Math.floor(Math.random() * frasesAltas.length)
        ]
      } else {
        frase = frasesMaximas[
          Math.floor(Math.random() * frasesMaximas.length)
        ]
      }

      const imgBuffer =
        await imagemFixaDaBrincadeira('narcisista', LINK_FOTO)

      const texto = caixaArlequina(
        'narcisista',
        `☠️ *TESTE DE NARCISISMO* ☠️

👤 @${alvo.split('@')[0]}

📊 Resultado: *${pct}%*

${frase}`
      )

      if (imgBuffer) {
        await arlequina.sendMessage(
          from,
          {
            image: imgBuffer,
            caption: texto,
            mentions: [alvo]
          },
          { quoted: info }
        )
      } else {
        await arlequina.sendMessage(
          from,
          {
            text: texto,
            mentions: [alvo]
          },
          { quoted: info }
        )
      }

    } catch (e) {
      console.error('ERRO narcisista:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}