const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'tetris',
  description: 'Tetris interativo',
  category: 'jogos',
  aliases: [],
  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🧱')
      const html = `<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}body{margin:0;background:linear-gradient(145deg,#09000f,#22002d,#0b0012);color:#fff;font-family:Arial,sans-serif;text-align:center;padding:12px}h1{font-size:20px;margin:4px}.sub{font-size:12px;opacity:.8;margin:5px 0 10px}.game{margin:auto;max-width:340px}.board{background:#11051b;border:2px solid #a855f7;border-radius:14px;box-shadow:0 0 18px #7e22ce66}button{border:1px solid #a855f7;border-radius:10px;background:#260033;color:#fff;padding:11px 15px;font-weight:700;font-size:14px;margin:4px;touch-action:manipulation}button:active{transform:scale(.96)}#score{margin:8px;font-weight:700;color:#e9d5ff}.row{display:flex;justify-content:center;flex-wrap:wrap;gap:2px}
</style></head><body><h1>🧱 TETRIS</h1><div class="sub">Encaixe as peças e limpe linhas</div><div id="score">Linhas: 0</div><canvas id="c" class="board" width="240" height="360" style="width:240px"></canvas><div class="row"><button onclick="mv(-1)">⬅️</button><button onclick="rot()">🔄</button><button onclick="mv(1)">➡️</button><button onclick="drop()">⬇️</button><button onclick="reset()">▶️</button></div><script>
const c=document.getElementById('c'),x=c.getContext('2d'),W=10,H=15,S=24;let b,p,lines;
const shapes=[[[1,1,1,1]],[[1,1],[1,1]],[[0,1,0],[1,1,1]],[[1,0,0],[1,1,1]],[[0,0,1],[1,1,1]],[[1,1,0],[0,1,1]]];
function reset(){b=Array.from({length:H},()=>Array(W).fill(0));lines=0;spawn();draw()}
function spawn(){p={a:shapes[Math.random()*shapes.length|0].map(r=>r.slice()),x:3,y:0};if(hit())reset()}
function hit(){return p.a.some((r,dy)=>r.some((v,dx)=>v&&(p.x+dx<0||p.x+dx>=W||p.y+dy>=H||(p.y+dy>=0&&b[p.y+dy][p.x+dx]))))}
function merge(){p.a.forEach((r,dy)=>r.forEach((v,dx)=>{if(v&&p.y+dy>=0)b[p.y+dy][p.x+dx]=1}));b=b.filter(r=>r.some(v=>!v));while(b.length<H)b.unshift(Array(W).fill(0));lines++ ;document.getElementById('score').textContent='Linhas: '+(lines-1);spawn()}
function mv(d){p.x+=d;if(hit())p.x-=d;draw()}function rot(){let old=p.a;p.a=old[0].map((_,i)=>old.map(r=>r[i]).reverse());if(hit())p.a=old;draw()}
function drop(){p.y++;if(hit()){p.y--;merge()}draw()}function draw(){x.clearRect(0,0,240,360);x.fillStyle='#100016';x.fillRect(0,0,240,360);b.forEach((r,y)=>r.forEach((v,z)=>{if(v){x.fillStyle='#a855f7';x.fillRect(z*S,y*S,S-2,S-2)}}));p.a.forEach((r,y)=>r.forEach((v,z)=>{if(v){x.fillStyle='#f0abfc';x.fillRect((p.x+z)*S,(p.y+y)*S,S-2,S-2)}}))}
setInterval(drop,500);document.body.onkeydown=e=>{if(e.key==='ArrowLeft')mv(-1);if(e.key==='ArrowRight')mv(1);if(e.key==='ArrowDown')drop();if(e.key==='ArrowUp')rot()};reset()</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'tetris-interativo',
        titulo: 'Tetris',
        texto: '> Tetris interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro tetris:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
