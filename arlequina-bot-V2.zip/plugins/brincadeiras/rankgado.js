const { enviarRank } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Mesmo link do comando base (gado.js)
const LINK_FOTO = 'https://pin.it/2MYyiGR6I'

module.exports = {
  name: 'rankgado',
  description: 'RANK GADO DO GRUPO',
  category: 'brincadeiras',
  aliases: ['rankgados'],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankgado", `❌ Este comando só funciona em grupos.`))
    await reagir('🐄')
    try {
      await enviarRank(arlequina, from, info, 'RANK GADO DO GRUPO', '🐄', 'rankgado', 'Top 5 mais gado do grupo!', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankgado:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
