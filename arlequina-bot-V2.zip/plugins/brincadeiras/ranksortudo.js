const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/4L7QuwFqz'

module.exports = {
  name: 'ranksortudo',
  description: 'RANK SORTUDO DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("ranksortudo", `❌ Este comando só funciona em grupos.`))
    await reagir('🍀')
    try {
      await enviarRank(arlequina, from, info, 'RANK SORTUDO DO GRUPO', '🍀', 'ranksortudo', 'Esses 5 tão na maré boa hoje!', LINK_FOTO)
    } catch (e) {
      console.error('ERRO ranksortudo:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
