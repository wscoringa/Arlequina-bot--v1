const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'velha',
  description: 'Jogo da velha vs bot',
  category: 'jogos',
  aliases: ['jogodavelha2', 'tictactoe'],

  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('❌')
      const html = `<!DOCTYPE html>
<html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{background:linear-gradient(#141e30,#243b55);font-family:Arial,sans-serif;color:#fff;padding:12px}
h1{text-align:center;font-size:18px}
.sub{text-align:center;font-size:11px;opacity:.85;margin:4px 0 10px}
#board{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;max-width:260px;margin:0 auto}
.cell{aspect-ratio:1;background:#1c2b3a;border-radius:10px;border:0;font-size:36px;font-weight:bold;color:#fff}
button#novo{display:block;margin:12px auto;padding:10px 16px;border:0;border-radius:8px;background:#3498db;color:#fff;font-weight:bold}
#msg{text-align:center;margin-top:8px;font-size:14px}
</style></head><body>
<h1>❌⭕ JOGO DA VELHA</h1>
<div class="sub">Você é ❌ — bot é ⭕</div>
<div id="board"></div>
<div id="msg">Sua vez</div>
<button id="novo">🔄 Novo</button>
<script>
let b,turn,over;
function init(){b=Array(9).fill('');turn='X';over=false;document.getElementById('msg').textContent='Sua vez';draw()}
function draw(){
  const el=document.getElementById('board');el.innerHTML='';
  b.forEach((v,i)=>{
    const c=document.createElement('button');c.className='cell';c.textContent=v==='X'?'❌':v==='O'?'⭕':'';
    c.onclick=()=>play(i);el.appendChild(c);
  });
}
function win(p){
  const L=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  return L.some(([a,c,d])=>b[a]===p&&b[c]===p&&b[d]===p);
}
function play(i){
  if(over||b[i]||turn!=='X')return;b[i]='X';
  if(win('X')){over=true;document.getElementById('msg').textContent='🏆 Você ganhou!';draw();return}
  if(b.every(v=>v)){over=true;document.getElementById('msg').textContent='🤝 Empate';draw();return}
  turn='O';draw();document.getElementById('msg').textContent='Bot pensando...';
  setTimeout(()=>{
    const free=b.map((v,i)=>v?'':i).filter(v=>v!=='');
    // try win / block
    let move=null;
    for(const i of free){b[i]='O';if(win('O')){move=i}b[i]='';if(move!==null)break}
    if(move===null){for(const i of free){b[i]='X';if(win('X')){move=i}b[i]='';if(move!==null)break}}
    if(move===null)move=free[Math.floor(Math.random()*free.length)];
    b[move]='O';
    if(win('O')){over=true;document.getElementById('msg').textContent='💀 Bot ganhou';}
    else if(b.every(v=>v)){over=true;document.getElementById('msg').textContent='🤝 Empate'}
    else{turn='X';document.getElementById('msg').textContent='Sua vez'}
    draw();
  },350);
}
document.getElementById('novo').onclick=init;init();
</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'velha-interativo',
        titulo: 'VELHA',
        texto: '> VELHA interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro velha:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
