const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/37LtF9Npu'

module.exports = {
  name: 'viciado',
  description: 'TESTE DE VICIADO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('📱')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["📵 Desapegado total.", "🌿 Hora do detox digital.", "☀️ Ficou longe do celular.", "🏃 Viveu a vida de verdade.", "😎 Não checou nem uma vez.", "🌳 Vida real em primeiro lugar.", "📴 Celular ficou esquecido o dia todo.", "🧘 Equilíbrio digital total."]
      const frasesAltas = ["📱 Viciado raiz!", "💀 Dorme com celular na mão.", "😅 Bateria de 0% toda hora.", "📲 Acordou e já foi no zap.", "😂 Modo avião é heresia.", "🔌 Já dorme de carregador na mão.", "📵 1% de bateria é situação de emergência.", "🔄 Atualiza o feed compulsivamente."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('viciado', LINK_FOTO)
      const texto = caixaArlequina("viciado", `📱 *TESTE DE VICIADO* 📱\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO viciado:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
