const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/3OSDlnpwG'

module.exports = {
  name: 'ciumento',
  description: 'TESTE DE CIUMENTO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('😒')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["😌 Confiante hoje!", "🕊️ Zero ciúme.", "💪 Segurança total.", "😎 Tranquilo como nunca.", "🌸 Relacionamento saudável.", "🦋 Liberdade no relacionamento.", "🧘 Zen mesmo sem resposta na hora.", "🌊 Tranquilidade total."]
      const frasesAltas = ["😒 Ciúme extremo!", "🔍 Checou o celular 20 vezes.", "💀 Nível doentio!", "🚨 Alerta vermelho.", "😤 Fez cena no grupo.", "📍 Pediu localização em tempo real.", "🕵️ Investigou o story dos outros.", "📵 Já tentou ver o \"online\" 50 vezes."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('ciumento', LINK_FOTO)
      const texto = caixaArlequina("ciumento", `😒 *TESTE DE CIUMENTO* 😒\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO ciumento:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
