const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa (coloca uma bem safada aqui)
const LINK_FOTO = 'https://pin.it/6UKCcjxoz'

module.exports = {
  name: 'job',
  description: 'TESTE DE JOB +18',
  category: 'brincadeiras',
  aliases: ['trampo', 'trabalho', 'job18', 'boquete', 'chupada'],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    
    await reagir('🍆')

    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      // Lista de "empregos" +18 bem pesados
      const empregos = [
        "🍆 Chupador(a) Profissional de Pau",
        "💦 Engolidor(a) de Porra",
        "🕳️ Buraco Viciado em Sexo",
        "👅 Lambedor(a) de Buceta/Caralho",
        "🍑 Levador(a) de Rola no Cu",
        "🤤 Garganta Profunda Nível Hard",
        "🧎‍♀️ Putinha de Joelhos",
        "🐶 Cachorrinha no Dogstyle",
        "⛓️ Dominatrix Safada",
        "🍼 Mamadeira de Leite",
        "🍌 Cavalgadora de Pau",
        "🌮 Buceta Melada 24h",
        "💦 Squirt Queen",
        "😈 Demônio do Sexo Oral",
        "🛏️ Prostituta de Luxo",
        "📹 Atriz de Pornô Amador",
        "🔗 Escrava Sexual",
        "🍑 Twerking no Pau",
        "👄 Boca de Veludo",
        "🥵 Viciado(a) em Gangbang"
      ]

      const emprego = empregos[Math.floor(Math.random() * empregos.length)]

      const pct = Math.floor(Math.random() * 101)
      
      const frasesBaixas = [
        "🥱 Tá meio ruim hoje, precisa treinar mais...",
        "😪 Engasgou e desistiu no meio do caminho.",
        "🫠 Performance fraca, nem molhou direito.",
        "📉 Tá precisando de Viagra ou de mais prática.",
        "🙃 Quase dormiu chupando."
      ]
      
      const frasesAltas = [
        "🔥 QUE GARGANTA É ESSA PORRA?!",
        "💦 Engoliu tudo e ainda pediu mais!",
        "🏆 Melhor boquete do grupo!",
        "👑 Lenda do Sexo Oral!",
        "🚀 Tá destruindo as rolas do grupo!",
        "😈 Demônio chupador(a), ninguém aguenta!"
      ]

      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('job', LINK_FOTO)

      const texto = caixaArlequina("job", `🔥 *TESTE DE JOB +18* 🔥\n\n`) +
                    `👤 @${alvo.split('@')[0]}\n\n` +
                    `🧾 Cargo: *${emprego}*\n\n` +
                    `📊 Desempenho: *${pct}%*\n\n` +
                    `${frase}`

      if (imgBuffer) {
        await arlequina.sendMessage(from, { 
          image: imgBuffer, 
          caption: texto, 
          mentions: [alvo] 
        }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { 
          text: texto, 
          mentions: [alvo] 
        }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO job +18:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
