const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'nerd',
  emoji: '🤓',
  titulo: 'É nerd',
  frases: ["sabe a resposta antes de terminar a pergunta! 🤓", "tem plano de estudo até pra dormir! 📚", "citou Wikipédia numa conversa de bar! 🧠"]
})
