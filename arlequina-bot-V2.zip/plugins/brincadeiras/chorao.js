const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'chorao',
  emoji: '😭',
  titulo: 'É chorão(a)',
  frases: ["chora até vendo comercial de banco! 😭", "já chorou de rir e depois chorou de verdade! 🥲", "usa mais lenço que qualquer um do grupo! 🤧"]
})
