module.exports = {
  name: 'sinuca',
  description: 'Abre um jogo de sinuca interativo',
  category: 'jogos',
  aliases: ['pool', 'bilhar', 'jogosinuca'],

  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🎱')

      const html = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;margin:0;padding:0}
html,body{background:linear-gradient(#0b3d1e,#145a32);font-family:Arial,sans-serif;color:#fff;overflow:hidden;height:100%}
.wrap{padding:10px 8px 16px;max-width:480px;margin:0 auto}
h1{text-align:center;font-size:18px;margin:4px 0}
.sub{text-align:center;font-size:11px;opacity:.9;margin-bottom:8px}
#c{display:block;width:100%;background:#0a5c2e;border-radius:10px;border:6px solid #5d3a1a;box-shadow:inset 0 0 20px #063;touch-action:none}
.bar{display:flex;gap:8px;align-items:center;margin-top:10px}
label{font-size:12px;white-space:nowrap}
input[type=range]{flex:1}
.btns{display:flex;gap:8px;margin-top:10px}
button{flex:1;padding:10px;border:0;border-radius:8px;font-weight:bold;font-size:13px;background:#f1c40f;color:#222}
button.sec{background:#2ecc71;color:#fff}
#msg{text-align:center;font-size:12px;margin-top:8px;min-height:16px}
</style>
</head>
<body>
<div class="wrap">
  <h1>🎱 SINUCA</h1>
  <div class="sub">Arraste na bola branca pra mirar • solte pra tacada</div>
  <canvas id="c" width="360" height="200"></canvas>
  <div class="bar">
    <label>Força</label>
    <input id="pow" type="range" min="8" max="100" value="55">
  </div>
  <div class="btns">
    <button id="reset" class="sec">🔄 Nova mesa</button>
    <button id="hint">💡 Dica</button>
  </div>
  <div id="msg">Boa sorte!</div>
</div>
<script>
const cv=document.getElementById('c'),ctx=cv.getContext('2d');
const W=cv.width,H=cv.height,R=7,FR=0.988,MIN=0.04;
const pockets=[{x:8,y:8},{x:W/2,y:4},{x:W-8,y:8},{x:8,y:H-8},{x:W/2,y:H-4},{x:W-8,y:H-8}];
const colors=['#f1c40f','#2980b9','#e74c3c','#8e44ad','#e67e22','#27ae60','#c0392b','#1a1a1a','#f1c40f','#2980b9','#e74c3c','#8e44ad','#e67e22','#27ae60','#c0392b'];
let balls=[],aiming=false,ax=0,ay=0,moving=false,score=0,msg=document.getElementById('msg');

function ball(x,y,c,n){return{x,y,vx:0,vy:0,c,n,out:false}}
function setup(){
  balls=[];score=0;
  balls.push(ball(W*0.28,H/2,'#fff',0));
  const sx=W*0.68,sy=H/2,gap=R*2.15;let n=1;
  for(let row=0;row<5;row++){
    for(let i=0;i<=row;i++){
      if(n>15)break;
      const x=sx+row*gap*0.9;
      const y=sy+(i-row/2)*gap;
      balls.push(ball(x,y,colors[(n-1)%colors.length],n));
      n++;
    }
  }
  moving=false;msg.textContent='Mesa pronta — arraste a branca!';
}
function wall(b){
  if(b.x<R+6){b.x=R+6;b.vx*=-0.85}
  if(b.x>W-R-6){b.x=W-R-6;b.vx*=-0.85}
  if(b.y<R+6){b.y=R+6;b.vy*=-0.85}
  if(b.y>H-R-6){b.y=H-R-6;b.vy*=-0.85}
}
function collide(a,b){
  const dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1;
  if(d>=R*2)return;
  const nx=dx/d,ny=dy/d,p=((a.vx-b.vx)*nx+(a.vy-b.vy)*ny);
  if(p>0)return;
  a.vx-=p*nx;a.vy-=p*ny;b.vx+=p*nx;b.vy+=p*ny;
  const o=R*2-d;a.x-=nx*o/2;a.y-=ny*o/2;b.x+=nx*o/2;b.y+=ny*o/2;
}
function pocket(b){
  for(const p of pockets){
    if(Math.hypot(b.x-p.x,b.y-p.y)<14){
      b.out=true;b.vx=0;b.vy=0;
      if(b.n===0){
        msg.textContent='💥 Bola branca na caçapa! Reposicionada.';
        setTimeout(()=>{b.out=false;b.x=W*0.28;b.y=H/2;},400);
      } else {
        score++;msg.textContent='🎯 Bola '+b.n+' encaçapada! ('+score+'/15)';
        if(score>=15)msg.textContent='🏆 Mesa limpa! Você ganhou!';
      }
      return;
    }
  }
}
function step(){
  let any=false;
  for(const b of balls){
    if(b.out)continue;
    b.x+=b.vx;b.y+=b.vy;b.vx*=FR;b.vy*=FR;
    if(Math.hypot(b.vx,b.vy)<MIN){b.vx=0;b.vy=0}else any=true;
    wall(b);pocket(b);
  }
  for(let i=0;i<balls.length;i++){
    if(balls[i].out)continue;
    for(let j=i+1;j<balls.length;j++){
      if(balls[j].out)continue;
      collide(balls[i],balls[j]);
    }
  }
  moving=any;
}
function drawTable(){
  ctx.fillStyle='#0a5c2e';ctx.fillRect(0,0,W,H);
  // rail shade
  ctx.strokeStyle='#074a24';ctx.lineWidth=2;ctx.strokeRect(6,6,W-12,H-12);
  for(const p of pockets){
    ctx.beginPath();ctx.arc(p.x,p.y,11,0,Math.PI*2);ctx.fillStyle='#111';ctx.fill();
  }
}
function drawBalls(){
  for(const b of balls){
    if(b.out)continue;
    ctx.beginPath();ctx.arc(b.x,b.y,R,0,Math.PI*2);
    ctx.fillStyle=b.c;ctx.fill();
    ctx.strokeStyle='rgba(0,0,0,.35)';ctx.lineWidth=1;ctx.stroke();
    if(b.n>0){
      ctx.fillStyle=b.n===8?'#fff':'#111';
      ctx.font='bold 8px Arial';ctx.textAlign='center';ctx.textBaseline='middle';
      ctx.fillText(String(b.n),b.x,b.y+0.5);
    }
  }
}
function drawAim(){
  if(!aiming||moving)return;
  const cue=balls[0];if(cue.out)return;
  ctx.strokeStyle='rgba(255,255,255,.7)';ctx.lineWidth=1.5;ctx.setLineDash([4,4]);
  ctx.beginPath();ctx.moveTo(cue.x,cue.y);ctx.lineTo(ax,ay);ctx.stroke();ctx.setLineDash([]);
  const dx=cue.x-ax,dy=cue.y-ay,len=Math.hypot(dx,dy)||1;
  const px=cue.x+(dx/len)*30,py=cue.y+(dy/len)*30;
  ctx.strokeStyle='#f5d76e';ctx.lineWidth=3;
  ctx.beginPath();ctx.moveTo(cue.x,cue.y);ctx.lineTo(px,py);ctx.stroke();
}
function frame(){
  if(moving)step();
  drawTable();drawBalls();drawAim();
  requestAnimationFrame(frame);
}
function pos(e){
  const r=cv.getBoundingClientRect();
  const t=e.touches?e.touches[0]:e;
  return{x:(t.clientX-r.left)*(W/r.width),y:(t.clientY-r.top)*(H/r.height)};
}
function nearCue(p){const c=balls[0];return!c.out&&Math.hypot(p.x-c.x,p.y-c.y)<R*3}

cv.addEventListener('pointerdown',e=>{
  if(moving)return;
  const p=pos(e);
  if(nearCue(p)){aiming=true;ax=p.x;ay=p.y;cv.setPointerCapture(e.pointerId)}
});
cv.addEventListener('pointermove',e=>{
  if(!aiming)return;
  const p=pos(e);ax=p.x;ay=p.y;
});
cv.addEventListener('pointerup',e=>{
  if(!aiming)return;aiming=false;
  const cue=balls[0];if(cue.out||moving)return;
  const p=pos(e);
  const dx=cue.x-p.x,dy=cue.y-p.y,len=Math.hypot(dx,dy)||1;
  const force=Number(document.getElementById('pow').value)/12;
  cue.vx=(dx/len)*force;cue.vy=(dy/len)*force;
  moving=true;msg.textContent='Tacada!';
});
document.getElementById('reset').onclick=setup;
document.getElementById('hint').onclick=()=>{msg.textContent='Puxe para trás da branca e solte. Ajuste a força no slider.'};
setup();frame();
</script>
</body>
</html>`

      await columbina.relayMessage(
        from,
        {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          botForwardedMessage: {
            message: {
              richResponseMessage: {
                messageType: 1,
                submessages: [
                  {
                    messageType: 2,
                    messageText: 'SINUCA INTERATIVA'
                  }
                ],
                unifiedResponse: {
                  data: Buffer.from(JSON.stringify({
                    response_id: 'sinuca-interativa',
                    sections: [
                      {
                        view_model: {
                          primitive: {
                            text: '> Sinuca interativa</>',
                            __typename: 'GenAIMarkdownTextUXPrimitive'
                          },
                          __typename: 'GenAISingleLayoutViewModel'
                        }
                      }
                    ],
                    embedded_screens: [
                      {
                        title: 'SINUCA',
                        content: [
                          {
                            __typename: 'FOAIDNixelButtonSheets',
                            tabs: [
                              {
                                id: 'tab_0',
                                tab_header: 'Sinuca',
                                sections: [
                                  {
                                    __typename: 'GenAIUnifiedResponseSection',
                                    view_model: {
                                      __typename: 'GenAISingleLayoutViewModel',
                                      primitive: {
                                        __typename: 'GenAIaeacdsnwHtmlPrimitive',
                                        payload: html,
                                        trusted_sources: ['columbina-apis.onrender.com']
                                      }
                                    }
                                  }
                                ]
                              }
                            ]
                          }
                        ]
                      }
                    ]
                  })).toString('base64')
                },
                contextInfo: {
                  forwardingScore: 1,
                  isForwarded: true,
                  forwardedAiBotMessageInfo: {
                    botJid: '867051314767696@bot'
                  },
                  forwardOrigin: 4
                }
              }
            }
          }
        },
        {}
      )
    } catch (error) {
      console.error('Erro ao abrir a sinuca:', error)
      await reply('Não foi possível abrir a sinuca agora.')
    }
  }
}
