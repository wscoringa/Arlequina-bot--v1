const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/a2Th4K39b'

module.exports = {
  name: 'rankmentiroso',
  description: 'RANK MENTIROSO DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankmentiroso", `❌ Este comando só funciona em grupos.`))
    await reagir('🤥')
    try {
      await enviarRank(arlequina, from, info, 'RANK MENTIROSO DO GRUPO', '🤥', 'rankmentiroso', 'Esses 5 merecem um Pinóquio.', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankmentiroso:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
