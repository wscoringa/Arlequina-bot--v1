const { enviarRankCasal, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/5xXcMU0wu'

module.exports = {
  name: 'rankcasal',
  description: 'Rank de casais do grupo (10 casais com @)',
  category: 'brincadeiras',
  aliases: ['ranknamoro', 'casais'],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankcasal", `❌ Este comando só funciona em grupos.`))
    await reagir('💜')
    try {
      await enviarRankCasal(arlequina, from, info, LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankcasal:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
