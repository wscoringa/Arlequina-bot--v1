const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/6VMcPXtGl'

module.exports = {
  name: 'rankfeio',
  description: 'RANK FEIO DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankfeio", `❌ Este comando só funciona em grupos.`))
    await reagir('💅')
    try {
      await enviarRank(arlequina, from, info, 'RANK FEIO DO GRUPO', '💅', 'rankfeio', 'Top 5 rei da beleza polêmica.', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankfeio:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
