const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'reacao',
  description: 'Teste de reação interativo',
  category: 'jogos',
  aliases: ['reflexo', 'reaction'],

  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('⚡')
      const html = `<!DOCTYPE html>
<html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{background:linear-gradient(#141e30,#243b55);font-family:Arial,sans-serif;color:#fff;padding:16px;text-align:center}
h1{font-size:18px}
.sub{font-size:12px;opacity:.85;margin:6px 0 14px}
#box{width:100%;max-width:300px;height:180px;margin:0 auto;border-radius:16px;background:#333;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:bold;user-select:none}
#box.wait{background:#c0392b}
#box.go{background:#27ae60}
#box.early{background:#f39c12}
#res{margin-top:12px;font-size:14px;min-height:40px}
button{margin-top:12px;padding:12px 20px;border:0;border-radius:10px;background:#3498db;color:#fff;font-weight:bold;font-size:14px}
</style></head><body>
<h1>⚡ REAÇÃO</h1>
<div class="sub">Espere ficar VERDE e toque o mais rápido possível</div>
<div id="box">Toque em Começar</div>
<div id="res"></div>
<button id="go">Começar</button>
<script>
const box=document.getElementById('box'),res=document.getElementById('res');
let state='idle',t0,timer,best=null;
function start(){
  clearTimeout(timer);state='wait';box.className='wait';box.textContent='Espere...';res.textContent='';
  const delay=1200+Math.random()*2500;
  timer=setTimeout(()=>{state='go';box.className='go';box.textContent='AGORA!';t0=performance.now()},delay);
}
box.onclick=()=>{
  if(state==='wait'){clearTimeout(timer);state='early';box.className='early';box.textContent='Cedo demais!';res.textContent='Tente de novo';return}
  if(state==='go'){
    const ms=Math.round(performance.now()-t0);state='idle';box.className='';box.textContent=ms+' ms';
    if(best===null||ms<best)best=ms;
    res.textContent='Melhor: '+best+' ms'+(ms<200?' 🔥':ms<350?' 👍':'');
  }
};
document.getElementById('go').onclick=start;
</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'reacao-interativo',
        titulo: 'Reação',
        texto: '> Reação interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro reacao:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
