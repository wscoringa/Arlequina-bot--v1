const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'arena',
  description: 'Mini Arena interativo',
  category: 'jogos',
  aliases: [],
  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('⚔️')
      const html = `<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}body{margin:0;background:linear-gradient(145deg,#09000f,#22002d,#0b0012);color:#fff;font-family:Arial,sans-serif;text-align:center;padding:12px}h1{font-size:20px;margin:4px}.sub{font-size:12px;opacity:.8;margin:5px 0 10px}.game{margin:auto;max-width:340px}.board{background:#11051b;border:2px solid #a855f7;border-radius:14px;box-shadow:0 0 18px #7e22ce66}button{border:1px solid #a855f7;border-radius:10px;background:#260033;color:#fff;padding:11px 15px;font-weight:700;font-size:14px;margin:4px;touch-action:manipulation}button:active{transform:scale(.96)}#score{margin:8px;font-weight:700;color:#e9d5ff}.row{display:flex;justify-content:center;flex-wrap:wrap;gap:2px}
</style></head><body><h1>⚔️ MINI ARENA</h1><div class="sub">Ataque os inimigos e sobreviva</div><div id="score">HP: 100 | Inimigos: 0</div><canvas id="c" class="board" width="300" height="250" style="width:300px;max-width:100%"></canvas><div class="row"><button onclick="move(-1)">⬅️</button><button onclick="attack()">⚔️ ATACAR</button><button onclick="move(1)">➡️</button></div><button onclick="start()">▶️ Reiniciar</button><script>
const c=document.getElementById('c'),x=c.getContext('2d');let hp,en,sc,px,run;
function start(){hp=100;en=[];sc=0;px=150;run=1;spawn();draw()}function spawn(){en.push({x:Math.random()*280+10,hp:2})}function move(d){if(run)px=Math.max(15,Math.min(285,px+d*25));draw()}function attack(){if(!run)return;let e=en[0];if(e&&Math.abs(e.x-px)<65){e.hp--;if(e.hp<=0){en.shift();sc++;spawn()}}else hp-=5;if(hp<=0){run=0;alert('💀 Derrotado! Pontos: '+sc)}draw()}function draw(){x.fillStyle='#100016';x.fillRect(0,0,300,250);x.fillStyle='#6b21a8';x.fillRect(0,215,300,35);x.fillStyle='#f0abfc';x.fillRect(px-12,190,24,25);en.forEach(e=>{x.fillStyle='#86efac';x.fillRect(e.x-10,185,20,30)});document.getElementById('score').textContent='HP: '+hp+' | Inimigos: '+sc}start()</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'arena-interativo',
        titulo: 'Mini Arena',
        texto: '> Mini Arena interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro arena:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
