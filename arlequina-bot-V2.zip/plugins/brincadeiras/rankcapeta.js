const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/2Uo8VShKm'

module.exports = {
  name: 'rankcapeta',
  description: 'RANK CAPETA DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankcapeta", `❌ Este comando só funciona em grupos.`))
    await reagir('😈')
    try {
      await enviarRank(arlequina, from, info, 'RANK CAPETA DO GRUPO', '😈', 'rankcapeta', 'Esses 5 tão cheios de maldade hoje!', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankcapeta:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
