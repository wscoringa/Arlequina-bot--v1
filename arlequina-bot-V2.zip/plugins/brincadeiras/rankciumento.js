const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/5evPj4MZu'

module.exports = {
  name: 'rankciumento',
  description: 'RANK CIUMENTO DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankciumento", `❌ Este comando só funciona em grupos.`))
    await reagir('😒')
    try {
      await enviarRank(arlequina, from, info, 'RANK CIUMENTO DO GRUPO', '😒', 'rankciumento', 'Esses 5 são os mais ciumenticoss.', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankciumento:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
