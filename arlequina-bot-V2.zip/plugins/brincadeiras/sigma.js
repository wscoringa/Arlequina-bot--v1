const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/1MWQxGh63'

module.exports = {
  name: 'sigma',
  description: 'TESTE DE SIGMA',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🗿')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["😅 Sigma em treinamento.", "🤔 Ainda depende dos outros.", "📉 Mentalidade sigma não encontrada.", "🙈 Hoje não foi diferente.", "😴 Tá muito comum.", "🤏 Falta atitude.", "🐑 Seguindo a manada hoje.", "📲 Pede aprovação pra tudo.", "🌫️ Presença esquecível."]
      const frasesAltas = ["🗿 Sigma detectado!", "🚬 Frio e calculista!", "🔥 Mentalidade acima da média!", "⚡ Não segue a multidão!", "💀 Presença lendária!", "👑 Sigma supremo!", "🌑 Trabalha em silêncio, entrega em dobro.", "🚶 Anda sozinho e não se importa.", "🧊 Frio até em situação de caos."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('sigma', LINK_FOTO)
      const texto = caixaArlequina("sigma", `🗿 *TESTE DE SIGMA* 🗿\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO sigma:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
