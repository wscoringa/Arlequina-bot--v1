const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/55XIzMuub'

module.exports = {
  name: 'rankinfiel',
  description: 'RANK INFIEL DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankinfiel", `❌ Este comando só funciona em grupos.`))
    await reagir('💔')
    try {
      await enviarRank(arlequina, from, info, 'RANK INFIEL DO GRUPO', '💔', 'rankinfiel', 'Esses 5 não resistem à tentação.', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankinfiel:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
