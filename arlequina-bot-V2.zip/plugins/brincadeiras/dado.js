const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'dado',
  description: 'Rola um dado de 6 faces',
  category: 'brincadeiras',
  aliases: ['dice', 'rolar'],
  async execute({ reply, reagir }) {
    await reagir('🎲')
    const faces = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅']
    const n = Math.floor(Math.random() * 6)
    return reply(caixaArlequina('DADO', `🎲 Você tirou: *${n + 1}*\n\n${faces[n]}`))
  }
}
