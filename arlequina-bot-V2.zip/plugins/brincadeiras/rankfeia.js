const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/4JB5Kcx60'

module.exports = {
  name: 'rankfeia',
  description: 'RANK FEIA DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankfeia", `❌ Este comando só funciona em grupos.`))
    await reagir('💅')
    try {
      await enviarRank(arlequina, from, info, 'RANK FEIA DO GRUPO', '💅', 'rankfeia', 'Top 5 rainha da beleza polêmica.', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankfeia:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
