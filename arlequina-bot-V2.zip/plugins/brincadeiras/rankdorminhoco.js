const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/qDlZeJ0O2'

module.exports = {
  name: 'rankdorminhoco',
  description: 'RANK DORMINHOCO DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankdorminhoco", `❌ Este comando só funciona em grupos.`))
    await reagir('😴')
    try {
      await enviarRank(arlequina, from, info, 'RANK DORMINHOCO DO GRUPO', '😴', 'rankdorminhoco', 'Esses 5 passam o dia dormindo.', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankdorminhoco:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
