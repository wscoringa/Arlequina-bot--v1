const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'luzes',
  description: 'Apague as luzes interativo',
  category: 'jogos',
  aliases: ['apagarluzes', 'lightsout'],

  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('💡')
      const html = `<!DOCTYPE html>
<html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{background:linear-gradient(#0f0c29,#302b63);font-family:Arial,sans-serif;color:#fff;padding:12px}
h1{text-align:center;font-size:18px}
.sub{text-align:center;font-size:11px;opacity:.85;margin:4px 0 10px}
#grid{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;max-width:280px;margin:0 auto}
.cell{aspect-ratio:1;border-radius:10px;border:0;background:#222;box-shadow:inset 0 0 8px #000}
.cell.on{background:#f1c40f;box-shadow:0 0 12px #f1c40f}
button{display:block;margin:12px auto;padding:10px 16px;border:0;border-radius:8px;background:#9b59b6;color:#fff;font-weight:bold}
#msg{text-align:center;font-size:13px;margin-top:8px}
</style></head><body>
<h1>💡 APAGUE AS LUZES</h1>
<div class="sub">Toque pra alternar a luz e as vizinhas</div>
<div id="grid"></div>
<div id="msg"></div>
<button id="novo">🔄 Embaralhar</button>
<script>
const N=5;let g;
function draw(){
  const el=document.getElementById('grid');el.innerHTML='';
  for(let r=0;r<N;r++)for(let c=0;c<N;c++){
    const b=document.createElement('button');b.className='cell'+(g[r][c]?' on':'');
    b.onclick=()=>toggle(r,c);el.appendChild(b);
  }
  if(g.every(row=>row.every(v=>!v)))document.getElementById('msg').textContent='🏆 Todas apagadas!';
  else document.getElementById('msg').textContent='';
}
function flip(r,c){if(r>=0&&r<N&&c>=0&&c<N)g[r][c]=!g[r][c]}
function toggle(r,c){flip(r,c);flip(r-1,c);flip(r+1,c);flip(r,c-1);flip(r,c+1);draw()}
function shuffle(){
  g=Array.from({length:N},()=>Array(N).fill(false));
  for(let i=0;i<12;i++)toggle(Math.floor(Math.random()*N),Math.floor(Math.random()*N));
  document.getElementById('msg').textContent='';
  // toggle already draws; ensure
  draw();
}
document.getElementById('novo').onclick=shuffle;shuffle();
</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'luzes-interativo',
        titulo: 'LUZES',
        texto: '> LUZES interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro luzes:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
