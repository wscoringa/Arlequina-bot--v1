const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'charmoso',
  emoji: '✨',
  titulo: 'É charmoso(a)',
  frases: ["entra na sala e todo mundo repara! ✨", "tem aquele sorriso que desarma qualquer briga! 😏", "é do tipo que nem precisa tentar! 💫"]
})
