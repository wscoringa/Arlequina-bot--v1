const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/7i8Ni9A1U'

module.exports = {
  name: 'rankrico',
  description: 'RANK RICO DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankrico", `❌ Este comando só funciona em grupos.`))
    await reagir('💰')
    try {
      await enviarRank(arlequina, from, info, 'RANK RICO DO GRUPO', '💰', 'rankrico', 'Os 5 mais ricos do grupo!', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankrico:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
