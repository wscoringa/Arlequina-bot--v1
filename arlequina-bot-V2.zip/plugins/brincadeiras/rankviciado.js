const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/3FGTQWWJ4'

module.exports = {
  name: 'rankviciado',
  description: 'RANK VICIADO DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankviciado", `❌ Este comando só funciona em grupos.`))
    await reagir('📱')
    try {
      await enviarRank(arlequina, from, info, 'RANK VICIADO DO GRUPO', '📱', 'rankviciado', 'Esses 5 não conseguem largar o celular.', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankviciado:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
