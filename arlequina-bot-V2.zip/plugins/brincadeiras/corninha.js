const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/2aIvOTP0S'

module.exports = {
  name: 'corninha',
  description: 'TESTE DE CORNINHA',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🐄')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["💪 Fiel como nunca!", "❤️ Relacionamento sagrado.", "🕊️ Zero traição por aqui.", "✨ Parceiro(a) sortudo(a).", "🔒 Fidelidade máxima.", "🛡️ Blindado(a) contra traição.", "💍 Relação a prova de dúvidas.", "🌹 Parceiro(a) de confiança plena."]
      const frasesAltas = ["🐄 Corninha confirmada.", "💀 Tá sabendo de nada.", "😬 O grupo sabe mais que você.", "😭 Dói só de ver.", "⚠️ Sinal de fumaça no relacionamento.", "📸 Print já tá circulando.", "🙈 O grupo inteiro sabia antes.", "🎭 Última a saber, como sempre."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('corninha', LINK_FOTO)
      const texto = caixaArlequina("corninha", `🐄 *TESTE DE CORNINHA* 🐄\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO corninha:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
