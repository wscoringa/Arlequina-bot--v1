const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/1LpLfXfoQ'

module.exports = {
  name: 'lindo',
  description: 'TESTE DE LINDO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🤴')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["😅 Hoje não é o dia.", "😬 Perdeu o pique.", "🥴 O charme sumiu.", "💤 Beleza de folga.", "🫤 Nem o espelho aprovou.", "😶 Charme tirou folga hoje.", "🫥 Brilho em baixa.", "📉 Beleza discreta demais."]
      const frasesAltas = ["🤴 Lindo demais!", "✨ Deslumbrante!", "💜 Beleza rara!", "🦁 Rei confirmado!", "😍 Perfeito hoje!", "💫 Impossível não notar!", "📸 Quebra a internet com uma foto!", "🥇 Disparado o mais elegante!"]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      // Antes tentava a pasta midias/brincadeiras/lindo.jpg primeiro, e só
      // usava o LINK_FOTO se não achasse nada lá — por isso sempre saía a
      // imagem local mesmo com o link configurado. Agora prioriza o link.
      const imgBuffer = await imagemFixaDaBrincadeira('lindo', LINK_FOTO)
      const texto = caixaArlequina("lindo", `🤴 *TESTE DE LINDO* 🤴\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO lindo:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
