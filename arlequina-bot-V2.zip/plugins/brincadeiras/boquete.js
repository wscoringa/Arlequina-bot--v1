const { imagemDaBrincadeira, imagemDeLink, baixarBufferUrl, converterGifParaMp4 } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Links NSFW 
const LINK_GIF = 'https://media1.tenor.com/m/8jKX3ekPjJoAAAAC/drinking-water.gif' // Substitua por um GIF de boquete

const LINK_FOTO = 'https://i.ibb.co/Z6YFS8ph/026e1d191e77c38a.jpg' // ← Coloque uma foto explícita aqui

module.exports = {
  name: 'boquete',
  description: 'TESTE DE BOQUETE 🔥 (versão +18)',
  category: 'brincadeiras',
  aliases: ['sede', 'goles', 'chupada', 'bj'],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')

    await reagir('💦')

    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const porcentagem = Math.floor(Math.random() * 201) // 0 a 200%

      const frasesFracas = [
        "😌 Foi só uma lambidinha tímida...",
        "🥤 Molhou só a cabecinha kkk",
        "💧 Tá com vergonha hoje hein?",
        "🙂 Quase nem chupou direito.",
        "😴 Boquete de sono."
      ]

      const frasesIntensas = [
        "🥵 QUE BOQUETE DO CARALHO!!",
        "💦 Engoliu até o talo, sem piedade!",
        "😮 Chupou como uma vadia profissional!",
        "🏆 Garganta profunda nível expert!",
        "🚰 Secou ele todinho!",
        "💪 Boquete lendário, porra!",
        "🔥 Cuspiu nada, engoliu tudo!"
      ]

      const frase = porcentagem <= 60
        ? frasesFracas[Math.floor(Math.random() * frasesFracas.length)]
        : frasesIntensas[Math.floor(Math.random() * frasesIntensas.length)]

      const texto = caixaArlequina(
  "boquete",
  `🔞 *TESTE DE BOQUETE* 🔥

👤 @${alvo.split('@')[0]}

🍆 Intensidade: *${porcentagem}%*

${frase}`
)
      // Tenta GIF em MP4
      let videoBuffer = null
      try {
        const gifBuffer = await baixarBufferUrl(LINK_GIF)
        videoBuffer = await converterGifParaMp4(gifBuffer)
      } catch (e) {
        console.error('ERRO boquete GIF:', e?.message)
      }

      if (videoBuffer) {
        await arlequina.sendMessage(from, { 
          video: videoBuffer, 
          gifPlayback: true, 
          caption: texto, 
          mentions: [alvo] 
        }, { quoted: info })
        return
      }

      // Tenta foto NSFW
      const imgBuffer = await imagemFixaDaBrincadeira('boquete', LINK_FOTO)
      if (imgBuffer) {
        await arlequina.sendMessage(from, { 
          image: imgBuffer, 
          caption: texto, 
          mentions: [alvo] 
        }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { 
          text: texto, 
          mentions: [alvo] 
        }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO boquete:', e?.message)
      await reply('❌ Deu erro no boquete, tenta de novo 😏')
    }
  }
}
