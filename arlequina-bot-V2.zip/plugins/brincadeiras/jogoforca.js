const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'jogoforca',
  description: 'Jogo da forca interativo',
  category: 'jogos',
  aliases: ['hangman', 'forcajogo'],

  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🪢')
      const html = `<!DOCTYPE html>
<html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{background:linear-gradient(#1a1a2e,#16213e);font-family:Arial,sans-serif;color:#fff;padding:12px}
h1{text-align:center;font-size:18px}
.sub{text-align:center;font-size:11px;opacity:.85;margin:4px 0 10px}
#word{text-align:center;font-size:22px;letter-spacing:6px;margin:12px 0;font-weight:bold}
#hang{text-align:center;font-family:monospace;font-size:13px;line-height:1.25;white-space:pre;color:#f1c40f;min-height:110px}
.keys{display:flex;flex-wrap:wrap;gap:5px;justify-content:center;max-width:340px;margin:10px auto}
.keys button{width:30px;height:34px;border:0;border-radius:6px;background:#0f3460;color:#fff;font-weight:bold;font-size:13px}
.keys button:disabled{opacity:.35}
#msg{text-align:center;margin-top:8px;font-size:13px}
button#novo{display:block;margin:10px auto;padding:10px 18px;border:0;border-radius:8px;background:#e94560;color:#fff;font-weight:bold}
</style></head><body>
<h1>FORCA</h1>
<div class="sub">Adivinhe a palavra — 6 erros e perdeu</div>
<pre id="hang"></pre>
<div id="word"></div>
<div class="keys" id="keys"></div>
<div id="msg"></div>
<button id="novo">Nova palavra</button>
<script>
const WORDS=["ARLEQUINA","CORINGA","WHATSAPP","FIGURINHA","BRASIL","SINUCA","PIANO","PURPLE","JOGADOR","CARTOLA","BANANA","FOGUETE","GUITARRA","DINHEIRO","AMIZADE","VENCEDOR","MISTERIO","AVENTURA","FANTASMA","TESOURO"];
const H=[
"  +---+\\n  |   |\\n      |\\n      |\\n      |\\n======",
"  +---+\\n  |   |\\n  O   |\\n      |\\n      |\\n======",
"  +---+\\n  |   |\\n  O   |\\n  |   |\\n      |\\n======",
"  +---+\\n  |   |\\n  O   |\\n /|   |\\n      |\\n======",
"  +---+\\n  |   |\\n  O   |\\n /|\\\\  |\\n      |\\n======",
"  +---+\\n  |   |\\n  O   |\\n /|\\\\  |\\n /    |\\n======",
"  +---+\\n  |   |\\n  O   |\\n /|\\\\  |\\n / \\\\  |\\n======"
].map(s=>s.replace(/\\\\n/g,"\\n"));
let secret="",shown=[],errs=0,done=false;
function start(){
  secret=WORDS[Math.floor(Math.random()*WORDS.length)];
  shown=secret.split("").map(function(){return "_"});errs=0;done=false;
  document.getElementById("hang").textContent=H[0];
  document.getElementById("word").textContent=shown.join(" ");
  document.getElementById("msg").textContent="Boa sorte!";
  var k=document.getElementById("keys");k.innerHTML="";
  "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("").forEach(function(L){
    var b=document.createElement("button");b.textContent=L;
    b.onclick=function(){
      if(done||b.disabled)return;b.disabled=true;
      if(secret.indexOf(L)>=0){
        secret.split("").forEach(function(c,i){if(c===L)shown[i]=L});
        document.getElementById("word").textContent=shown.join(" ");
        if(shown.indexOf("_")<0){done=true;document.getElementById("msg").textContent="Acertou: "+secret}
      } else {
        errs++;document.getElementById("hang").textContent=H[Math.min(errs,6)];
        if(errs>=6){done=true;document.getElementById("msg").textContent="Perdeu! Era: "+secret;document.getElementById("word").textContent=secret.split("").join(" ")}
      }
    };
    k.appendChild(b);
  });
}
document.getElementById("novo").onclick=start;start();
</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'jogoforca-interativo',
        titulo: 'FORCA',
        texto: '> Forca interativa</>',
        html
      })
    } catch (e) {
      console.error('Erro forca:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
