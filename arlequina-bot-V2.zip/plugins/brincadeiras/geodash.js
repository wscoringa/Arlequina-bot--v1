const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'geodash',
  description: 'Geometry Dash interativo',
  category: 'jogos',
  aliases: [],
  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🟪')
      const html = `<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}body{margin:0;background:linear-gradient(145deg,#09000f,#22002d,#0b0012);color:#fff;font-family:Arial,sans-serif;text-align:center;padding:12px}h1{font-size:20px;margin:4px}.sub{font-size:12px;opacity:.8;margin:5px 0 10px}.game{margin:auto;max-width:340px}.board{background:#11051b;border:2px solid #a855f7;border-radius:14px;box-shadow:0 0 18px #7e22ce66}button{border:1px solid #a855f7;border-radius:10px;background:#260033;color:#fff;padding:11px 15px;font-weight:700;font-size:14px;margin:4px;touch-action:manipulation}button:active{transform:scale(.96)}#score{margin:8px;font-weight:700;color:#e9d5ff}.row{display:flex;justify-content:center;flex-wrap:wrap;gap:2px}
</style></head><body><h1>🟪 GEOMETRY DASH</h1><div class="sub">Toque para pular os obstáculos</div><div id="score">Pontos: 0</div><canvas id="c" class="board" width="320" height="180" style="width:100%;max-width:320px"></canvas><div><button onclick="jump()">⬆️ PULAR</button><button onclick="start()">▶️ REINICIAR</button></div><script>
const c=document.getElementById('c'),x=c.getContext('2d');let p,o,s=0,v=0,run=0,raf;
function start(){p={x:45,y:135,w:22,h:22,vy:0,on:1};o=[];s=0;run=1;loop()}
function jump(){if(!run)return start();if(p.on){p.vy=-9;p.on=0}}
function loop(){if(!run)return;x.clearRect(0,0,320,180);x.fillStyle='#16001f';x.fillRect(0,0,320,180);x.fillStyle='#7e22ce';x.fillRect(0,158,320,22);
if(Math.random()<.025)o.push({x:320,h:18+Math.random()*28});o.forEach(a=>a.x-=5);o=o.filter(a=>a.x>-30);p.vy+=.55;p.y+=p.vy;if(p.y>=136){p.y=136;p.vy=0;p.on=1}
x.fillStyle='#e879f9';x.fillRect(p.x,p.y,p.w,p.h);x.fillStyle='#c084fc';o.forEach(a=>x.fillRect(a.x,158-a.h,18,a.h));
for(const a of o)if(p.x<a.x+18&&p.x+p.w>a.x&&p.y+p.h>158-a.h){run=0;alert('💀 Game Over! Pontos: '+s);return} s++;document.getElementById('score').textContent='Pontos: '+Math.floor(s/10);raf=requestAnimationFrame(loop)}
c.onclick=jump;document.body.onkeydown=e=>{if(e.code==='Space')jump()};start()</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'geodash-interativo',
        titulo: 'Geometry Dash',
        texto: '> Geometry Dash interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro geodash:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
