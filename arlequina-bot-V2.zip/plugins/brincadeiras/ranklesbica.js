const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/c7HChlLLt'

module.exports = {
  name: 'ranklesbica',
  description: 'RANK LÉSBICA DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("ranklesbica", `❌ Este comando só funciona em grupos.`))
    await reagir('🌈')
    try {
      await enviarRank(arlequina, from, info, 'RANK LÉSBICA DO GRUPO', '🌈', 'ranklesbica', 'Top 5 lindas e orgulhosas! 🏳️‍🌈', LINK_FOTO)
    } catch (e) {
      console.error('ERRO ranklesbica:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
