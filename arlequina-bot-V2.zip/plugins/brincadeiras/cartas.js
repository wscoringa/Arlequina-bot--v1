const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'cartas',
  description: 'Arlequina Cards interativo',
  category: 'jogos',
  aliases: [],
  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🃏')
      const html = `<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}body{margin:0;background:linear-gradient(145deg,#09000f,#22002d,#0b0012);color:#fff;font-family:Arial,sans-serif;text-align:center;padding:12px}h1{font-size:20px;margin:4px}.sub{font-size:12px;opacity:.8;margin:5px 0 10px}.game{margin:auto;max-width:340px}.board{background:#11051b;border:2px solid #a855f7;border-radius:14px;box-shadow:0 0 18px #7e22ce66}button{border:1px solid #a855f7;border-radius:10px;background:#260033;color:#fff;padding:11px 15px;font-weight:700;font-size:14px;margin:4px;touch-action:manipulation}button:active{transform:scale(.96)}#score{margin:8px;font-weight:700;color:#e9d5ff}.row{display:flex;justify-content:center;flex-wrap:wrap;gap:2px}
</style></head><body><h1>🃏 ARLEQUINA CARDS</h1><div class="sub">Escolha uma carta e enfrente o adversário</div><div id="score">Sua força: 0 | Inimigo: 0</div><div id="cards" class="row"></div><div id="msg" style="margin:12px;min-height:36px"></div><button onclick="start()">🔄 Nova batalha</button><script>
const area=document.getElementById('cards'),sc=document.getElementById('score'),msg=document.getElementById('msg');let you=0,enemy=0;
function start(){you=0;enemy=0;msg.textContent='Escolha uma carta';area.innerHTML='';['⚔️ Ataque','🛡️ Defesa','✨ Poder'].forEach((t,i)=>{let b=document.createElement('button');b.textContent=t;b.onclick=()=>play(i);area.appendChild(b)});score()}
function play(i){let vals=[8,5,12],v=vals[i],e=3+Math.floor(Math.random()*11);you+=v;enemy+=e;msg.textContent=v>=e?'💜 Você ganhou a rodada!':'🖤 O rival levou a melhor!';score();if(you>=30||enemy>=30){msg.textContent=you>enemy?'🏆 VITÓRIA!':'💀 DERROTA!';area.innerHTML=''}}
function score(){sc.textContent='Sua força: '+you+' | Inimigo: '+enemy}start()</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'cartas-interativo',
        titulo: 'Arlequina Cards',
        texto: '> Arlequina Cards interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro cartas:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
