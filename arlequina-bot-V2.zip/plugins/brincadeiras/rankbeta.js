const { enviarRank } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Mesmo link do comando base (beta.js)
const LINK_FOTO = 'https://pin.it/5jp2yfCqN'

module.exports = {
  name: 'rankbeta',
  description: 'RANK BETA DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankbeta", `❌ Este comando só funciona em grupos.`))
    await reagir('🐑')
    try {
      await enviarRank(arlequina, from, info, 'RANK BETA DO GRUPO', '🐑', 'rankbeta', 'Top 5 mais beta do grupo!', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankbeta:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
