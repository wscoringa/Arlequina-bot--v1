const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'asteroides',
  description: 'Asteroid Dodge interativo',
  category: 'jogos',
  aliases: [],
  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🪐')
      const html = `<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}body{margin:0;background:linear-gradient(145deg,#09000f,#22002d,#0b0012);color:#fff;font-family:Arial,sans-serif;text-align:center;padding:12px}h1{font-size:20px;margin:4px}.sub{font-size:12px;opacity:.8;margin:5px 0 10px}.game{margin:auto;max-width:340px}.board{background:#11051b;border:2px solid #a855f7;border-radius:14px;box-shadow:0 0 18px #7e22ce66}button{border:1px solid #a855f7;border-radius:10px;background:#260033;color:#fff;padding:11px 15px;font-weight:700;font-size:14px;margin:4px;touch-action:manipulation}button:active{transform:scale(.96)}#score{margin:8px;font-weight:700;color:#e9d5ff}.row{display:flex;justify-content:center;flex-wrap:wrap;gap:2px}
</style></head><body><h1>🪐 ASTEROID DODGE</h1><div class="sub">Mova a nave e sobreviva o máximo</div><div id="score">Tempo: 0</div><canvas id="c" class="board" width="300" height="300" style="width:300px;max-width:100%"></canvas><div class="row"><button onclick="mv(-1)">⬅️</button><button onclick="mv(1)">➡️</button><button onclick="start()">▶️</button></div><script>
const c=document.getElementById('c'),x=c.getContext('2d');let ship,rocks,t,run;
function start(){ship=150;rocks=[];t=0;run=1;loop()}function mv(d){ship=Math.max(12,Math.min(288,ship+d*25))}function loop(){if(!run)return;x.fillStyle='#08000d';x.fillRect(0,0,300,300);if(Math.random()<.06)rocks.push({x:Math.random()*300,y:-15,r:8+Math.random()*10});rocks.forEach(r=>r.y+=3.5);rocks=rocks.filter(r=>r.y<315);x.fillStyle='#e879f9';x.beginPath();x.moveTo(ship,265);x.lineTo(ship-12,285);x.lineTo(ship+12,285);x.fill();x.fillStyle='#c084fc';rocks.forEach(r=>{x.beginPath();x.arc(r.x,r.y,r.r,0,7);x.fill()});for(let r of rocks)if(Math.hypot(r.x-ship,r.y-278)<r.r+12){run=0;alert('💥 Nave atingida! Tempo: '+Math.floor(t/10));return}t++;document.getElementById('score').textContent='Tempo: '+Math.floor(t/10);requestAnimationFrame(loop)}document.body.onkeydown=e=>{if(e.key==='ArrowLeft')mv(-1);if(e.key==='ArrowRight')mv(1)};c.onclick=e=>mv(e.offsetX<150?-1:1);start()</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'asteroides-interativo',
        titulo: 'Asteroid Dodge',
        texto: '> Asteroid Dodge interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro asteroides:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
