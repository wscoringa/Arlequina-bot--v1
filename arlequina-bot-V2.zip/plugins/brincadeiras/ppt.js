const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'ppt',
  description: 'Pedra, papel ou tesoura',
  category: 'brincadeiras',
  aliases: ['jokenpo', 'pedrapapeltesoura'],
  async execute({ reply, reagir, args, prefix }) {
    const escolha = (args[0] || '').toLowerCase().normalize('NFD').replace(/\p{M}/gu, '')
    const opcoes = ['pedra', 'papel', 'tesoura']
    if (!opcoes.includes(escolha)) {
      return reply(caixaArlequina('PPT', `✊🖐✌ Use:\n*${prefix}ppt pedra*\n*${prefix}ppt papel*\n*${prefix}ppt tesoura*`))
    }
    await reagir('✊')
    const bot = opcoes[Math.floor(Math.random() * 3)]
    let resultado = '😐 *Empate!*'
    if (
      (escolha === 'pedra' && bot === 'tesoura') ||
      (escolha === 'papel' && bot === 'pedra') ||
      (escolha === 'tesoura' && bot === 'papel')
    ) resultado = '🏆 *Você ganhou!*'
    else if (escolha !== bot) resultado = '😈 *Eu ganhei!*'

    const emoji = { pedra: '✊', papel: '🖐', tesoura: '✌' }
    return reply(caixaArlequina('PPT', `Você: ${emoji[escolha]} *${escolha}*\nBot: ${emoji[bot]} *${bot}*\n\n${resultado}`))
  }
}
