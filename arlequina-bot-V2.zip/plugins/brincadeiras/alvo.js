const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'alvo',
  description: 'Target Trainer interativo',
  category: 'jogos',
  aliases: [],
  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🎯')
      const html = `<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}body{margin:0;background:linear-gradient(145deg,#09000f,#22002d,#0b0012);color:#fff;font-family:Arial,sans-serif;text-align:center;padding:12px}h1{font-size:20px;margin:4px}.sub{font-size:12px;opacity:.8;margin:5px 0 10px}.game{margin:auto;max-width:340px}.board{background:#11051b;border:2px solid #a855f7;border-radius:14px;box-shadow:0 0 18px #7e22ce66}button{border:1px solid #a855f7;border-radius:10px;background:#260033;color:#fff;padding:11px 15px;font-weight:700;font-size:14px;margin:4px;touch-action:manipulation}button:active{transform:scale(.96)}#score{margin:8px;font-weight:700;color:#e9d5ff}.row{display:flex;justify-content:center;flex-wrap:wrap;gap:2px}
</style></head><body><h1>🎯 TARGET TRAINER</h1><div class="sub">Acerte o máximo de alvos em 30 segundos</div><div id="score">Acertos: 0 | Tempo: 30</div><div id="arena" class="board" style="height:300px;max-width:320px;position:relative;margin:auto;overflow:hidden"></div><button onclick="start()">▶️ Começar</button><script>
const a=document.getElementById('arena'),sc=document.getElementById('score');let hits=0,time=30,timer;
function target(){a.innerHTML='';let b=document.createElement('button');b.textContent='🎯';b.style.position='absolute';b.style.left=Math.random()*85+'%';b.style.top=Math.random()*85+'%';b.style.fontSize='24px';b.onclick=()=>{hits++;sc.textContent='Acertos: '+hits+' | Tempo: '+time;target()};a.appendChild(b)}
function start(){clearInterval(timer);hits=0;time=30;target();timer=setInterval(()=>{time--;sc.textContent='Acertos: '+hits+' | Tempo: '+time;if(time<=0){clearInterval(timer);a.innerHTML='<h2>🏆 '+hits+' acertos!</h2>'}},1000)}start()</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'alvo-interativo',
        titulo: 'Target Trainer',
        texto: '> Target Trainer interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro alvo:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
