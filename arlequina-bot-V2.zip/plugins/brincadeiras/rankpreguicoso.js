const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/tJDRaHrOb'

module.exports = {
  name: 'rankpreguicoso',
  description: 'RANK PREGUIÇOSO DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankpreguicoso", `❌ Este comando só funciona em grupos.`))
    await reagir('🦥')
    try {
      await enviarRank(arlequina, from, info, 'RANK PREGUIÇOSO DO GRUPO', '🦥', 'rankpreguicoso', 'Esses 5 são os campeões do sofá.', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankpreguicoso:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
