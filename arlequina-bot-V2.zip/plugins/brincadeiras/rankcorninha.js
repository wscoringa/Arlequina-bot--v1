const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/7veqBLq9R'

module.exports = {
  name: 'rankcorninha',
  description: 'RANK CORNINHA DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankcorninha", `❌ Este comando só funciona em grupos.`))
    await reagir('🐄')
    try {
      await enviarRank(arlequina, from, info, 'RANK CORNINHA DO GRUPO', '🐄', 'rankcorninha', 'Esses 5 já sofreram no amor.', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankcorninha:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
