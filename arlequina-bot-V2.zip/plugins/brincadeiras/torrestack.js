const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'torrestack',
  description: 'Tower Stack interativo',
  category: 'jogos',
  aliases: [],
  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🗼')
      const html = `<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}body{margin:0;background:linear-gradient(145deg,#09000f,#22002d,#0b0012);color:#fff;font-family:Arial,sans-serif;text-align:center;padding:12px}h1{font-size:20px;margin:4px}.sub{font-size:12px;opacity:.8;margin:5px 0 10px}.game{margin:auto;max-width:340px}.board{background:#11051b;border:2px solid #a855f7;border-radius:14px;box-shadow:0 0 18px #7e22ce66}button{border:1px solid #a855f7;border-radius:10px;background:#260033;color:#fff;padding:11px 15px;font-weight:700;font-size:14px;margin:4px;touch-action:manipulation}button:active{transform:scale(.96)}#score{margin:8px;font-weight:700;color:#e9d5ff}.row{display:flex;justify-content:center;flex-wrap:wrap;gap:2px}
</style></head><body><h1>🗼 TOWER STACK</h1><div class="sub">Toque para empilhar os blocos</div><div id="score">Altura: 0</div><canvas id="c" class="board" width="300" height="300" style="width:300px;max-width:100%"></canvas><button onclick="start()">▶️ Reiniciar</button><script>
const c=document.getElementById('c'),x=c.getContext('2d');let blocks,cur,dir,sc,run;
function start(){blocks=[{x:100,w:100,y:270}];cur={x:0,w:100,y:240};dir=1;sc=0;run=1;loop()}
function drop(){if(!run)return;let last=blocks[blocks.length-1],left=Math.max(cur.x,last.x),right=Math.min(cur.x+cur.w,last.x+last.w);if(right-left<15){run=0;alert('💥 Torre caiu! Altura: '+sc);return}blocks.push({x:left,w:right-left,y:last.y-30});sc++;cur={x:0,w:right-left,y:last.y-60};document.getElementById('score').textContent='Altura: '+sc}
function loop(){x.fillStyle='#100016';x.fillRect(0,0,300,300);x.fillStyle='#a855f7';blocks.forEach(b=>x.fillRect(b.x,b.y,b.w,26));if(run){cur.x+=dir*3;if(cur.x<0||cur.x+cur.w>300)dir*=-1;x.fillStyle='#f0abfc';x.fillRect(cur.x,cur.y,cur.w,26);requestAnimationFrame(loop)}}c.onclick=drop;document.body.onkeydown=e=>{if(e.code==='Space')drop()};start()</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'torrestack-interativo',
        titulo: 'Tower Stack',
        texto: '> Tower Stack interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro torrestack:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
