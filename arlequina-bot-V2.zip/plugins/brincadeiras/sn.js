const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'sn',
  description: 'Responde sim ou não pra uma pergunta',
  category: 'brincadeiras',
  aliases: ['simnao', 'simounao'],
  async execute({ reply, reagir, q, args, prefix }) {
    const pergunta = (q || args.join(' ') || '').trim()
    if (!pergunta) return reply(caixaArlequina('SN', `❓ Use: *${prefix}sn* vai chover hoje?`))
    await reagir('🤔')
    const resp = Math.random() < 0.5 ? '✅ *SIM*' : '❌ *NÃO*'
    return reply(caixaArlequina('SN', `❓ *${pergunta}*\n\n${resp}\n\n_Segundo meus cálculos..._`))
  }
}
