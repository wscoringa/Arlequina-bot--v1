const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'quebrablocos',
  description: 'Quebra-blocos interativo',
  category: 'jogos',
  aliases: ['breakout', 'blocos'],

  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🧱')
      const html = `<!DOCTYPE html>
<html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{background:linear-gradient(#0f0c29,#302b63);font-family:Arial,sans-serif;color:#fff;padding:12px}
h1{text-align:center;font-size:18px}
.sub{text-align:center;font-size:11px;opacity:.85;margin:4px 0 8px}
#c{display:block;margin:0 auto;background:#1a1a2e;border:3px solid #7f5af0;border-radius:8px;width:100%;max-width:340px;touch-action:none}
#sc{text-align:center;margin-top:8px;font-size:13px}
button{display:block;margin:10px auto;padding:10px 16px;border:0;border-radius:8px;background:#7f5af0;color:#fff;font-weight:bold}
</style></head><body>
<h1>🧱 QUEBRA-BLOCOS</h1>
<div class="sub">Arraste a barra • quebre todos</div>
<canvas id="c" width="320" height="240"></canvas>
<div id="sc">Pontos: 0</div>
<button id="go">▶️ Jogar</button>
<script>
const cv=document.getElementById('c'),ctx=cv.getContext('2d');
let px,bx,by,bvx,bvy,bricks,score,run,lives;
function reset(){
  px=130;bx=160;by=180;bvx=2.8;bvy=-2.8;score=0;lives=3;run=true;
  bricks=[];
  const cols=8,rows=4,bw=36,bh=12;
  for(let r=0;r<rows;r++)for(let c=0;c<cols;c++)
    bricks.push({x:8+c*(bw+4),y:20+r*(bh+6),w:bw,h:bh,on:true,color:['#ff6b6b','#feca57','#48dbfb','#1dd1a1'][r]});
  document.getElementById('sc').textContent='Pontos: 0 | Vidas: 3';
}
function frame(){
  if(!run)return;
  bx+=bvx;by+=bvy;
  if(bx<6||bx>314)bvx*=-1;
  if(by<6)bvy*=-1;
  if(by>234){lives--;bx=160;by=180;bvy=-2.8;if(lives<=0){run=false;document.getElementById('sc').textContent='💀 Fim! Pontos: '+score;}}
  if(by>200&&by<210&&bx>px&&bx<px+60){bvy=-Math.abs(bvy);bx=Math.max(px+1,Math.min(px+59,bx))}
  bricks.forEach(b=>{
    if(!b.on)return;
    if(bx>b.x&&bx<b.x+b.w&&by>b.y&&by<b.y+b.h){b.on=false;bvy*=-1;score+=10;document.getElementById('sc').textContent='Pontos: '+score+' | Vidas: '+lives}
  });
  if(bricks.every(b=>!b.on)){run=false;document.getElementById('sc').textContent='🏆 Zerou! Pontos: '+score}
  ctx.fillStyle='#1a1a2e';ctx.fillRect(0,0,320,240);
  bricks.forEach(b=>{if(!b.on)return;ctx.fillStyle=b.color;ctx.fillRect(b.x,b.y,b.w,b.h)});
  ctx.fillStyle='#fff';ctx.fillRect(px,208,60,8);
  ctx.beginPath();ctx.arc(bx,by,5,0,Math.PI*2);ctx.fillStyle='#f1c40f';ctx.fill();
  requestAnimationFrame(frame);
}
function move(e){
  const r=cv.getBoundingClientRect();const t=e.touches?e.touches[0]:e;
  px=(t.clientX-r.left)*(320/r.width)-30;if(px<0)px=0;if(px>260)px=260;
}
cv.addEventListener('pointermove',move);cv.addEventListener('touchmove',move,{passive:true});
document.getElementById('go').onclick=()=>{reset();frame()};
reset();frame();
</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'quebrablocos-interativo',
        titulo: 'Quebra-Blocos',
        texto: '> Quebra-Blocos interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro quebrablocos:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
