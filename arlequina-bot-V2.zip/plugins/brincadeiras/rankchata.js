const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/k3EzqQhxC'

module.exports = {
  name: 'rankchata',
  description: 'RANK CHATA DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankchata", `❌ Este comando só funciona em grupos.`))
    await reagir('😤')
    try {
      await enviarRank(arlequina, from, info, 'RANK CHATA DO GRUPO', '😤', 'rankchata', 'Top 5 mais difíceis de lidar no grupo.', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankchata:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
