const { imagemDeLink, imagemDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/6ZbtPOWJr'

module.exports = {
  name: 'carioca',
  description: 'TESTE DE CARIOCA',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🏖️')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["😐 Nada de carioca hoje.", "🧊 Passou longe do Rio.", "📉 Sotaque zero."]
      const frasesAltas = ["🏖️ 100% carioca da gema!", "🌊 Nasceu de frente pro mar!", "⚽ Só falta a praia e a bola!", "🎉 Malandragem carioca em ação!"]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('carioca', LINK_FOTO)
      const texto = caixaArlequina("carioca", `🏖️ *TESTE DE CARIOCA* 🏖️\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO carioca:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
