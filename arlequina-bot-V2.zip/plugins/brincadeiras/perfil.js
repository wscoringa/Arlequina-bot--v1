/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: perfil
*/
const { carregarUsuarios } = require('../../arquivos/js/rpgDB.js')
const fs = require('fs')
const path = require('path')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'perfil',
description: "Veja seu perfil de brincadeiras",
category: 'brincadeiras',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, groupAdmins, isDono, commandManager }) {

const sock = arlequina
const msg = info
const jid = sender
const nome = pushname
const comando = 'perfil'
const isGrupo = isGroup

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  
  const alvoMencionado =
  msg.message?.extendedTextMessage?.contextInfo?.participant ||
  msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
  
  const jidPerfil = alvoMencionado || jid
  const numeroPerfil = jidPerfil.split('@')[0]
  const nomePerfil = alvoMencionado ? `@${numeroPerfil}` : (msg.pushName || 'Usuário')
  
  const humores = ['🧠 Inteligente', '😹 Engraçado', '😎 Frio', '🤪 Doido', '😈 Malvado']
  const trabalhos = ['⚽ Jogador', '👨‍💻 Programador', '🕵️ Detetive', '🚕 Motorista', '🦹 Vilão']
  const casas = ['🗑️ Lixão', '🏠 Casa Simples', '🏡 Mansão', '🏰 Castelo', '🌉 Debaixo da Ponte']
  const relacionamentos = ['Solteiro(a)', 'Casado(a) 💍', 'Enrolado(a)', 'Namorando ❤️']
  
  const humor = humores[Math.floor(Math.random() * humores.length)]
  const trabalho = trabalhos[Math.floor(Math.random() * trabalhos.length)]
  const casa = casas[Math.floor(Math.random() * casas.length)]
  const relacionamento = relacionamentos[Math.floor(Math.random() * relacionamentos.length)]
  
  const programa = (Math.random() * 5000).toFixed(2)
  
  const gado = Math.floor(Math.random() * 101)
  const puta = Math.floor(Math.random() * 101)
  const gostosura = Math.floor(Math.random() * 101)
  const beleza = Math.floor(Math.random() * 101)
  const corno = Math.floor(Math.random() * 101)
  const santo = Math.floor(Math.random() * 101)
  const safado = Math.floor(Math.random() * 101)
  const empresario = Math.floor(Math.random() * 101)
  const vagabundo = Math.floor(Math.random() * 101)
  

  const raridades = [
  '🪨 Comum',
  '🥉 Incomum',
  '🥈 Raro',
  '🥇 Épico',
  '💎 Lendário'
  ]
  
  const raridade =
  raridades[Math.floor(Math.random() * raridades.length)]

  // Status de ADM real do alvo (ou de quem usou o comando, se não marcou ninguém)
  // OBS: comparar os JIDs direto com .includes() falha sempre que o WhatsApp
  // usa formatos diferentes pro mesmo usuário (ex: "@lid" vs "@s.whatsapp.net"),
  // fazendo um ADM de verdade aparecer como "Não é ADM". Por isso comparamos
  // só os dígitos do número, igual o resto do bot já faz.
  const soNumero = (jid) => (jid || '').toString().split('@')[0].replace(/[^0-9]/g, '')
  let souADM = false
  if (isGrupo && Array.isArray(groupAdmins) && groupAdmins.length) {
    const alvoPuro = soNumero(jidPerfil)
    souADM = groupAdmins.some(admin => soNumero(admin) === alvoPuro)
  }
  const ehDono = typeof isDono === 'function' ? isDono() : false
  const textoADM = alvoMencionado
    ? (souADM ? '👑 Sim, é ADM' : '❌ Não é ADM')
    : (ehDono ? '🃏 Dono(a) do Bot' : (souADM ? '👑 Sim, é ADM' : '❌ Não é ADM'))
  
  let foto = null
  let fotoErro = null
  
  const tentarFoto = async (jidTentativa) => {
  try {
  return await sock.profilePictureUrl(jidTentativa, 'image')
  } catch (e) {
  return null
  }
  }
  
  try {
  
  let jidFoto = jidPerfil
  
  // 1ª tentativa: JID como veio
  foto = await tentarFoto(jidFoto)
  
  // 2ª tentativa: usar participantPn / participantAlt (Baileys mapeia @lid -> número real aqui)
  if (!foto) {
  
  const altJid =
  msg.key.participantPn ||
  msg.key.participantAlt ||
  msg.key.senderPn
  
  if (altJid && altJid !== jidFoto) {
  foto = await tentarFoto(altJid)
  }
  }
  
  // 3ª tentativa: se for @lid, resolver número real via groupMetadata (se for grupo)
  if (!foto && jidFoto.includes('@lid') && isGrupo) {
  
  try {
  const metadata = await sock.groupMetadata(from)
  const participante = metadata.participants.find(p => p.id === jidFoto)
  
  const numeroReal =
  participante?.jid ||
  participante?.phoneNumber ||
  participante?.lid
  
  if (numeroReal && numeroReal !== jidFoto && numeroReal.includes('@s.whatsapp.net')) {
  foto = await tentarFoto(numeroReal)
  }
  } catch (e) {}
  }
  
  // 4ª tentativa: usar sock.onWhatsApp para resolver o LID
  if (!foto && jidFoto.includes('@lid')) {
  
  try {
  const numeroLimpo = jidFoto.split('@')[0]
  const resultado = await sock.onWhatsApp(numeroLimpo)
  
  const jidResolvido = resultado?.[0]?.jid
  
  if (jidResolvido && jidResolvido !== jidFoto) {
  foto = await tentarFoto(jidResolvido)
  }
  } catch (e) {}
  }
  
  // 5ª tentativa: trocar @lid por @s.whatsapp.net (pode funcionar em alguns casos)
  if (!foto && jidFoto.includes('@lid')) {
  foto = await tentarFoto(jidFoto.replace('@lid', '@s.whatsapp.net'))
  }
  
  // 6ª tentativa: se não tem @, assumir número puro
  if (!foto && !jidFoto.includes('@')) {
  foto = await tentarFoto(`${jidFoto}@s.whatsapp.net`)
  }
  
  if (!foto) fotoErro = 'Não foi possível obter a foto (privacidade ou JID não resolvido).'
  
  } catch (e) {
  fotoErro = e?.message || 'Erro desconhecido'
  foto = null
  }
  
  const usuarios = carregarUsuarios()
  const dadosRPG = usuarios[jidPerfil]
  
  const statsRPG = dadosRPG
  ? `✦═══════✧═══════✦
║ 🎮 *STATS REAIS*
✦═══════✧═══════✦
║
║ ⭐ *LEVEL:* ${dadosRPG.level}
║ 🪙 *OURO:* ${dadosRPG.ouro}
║ 💰 *SALDO:* R$ ${dadosRPG.saldo}
║ 🏦 *BANCO:* R$ ${dadosRPG.banco}
║ ⚔️ *VITÓRIAS:* ${dadosRPG.vitorias}
║ 💀 *DERROTAS:* ${dadosRPG.derrotas}
║
`
  : ''

  const texto = `✦═══════✧═══════✦
║ 🥂 *MEU PERFIL* 🃏💜
✦═══════✧═══════✦
║
║ 🌌 *NOME:* ${nomePerfil}
║ 📱 *USUÁRIO:* ${numeroPerfil}
║ 🔱 *ADM:* ${textoADM}
║ 😹 *HUMOR:* ${humor}
║
✦═══════✧═══════✦
║ 💼 *VIDA*
✦═══════✧═══════✦
║
║ 💼 *TRABALHO:* ${trabalho}
║ 🏠 *MORA EM:* ${casa}
║ ❤️ *RELACIONAMENTO:* ${relacionamento}
║ 🍼 *PROGRAMA:* R$ ${programa}
║
✦═══════✧═══════✦
║ 💋 *PERSONALIDADE*
✦═══════✧═══════✦
║
║ 🐂 *NIVEL-GADO:* ${gado}%
║ 🌸 *NIVEL-PUTA:* ${puta}%
║ 🥵 *NIVEL-GOXTOSURA:* ${gostosura}%
║ 😍 *NIVEL-BELEZA:* ${beleza}%
║ 🐂 *CORNO:* ${corno}%
║ 😇 *SANTO(A):* ${santo}%
║ 😈 *SAFADO(A):* ${safado}%
║ 💼 *EMPRESARIO(A):* ${empresario}%
║ 🦥 *VAGABUNDO(A):* ${vagabundo}%
║
${statsRPG}✦═══════✧═══════✦
║ 💎 *RARIDADE:* ${raridade}
✦═══════✧═══════✦
🃏💜 *Arlequina Bot* 💜🃏`

  const imagemArlequina = path.join(__dirname, '../../arquivos/imagem/menu.jpg')

  let imagemEnvio
  if (foto) {
    imagemEnvio = { url: foto }
  } else if (fs.existsSync(imagemArlequina)) {
    imagemEnvio = fs.readFileSync(imagemArlequina)
  } else {
    imagemEnvio = { url: 'https://i.imgur.com/6VBx3io.png' }
  }

  await enviar({
  image: imagemEnvio,
  caption: texto,
  mentions: alvoMencionado ? [alvoMencionado] : []
  }, { quoted: msg })
} catch (e) {
console.log('❌ ERRO BRINCADEIRA (perfil):', e?.message)
await reply(caixaArlequina("perfil", `❌ Não consegui executar esse comando agora, tenta de novo.`))
}

}
}
