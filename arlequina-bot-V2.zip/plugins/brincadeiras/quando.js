const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'quando',
  description: 'Responde quando algo vai acontecer',
  category: 'brincadeiras',
  aliases: ['when'],
  async execute({ reply, reagir, q, args, prefix }) {
    const pergunta = (q || args.join(' ') || '').trim()
    if (!pergunta) return reply(caixaArlequina('QUANDO', `📅 Use: *${prefix}quando* vou ficar rico`))
    await reagir('📅')
    const tempos = ['Hoje', 'Amanhã', 'Nunca', 'Em breve', 'Daqui a pouco', 'Ano que vem', 'Daqui 1 semana', 'Daqui 1 mês', 'Daqui 1 ano', 'No próximo sábado', 'Quando o Flamengo for rebaixado', 'Quando o sol nascer no oeste']
    const t = tempos[Math.floor(Math.random() * tempos.length)]
    return reply(caixaArlequina('QUANDO', `❓ *${pergunta}*\n\n📅 Resposta: *${t}*`))
  }
}
