const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (coloca uma bem safada e molhada)
const LINK_FOTO = 'https://i.ibb.co/fdLcqrHV/cb9394561b3710d9.jpg'

module.exports = {
  name: 'bct',
  description: 'TESTE DE BCT +18',
  category: 'brincadeiras',
  aliases: ['buceta', 'bct18', 'testebct', 'molhada'],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    
    await reagir('💦')

    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)

      // Frases baixas +18
      const frasesBaixas = [
        "🥱 Buceta seca hoje, nem molhou...",
        "😅 Tá meio adormecida, precisa de carinho.",
        "🙈 Modo freira ativado.",
        "🫠 Quase nem aperta.",
        "💤 Sem clima, sem tesão.",
        "📉 Produção de mel baixa demais.",
        "🫤 Passou batido, ninguém sentiu."
      ]

      // Frases altas +18
      const frasesAltas = [
        "🔥 BUCETA EM CHAMAS, tá encharcada!",
        "💦 Molhando o grupo inteiro!",
        "😈 A mais safada e apertada do rolê!",
        "🏆 Rainha da Buceta Molhada!",
        "👑 Tá pingando de tesão!",
        "🌶️ Nível insano de putaria!",
        "😮‍💨 Tá destruindo as mãos e os paus!",
        "🍑 Melhor buceta do grupo, sem dúvida!"
      ]

      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('bct', LINK_FOTO)

      const texto = caixaArlequina("bct", `💦 *TESTE DE BCT +18* 💦\n\n`) +
                    `👤 @${alvo.split('@')[0]}\n\n` +
                    `📊 Nível de Buceta: *${pct}%*\n\n` +
                    `${frase}`

      if (imgBuffer) {
        await arlequina.sendMessage(from, { 
          image: imgBuffer, 
          caption: texto, 
          mentions: [alvo] 
        }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { 
          text: texto, 
          mentions: [alvo] 
        }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO bct +18:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
