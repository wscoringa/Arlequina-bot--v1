const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'minas',
  description: 'Campo minado interativo',
  category: 'jogos',
  aliases: ['campominado', 'minesweeper'],

  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('💣')
      const html = `<!DOCTYPE html>
<html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{background:linear-gradient(#2c3e50,#1a252f);font-family:Arial,sans-serif;color:#ecf0f1;padding:12px}
h1{text-align:center;font-size:18px}
.sub{text-align:center;font-size:11px;opacity:.85;margin:4px 0 8px}
#grid{display:grid;grid-template-columns:repeat(8,1fr);gap:3px;max-width:300px;margin:0 auto}
.cell{aspect-ratio:1;background:#34495e;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:bold;color:#fff}
.cell.open{background:#7f8c8d}
.cell.mine{background:#e74c3c}
.cell.flag{background:#f39c12}
button{display:block;margin:10px auto;padding:10px 16px;border:0;border-radius:8px;background:#3498db;color:#fff;font-weight:bold}
#msg{text-align:center;font-size:12px;margin-top:6px}
</style></head><body>
<h1>💣 CAMPO MINADO</h1>
<div class="sub">Toque = abrir • Segure = bandeira</div>
<div id="grid"></div>
<div id="msg"></div>
<button id="novo">🔄 Novo</button>
<script>
const N=8,MINES=10;let board,open,flag,dead,won;
function init(){
  board=Array.from({length:N},()=>Array(N).fill(0));
  open=Array.from({length:N},()=>Array(N).fill(false));
  flag=Array.from({length:N},()=>Array(N).fill(false));
  dead=false;won=false;document.getElementById('msg').textContent='Minas: '+MINES;
  let m=0;while(m<MINES){const r=Math.floor(Math.random()*N),c=Math.floor(Math.random()*N);if(board[r][c]!==-1){board[r][c]=-1;m++}}
  for(let r=0;r<N;r++)for(let c=0;c<N;c++){
    if(board[r][c]===-1)continue;let n=0;
    for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++){const rr=r+dr,cc=c+dc;if(rr>=0&&rr<N&&cc>=0&&cc<N&&board[rr][cc]===-1)n++}
    board[r][c]=n;
  }
  draw();
}
function draw(){
  const el=document.getElementById('grid');el.innerHTML='';
  for(let r=0;r<N;r++)for(let c=0;c<N;c++){
    const d=document.createElement('div');d.className='cell';
    if(flag[r][c]){d.classList.add('flag');d.textContent='🚩'}
    else if(open[r][c]){
      d.classList.add('open');
      if(board[r][c]===-1){d.classList.add('mine');d.textContent='💣'}
      else if(board[r][c]>0)d.textContent=board[r][c];
    }
    let t=null;
    d.ontouchstart=e=>{e.preventDefault();t=setTimeout(()=>{if(dead||won||open[r][c])return;flag[r][c]=!flag[r][c];draw()},450)};
    d.ontouchend=e=>{e.preventDefault();if(t){clearTimeout(t);t=null;click(r,c)}};
    d.onmousedown=()=>{if(dead||won)return;if(event.button===2){flag[r][c]=!flag[r][c];draw()}else click(r,c)};
    d.oncontextmenu=e=>e.preventDefault();
    el.appendChild(d);
  }
}
function click(r,c){
  if(dead||won||flag[r][c]||open[r][c])return;
  if(board[r][c]===-1){dead=true;for(let i=0;i<N;i++)for(let j=0;j<N;j++)if(board[i][j]===-1)open[i][j]=true;document.getElementById('msg').textContent='💥 Boom!';draw();return}
  flood(r,c);draw();
  let left=0;for(let i=0;i<N;i++)for(let j=0;j<N;j++)if(board[i][j]!==-1&&!open[i][j])left++;
  if(left===0){won=true;document.getElementById('msg').textContent='🏆 Limpou o campo!'}
}
function flood(r,c){
  if(r<0||r>=N||c<0||c>=N||open[r][c]||flag[r][c])return;
  open[r][c]=true;if(board[r][c]!==0)return;
  for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++)flood(r+dr,c+dc);
}
document.getElementById('novo').onclick=init;init();
</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'minas-interativo',
        titulo: 'MINAS',
        texto: '> MINAS interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro minas:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
