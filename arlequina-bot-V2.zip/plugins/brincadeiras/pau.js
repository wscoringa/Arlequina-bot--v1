const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando — troque pelo link que você quiser usar
const LINK_FOTO = 'https://pin.it/2vObMfVGi'

module.exports = {
  name: 'pau',
  description: 'Mede o tamanho em cm',
  category: 'brincadeiras',
  aliases: ['tamanho', 'pinto'],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('📏')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const cm = Math.floor(Math.random() * 26) + 2 // 2 a 27 cm

      const frasesBaixas = ["🥲 Calma, ninguém vai saber...", "😅 Foi mal.", "🙈 Precisa de uma régua melhor.", "🤏 Pequenininho...", "💀 O grupo sentiu pena.", "😴 Modo econômico ativado."]
      const frasesMedias = ["😌 Na média, tá tranquilo.", "🙂 Nem pouco nem muito.", "👍 Passável.", "😏 Dá pro gasto."]
      const frasesAltas = ["🔥 Monstro do grupo!", "💪 Assustador!", "😈 O grupo tremeu!", "🏆 Recorde do grupo!", "👑 Ninguém chega perto!", "🚨 Alerta geral!"]
      const frase = cm <= 9
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : cm <= 18
        ? frasesMedias[Math.floor(Math.random() * frasesMedias.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const texto = caixaArlequina("pau", `📏 *MEDIDOR* 📏\n\n👤 @${alvo.split('@')[0]}\n\n📐 Tamanho: *${cm} cm*\n\n${frase}`)

      const imgBuffer = await imagemFixaDaBrincadeira('pau', LINK_FOTO)
      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO pau:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
