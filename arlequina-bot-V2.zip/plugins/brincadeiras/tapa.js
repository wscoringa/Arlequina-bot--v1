const { enviarGifFixo } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const LINK_GIF = 'https://media1.tenor.com/m/8VAgT4nmZ-UAAAAC/slap-anime.gif'

module.exports = {
  name: 'tapa',
  description: 'TAPA ALEATÓRIO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('👋')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = [
        "🤲 O tapa foi fraco...", "😌 Quase não doeu.", "🥲 Tapa de algodão.", "👋 Suave demais.",
        "😅 O tapa virou carinho.", "🍃 Mais brisa que tapa.", "😴 Nem acordou.", "🤏 Tapa de formiga.",
        "🪶 Levinho igual pena.", "😶 Ninguém sentiu nada."
      ]
      const frasesAltas = [
        "👋 Tapa lendário!", "💥 Derrubou do banco!", "😂 Acordou até o vizinho!", "💀 TAPA HISTÓRICO!",
        "😳 Doeu até em mim!", "🚀 Saiu voando!", "🔊 Ecoou no bairro inteiro!", "🌪️ Tapa tsunami!",
        "🥊 Nocaute técnico!", "📉 A confiança da pessoa caiu junto.", "🧨 Explosão de tapa!", "🩹 Vai precisar de curativo."
      ]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const texto = caixaArlequina("tapa", `👋 *TAPA ALEATÓRIO* 👋\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      await enviarGifFixo(arlequina, from, info, LINK_GIF, 'tapa', texto, [alvo])
    } catch (e) {
      console.error('ERRO tapa:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
