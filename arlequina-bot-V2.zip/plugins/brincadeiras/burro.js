const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/3VgH6nl1h'

module.exports = {
  name: 'burro',
  description: 'TESTE DE BURRO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🫏')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["🧠 Gênio disfarçado.", "💡 QI acima da média!", "📚 Einstein do grupo.", "🎓 Inteligência rara.", "🔬 Quase um cientista.", "🦉 Sabedoria de coruja velha.", "📐 Resolve até cálculo de cabeça.", "🏅 Top 1 do grupo de estudos."]
      const frasesAltas = ["🫏 Burrice lendária!", "💀 Passou da conta hoje.", "🤦 Nem o professor aguenta.", "🧱 Parede pensa mais.", "😬 Isso dói de assistir.", "🥴 Nível burro máximo!", "📏 Confundiu metro com quilômetro.", "🙃 Leu errado de propósito, né?", "🔄 Repetiu a mesma pergunta 3 vezes."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('burro', LINK_FOTO)
      const texto = caixaArlequina("burro", `🫏 *TESTE DE BURRO* 🫏\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO burro:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
