const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/1uev11b6m'

module.exports = {
  name: 'rankgostosa',
  description: 'RANK GOSTOSA DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankgostosa", `❌ Este comando só funciona em grupos.`))
    await reagir('🔥')
    try {
      await enviarRank(arlequina, from, info, 'RANK GOSTOSA DO GRUPO', '🔥', 'rankgostosa', 'Top 5 mais gostosas do grupo!', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankgostosa:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
