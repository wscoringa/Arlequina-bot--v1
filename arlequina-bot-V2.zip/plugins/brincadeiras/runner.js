const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'runner',
  description: 'Endless Runner interativo',
  category: 'jogos',
  aliases: [],
  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🏃')
      const html = `<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}body{margin:0;background:linear-gradient(145deg,#09000f,#22002d,#0b0012);color:#fff;font-family:Arial,sans-serif;text-align:center;padding:12px}h1{font-size:20px;margin:4px}.sub{font-size:12px;opacity:.8;margin:5px 0 10px}.game{margin:auto;max-width:340px}.board{background:#11051b;border:2px solid #a855f7;border-radius:14px;box-shadow:0 0 18px #7e22ce66}button{border:1px solid #a855f7;border-radius:10px;background:#260033;color:#fff;padding:11px 15px;font-weight:700;font-size:14px;margin:4px;touch-action:manipulation}button:active{transform:scale(.96)}#score{margin:8px;font-weight:700;color:#e9d5ff}.row{display:flex;justify-content:center;flex-wrap:wrap;gap:2px}
</style></head><body><h1>🏃 ENDLESS RUNNER</h1><div class="sub">Corra, pule e desvie dos obstáculos</div><div id="score">Pontos: 0</div><canvas id="c" class="board" width="320" height="180" style="width:100%;max-width:320px"></canvas><button onclick="jump()">⬆️ PULAR</button><button onclick="start()">▶️ REINICIAR</button><script>
const c=document.getElementById('c'),x=c.getContext('2d');let p,obs,sc,run;
function start(){p={x:45,y:135,vy:0};obs=[];sc=0;run=1;loop()}function jump(){if(!run)return start();if(p.y>=135)p.vy=-10}function loop(){if(!run)return;x.fillStyle='#100016';x.fillRect(0,0,320,180);x.fillStyle='#6b21a8';x.fillRect(0,158,320,22);p.vy+=.6;p.y+=p.vy;if(p.y>135)p.y=135;if(Math.random()<.03)obs.push({x:320,h:18+Math.random()*30});obs.forEach(a=>a.x-=5);obs=obs.filter(a=>a.x>-20);x.fillStyle='#e879f9';x.fillRect(p.x,p.y,22,23);x.fillStyle='#c084fc';obs.forEach(a=>x.fillRect(a.x,158-a.h,18,a.h));for(let a of obs)if(p.x<a.x+18&&p.x+22>a.x&&p.y+23>158-a.h){run=0;alert('💀 Fim! Pontos: '+Math.floor(sc/10));return}sc++;document.getElementById('score').textContent='Pontos: '+Math.floor(sc/10);requestAnimationFrame(loop)}c.onclick=jump;start()</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'runner-interativo',
        titulo: 'Endless Runner',
        texto: '> Endless Runner interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro runner:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
