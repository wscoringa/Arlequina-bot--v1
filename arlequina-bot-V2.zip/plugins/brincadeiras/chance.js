const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'chance',
  description: 'Calcula a chance de algo acontecer',
  category: 'brincadeiras',
  aliases: ['probabilidade'],
  async execute({ reply, reagir, q, args, prefix }) {
    const texto = (q || args.join(' ') || '').trim()
    if (!texto) return reply(caixaArlequina('CHANCE', `🎲 Use: *${prefix}chance* eu ganhar na mega`))
    await reagir('🎲')
    const pct = Math.floor(Math.random() * 101)
    return reply(caixaArlequina('CHANCE', `🎯 *${texto}*\n\n📊 Chance: *${pct}%*`))
  }
}
