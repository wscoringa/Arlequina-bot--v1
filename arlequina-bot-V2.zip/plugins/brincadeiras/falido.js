const { imagemDeLink, imagemDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://images.pexels.com/photos/12001949/pexels-photo-12001949.jpeg?auto=compress&cs=tinysrgb&w=1200'

module.exports = {
  name: 'falido',
  description: 'TESTE DE FALIDO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('💸')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["💰 Tá rico hoje!", "😎 Carteira cheia!", "📈 Longe da falência!", "🤑 Investidor nato!"]
      const frasesAltas = ["💸 Falido nível máximo!", "📉 Conta no vermelho!", "🥲 Pediu fiado de novo!", "🏦 Banco já nem atende mais!", "🃏 Nem a Arlequina empresta pra esse!"]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('falido', LINK_FOTO)
      const texto = caixaArlequina("falido", `💸 *TESTE DE FALIDO* 💸\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO falido:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
