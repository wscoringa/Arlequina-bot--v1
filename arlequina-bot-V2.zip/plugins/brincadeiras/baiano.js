const { imagemDeLink, imagemDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/70wB1F3RU'

module.exports = {
  name: 'baiano',
  description: 'TESTE DE BAIANO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🌴')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["😐 Sotaque baiano fraco hoje.", "🧊 Sem axé nenhum.", "📉 Passou longe da Bahia."]
      const frasesAltas = ["🌴 Baianidade nata!", "🎶 Só falta o axé tocando!", "☀️ Sotaque 100% Salvador!", "🏖️ Nasceu na praia com certeza!"]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('baiano', LINK_FOTO)
      const texto = caixaArlequina("baiano", `🌴 *TESTE DE BAIANO* 🌴\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO baiano:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
