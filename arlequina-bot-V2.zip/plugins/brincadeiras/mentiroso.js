const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/7meJKTTrV'

module.exports = {
  name: 'mentiroso',
  description: 'TESTE DE MENTIROSO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🤥')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["✅ Honesto como sempre!", "🤝 Palavra de lei.", "💎 Confiança máxima.", "🕊️ Verdade no sangue.", "🌟 O grupo confia em você.", "📖 Só fala a verdade, sempre.", "🤲 Transparência total.", "🪶 Leve na consciência."]
      const frasesAltas = ["🤥 Nariz crescendo!", "💀 Mentiu até a conta.", "😬 Ninguém acreditou.", "🎭 Ator de novela.", "😅 Pinóquio com inveja.", "🤥 Já inventou até desculpa pra desculpa.", "🎬 Roteiro novo a cada pergunta.", "📚 Coleção de histórias inventadas."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('mentiroso', LINK_FOTO)
      const texto = caixaArlequina("mentiroso", `🤥 *TESTE DE MENTIROSO* 🤥\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO mentiroso:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
