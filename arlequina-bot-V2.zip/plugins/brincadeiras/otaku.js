const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/5iahH114l'

module.exports = {
  name: 'otaku',
  description: 'TESTE DE OTAKU',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🎌')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["😤 Anti-anime mesmo.", "💀 Nunca viu um episódio.", "😎 Mainstream preferido.", "🤷 Anime? Que isso?", "📺 Prefere reality show.", "📺 Prefere série gringa.", "🎮 Mais videogame que anime.", "🤷 Nunca ouviu falar de fansub."]
      const frasesAltas = ["🎌 Otaku raiz!", "🍜 Vive em animes!", "💀 Episódio 1 até 999.", "🗾 Já pediu visto pro Japão.", "✨ Waifu no coração!", "🎌 Sabe a abertura de cabeça.", "📦 Coleção de figures intacta.", "🍙 Já tentou cozinhar bento japonês."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('otaku', LINK_FOTO)
      const texto = caixaArlequina("otaku", `🎌 *TESTE DE OTAKU* 🎌\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO otaku:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
