const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'otario',
  emoji: '🤡',
  titulo: 'Caiu numa boa hoje',
  frases: ["acreditou em corrente de zap de novo! 🤡", "já foi trollado(a) 3 vezes essa semana! 😂", "compra tudo que aparece em anúncio! 🛒"]
})
