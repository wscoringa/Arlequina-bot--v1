const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/3qjVNxbHe'

module.exports = {
  name: 'linda',
  description: 'TESTE DE LINDA',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('👸')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["😅 Hoje não é o dia.", "😬 Perdeu o pique.", "🥴 O charme sumiu.", "💤 Beleza de folga.", "🫤 Nem o espelho aprovou.", "😶 Charme tirou folga hoje.", "🫥 Brilho em baixa.", "📉 Beleza discreta demais."]
      const frasesAltas = ["👸 Linda demais!", "✨ Deslumbrante!", "💜 Beleza rara!", "🌹 Rainha confirmada!", "😍 Perfeita hoje!", "💫 Impossível não notar!", "📸 Quebra a internet com uma foto!", "🦋 Beleza que ilumina o ambiente!", "🥇 Disparada a mais elegante!"]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('linda', LINK_FOTO)
      const texto = caixaArlequina("linda", `👸 *TESTE DE LINDA* 👸\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO linda:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
