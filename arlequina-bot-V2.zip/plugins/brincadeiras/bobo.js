const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'bobo',
  emoji: '🤪',
  titulo: 'É meio bobo(a)',
  frases: ["ri sozinho lembrando de nada! 🤪", "confunde receita com bula de remédio! 💊", "já perguntou se peixe tem sede! 🐟"]
})
