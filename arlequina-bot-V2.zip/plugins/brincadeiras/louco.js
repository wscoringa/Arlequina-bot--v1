const { imagemDeLink, imagemDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/1VPDrNK85'

module.exports = {
  name: 'louco',
  description: 'TESTE DE LOUCO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🤪')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["😐 Hoje tá bem normal.", "🧘 Equilibrado demais.", "📏 Nada de doido hoje.", "😴 Comportamento na régua."]
      const frasesAltas = ["🤪 Loucura total!", "🌪️ Sem noção nenhuma!", "🎢 Maluco de marca maior!", "💥 Doido igual porta de motel!", "🃏 Loucura nível Arlequina!"]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('louco', LINK_FOTO)
      const texto = caixaArlequina("louco", `🤪 *TESTE DE LOUCO* 🤪\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO louco:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
