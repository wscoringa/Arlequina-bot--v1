const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'zumbis',
  description: 'Zombie Survival interativo',
  category: 'jogos',
  aliases: [],
  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🧟')
      const html = `<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}body{margin:0;background:linear-gradient(145deg,#09000f,#22002d,#0b0012);color:#fff;font-family:Arial,sans-serif;text-align:center;padding:12px}h1{font-size:20px;margin:4px}.sub{font-size:12px;opacity:.8;margin:5px 0 10px}.game{margin:auto;max-width:340px}.board{background:#11051b;border:2px solid #a855f7;border-radius:14px;box-shadow:0 0 18px #7e22ce66}button{border:1px solid #a855f7;border-radius:10px;background:#260033;color:#fff;padding:11px 15px;font-weight:700;font-size:14px;margin:4px;touch-action:manipulation}button:active{transform:scale(.96)}#score{margin:8px;font-weight:700;color:#e9d5ff}.row{display:flex;justify-content:center;flex-wrap:wrap;gap:2px}
</style></head><body><h1>🧟 ZOMBIE SURVIVAL</h1><div class="sub">Sobreviva às ondas e marque pontos</div><div id="score">Pontos: 0</div><canvas id="c" class="board" width="300" height="300" style="width:300px;max-width:100%"></canvas><div class="row"><button onclick="mv(0,-1)">⬆️</button><button onclick="mv(-1,0)">⬅️</button><button onclick="mv(0,1)">⬇️</button><button onclick="mv(1,0)">➡️</button></div><button onclick="start()">▶️ Reiniciar</button><script>
const c=document.getElementById('c'),x=c.getContext('2d');let p,z,sc,run;
function start(){p={x:150,y:150};z=[];sc=0;run=1;loop()}function mv(dx,dy){p.x=Math.max(12,Math.min(288,p.x+dx*18));p.y=Math.max(12,Math.min(288,p.y+dy*18))}function loop(){if(!run)return;x.fillStyle='#100016';x.fillRect(0,0,300,300);if(Math.random()<.025)z.push({x:Math.random()*300,y:Math.random()*300});z.forEach(a=>{let dx=p.x-a.x,dy=p.y-a.y,d=Math.hypot(dx,dy)||1;a.x+=dx/d*.8;a.y+=dy/d*.8});z.forEach(a=>{x.fillStyle='#86efac';x.beginPath();x.arc(a.x,a.y,9,0,7);x.fill()});x.fillStyle='#f0abfc';x.beginPath();x.arc(p.x,p.y,10,0,7);x.fill();for(let a of z)if(Math.hypot(a.x-p.x,a.y-p.y)<18){run=0;alert('🧟 Fim! Pontos: '+sc);return}sc++;document.getElementById('score').textContent='Pontos: '+Math.floor(sc/10);requestAnimationFrame(loop)}start()</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'zumbis-interativo',
        titulo: 'Zombie Survival',
        texto: '> Zombie Survival interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro zumbis:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
