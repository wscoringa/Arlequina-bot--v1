const { enviarRank } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Mesmo link do comando base (falido.js)
const LINK_FOTO = 'https://images.pexels.com/photos/12001949/pexels-photo-12001949.jpeg?auto=compress&cs=tinysrgb&w=1200'

module.exports = {
  name: 'rankfalido',
  description: 'RANK FALIDO DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankfalido", `❌ Este comando só funciona em grupos.`))
    await reagir('💸')
    try {
      await enviarRank(arlequina, from, info, 'RANK FALIDO DO GRUPO', '💸', 'rankfalido', 'Top 5 mais falidos do grupo!', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankfalido:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
