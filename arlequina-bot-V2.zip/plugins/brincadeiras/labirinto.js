const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'labirinto',
  description: 'Labirinto interativo',
  category: 'jogos',
  aliases: [],
  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🌀')
      const html = `<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}body{margin:0;background:linear-gradient(145deg,#09000f,#22002d,#0b0012);color:#fff;font-family:Arial,sans-serif;text-align:center;padding:12px}h1{font-size:20px;margin:4px}.sub{font-size:12px;opacity:.8;margin:5px 0 10px}.game{margin:auto;max-width:340px}.board{background:#11051b;border:2px solid #a855f7;border-radius:14px;box-shadow:0 0 18px #7e22ce66}button{border:1px solid #a855f7;border-radius:10px;background:#260033;color:#fff;padding:11px 15px;font-weight:700;font-size:14px;margin:4px;touch-action:manipulation}button:active{transform:scale(.96)}#score{margin:8px;font-weight:700;color:#e9d5ff}.row{display:flex;justify-content:center;flex-wrap:wrap;gap:2px}
</style></head><body><h1>🌀 LABIRINTO</h1><div class="sub">Leve o quadrado roxo até a saída</div><div id="score">Movimentos: 0</div><canvas id="c" class="board" width="300" height="300" style="width:300px;max-width:100%"></canvas><div class="row"><button onclick="go(0,-1)">⬆️</button></div><div class="row"><button onclick="go(-1,0)">⬅️</button><button onclick="go(0,1)">⬇️</button><button onclick="go(1,0)">➡️</button></div><button onclick="reset()">🔄 Novo</button><script>
const c=document.getElementById('c'),x=c.getContext('2d'),N=10,S=30;let px,py,moves;let maze=[
'1111111111','1000000001','1011111101','1010000101','1010110101','1010100101','1010111101','1000000001','1111111101','1111111101'];
function reset(){px=1;py=1;moves=0;draw()}function go(dx,dy){let nx=px+dx,ny=py+dy;if(nx<0||ny<0||nx>=N||ny>=N||maze[ny][nx]==='1')return;px=nx;py=ny;moves++;document.getElementById('score').textContent='Movimentos: '+moves;draw();if(px===8&&py===8){setTimeout(()=>alert('🏆 Você escapou!'),50)}}
function draw(){x.fillStyle='#100016';x.fillRect(0,0,300,300);for(let y=0;y<N;y++)for(let z=0;z<N;z++){x.fillStyle=maze[y][z]==='1'?'#6b21a8':'#1f0b2b';x.fillRect(z*S,y*S,S-1,S-1)}x.fillStyle='#f0abfc';x.fillRect(px*S+5,py*S+5,20,20);x.fillStyle='#86efac';x.fillRect(8*S+7,8*S+7,16,16)}reset()</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'labirinto-interativo',
        titulo: 'Labirinto',
        texto: '> Labirinto interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro labirinto:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
