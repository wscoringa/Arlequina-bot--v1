const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/5MVa6r4XN'

module.exports = {
  name: 'casal',
  description: 'Sorteia um casal aleatório do grupo com @',
  category: 'brincadeiras',
  aliases: ['amor', 'shippar'],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('💞')
    try {
      const metadata = await arlequina.groupMetadata(from)
      const participantes = metadata.participants.map(p => p.id)
      if (participantes.length < 2) return reply('❌ Preciso de pelo menos 2 pessoas no grupo.')

      const p1 = participantes[Math.floor(Math.random() * participantes.length)]
      let p2 = participantes[Math.floor(Math.random() * participantes.length)]
      while (p1 === p2) p2 = participantes[Math.floor(Math.random() * participantes.length)]

      // 0 a 100% — quanto maior o número, melhor o resultado (escalonado em 4 faixas)
      const pct = Math.floor(Math.random() * 101)

      const frasesRuim = [
        '💔 Melhor cada um seguir seu caminho...',
        '🥀 Esse casal não tem muita química.',
        '💀 A chance de dar certo é pequena.',
        '🧊 Temperatura do amor: congelada.'
      ]

      const frasesDuvidoso = [
        '😬 Parece que não vai dar certo.',
        '🙃 Talvez seja melhor só amizade.',
        '😅 O amor tá em modo econômico aqui.',
        '🫤 Tá faltando faísca entre vocês.'
      ]

      const frasesBoa = [
        '🌸 Amor em flor no grupo.',
        '🤍 Dois corações que batem igual.',
        '🃏 Arlequina sorriu pro casal.',
        '🥰 Que casal lindo!',
        '❤️ Destino aprovado!',
        '🌹 Que combinação linda demais!'
      ]

      const frasesPerfeita = [
        '💖 Casal perfeito!',
        '😍 Feitos um para o outro.',
        '💘 O amor está no ar.',
        '🔥 Amor que não tem explicação!',
        '💍 Já pode casar, vai!',
        '🎭 Até o Coringa aprovou esse amor!',
        '👑 Casal lendário do grupo!',
        '💫 Alma gêmea encontrada!',
        '❤️‍🔥 Paixão de cinema!'
      ]

      let frase
      if (pct <= 25) frase = frasesRuim[Math.floor(Math.random() * frasesRuim.length)]
      else if (pct <= 50) frase = frasesDuvidoso[Math.floor(Math.random() * frasesDuvidoso.length)]
      else if (pct <= 75) frase = frasesBoa[Math.floor(Math.random() * frasesBoa.length)]
      else frase = frasesPerfeita[Math.floor(Math.random() * frasesPerfeita.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('casal', LINK_FOTO)
      const texto = caixaArlequina("casal", `💞 *CASAL DO GRUPO* 💞\n\n❤️ @${p1.split('@')[0]}\n💜 @${p2.split('@')[0]}\n\n📊 Compatibilidade: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [p1, p2] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [p1, p2] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO casal:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
