const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'brabo',
  emoji: '🔥',
  titulo: 'Tá brabo(a) hoje',
  frases: ["tá voando em tudo que faz hoje! 🔥", "ninguém segura esse desempenho! 🚀", "hoje é dia de ser reconhecido(a)! 🏆"]
})
