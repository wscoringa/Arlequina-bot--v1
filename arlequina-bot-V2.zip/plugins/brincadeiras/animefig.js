/*
 Comandos de personagem de anime (!naruto, !sasuke, !nezuko, etc) —
 mesma ideia visual do "/kagura" do Kimori (card com o nome do
 personagem e "Solicitado por"), só que usando uma API PÚBLICA e
 gratuita (safebooru, sempre filtrando rating:safe) em vez da API paga
 e privada que o Kimori usa — essa eu não tenho como replicar sem a
 chave deles.

 Também dá pra buscar qualquer outro nome com !animefig <nome>.
*/
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const HEADERS_PADRAO = { 'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0 Mobile Safari/537.36' }

// mesma lista de personagens do Kimori, com legenda parecida
const CAPTIONS = {
  kagura: '☂️ *Kagura*',
  naruto: '🍥 *Naruto Uzumaki*',
  sasuke: '⚡ *Sasuke Uchiha*',
  sakura: '🌸 *Sakura Haruno*',
  tsunade: '💪 *Tsunade Senju*',
  itachi: '🍥 *Itachi Uchiha*',
  madara: '🍥 *Madara Uchiha*',
  minato: '⚡ *Minato Namikaze*',
  boruto: '🍥 *Boruto Uzumaki*',
  deidara: '💣 *Deidara*',
  nezuko: '🎀 *Nezuko Kamado*',
  mikasa: '⚔️ *Mikasa Ackerman*',
  erza: '⚔️ *Erza Scarlet*',
  emilia: '❄️ *Emilia*',
  hestia: '🔥 *Hestia*',
  rize: '🩸 *Rize Kamishiro*',
  kaori: '🎻 *Kaori Miyazono*',
  miku: '💙 *Hatsune Miku*',
  kurumi: '⏰ *Kurumi Tokisaki*',
  mikasa_ackerman: '⚔️ *Mikasa Ackerman*',
  onepiece: '🏴‍☠️ *One Piece*',
  pokemon: '⚡ *Pokémon*'
}

async function buscarImagem(tag) {
  const { data } = await axios.get('https://safebooru.org/index.php', {
    params: { page: 'dapi', s: 'post', q: 'index', tags: `${tag} rating:safe`, json: 1, limit: 40 },
    headers: HEADERS_PADRAO,
    timeout: 15000
  })
  const resultados = Array.isArray(data) ? data : []
  if (!resultados.length) return null
  const escolhido = resultados[Math.floor(Math.random() * resultados.length)]
  return escolhido.file_url || `https://safebooru.org/images/${escolhido.directory}/${escolhido.image}`
}

module.exports = {
  name: 'animefig',
  description: 'Busca imagem de personagem de anime (API pública, sempre rating:safe)',
  category: 'brincadeiras',
  aliases: Object.keys(CAPTIONS),
  async execute({ arlequina, from, info, args, q, reply, reagir, prefix, pushname, command }) {
    // se veio de um dos apelidos de personagem (ex: !naruto), usa o
    // próprio nome do comando. Se veio de !animefig, usa o texto digitado.
    const comandoUsado = (command || '').toLowerCase()
    const nomeBusca = CAPTIONS[comandoUsado] ? comandoUsado : (q || args.join(' ')).trim()

    if (!nomeBusca) {
      return reply(caixaArlequina('animefig', `🎨 Como usar:\n${prefix}animefig <nome do personagem>\n\nEx: ${prefix}animefig Naruto\n\nOu use os atalhos: ${Object.keys(CAPTIONS).map(k => `${prefix}${k}`).join(', ')}`))
    }

    await reagir('🎨')

    try {
      const tag = nomeBusca.toLowerCase().replace(/\s+/g, '_')
      const url = await buscarImagem(tag)

      if (!url) {
        return reply(caixaArlequina('animefig', `❌ Não achei nenhuma imagem de *${nomeBusca}*.\n💡 Tenta escrever o nome de outro jeito (geralmente funciona melhor em inglês).`))
      }

      const { data: imgBuffer } = await axios.get(url, { responseType: 'arraybuffer', headers: HEADERS_PADRAO, timeout: 20000 })

      const legenda = CAPTIONS[comandoUsado] || `✨ *${nomeBusca}*`
      const caption = `${legenda}\n👤 Solicitado por: ${pushname}`

      await arlequina.sendMessage(from, { image: Buffer.from(imgBuffer), caption }, { quoted: info })
    } catch (e) {
      console.log('❌ ERRO animefig:', e?.message)
      await reply('❌ Não consegui buscar agora, tenta de novo em instantes.')
    }
  }
}
