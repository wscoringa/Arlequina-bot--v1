const { enviarRank } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Mesmo link do comando base (baiana.js)
const LINK_FOTO = 'https://pin.it/7muuk9Wlk'

module.exports = {
  name: 'rankbaiana',
  description: 'RANK BAIANA DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankbaiana", `❌ Este comando só funciona em grupos.`))
    await reagir('🌴')
    try {
      await enviarRank(arlequina, from, info, 'RANK BAIANA DO GRUPO', '🌴', 'rankbaiana', 'Top 5 mais baiana do grupo!', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankbaiana:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
