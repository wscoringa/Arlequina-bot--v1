const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque pelo link do Pinterest que você quiser)
const LINK_FOTO = 'https://pin.it/4TH6MayzN'

module.exports = {
  name: 'safada',
  description: 'TESTE DE SAFADA',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('😏')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["😇 Hoje tá santa demais.", "😅 Perdeu a manha hoje.", "🙈 Modo comportada ativado.", "🥱 Sem gracinha hoje.", "💤 Folga do sofrimento alheio.", "🫤 Hoje passou batido.", "🫥 Cota de cantada zerada.", "📉 Baixa produção de cantada hoje."]
      const frasesAltas = ["😏 Nível de safadeza crítico!", "🔥 Cantada não falta nessa aí!", "😈 O grupo já tá de olho!", "🏆 Campeã da zoeira safada!", "👑 Manda bem até de longe!", "💥 Ninguém segura essa lábia!", "🌶️ Tá pegando fogo por aqui!", "😮‍💨 O grupo ficou sem resposta!"]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('safada', LINK_FOTO)
      const texto = caixaArlequina("safada", `😏 *TESTE DE SAFADA* 😏\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO safada:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
