const { topAtivos } = require('../../arquivos/js/atividadeManager.js')
const { imagemFixaDoRank } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/3RjUxXBxd'

module.exports = {
  name: 'rankativo',
  description: 'Rank dos 10 membros mais ativos do grupo',
  category: 'brincadeiras',
  aliases: ['rankatividade', 'maisativos', 'topativo'],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankativo", `❌ Este comando só funciona em grupos.`))
    await reagir('📊')
    try {
      const top = topAtivos(from, 10)

      if (top.length === 0) {
        return reply('📊 Ainda não há dados de atividade nesse grupo. Comecem a interagir!')
      }

      function medalha(i) {
        if (i === 0) return '🥇'
        if (i === 1) return '🥈'
        if (i === 2) return '🥉'
        return `${i + 1}°`
      }

      const mentions = top.map(u => u.jid)

      let texto = `📊💜 *RANK DE ATIVOS DO GRUPO* 💜📊\n\n`

      top.forEach((u, i) => {
        texto += `${medalha(i)} @${u.jid.split('@')[0]}\n`
        texto += `💬 Msgs: *${u.msgs}*  |  🤖 Cmds: *${u.cmds}*  |  🎭 Stickers: *${u.stickers}*\n`
        texto += `📈 Total: *${u.total}*\n\n`
      })

      // Soma total geral
      const totalGeral = top.reduce((acc, u) => acc + u.total, 0)
      texto += `━━━━━━━━━━━━━━━━━━\n`
      texto += `📦 *Total de interações:* ${totalGeral}\n`
      texto += `💜 _Rank atualizado em tempo real_`

      const imgBuffer = await imagemFixaDoRank('rankativo', LINK_FOTO)
      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO rankativo:', e?.message)
      await reply('❌ Erro ao buscar dados de atividade.')
    }
  }
}
