const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'carinhoso',
  emoji: '🥰',
  titulo: 'É carinhoso(a)',
  frases: ["manda bom dia todo santo dia! 🌞", "abraço dele(a) resolve qualquer treta! 🤗", "é o colo que todo grupo precisa! 💜"]
})
