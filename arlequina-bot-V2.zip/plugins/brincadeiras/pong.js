const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'pong',
  description: 'Pong interativo',
  category: 'jogos',
  aliases: ['jogopong'],

  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🏓')
      const html = `<!DOCTYPE html>
<html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{background:#111;font-family:Arial,sans-serif;color:#0f0;padding:12px}
h1{text-align:center;font-size:18px;color:#0f0}
.sub{text-align:center;font-size:11px;opacity:.8;margin:4px 0 8px;color:#8f8}
#c{display:block;margin:0 auto;background:#000;border:2px solid #0f0;width:100%;max-width:340px;touch-action:none}
#sc{text-align:center;margin-top:8px;font-size:14px}
button{display:block;margin:10px auto;padding:10px 16px;border:1px solid #0f0;background:#000;color:#0f0;border-radius:6px;font-weight:bold}
</style></head><body>
<h1>🏓 PONG</h1>
<div class="sub">Arraste pra mover a barra</div>
<canvas id="c" width="320" height="220"></canvas>
<div id="sc">Você 0 × 0 CPU</div>
<button id="go">▶️ Jogar</button>
<script>
const cv=document.getElementById('c'),ctx=cv.getContext('2d');
let px,py,bx,by,bvx,bvy,cpu,ps,cs,run;
function reset(){
  px=130;py=200;cpu=130;bx=160;by=110;bvx=3*(Math.random()>.5?1:-1);bvy=2.5;ps=0;cs=0;run=true;
  document.getElementById('sc').textContent='Você 0 × 0 CPU';
}
function frame(){
  if(!run)return;
  bx+=bvx;by+=bvy;
  if(bx<6||bx>314)bvx*=-1;
  if(by<8){bvy*=-1}
  if(by>214){cs++;by=110;bx=160;bvy=-2.5;document.getElementById('sc').textContent='Você '+ps+' × '+cs+' CPU'}
  // player paddle
  if(by>py-6&&by<py+8&&bx>px&&bx<px+60){bvy=-Math.abs(bvy)-0.15;by=py-6}
  // cpu
  const target=bx-30;cpu+=(target-cpu)*0.08;
  if(by<18&&by>6&&bx>cpu&&bx<cpu+60){bvy=Math.abs(bvy)+0.1;by=18}
  if(ps>=5||cs>=5){run=false;document.getElementById('sc').textContent=(ps>cs?'🏆 Você ganhou! ':'💀 CPU ganhou! ')+ps+'×'+cs}
  // draw
  ctx.fillStyle='#000';ctx.fillRect(0,0,320,220);
  ctx.fillStyle='#0f0';
  ctx.fillRect(px,py,60,8);ctx.fillRect(cpu,8,60,8);
  ctx.beginPath();ctx.arc(bx,by,5,0,Math.PI*2);ctx.fill();
  requestAnimationFrame(frame);
}
function move(e){
  const r=cv.getBoundingClientRect();
  const t=e.touches?e.touches[0]:e;
  px=(t.clientX-r.left)*(320/r.width)-30;
  if(px<0)px=0;if(px>260)px=260;
}
cv.addEventListener('pointermove',move);cv.addEventListener('touchmove',move,{passive:true});
document.getElementById('go').onclick=()=>{reset();frame()};
reset();frame();
</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'pong-interativo',
        titulo: 'Pong',
        texto: '> Pong interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro pong:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
