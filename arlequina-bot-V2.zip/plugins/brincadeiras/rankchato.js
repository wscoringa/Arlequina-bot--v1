const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/2vDfxwCEm'

module.exports = {
  name: 'rankchato',
  description: 'RANK CHATO DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankchato", `❌ Este comando só funciona em grupos.`))
    await reagir('😤')
    try {
      await enviarRank(arlequina, from, info, 'RANK CHATO DO GRUPO', '😤', 'rankchato', 'Top 5 mais difíceis de lidar no grupo.', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankchato:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
