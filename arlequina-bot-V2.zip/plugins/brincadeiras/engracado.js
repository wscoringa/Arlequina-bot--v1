const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'engracado',
  emoji: '😂',
  titulo: 'É engraçado(a)',
  frases: ["é comediante nato, nem precisa tentar! 😂", "faz rir só de entrar na sala! 🎭", "tem piada pronta pra qualquer situação! 🃏"]
})
