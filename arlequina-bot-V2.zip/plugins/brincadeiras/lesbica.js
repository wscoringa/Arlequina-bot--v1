const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/7dkXcBtgv'

module.exports = {
  name: 'lesbica',
  description: 'TESTE LÉSBICA',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🌈')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["💅 Hétero por hoje.", "😤 Zero dúvidas.", "✊ Linha reta.", "🤷 Nada a declarar.", "📏 Tudo dentro da linha hoje.", "🤷 Sem novidade por aqui.", "😌 Nada a declarar mesmo."]
      const frasesAltas = ["🌈 100% confirmado!", "💅 Orgulho total!", "✨ Mais arco-íris impossível!", "👑 Rainha do grupo!", "🎊 Pride em tempo integral!", "💃 Arrasou com estilo!", "🎉 Brilho e confiança em dose extra!", "🌟 Autenticidade no talo!"]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('lesbica', LINK_FOTO)
      const texto = caixaArlequina("lesbica", `🌈 *TESTE LÉSBICA* 🌈\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO lesbica:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
