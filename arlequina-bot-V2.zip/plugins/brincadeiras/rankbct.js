const { enviarRank, imagemDeLink } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (recomendo uma bem safada)
const LINK_FOTO = 'https://i.ibb.co/3mSM7vpG/e860effb5cf99a87.jpg'

module.exports = {
  name: 'rankbct',
  description: 'RANK BCT +18 DO GRUPO',
  category: 'brincadeiras',
  aliases: ['rankbuceta', 'rankbct18', 'topbct'],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankbct", `❌ Este comando só funciona em grupos.`))
    
    await reagir('💦')

    try {
      await enviarRank(
        arlequina, 
        from, 
        info, 
        '🔥 RANK BCT +18 DO GRUPO 🔥', 
        '🐱', 
        'rankbct', 
        'As 5 bucetas mais molhadas e fodidas do grupo! 😈', 
        LINK_FOTO
      )
    } catch (e) {
      console.error('ERRO rankbct +18:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
