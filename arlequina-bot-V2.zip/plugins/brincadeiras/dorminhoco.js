const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/6yvN2Q67l'

module.exports = {
  name: 'dorminhoco',
  description: 'TESTE DE DORMINHOCO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('😴')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["⚡ Energia a mil hoje!", "☀️ Acordou cedinho.", "💪 Disposto e animado.", "🏃 Zero sono agora.", "🌟 Produtividade máxima.", "🐓 Acordou antes do galo.", "📅 Agenda cheia e cumprida.", "🚀 Decolou o dia logo cedo."]
      const frasesAltas = ["😴 Dormiu no grupo.", "💤 Ronco audível aqui.", "🛏️ Vive em pijama.", "🌙 Dorminhoco raiz!", "💀 Apagou em tempo recorde.", "⏰ O despertador desistiu.", "🛌 Travesseiro é seu melhor amigo.", "🌚 Perdeu o dia inteiro dormindo."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('dorminhoco', LINK_FOTO)
      const texto = caixaArlequina("dorminhoco", `😴 *TESTE DE DORMINHOCO* 😴\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO dorminhoco:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
