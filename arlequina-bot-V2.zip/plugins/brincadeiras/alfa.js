const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/5TyFJWZZS'

module.exports = {
  name: 'alfa',
  description: 'TESTE DE ALFA',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🐺')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["😅 Ainda tá treinando.", "🐺 Alfa em desenvolvimento.", "🤏 Falta presença.", "📉 Dominância baixa.", "🙈 Hoje não impressionou.", "😴 Energia de líder ausente.", "😬 Seguidor nato hoje.", "📵 Sem presença de líder.", "🐑 Mais ovelha que lobo."]
      const frasesAltas = ["🐺 Alfa supremo!", "👑 Nasceu líder!", "🔥 Presença intimidadora!", "💪 Dominância máxima!", "⚡ Todo mundo respeita!", "🚀 Nível alfa absurdo!", "🏆 Líder da matilha!", "🐺 Ninguém questiona essa liderança!", "🎯 Decide por todo mundo!", "🦁 Postura de rei da selva!"]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('alfa', LINK_FOTO)
      const texto = caixaArlequina("alfa", `🐺 *TESTE DE ALFA* 🐺\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO alfa:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
