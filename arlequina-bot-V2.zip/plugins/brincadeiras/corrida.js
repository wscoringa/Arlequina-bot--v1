const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'corrida',
  description: 'Corrida interativa',
  category: 'jogos',
  aliases: ['racing', 'jogocorrida'],

  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🏎️')
      const html = `<!DOCTYPE html>
<html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{background:#111;font-family:Arial,sans-serif;color:#fff;padding:10px;touch-action:none}
h1{text-align:center;font-size:18px}
.sub{text-align:center;font-size:11px;opacity:.8;margin:4px 0 8px}
canvas{display:block;width:100%;max-width:320px;margin:0 auto;background:#222;border-radius:10px;border:3px solid #444}
#hud{text-align:center;margin-top:8px;font-size:13px}
button{display:block;margin:10px auto;padding:10px 16px;border:0;border-radius:8px;background:#e67e22;color:#fff;font-weight:bold}
</style></head><body>
<h1>🏎️ CORRIDA</h1>
<div class="sub">Toque esquerda/direita pra desviar</div>
<canvas id="c" width="240" height="360"></canvas>
<div id="hud">Score: 0</div>
<button id="start">▶ Começar</button>
<script>
const cv=document.getElementById('c'),ctx=cv.getContext('2d');
let car={x:105,y:300,w:30,h:45},obs=[],score=0,speed=3,run=false,dead=false;
function reset(){car.x=105;obs=[];score=0;speed=3;dead=false;document.getElementById('hud').textContent='Score: 0'}
function spawn(){const lane=[30,105,180][Math.floor(Math.random()*3)];obs.push({x:lane,y:-50,w:30,h:45,c:'#'+Math.floor(Math.random()*0xffffff).toString(16).padStart(6,'0')})}
function frame(){
  if(!run)return;
  ctx.fillStyle='#2c3e50';ctx.fillRect(0,0,240,360);
  // road lines
  ctx.strokeStyle='#fff';ctx.lineWidth=3;ctx.setLineDash([15,15]);
  ctx.beginPath();ctx.moveTo(80,0);ctx.lineTo(80,360);ctx.moveTo(160,0);ctx.lineTo(160,360);ctx.stroke();ctx.setLineDash([]);
  if(Math.random()<0.03)spawn();
  for(let i=obs.length-1;i>=0;i--){
    const o=obs[i];o.y+=speed;ctx.fillStyle=o.c;ctx.fillRect(o.x,o.y,o.w,o.h);
    if(o.y>360){obs.splice(i,1);score++;speed=3+score*0.05;document.getElementById('hud').textContent='Score: '+score}
    if(o.x<car.x+car.w&&o.x+o.w>car.x&&o.y<car.y+car.h&&o.y+o.h>car.y){dead=true;run=false;document.getElementById('hud').textContent='💥 Score: '+score}
  }
  ctx.fillStyle='#3498db';ctx.fillRect(car.x,car.y,car.w,car.h);
  ctx.fillStyle='#fff';ctx.fillRect(car.x+5,car.y+8,8,8);ctx.fillRect(car.x+17,car.y+8,8,8);
  requestAnimationFrame(frame);
}
cv.addEventListener('pointerdown',e=>{
  const r=cv.getBoundingClientRect();
  const x=(e.clientX-r.left)*(240/r.width);
  if(x<120)car.x=Math.max(20,car.x-75);else car.x=Math.min(190,car.x+75);
});
document.getElementById('start').onclick=()=>{reset();run=true;frame()};
ctx.fillStyle='#2c3e50';ctx.fillRect(0,0,240,360);
ctx.fillStyle='#fff';ctx.font='14px Arial';ctx.textAlign='center';ctx.fillText('Toque ▶ Começar',120,180);
</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'corrida-interativo',
        titulo: 'CORRIDA',
        texto: '> CORRIDA interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro corrida:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
