const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'pegador',
  emoji: '😎',
  titulo: 'Tá no papel de "pegador(a)" hoje',
  frases: ["troca de crush mais rápido que troca de roupa! 😎", "tem admirador secreto até no delivery! 🍕", "arrasa corações e nem percebe! 💘"]
})
