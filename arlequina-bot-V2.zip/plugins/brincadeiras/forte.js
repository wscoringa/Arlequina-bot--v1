const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'forte',
  emoji: '💪',
  titulo: 'É forte',
  frases: ["levanta o dia com uma mão só! 💪", "é tipo aço puro, ninguém derruba! 🏋️", "carrega o grupo inteiro nas costas! 🦾"]
})
