const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'misterioso',
  emoji: '🕵️',
  titulo: 'É misterioso(a)',
  frases: ["ninguém sabe o que se passa na cabeça dele(a)! 🕵️", "aparece e some sem avisar! 🌙", "guarda segredo até de si mesmo(a)! 🤐"]
})
