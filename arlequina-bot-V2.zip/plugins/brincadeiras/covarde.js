const { criarTracoCard } = require('../../arquivos/js/tracoCard.js')

module.exports = criarTracoCard({
  name: 'covarde',
  emoji: '🐔',
  titulo: 'É covarde',
  frases: ["corre até de sombra! 🐔", "some quando a conta chega! 💸", "tem medo até do próprio grito! 😱"]
})
