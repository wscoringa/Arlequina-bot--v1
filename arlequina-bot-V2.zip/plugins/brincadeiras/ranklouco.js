const { enviarRank } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Mesmo link do comando base (louco.js)
const LINK_FOTO = 'https://pin.it/7pt3xLXf0'

module.exports = {
  name: 'ranklouco',
  description: 'RANK LOUCO DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("ranklouco", `❌ Este comando só funciona em grupos.`))
    await reagir('🤪')
    try {
      await enviarRank(arlequina, from, info, 'RANK LOUCO DO GRUPO', '🤪', 'ranklouco', 'Top 5 mais loucos do grupo!', LINK_FOTO)
    } catch (e) {
      console.error('ERRO ranklouco:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}