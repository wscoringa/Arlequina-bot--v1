const { enviarRank } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Mesmo link do comando base (carioca.js)
const LINK_FOTO = 'https://pin.it/6yfTxQ46o'

module.exports = {
  name: 'rankcarioca',
  description: 'RANK CARIOCA DO GRUPO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, isGroup }) {
    if (!isGroup) return reply(caixaArlequina("rankcarioca", `❌ Este comando só funciona em grupos.`))
    await reagir('🏖️')
    try {
      await enviarRank(arlequina, from, info, 'RANK CARIOCA DO GRUPO', '🏖️', 'rankcarioca', 'Top 5 mais carioca do grupo!', LINK_FOTO)
    } catch (e) {
      console.error('ERRO rankcarioca:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
