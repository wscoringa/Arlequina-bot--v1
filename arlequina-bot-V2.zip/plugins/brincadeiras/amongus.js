const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'amongus',
  description: 'Sorteia o impostor do grupo',
  category: 'brincadeiras',
  aliases: ['impostor', 'among'],
  async execute({ arlequina, from, info, reply, reagir, isGroup, groupMembers, sender }) {
    if (!isGroup) return reply(caixaArlequina('AMONGUS', '❌ Só funciona em grupo.'))
    await reagir('🔴')
    const membros = (groupMembers || []).map(m => m.id || m).filter(Boolean)
    if (membros.length < 2) return reply(caixaArlequina('AMONGUS', '❌ Precisa de mais membros no grupo.'))
    const impostor = membros[Math.floor(Math.random() * membros.length)]
    const texto = caixaArlequina('AMONGUS', `🔴 *AMONG US*\n\n🚨 Um impostor foi sorteado...\n\n🔪 @${String(impostor).split('@')[0]} é o *IMPOSTOR*!\n\n_Emergência chamada._`)
    await arlequina.sendMessage(from, { text: texto, mentions: [impostor] }, { quoted: info })
  }
}
