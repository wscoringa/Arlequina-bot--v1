const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/2MYyiGR6I'

module.exports = {
  name: 'gado',
  description: 'TESTE DE GADO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🐮')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["😎 Independente total!", "🦅 Não se apega não.", "💪 Orgulho preservado.", "✊ Não baba não.", "🔥 Postura de respeito.", "🧊 Sangue de gelo, zero apego.", "🚪 Sai de boa se não der certo.", "🦅 Voa livre sempre."]
      const frasesAltas = ["🐮 Gado raiz!", "💀 Baba até na foto de perfil.", "😭 Manda mensagem e fica esperando.", "🤦 Sem esperanças.", "😮‍💨 Nível gado extremo.", "📲 Responde em menos de 1 segundo.", "🎁 Já mandou presente sem ser pedido.", "🐾 Segue até o status apagado."]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('gado', LINK_FOTO)
      const texto = caixaArlequina("gado", `🐮 *TESTE DE GADO* 🐮\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO gado:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
