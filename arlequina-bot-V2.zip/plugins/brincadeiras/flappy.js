const { enviarJogoHtml } = require('../../arquivos/js/jogoHtml.js')

module.exports = {
  name: 'flappy',
  description: 'Flappy Bird interativo',
  category: 'jogos',
  aliases: ['passaro', 'flappybird'],

  async execute({ columbina, from, reagir, reply }) {
    try {
      await reagir('🐦')
      const html = `<!DOCTYPE html>
<html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{background:linear-gradient(#70c5ce,#ddeeff);font-family:Arial,sans-serif;color:#222;padding:12px}
h1{text-align:center;font-size:18px}
.sub{text-align:center;font-size:11px;margin:4px 0 8px}
#c{display:block;margin:0 auto;background:#70c5ce;border:3px solid #2d3436;border-radius:8px;width:100%;max-width:320px;touch-action:none}
#sc{text-align:center;margin-top:8px;font-weight:bold}
button{display:block;margin:10px auto;padding:12px 18px;border:0;border-radius:10px;background:#fdcb6e;font-weight:bold}
</style></head><body>
<h1>🐦 FLAPPY</h1>
<div class="sub">Toque na tela pra voar</div>
<canvas id="c" width="300" height="400"></canvas>
<div id="sc">Pontos: 0</div>
<button id="go">▶️ Jogar</button>
<script>
const cv=document.getElementById('c'),ctx=cv.getContext('2d');
let y,vy,pipes,score,run,frameN;
function reset(){y=200;vy=0;pipes=[];score=0;run=true;frameN=0;document.getElementById('sc').textContent='Pontos: 0'}
function addPipe(){const gap=90;const top=40+Math.random()*180;pipes.push({x:300,top,gap})}
function tick(){
  if(!run)return;
  frameN++;vy+=0.35;y+=vy;
  if(frameN%90===0)addPipe();
  pipes.forEach(p=>p.x-=2.2);
  pipes=pipes.filter(p=>p.x>-50);
  for(const p of pipes){
    if(p.x<44&&p.x>4){
      if(y<p.top||y>p.top+p.gap){run=false;document.getElementById('sc').textContent='💀 Fim! Pontos: '+score}
    }
    if(!p.passed&&p.x+40<20){p.passed=true;score++;document.getElementById('sc').textContent='Pontos: '+score}
  }
  if(y>390||y<0){run=false;document.getElementById('sc').textContent='💀 Fim! Pontos: '+score}
  ctx.fillStyle='#70c5ce';ctx.fillRect(0,0,300,400);
  ctx.fillStyle='#2ecc71';
  pipes.forEach(p=>{ctx.fillRect(p.x,0,40,p.top);ctx.fillRect(p.x,p.top+p.gap,40,400-(p.top+p.gap))});
  ctx.fillStyle='#f1c40f';ctx.beginPath();ctx.arc(30,y,12,0,Math.PI*2);ctx.fill();
  requestAnimationFrame(tick);
}
function flap(){if(run)vy=-5.5}
cv.addEventListener('pointerdown',flap);
document.getElementById('go').onclick=()=>{reset();tick()};
reset();tick();
</script></body></html>`
      await enviarJogoHtml(columbina, from, {
        id: 'flappy-interativo',
        titulo: 'Flappy',
        texto: '> Flappy interativo</>',
        html
      })
    } catch (e) {
      console.error('Erro flappy:', e?.message || e)
      await reply('Não foi possível abrir o jogo agora.')
    }
  }
}
