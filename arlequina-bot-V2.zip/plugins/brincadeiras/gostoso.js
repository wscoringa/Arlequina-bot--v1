const { imagemFixaDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Link da foto fixa desse comando (troque por outro link quando quiser)
const LINK_FOTO = 'https://pin.it/3RjUxXBxd'

module.exports = {
  name: 'gostoso',
  description: 'TESTE DE GOSTOSO',
  category: 'brincadeiras',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    if (!isGroup) return reply('❌ Este comando só funciona em grupos.')
    await reagir('🔥')
    try {
      const alvo = info.message?.extendedTextMessage?.contextInfo?.participant
              || info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
              || sender

      const pct = Math.floor(Math.random() * 101)
      const frasesBaixas = ["🥲 Hoje não tá rolando irmão...", "😅 Tá meio apagado.", "🙈 Beleza em modo econômico.", "🤏 Precisa dar uma turbinada.", "💀 O grupo não sentiu o impacto.", "😴 Dia fraco pra gostosura.", "🫤 Tá passando despercebido hoje.", "😶 Hoje passou batido.", "🫥 Charme tirou o dia de folga.", "📉 Pouco impacto no grupo hoje."]
      const frasesAltas = ["🔥 Tá destruindo no grupo!", "💪 Nível de gostosura insano!", "😈 O grupo notou sim!", "🏆 Campeão da gostosura hoje!", "👑 Não tem nem comparação!", "💥 Explodiu o medidor de atração!", "🌶️ Tá quente demais aqui!", "💪 Arrasou sem nem precisar tentar!", "🚨 Alerta de gostosura ativado!", "😮‍💨 O grupo ficou sem reação!"]
      const frase = pct <= 40
        ? frasesBaixas[Math.floor(Math.random() * frasesBaixas.length)]
        : frasesAltas[Math.floor(Math.random() * frasesAltas.length)]

      const imgBuffer = await imagemFixaDaBrincadeira('gostoso', LINK_FOTO)
      const texto = caixaArlequina("gostoso", `🔥 *TESTE DE GOSTOSO* 🔥\n\n👤 @${alvo.split('@')[0]}\n\n📊 Resultado: *${pct}%*\n\n${frase}`)

      if (imgBuffer) {
        await arlequina.sendMessage(from, { image: imgBuffer, caption: texto, mentions: [alvo] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [alvo] }, { quoted: info })
      }
    } catch (e) {
      console.error('ERRO gostoso:', e?.message)
      await reply('❌ Não consegui executar agora, tenta de novo.')
    }
  }
}
