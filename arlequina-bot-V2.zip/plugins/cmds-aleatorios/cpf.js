const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

// Valida só o algoritmo do CPF (dígito verificador) — não consulta
// nenhum órgão nem confirma se a pessoa existe, é só checagem matemática.
function cpfValido(cpf) {
  cpf = cpf.replace(/\D/g, '')
  if (cpf.length !== 11 || /^(\d)\1+$/.test(cpf)) return false
  let soma = 0, resto
  for (let i = 1; i <= 9; i++) soma += parseInt(cpf[i - 1]) * (11 - i)
  resto = (soma * 10) % 11
  if (resto === 10 || resto === 11) resto = 0
  if (resto !== parseInt(cpf[9])) return false
  soma = 0
  for (let i = 1; i <= 10; i++) soma += parseInt(cpf[i - 1]) * (12 - i)
  resto = (soma * 10) % 11
  if (resto === 10 || resto === 11) resto = 0
  return resto === parseInt(cpf[10])
}

module.exports = {
  name: 'cpf',
  description: '🪪 Valida o dígito verificador de um CPF (não consulta dados reais)',
  category: 'cmds-aleatorios',
  aliases: [],
  async execute({ args, reply, reagir, prefix }) {
    const cpf = (args[0] || '').replace(/\D/g, '')
    if (cpf.length !== 11) return reply(caixaArlequina('cpf', `❌ Digite os 11 números do CPF.\n💡 Ex: *${prefix}cpf* 12345678909`))
    await reagir('🪪')
    const valido = cpfValido(cpf)
    await reply(caixaArlequina('cpf', `🪪 CPF: ${cpf}\n\n${valido ? '✅ Dígito verificador válido (formato correto)' : '❌ Dígito verificador inválido'}\n\n⚠️ Isso só confere a matemática do número — não confirma se a pessoa existe de verdade.`))
  }
}
