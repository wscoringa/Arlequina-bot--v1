const fs = require('fs')
const path = require('path')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const CFG_PATH = path.join(__dirname, '../../arquivos/json/ffinfo_config.json')

function loadCfg() {
  try {
    if (fs.existsSync(CFG_PATH)) return JSON.parse(fs.readFileSync(CFG_PATH, 'utf8'))
  } catch (_) {}
  return null
}

function pick(obj, keys, fallback = '—') {
  if (!obj || typeof obj !== 'object') return fallback
  for (const k of keys) {
    const parts = k.split('.')
    let cur = obj
    for (const p of parts) {
      if (cur == null) { cur = undefined; break }
      cur = cur[p]
    }
    if (cur !== undefined && cur !== null && cur !== '') return cur
  }
  return fallback
}

async function tryUrl(url, headers = {}) {
  const res = await axios.get(url, {
    timeout: 14000,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ArlequinaBot/1.0',
      Accept: 'application/json',
      ...headers
    },
    validateStatus: s => s < 500
  })
  const d = res.data
  if (!d || typeof d !== 'object') return null
  if (d.error || d.status === 'error') return null
  // precisa ter pelo menos um campo de perfil
  const has =
    d.basicInfo || d.basicinfo || d.AccountInfo || d.nickname || d.data ||
    d.AccountName || d.player || d.result
  return has ? d : null
}

module.exports = {
  name: 'ffinfo',
  description: 'Puxa perfil do Free Fire pelo UID',
  category: 'ferramentas',
  aliases: ['ff', 'ffperfil', 'perfilff', 'idff'],

  async execute({ reply, reagir, prefix, args, q }) {
    const uid = (q || args[0] || '').replace(/\D/g, '')
    if (!uid || uid.length < 6) {
      return reply(caixaArlequina('FREE FIRE', `📌 *Uso:* ${prefix}ffinfo <UID>

Exemplo:
*${prefix}ffinfo 11386825555*`))
    }

    await reagir('🔍')

    let data = null
    let lastErr = ''

    // 1) Config do dono (recomendado)
    const cfg = loadCfg()
    if (cfg?.url) {
      try {
        const url = String(cfg.url).replace(/\{uid\}/gi, uid)
        data = await tryUrl(url, cfg.headers || {})
      } catch (e) {
        lastErr = e?.message || 'config falhou'
      }
    }

    // 2) Lista de endpoints públicos (mudam/caem com frequência)
    if (!data) {
      const endpoints = [
        `https://glob-info2.vercel.app/info?uid=${uid}`,
        `https://freefire-api-six.vercel.app/get_player_personal_show?server=br&uid=${uid}`,
        `https://freefire-api-six.vercel.app/get_player_personal_show?server=ind&uid=${uid}`,
        `https://freefireinfo-zy9l.onrender.com/api/v1/player-profile?uid=${uid}&server=BR`
      ]
      for (const url of endpoints) {
        try {
          data = await tryUrl(url)
          if (data) break
        } catch (e) {
          lastErr = e?.message || lastErr
        }
      }
    }

    if (!data) {
      await reagir('❌')
      return reply(caixaArlequina('FREE FIRE', `❌ Não consegui puxar o UID *${uid}*.

As APIs *públicas* de Free Fire estão instáveis/pagas agora.

💡 *Dono:* configure a sua API em:
\`arquivos/json/ffinfo_config.json\`

Exemplo:
\`\`\`json
{
  "url": "https://sua-api.vercel.app/info?uid={uid}",
  "headers": {}
}
\`\`\`

Repos públicos costumam precisar de deploy próprio (GitHub + Vercel).

_${lastErr || 'sem resposta útil'}_`))
    }

    const basic = data.basicInfo || data.basicinfo || data.AccountInfo || data.data?.basicInfo || data.data || data.player || data
    const nick = pick(basic, ['nickname', 'AccountName', 'name'], pick(data, ['nickname', 'PlayerNickname'], '—'))
    const level = pick(basic, ['level', 'AccountLevel', 'lvl'], '—')
    const likes = pick(basic, ['liked', 'AccountLikes', 'likes', 'Like'], '—')
    const region = pick(basic, ['region', 'AccountRegion', 'Region'], '—')
    const rank = pick(basic, ['rank', 'BrMaxRank', 'maxRank'], '—')
    const rankPts = pick(basic, ['rankingPoints', 'BrRankingPoints'], '')
    const exp = pick(basic, ['exp', 'AccountEXP'], '—')
    const createAt = pick(basic, ['createAt', 'AccountCreateTime'], '')
    const lastLogin = pick(basic, ['lastLoginAt', 'AccountLastLogin'], '')

    let criado = createAt
    if (createAt && /^\d+$/.test(String(createAt))) {
      try { criado = new Date(Number(createAt) * 1000).toLocaleDateString('pt-BR') } catch (_) {}
    }
    let login = lastLogin
    if (lastLogin && /^\d+$/.test(String(lastLogin))) {
      try { login = new Date(Number(lastLogin) * 1000).toLocaleString('pt-BR') } catch (_) {}
    }

    await reagir('✅')
    return reply(caixaArlequina('FREE FIRE', `🎮 *Perfil Free Fire*

👤 Nick: *${nick}*
🆔 UID: *${uid}*
⭐ Level: *${level}*
❤️ Likes: *${likes}*
🌍 Região: *${region}*
🏆 Rank: *${rank}*${rankPts !== '—' && rankPts !== '' ? ` (${rankPts} pts)` : ''}
✨ EXP: *${exp}*
${criado && criado !== '—' ? `📅 Conta: *${criado}*\n` : ''}${login && login !== '—' ? `🕐 Último login: *${login}*` : ''}`.trim()))
  }
}
