/*
 Comando criado dinamicamente com !addcase por um dono da Arlequina.
 // ADDCASE_DINAMICO
*/
module.exports = {
name: "casetiktoksearchcasettstryconstaxiosrequireaxiosifqreturnreplyxsprefixcomandomcpozeawaitreagirconstdataresawaitaxiosgethttp9311510114515592apitiktoksearchparamsqapitokenpovoifresstatus",
description: "Comando criado com addcase",
category: 'cmds-aleatorios',
aliases: [],
async execute({ reply }) {
  return reply("| !res.resultado) {\nreturn reply('❌ *ɴᴇɴʜᴜᴍ ᴠɪ́ᴅᴇᴏ ᴇɴᴄᴏɴᴛʀᴀᴅᴏ*')\n}\nconst data = res.resultado\nawait RyuX.sendMessage(from, {\nvideo: {\nurl: data.video_hd || data.video\n},\ncaption:`\n📌 *ᴛɪ́ᴛᴜʟᴏ:* ${data.titulo || 'Sem título'}\n👤 *ᴀᴜᴛᴏʀ:* ${data.autor || 'Desconhecido'}\n🆔 *ᴜꜱᴜᴀʀɪᴏ:* @${data.usuario || '-'}\n⏱️ *ᴅᴜʀᴀᴄ̧ᴀ̃ᴏ:* ${data.duracao || 0}s`\n}, { quoted: info })\nawait reagir('✅')\n} catch (e) {\nconsole.log(e)\nawait reagir('❌')\nreply('❌ *ᴇʀʀᴏ ᴀᴏ ʙᴜsᴄᴀʀ ᴠɪ́ᴅᴇᴏ*')\n}\n}\nbreak//✧･ﾟ: ᴅᴇᴠʟᴀʙ ✧･ﾟ:")
}
}
