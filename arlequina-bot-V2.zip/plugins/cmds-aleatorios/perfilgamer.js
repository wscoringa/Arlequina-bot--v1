const { criarPerfilCard } = require('../../arquivos/js/perfilCard.js')

module.exports = criarPerfilCard({
  name: 'perfilgamer',
  titulo: 'Perfil Gamer',
  emoji: '🎮',
  aliases: [],
  traços: [
    { emoji: '🏆', label: 'Rank', opcoes: ['Bronze Eterno', 'Prata com sorte', 'Ouro carregado', 'Desafiante de mentira', 'Master no papel'] },
    { emoji: '🎯', label: 'Especialidade', opcoes: ['Culpar o ping', 'Rage quit profissional', 'Carregar o time no chat', 'Trocar de personagem toda partida', 'Reportar todo mundo'] },
    { emoji: '🎧', label: 'Frase de call', opcoes: ['"Foi lag"', '"Vocês que jogam mal"', '"Só mais uma"', '"Já volto, mãe chamou"', '"Bugou, upa vídeo"'] },
    { emoji: '🕹️', label: 'Jogo favorito', opcoes: ['Aquele que sempre reclama', 'Só jogo ranqueada', 'Modo treino há 3 anos', 'Só assiste live', 'Instala e desinstala toda semana'] },
    { emoji: '⏰', label: 'Horário de pico', opcoes: ['3h da manhã', 'Hora da prova', 'Durante o trabalho', 'Bateria em 1%', 'Sempre'] }
  ]
})
