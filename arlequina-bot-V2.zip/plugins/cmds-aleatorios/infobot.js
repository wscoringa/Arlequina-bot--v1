/*
 Comando: infobot
 Aliases: botinfo, systeminfo, infosys

 Raio-X completo da Arlequina:
 comandos, aliases, uptime, Baileys, protocolo WA,
 Node, plataforma, CPU, memória, grupos, RPG,
 premium, aluguel, dono, prefixo, canal e status.
*/

const os = require('os')
const { fetchLatestBaileysVersion } = require('@itsliaaa/baileys')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const donoState = require('../../arquivos/js/donoState.js')
const { carregarUsuarios } = require('../../arquivos/js/rpgDB.js')

function formatarUptime(segundosTotais) {
  const d = Math.floor(segundosTotais / 86400)
  const h = Math.floor((segundosTotais % 86400) / 3600)
  const m = Math.floor((segundosTotais % 3600) / 60)
  const s = Math.floor(segundosTotais % 60)

  return [
    d > 0 ? `${d}d` : null,
    h > 0 ? `${h}h` : null,
    m > 0 ? `${m}m` : null,
    `${s}s`
  ].filter(Boolean).join(' ')
}

module.exports = {
  name: 'infobot',
  description: '📊 Mostra as informações completas do bot',
  category: 'cmds-aleatorios',
  aliases: ['botinfo', 'systeminfo', 'infosys'],

  async execute({
    arlequina,
    from,
    info,
    reply,
    reagir,
    config,
    prefix,
    commandManager
  }) {

    try {
      await reagir('📊')

      // ═══════════════════════════════
      // 🃏 COMANDOS
      // ═══════════════════════════════

      const todosComandos = commandManager.ObterTodosComandos()

      const comandosUnicos = todosComandos.filter(
        c => !c.isAlias
      )

      const totalAliases =
        todosComandos.length - comandosUnicos.length

      // ═══════════════════════════════
      // 📡 WHATSAPP / BAILEYS
      // ═══════════════════════════════

      let protocoloWA = 'desconhecido'

      try {
        const { version } = await fetchLatestBaileysVersion()

        protocoloWA = Array.isArray(version)
          ? version.join('.')
          : String(version)

      } catch (_) {}

      let versaoBaileys = 'desconhecida'

      try {
        versaoBaileys =
          require('@itsliaaa/baileys/package.json').version
      } catch (_) {}

      // ═══════════════════════════════
      // 🖥️ HARDWARE
      // ═══════════════════════════════

      const cpus = os.cpus() || []

      const cpuModelo =
        cpus[0]?.model?.trim() || 'desconhecida'

      const cpuNucleos = cpus.length

      const rssMB = (
        process.memoryUsage().rss /
        1024 /
        1024
      ).toFixed(1)

      const heapMB = (
        process.memoryUsage().heapUsed /
        1024 /
        1024
      ).toFixed(1)

      const ramTotalGB = (
        os.totalmem() /
        1024 /
        1024 /
        1024
      ).toFixed(1)

      const ramLivreGB = (
        os.freemem() /
        1024 /
        1024 /
        1024
      ).toFixed(1)

      // ═══════════════════════════════
      // 👥 DADOS DO BOT
      // ═══════════════════════════════

      let totalGrupos = 'N/A'

      try {
        const grupos =
          await arlequina.groupFetchAllParticipating()

        totalGrupos =
          Object.keys(grupos || {}).length

      } catch (_) {}

      let totalUsuariosRpg = 'N/A'

      try {
        totalUsuariosRpg =
          Object.keys(carregarUsuarios() || {}).length

      } catch (_) {}

      const totalPremium =
        commandManager.UsuariosPremium?.size ?? 'N/A'

      const totalAluguel =
        Object.keys(
          donoState.aluguel?.grupos || {}
        ).length

      // ═══════════════════════════════
      // 🤖 IDENTIDADE
      // ═══════════════════════════════

      let versaoBot = '2.0.0'

      try {
        versaoBot =
          require('../../package.json').version ||
          versaoBot
      } catch (_) {}

      const nomeBot =
        config?.NomeDoBot ||
        'Arlequina Bot'

      const canal =
        config?.canal ||
        'https://whatsapp.com/channel/0029VbDFppvCBtx6Qbn4nX1x'

      const numeroDono =
        (config?.NumeroDoDono || '')
          .toString()
          .replace(/\D/g, '')

      const status =
        donoState.botStatus?.ligado
          ? 'ONLINE 🟢'
          : 'OFFLINE 🔴'

      // ═══════════════════════════════
      // 🃏 MENSAGEM
      // ═══════════════════════════════

      const corpo = `

╭━━━ 🃏💜 *𝐀𝐑𝐋𝐄𝐐𝐔𝐈𝐍𝐀 𝐗 𝐎𝐅𝐈𝐂𝐈𝐀𝐋* 💜🃏 ━━━╮
┃
┃        🩸 *𝐒𝐘𝐒𝐓𝐄𝐌 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍* 🩸
┃
┃ 🃏 *𝐈𝐃𝐄𝐍𝐓𝐈𝐃𝐀𝐃𝐄*
┃
┃ 🤖 Bot: *${nomeBot}*
┃ 📦 Versão: *v${versaoBot}*
┃ ⚡ Status: *${status}*
┃ ⏱️ Uptime: *${formatarUptime(process.uptime())}*
┃
┃ ══════════════════════
┃
┃ 📜 *𝐀𝐑𝐒𝐄𝐍𝐀𝐋 𝐃𝐄 𝐂𝐎𝐌𝐀𝐍𝐃𝐎𝐒*
┃
┃ 🃏 Comandos: *${comandosUnicos.length}*
┃ 🔗 Aliases: *${totalAliases}*
┃ 💜 Total registrado: *${todosComandos.length}*
┃
┃ ══════════════════════
┃
┃ 🧠 *𝐍𝐔́𝐂𝐋𝐄𝐎 𝐃𝐎 𝐒𝐈𝐒𝐓𝐄𝐌𝐀*
┃
┃ 📚 Baileys: *v${versaoBaileys}*
┃ 📡 Protocolo WA: *${protocoloWA}*
┃ 🧠 Node.js: *${process.version}*
┃ 🖥️ Plataforma: *${process.platform}*
┃ 📱 Arquitetura: *${os.arch()}*
┃
┃ ══════════════════════
┃
┃ ⚙️ *𝐇𝐀𝐑𝐃𝐖𝐀𝐑𝐄*
┃
┃ 🖥️ CPU: *${cpuModelo}*
┃ 🔢 Núcleos: *${cpuNucleos}x*
┃ 💾 RSS: *${rssMB} MB*
┃ 📊 Heap: *${heapMB} MB*
┃ 🗄️ RAM: *${ramLivreGB}/${ramTotalGB} GB livre*
┃
┃ ══════════════════════
┃
┃ 👥 *𝐀𝐓𝐈𝐕𝐈𝐃𝐀𝐃𝐄 𝐃𝐀 𝐀𝐑𝐋𝐄𝐐𝐔𝐈𝐍𝐀*
┃
┃ 👥 Grupos: *${totalGrupos}*
┃ 🧑 Usuários RPG: *${totalUsuariosRpg}*
┃ 💎 Premium ativos: *${totalPremium}*
┃ 🎫 Grupos alugados: *${totalAluguel}*
┃
┃ ══════════════════════
┃
┃ 👑 *𝐂𝐎𝐍𝐓𝐑𝐎𝐋𝐄*
┃
┃ 👑 Dono: *wa.me/${numeroDono}*
┃ 🔣 Prefixo: *${prefix}*
┃ 📢 Canal: *ARLEQUINA OFICIAL*
┃
┃ ══════════════════════
┃
┃ 🃏💜 *𝐀𝐑𝐋𝐄𝐐𝐔𝐈𝐍𝐀 ✘ 𝐎𝐅𝐈𝐂𝐈𝐀𝐋*
┃
┃ 🩸 _Sistema ativo._
┃ 💜 _Todos os módulos em operação._
┃
╰━━━ 🃏💜 *𝐒𝐘𝐒𝐓𝐄𝐌 𝐎𝐍𝐋𝐈𝐍𝐄* 💜🃏 ━━━╯
`

      await reply(
        caixaArlequina('infobot', corpo)
      )

    } catch (e) {

      console.log(
        '❌ ERRO (infobot):',
        e?.message
      )

      await reply(
        '❌ Não consegui puxar as informações do bot agora.'
      )
    }
  }
}
