const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'totalcmds',
  description: 'Mostra quantos comandos o bot tem cadastrados, por categoria',
  category: 'cmds-aleatorios',
  aliases: ['totalcomandos', 'qtdcmds'],

  async execute({ arlequina, from, info, reply, commandManager }) {
    try {
      const todos = commandManager
        .ObterTodosComandos()
        .filter(c => !c.isAlias)

      const total = todos.length

      await arlequina.sendMessage(from, {
        text: `

╭━━━ 🃏💜 *𝐀𝐑𝐋𝐄𝐐𝐔𝐈𝐍𝐀* 💜🃏 ━━━╮
┃
┃        ✦ *𝐂𝐄𝐍𝐓𝐑𝐀𝐋 𝐃𝐎 𝐒𝐈𝐒𝐓𝐄𝐌𝐀* ✦
┃
┃  🩸 *𝐑𝐄𝐆𝐈𝐒𝐓𝐑𝐎 𝐃𝐄 𝐂𝐎𝐌𝐀𝐍𝐃𝐎𝐒*
┃
┃  ╭──────────────────╮
┃  │                  │
┃  │      🃏 *${total}* 🃏
┃  │    *COMANDOS ATIVOS*
┃  │                  │
┃  ╰──────────────────╯
┃
┃  💜 *MÓDULOS DISPONÍVEIS*
┃
┃  🎭 Diversão
┃  🛡️ Administração
┃  ⚔️ Proteção
┃  🎮 Jogos
┃  🐉 RPG
┃  ⚙️ Utilidades
┃  👑 Sistema do Dono
┃
┃  ──────────────────
┃
┃  ⚡ *STATUS:* ONLINE
┃  🃏 *SISTEMA:* OPERACIONAL
┃  💜 *VERSÃO:* OFICIAL
┃
┃  🩸 *ARLEQUINA ✘ OFICIAL*
┃  _O caos está apenas começando..._
┃
╰━━━ 🃏💜 *SYSTEM ONLINE* 💜🃏 ━━━╯
`
      }, { quoted: info })

    } catch (e) {
      console.log('❌ ERRO totalcmds:', e?.message)
      await reply(
        caixaArlequina(
          "totalcmds",
          `❌ Não consegui contar os comandos agora.`
        )
      )
    }
  }
}
