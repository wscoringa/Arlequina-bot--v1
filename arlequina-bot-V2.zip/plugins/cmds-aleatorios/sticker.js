/*
 Comando: sticker (aliases: s, fig, figurinha)

 BUGFIX: antes existiam DOIS arquivos de comando diferentes brigando
 pelos mesmos nomes/aliases (cmds-aleatorios/sticker.js e
 efeitos/s.js). O jeito que o bot carrega plugins faz o nome do
 arquivo mais recente sobrescrever o anterior, mas os ALIASES só
 registram se ainda não existir — resultado: "#sticker" e "#fig" iam
 pra um arquivo, e "#s" e "#figurinha" iam pro OUTRO arquivo, cada um
 com um limite de vídeo diferente (9s vs 13s) e formatação diferente.
 Pra quem usa o bot, parecia tudo "o mesmo comando de figurinha", mas
 se comportava diferente dependendo de qual palavra a pessoa digitava.

 Unifiquei em um arquivo só. Agora funciona com:
 - Imagem/vídeo marcado (respondendo com #sticker)
 - Imagem/vídeo mandado direto com a legenda "#sticker"
 - Vídeos de até 13 segundos
*/
const { sendImageAsSticker2, sendVideoAsSticker2 } = require('../../arquivos/js/exif2.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const { metaFigurinha } = require('../../arquivos/js/stickerMeta.js')

const MAX_SEGUNDOS_VIDEO = 13

// Desembrulha camadas que o WhatsApp/Baileys usam pra "empacotar" a
// mensagem de verdade: mensagem temporária (grupo com "mensagens
// temporárias" ativado) e view-once. Sem isso, uma foto mandada num
// grupo com esse recurso ligado "sumia" pro comando de figurinha,
// mesmo estando ali normalmente pra quem olha o WhatsApp.
function desembrulhar(msg) {
  let atual = msg
  let seguranca = 0
  while (atual && seguranca < 5) {
    if (atual.ephemeralMessage?.message) { atual = atual.ephemeralMessage.message; seguranca++; continue }
    if (atual.viewOnceMessageV2?.message) { atual = atual.viewOnceMessageV2.message; seguranca++; continue }
    if (atual.viewOnceMessageV2Extension?.message) { atual = atual.viewOnceMessageV2Extension.message; seguranca++; continue }
    if (atual.viewOnceMessage?.message) { atual = atual.viewOnceMessage.message; seguranca++; continue }
    if (atual.documentWithCaptionMessage?.message) { atual = atual.documentWithCaptionMessage.message; seguranca++; continue }
    break
  }
  return atual || {}
}

module.exports = {
  name: 'sticker',
  description: '🎭 Transforma imagem ou vídeo em figurinha',
  category: 'cmds-aleatorios',
  aliases: ['s', 'fig', 'figurinha'],
  async execute({ arlequina, from, info, reply, reagir, pushname, sender, groupName, config, getFileBuffer, prefix }) {
    try {
      if (!info || !info.message) {
        return reply('❌ Erro: mensagem não encontrada!')
      }

      const quotedMsg = desembrulhar(info.message?.extendedTextMessage?.contextInfo?.quotedMessage)
      const mensagemAtual = desembrulhar(info.message)

      // Aceita tanto mídia marcada/respondida quanto mandada direto com legenda
      const imagem =
        quotedMsg?.imageMessage ||
        mensagemAtual?.imageMessage

      const video =
        quotedMsg?.videoMessage ||
        mensagemAtual?.videoMessage

      // Alguns apps mandam foto/vídeo "disfarçado" de documento (pra não
      // perder qualidade). Se o documento for image/* ou video/*, trata
      // ele como se fosse a mídia normal.
      const documentoQuoted = quotedMsg?.documentMessage
      const documentoDireto = mensagemAtual?.documentMessage
      const imagemPorDocumento = documentoQuoted?.mimetype?.startsWith('image/') ? documentoQuoted
        : documentoDireto?.mimetype?.startsWith('image/') ? documentoDireto : null
      const videoPorDocumento = documentoQuoted?.mimetype?.startsWith('video/') ? documentoQuoted
        : documentoDireto?.mimetype?.startsWith('video/') ? documentoDireto : null

      const imagemFinal = imagem || imagemPorDocumento
      const videoFinal = video || videoPorDocumento

      if (!imagemFinal && !videoFinal) {
        return reply(caixaArlequina('sticker', `🎭 *Como usar:*\nMarque/responda uma foto ou vídeo com *${prefix}sticker*\nOu mande a foto/vídeo com a legenda *${prefix}sticker*\n\n💡 Vídeos: máximo ${MAX_SEGUNDOS_VIDEO} segundos`))
      }

      if (videoFinal && (videoFinal.seconds || 0) > MAX_SEGUNDOS_VIDEO) {
        return reply(`❌ Vídeo muito longo! Máximo *${MAX_SEGUNDOS_VIDEO} segundos*.`)
      }

      await reagir('🎭')

      const meta = metaFigurinha({ pushname, sender, groupName, config })

      if (videoFinal) {
        const tipoDownload = videoFinal === videoPorDocumento ? 'document' : 'video'
        const buffer = await getFileBuffer(videoFinal, tipoDownload)
        await sendVideoAsSticker2(arlequina, from, buffer, info, meta)
      } else {
        const tipoDownload = imagemFinal === imagemPorDocumento ? 'document' : 'image'
        const buffer = await getFileBuffer(imagemFinal, tipoDownload)
        await sendImageAsSticker2(arlequina, from, buffer, info, meta)
      }

      await reagir('✅')
    } catch (e) {
      console.error('❌ ERRO sticker:', e?.message)
      await reply(`❌ Erro ao criar figurinha: ${e?.message || 'tente com outra imagem/vídeo'}`)
    }
  }
}
