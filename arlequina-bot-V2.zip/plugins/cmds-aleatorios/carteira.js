/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: carteira
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'carteira',
description: "Veja sua carteira/saldo",
category: 'cmds-aleatorios',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  if (!usuarios[sender]) {
  usuarios[sender] = {
  saldo: 0,
  banco: 0,
  xp: 0,
  level: 1,
  nomeBanco: null,
  pix: null
  }
  }
  
  const saldo = usuarios[sender].saldo
  
  let frase = ''
  
  if (saldo < 1000)
  frase = '😅 Sua carteira está quase vazia.'
  
  else if (saldo < 50000)
  frase = '💵 Você tem um dinheiro legal para gastar.'
  
  else if (saldo < 500000)
  frase = '🤑 Sua carteira está bem recheada.'
  
  else
  frase = '💎 Você anda carregando uma fortuna no bolso!'
  
  await enviar({
  text: `
  ╭─━━─🃏💜「 👛 CARTEIRA 」💜🃏─━━─╮
  ┃ 💰 Dinheiro:
  ┃ R$ ${saldo.toLocaleString('pt-BR')}
  ╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
  
  ${frase}
  `
  }, { quoted: msg })
} catch (e) {
console.log('❌ ERRO (carteira):', e?.message)
await reply(caixaArlequina("carteira", `❌ Não consegui executar esse comando agora.`))
} finally {
salvarUsuarios(usuarios)
}

}
}
