/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: comprar
*/
const { carregarUsuarios, salvarUsuarios, getUsuario, ITENS_LOJA } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'comprar',
description: "Compra um item da loja",
category: 'cmds-aleatorios',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

// Antes o código usava uma variável "lojaRPG" que não existia em
// lugar nenhum (o comando dava erro toda vez que alguém comprava).
// Agora monta o lookup direto a partir do catálogo real da loja.
const lojaRPG = Object.fromEntries(ITENS_LOJA.map(i => [i.id, i]))

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const item = args[0]?.toLowerCase()
  
  if (!item || !lojaRPG[item]) {
  const listaItens = ITENS_LOJA.map(i => `• ${i.id} (${i.nome})`).join('\n')
  return enviar({
  text: `❌ Item inexistente.\n\n📦 *Itens disponíveis:*\n${listaItens}\n\nUse: ${prefix}comprar <id do item>`
  },{quoted:msg})
  }
  
  const preco = lojaRPG[item].preco
  
  if (usuarios[sender].saldo < preco) {
  return enviar({
  text:'💸 Saldo insuficiente.'
  },{quoted:msg})
  }
  
  usuarios[sender].saldo -= preco
  
  if (!usuarios[sender].inventario)
  usuarios[sender].inventario = []
  
  usuarios[sender].inventario.push(item)
  
  await enviar({
  text:`${caixaArlequina("comprar", `🛍️ COMPRA REALIZADA
  
  📦 Item:
  ${lojaRPG[item].nome}
  
  💰 Valor:
  R$ ${preco.toLocaleString('pt-BR')}`)}`
  },{quoted:msg})
} catch (e) {
console.log('❌ ERRO (comprar):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
