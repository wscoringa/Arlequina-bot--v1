const fs = require('fs')
const path = require('path')
const donoState = require('../../arquivos/js/donoState.js')
const { ehVip, msgSoVip } = require('../../arquivos/js/vipHelper.js')
const { caixaArlequina, caixaInfoUsuario, caixaMenuFancy } = require('../../arquivos/js/estiloArlequina')

// Pasta com todos os JSON +18 (um arquivo por categoria)
const PASTA_JSONS = path.join(__dirname, '../../arquivos/JSONS +18')

function listarCategorias() {
  try {
    if (!fs.existsSync(PASTA_JSONS)) return []
    return fs.readdirSync(PASTA_JSONS)
      .filter(f => f.toLowerCase().endsWith('.json'))
      .map(f => path.basename(f, '.json'))
      .sort((a, b) => a.localeCompare(b, 'pt-BR'))
  } catch (e) {
    return []
  }
}

function carregarCategoria(nome) {
  try {
    const arquivos = fs.readdirSync(PASTA_JSONS).filter(f => f.toLowerCase().endsWith('.json'))
    const arquivo = arquivos.find(f => path.basename(f, '.json').toLowerCase() === String(nome).toLowerCase())
    if (!arquivo) return null
    const data = JSON.parse(fs.readFileSync(path.join(PASTA_JSONS, arquivo), 'utf8'))
    return Array.isArray(data) ? data : null
  } catch (e) {
    return null
  }
}

function isVideo(url) {
  const u = (url || '').toLowerCase()
  return u.endsWith('.mp4') || u.endsWith('.webm') || u.endsWith('.mov') || u.includes('.mp4')
}

// Categorias disponíveis no momento do load (pra aliases)
const CATEGORIAS = listarCategorias()

// Aliases = todos os nomes das categorias (original + minúsculo) + alguns extras
const aliasesExtras = ['+18', 'nsfw', 'adulto', '18', 'menu+18']
const aliasesCategorias = []
for (const c of CATEGORIAS) {
  aliasesCategorias.push(c)
  const lower = c.toLowerCase()
  if (lower !== c) aliasesCategorias.push(lower)
}

// Aliases extras vindos de outros bots (mapeiam pro nome do JSON)
const ALIASES_MAP = {
  alifox: 'AlineFx',
  alinefx: 'AlineFx',
  amichan: 'Amiichan',
  amiichan: 'Amiichan',
  carnie: 'Carniello',
  carniello: 'Carniello',
  egirlvideo: 'EgirlVid',
  egirlvid: 'EgirlVid',
  porno: 'PornoVid',
  pornovid: 'PornoVid',
  only: 'Onlyfans',
  onlyfans: 'Onlyfans',
  princesa: 'Princesa',
  meladinha: 'Meladinha',
  gotica: 'Gotica',
  celestine: 'Celestine'
}
for (const a of Object.keys(ALIASES_MAP)) {
  aliasesCategorias.push(a)
}

module.exports = {
  name: 'menu18',
  description: 'Menu e comandos de conteúdo +18 (enviado no PV)',
  category: 'menu',
  aliases: [...new Set([...aliasesExtras, ...aliasesCategorias])],

  async execute(ctx) {
    const {
      arlequina, columbina, from, info, reply, reagir, prefix,
      q, args, command, sender, pushname, isGroup, isDono, isAdm, config
    } = ctx

    const conn = arlequina || columbina
    const categorias = listarCategorias()
    let cmd = (command || '').toString()

    // +18 só VIP (dono sempre conta como VIP)
    if (!ehVip(sender, isDono)) {
      return reply(caixaArlequina('MENU +18', msgSoVip(prefix)))
    }

    // Resolve aliases extras (alifox -> AlineFx etc)
    const ALIASES_MAP = {
      alifox: 'AlineFx', alinefx: 'AlineFx',
      amichan: 'Amiichan', amiichan: 'Amiichan',
      carnie: 'Carniello', carniello: 'Carniello',
      egirlvideo: 'EgirlVid', egirlvid: 'EgirlVid',
      porno: 'PornoVid', pornovid: 'PornoVid',
      only: 'Onlyfans', onlyfans: 'Onlyfans'
    }
    let cmdResolvido = ALIASES_MAP[cmd.toLowerCase()] || cmd

    // Se o comando digitado for uma categoria (ex: !Rute, !Aline)
    const ehCategoria = categorias.some(c => c.toLowerCase() === cmdResolvido.toLowerCase())
    if (ehCategoria) cmd = cmdResolvido

    try {
      // ═══════════════════════════════════════════════════
      // CASO 1: Comando de categoria direta (!Rute, !Aline...)
      // ═══════════════════════════════════════════════════
      if (ehCategoria) {
        // Verifica se modo18 está ativo no grupo (se for grupo)
        if (isGroup) {
          const ativo = !!(donoState.modo18Grupos && donoState.modo18Grupos[from])
          if (!ativo && !isDono()) {
            return reply(caixaArlequina('MENU +18', `🔞 O *modo +18* está desativado neste grupo.\n\nPeça pra um ADM usar:\n*${prefix}modo18 1*`))
          }
        }

        const itens = carregarCategoria(cmd)
        if (!itens || !itens.length) {
          return reply(caixaArlequina('MENU +18', `❌ Categoria *"${cmd}"* sem itens no momento.`))
        }

        await reagir('🔞')

        const link = itens[Math.floor(Math.random() * itens.length)]

        // Nomes do bot e do dono (puxados do config)
        const nomeBot = config?.NomeDoBot || 'Arlequina'
        const nomeDono = config?.NomeDoDono || 'coringa'

        // Frases aleatórias safadinhas (éticas o suficiente pra não passar do limite)
        const frases = [
          `Perfeita pro seu safadinho 😈`,
          `Olha essa delícia que eu separei pra você 🔥`,
          `Só pros olhos do safado 👀💜`,
          `Toma essa aí, safadinho 😏`,
          `Especialmente pra você, safado 🔞`,
          `Quente igual você gosta 🔥😈`,
          `Pro safadinho de plantão 💜`,
          `Essa aqui é pro seu prazer 😏`,
          `Direto pro PV do safado 🔥`,
          `Olha o presente do safadinho 🎁🔞`,
          `Pra esquentar a noite 😈`,
          `Seu safadinho merece essa 💜`,
          `Só pra quem aguenta 🔥`,
          `Delícia liberada pro safado 😏`,
          `Com carinho da ${nomeBot} pro safadinho 🃏`
        ]
        const fraseAleatoria = frases[Math.floor(Math.random() * frases.length)]

        const caption = `╭─━━─🔞💜「 *${cmd.toUpperCase()}* 」💜🔞─━━─╮

${fraseAleatoria}

💜 Feito com carinho pela *${nomeBot}*
👑 Dono: *${nomeDono}*

⚠️ Conteúdo +18 • Apenas para maiores de idade

╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
      🃏 *${nomeBot}* 💜😈`


        // SEMPRE envia no PV da pessoa (como pedido)
        const destino = sender // PV do usuário que pediu

        try {
          if (isVideo(link)) {
            await conn.sendMessage(destino, {
              video: { url: link },
              caption: caption
            })
          } else {
            await conn.sendMessage(destino, {
              image: { url: link },
              caption: caption
            })
          }

          // Confirma no grupo com mensagem aleatória safadinha
          if (isGroup) {
            const msgsGrupo = [
              `Já tô enviando no seu privado, safadinha 😈💜`,
              `Olha o PV, safado… já mandei sua delícia 🔥`,
              `Chegando no seu privado agora, safadinho 😏`,
              `Mandei no PV, vai lá olhar seu presente 🔞💜`,
              `Já foi pro seu privado, safada 🔥`,
              `Seu conteúdo tá no PV, safadinho… corre lá 😈`,
              `Enviei no privado, vai ver o que te espera 💜😏`,
              `Tá no seu PV, safado. Aproveita 🔥`,
              `Já tô mandando no privado, safadinha 🃏💜`,
              `Olha o privado, delícia liberada 😈`,
              `Foi pro seu PV agora mesmo, safadinho 🔥`,
              `Chegou no privado, vai lá safado 💜`
            ]
            const msgGrupo = msgsGrupo[Math.floor(Math.random() * msgsGrupo.length)]
            try {
              await conn.sendMessage(from, {
                text: caixaArlequina('MENU +18', `${msgGrupo}\n\n📁 *${cmd}*\n👤 @${sender.split('@')[0]}`),
                mentions: [sender]
              }, { quoted: info })
            } catch (_) {}
          }
          await reagir('✅')
        } catch (errEnvio) {
          console.error('Erro ao enviar +18 no PV:', errEnvio?.message)
          // Fallback: tenta mandar no chat atual se PV falhar (ex: usuário não tem conversa aberta)
          try {
            if (isVideo(link)) {
              await conn.sendMessage(from, { video: { url: link }, caption }, { quoted: info })
            } else {
              await conn.sendMessage(from, { image: { url: link }, caption }, { quoted: info })
            }
            await reagir('✅')
          } catch (e2) {
            await reagir('❌')
            return reply(caixaArlequina('MENU +18', `❌ Não consegui enviar a mídia.\nTente novamente ou abra o PV comigo primeiro.\n\n_${errEnvio?.message || 'erro'}_`))
          }
        }
        return
      }

      // ═══════════════════════════════════════════════════
      // CASO 2: menu18 (com ou sem argumento de categoria)
      // ═══════════════════════════════════════════════════
      if (!categorias.length) {
        return reply(caixaArlequina('MENU +18', '❌ Nenhum JSON encontrado na pasta *arquivos/JSONS +18*.'))
      }

      const escolha = (q || args.join(' ') || '').trim()

      // Se passou argumento (menu18 Aline), trata como categoria
      if (escolha) {
        // Reutiliza a lógica acima setando command temporariamente
        ctx.command = escolha
        return module.exports.execute(ctx)
      }

      // Sem argumento → mostra o menu fancy estilo Admin
      await reagir('🔞')

      const p = prefix
      // Monta seções estilo Admin (pode dividir se quiser, aqui uma seção grande)
      const secoes = [
        {
          nome: 'CATEGORIAS REAL +18',
          comandos: categorias.map(c => `${p}${c}`)
        },
        {
          nome: 'HENTAI',
          comandos: [
            `${p}hentai`, `${p}hentai2`, `${p}hentai3`, `${p}neko`, `${p}neko2`,
            `${p}ass`, `${p}boobs`, `${p}pussy`, `${p}blowjob`, `${p}bdsm`,
            `${p}yuri`, `${p}trap`, `${p}waifu`, `${p}ero`, `${p}orgy`,
            `${p}gangbang`, `${p}masturbation`, `${p}shotas`, `${p}zettai`,
            `${p}foto18`, `${p}glasses`, `${p}jahy`, `${p}manga`
          ]
        },
        {
          nome: 'YAOI',
          comandos: [
            `${p}gojoyaoi`, `${p}narutoyaoi`, `${p}sasukeyaoi`, `${p}kakashiyaoi`,
            `${p}luffyyaoi`, `${p}gokuyaoi`, `${p}vegetayaoi`, `${p}saitamayaoi`,
            `${p}tanjiroyaoi`, `${p}todorokiyaoi`, `${p}jirayayaoi`
          ]
        },
        {
          nome: 'PLAQUINHAS',
          comandos: [
            `${p}plaq1 <texto>`, `${p}plaq2 <texto>`, `${p}plaq3 <texto>`,
            `${p}plaq4 <texto>`, `${p}plaq5 <texto>`, `${p}plaq6 <texto>`,
            `${p}plaq7 <texto>`, `${p}plaq8 <texto>`, `${p}plaq9 <texto>`
          ]
        },
        {
          nome: 'COMANDOS',
          comandos: [
            `${p}menu18 — Abre este menu`,
            `${p}vx [1-5] — Vídeos +18 no PV`,
            `${p}addxv Nome link — Dono: add foto/vídeo`,
            `${p}delxv Nome — Dono: remove item`,
            `${p}xvideos [1-5] — Alias do vx`,
            `${p}modo18 1 — Ativa modo +18 (só ADM)`,
            `💎 Comandos +18: *somente VIP* (dono sempre VIP)`,
            `${p}modo18 0 — Desativa modo +18 (só ADM)`
          ]
        }
      ]

      const infoBox = caixaInfoUsuario({
        nomeBot: config?.NomeDoBot || 'Arlequina 💜',
        numeroUsuario: String(sender || '').split('@')[0],
        nomeDono: config?.NomeDoDono || 'coringa 🃏',
        cargo: isDono() ? 'Dono 🃏' : (isAdm ? 'Administrador 🛡️' : 'Membro'),
        vip: ehVip(sender, isDono) ? 'Sim 💎' : 'Não'
      })

      const menuTexto = `${infoBox}
╎
${caixaMenuFancy('MENU +18', secoes)}

⚠️ *Conteúdo apenas para maiores de 18 anos.*
📬 Os conteúdos são enviados no *seu privado*.`

      const imageUrl = path.join(__dirname, '../../arquivos/imagem/menu.jpg')
      try {
        if (fs.existsSync(imageUrl)) {
          await conn.sendMessage(from, {
            image: fs.readFileSync(imageUrl),
            caption: menuTexto,
            mentions: [sender]
          }, { quoted: info })
        } else {
          await conn.sendMessage(from, {
            text: menuTexto,
            mentions: [sender]
          }, { quoted: info })
        }
      } catch (e) {
        console.log('❌ ERRO menu18:', e?.message)
        await reply(menuTexto)
      }
    } catch (e) {
      console.error('Erro menu18:', e?.message || e)
      await reagir('❌')
      return reply(caixaArlequina('MENU +18', `❌ Erro interno.\n_${e?.message || 'desconhecido'}_`))
    }
  }
}
