const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
module.exports = {
  name: 'meuprefixo',
  description: 'Mostra o prefixo atual do bot',
  category: 'cmds-aleatorios',
  aliases: ['prefixo', 'prefix'],
  async execute({ arlequina, from, info, prefix, reply }) {
    try {
      const prefixAtual = prefix || '(sem prefixo — use só o nome do comando)'
      await arlequina.sendMessage(from, {
        text: `╭─━━─🃏💜「 🃏 愛ＡＲＬＥＱＵＩＮＡ 」💜🃏─━━─╮
┃ 💜 Esse é o meu prefixo atual:
┃ ➜ 「 ${prefixAtual} 」
┃
┃ ⚠️ Não esqueça! Use meu prefixo
┃ antes de cada comando.
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯`
      }, { quoted: info })
    } catch (e) {
      await reply(`${caixaArlequina("meuprefixo", `💜 Prefixo atual: *${prefix || 'nenhum'}*`)}`)
    }
  }
}
