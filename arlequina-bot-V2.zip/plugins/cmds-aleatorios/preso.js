/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: preso
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'preso',
description: "Veja se está preso",
category: 'cmds-aleatorios',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  if (
  !ehDonoReal(jid, sender, jidReal, numeroReal) &&
  !usuarios[sender]?.policial
  ) {
  return enviar({
  text: '❌ Apenas policiais ou donos podem usar este comando.'
  }, { quoted: msg })
  }
  
  const alvo =
  msg.message?.extendedTextMessage?.contextInfo?.participant ||
  msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
  
  if (!alvo) {
  return enviar({
  text: '❌ Marque uma pessoa.\n\nExemplo:\n!preso @membro 30s'
  }, { quoted: msg })
  }
  
  // Proteção contra prender dono
  if (ehDono(alvo, alvo.split('@')[0])) {
  return enviar({
  text: '👑 Você não pode prender meu dono, seu arrombado!'
  }, { quoted: msg })
  }
  
  const tempoTexto = args[1] || '1h'
  
  const numeroTempo = parseInt(tempoTexto)
  
  if (isNaN(numeroTempo)) {
  return enviar({
  text: '❌ Tempo inválido.\n\nExemplo:\n!preso @membro 30s'
  }, { quoted: msg })
  }
  
  const unidade = tempoTexto.slice(-1).toLowerCase()
  
  let tempoMs = 0
  
  if (unidade === 's') {
  tempoMs = numeroTempo * 1000
  }
  else if (unidade === 'm') {
  tempoMs = numeroTempo * 60000
  }
  else if (unidade === 'h') {
  tempoMs = numeroTempo * 3600000
  }
  else {
  return enviar({
  text: `${caixaArlequina("preso", `❌ Use:
  
  !preso @membro 30s
  !preso @membro 50m
  !preso @membro 2h`)}`
  }, { quoted: msg })
  }
  
  if (!usuarios[alvo]) {
  usuarios[alvo] = {
  saldo: 0,
  banco: 0,
  xp: 0,
  level: 1,
  preso: false,
  tempoPreso: 0,
  presoPor: null,
  policial: false
  }
  }
  
  usuarios[alvo].preso = true
  usuarios[alvo].tempoPreso = Date.now() + tempoMs
  usuarios[alvo].presoPor = sender
  
  await enviar({
  text: `⛓️ PRISÃO EFETUADA
  
  🚔 Policial:
  @${sender.split('@')[0]}
  
  👤 Preso:
  @${alvo.split('@')[0]}
  
  ⏳ Pena:
  ${numeroTempo}${unidade}
  
  ❌ O preso só poderá usar:
  🏃 !fugir
  📜 !pena`,
  mentions: [sender, alvo]
  }, { quoted: msg })
} catch (e) {
console.log('❌ ERRO (preso):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
