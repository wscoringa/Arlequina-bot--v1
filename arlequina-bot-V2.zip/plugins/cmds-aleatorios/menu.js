const fs = require('fs')
const path = require('path')
const { prepareWAMessageMedia, generateWAMessageFromContent, generateMessageIDV2, isJidGroup } = require('@whiskeysockets/baileys')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const donoState = require('../../arquivos/js/donoState.js')

// Node extra que avisa o servidor do WhatsApp que essa mensagem tem um
// "native flow" de verdade (botão/lista). Sem isso, o WhatsApp aceita a
// mensagem só com o texto e ignora completamente a parte interativa.
function nodeDoBotao(jid) {
  const node = {
    tag: 'biz',
    attrs: {},
    content: [{
      tag: 'interactive',
      attrs: { type: 'native_flow', v: '1' },
      content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }]
    }]
  }
  const nodes = [node]
  if (!isJidGroup(jid)) nodes.push({ tag: 'bot', attrs: { biz_bot: '1' } })
  return nodes
}

module.exports = {
name: 'menu',
description: 'Mostra o menu de comandos',
category: 'cmds-aleatorios',
aliases: ['comandos','help'],
async execute({ columbina, arlequina, from, info, prefix, reply, reagir, pushname, sender, isGroup, config }) {
try {

await reagir("🃏")

const conn = columbina || arlequina

// Se existir um arquivo menu.mp4 na pasta, usa vídeo no menu. Senão, usa a
// imagem menu.jpg de sempre. É só colocar o arquivo lá que o bot já pega.
const caminhoVideo = path.join(__dirname,'../../arquivos/imagem/menu.mp4')
const caminhoImagem = path.join(__dirname,'../../arquivos/imagem/menu.jpg')
let tipoMidia = null
let bufferMenu = null
if (fs.existsSync(caminhoVideo)) {
  tipoMidia = 'video'
  bufferMenu = fs.readFileSync(caminhoVideo)
} else if (fs.existsSync(caminhoImagem)) {
  tipoMidia = 'image'
  bufferMenu = fs.readFileSync(caminhoImagem)
}

const canal = config?.canal || 'https://whatsapp.com/channel/0029VbDFppvCBtx6Qbn4nX1x'
const criador = 'https://www.instagram.com/pv_wyllyam_06?igsh=NjltZXA5d3hwbHU2'

let versaoBot = '2.0.0'
try { versaoBot = require('../../package.json').version || versaoBot } catch (_) {}

const menuTxt = `
💜─🃏─💜─🃏─💜

『 ARLEQUINA BOT 』

💜─🃏─💜─🃏─💜
    》Arlequina Bot《
💜━─━─━─💜─━─━─━─💜
│💜╭─🃏༺ARLEQUINA༻🃏─╮
│💜│ Bot: Arlequina Bot
│💜│ Versão: v${versaoBot}
│💜│ User:[${pushname}]
│💜│ Numero: ${sender.split("@")[0]}
│💜│ Grupo: ${isGroup ? 'Sim✅' : 'Não❌'}
│💜│ Status: Online🟢
│💜╰─🃏༺ARLEQUINA༻🃏─╯
💜━─━─━─💜─━─━─━─💜

© Arlequina Bot v${versaoBot}`

const listaCompleta = `${menuTxt}

*Digite o comando pra abrir cada menu:*

🛡️ ${prefix}menuadm — Admin
📋 ${prefix}menucmds — Comandos gerais
👑${prefix}menudono — Dono
⬇️ ${prefix}menudownloads — Downloads
🎨 ${prefix}menuefeitos — Efeitos
🤖${prefix}menuia — Inteligência artificial
🎬 ${prefix}menumidias — Mídias
🎭 ${prefix}menubrincadeira — Brincadeiras
🧠 ${prefix}menuquiz — Quiz & jogos
💞 ${prefix}menusocial — Social & interação
🛠️ ${prefix}menuferramentas — Ferramentas
🔍 ${prefix}menupesquisas — Pesquisas
💎 ${prefix}menupremium — Premium
⚔️ ${prefix}menurpg — RPG
🔞 ${prefix}menu18 — Conteúdo +18

🎫 Planos de aluguel: ${prefix}planoaluguel (semanal/mensal/vitalicio)
📶 ${prefix}ping — Latência do bot

📢 Canal: ${canal}
🃏 Criador: ${criador}`

try {
  // Se o dono desligou os botões (!menubotoes off), pula direto pro
  // fallback de imagem/vídeo + texto — nem tenta o menu interativo.
  if (!donoState.menuBotoesOn) throw new Error('botoes_desligados_manual')

  // Se o arquivo salvo por !videomenu for um GIF (vídeo com gifPlayback),
  // manda essa flag junto pra o WhatsApp exibir como GIF de verdade.
  const ehGifMenu = tipoMidia === 'video' && !!donoState.menuGifPlayback

  const mediaMenu = bufferMenu ? await prepareWAMessageMedia(
    tipoMidia === 'video' ? { video: bufferMenu, gifPlayback: ehGifMenu } : { [tipoMidia]: bufferMenu },
    { upload: conn.waUploadToServer }
  ) : null

  const conteudoMensagem = {
    interactiveMessage: {
      contextInfo: {
        stanzaId: info.key.id,
        participant: info.key.participant || info.key.remoteJid,
        quotedMessage: info.message,
        mentionedJid: [sender]
      },
      header: {
        hasMediaAttachment: !!mediaMenu,
        imageMessage: (mediaMenu && tipoMidia === 'image') ? mediaMenu.imageMessage : undefined,
        videoMessage: (mediaMenu && tipoMidia === 'video') ? mediaMenu.videoMessage : undefined
      },
      body: { text: menuTxt },
      footer: { text: '© Arlequina Bot' },
      nativeFlowMessage: {
        buttons: [{
          name: 'cta_url',
          buttonParamsJson: JSON.stringify({
            display_text: '📢💜 VER CANAL 💜📢',
            url: canal,
            merchant_url: canal
          })
        },{
          name: 'cta_url',
          buttonParamsJson: JSON.stringify({
            display_text: '🃏💜 CRIADOR 💜🃏',
            url: criador,
            merchant_url: criador
          })
        },{
          name: 'single_select',
          buttonParamsJson: JSON.stringify({
            title: '💜🃏 MENU LISTA 💜',
            sections: [{
              title: 'Escolha uma opção',
              rows: [
                { header: '', title: '🛡️ Admin', description: 'Comandos apenas para administradores', id: `${prefix}menuadm` },
                { header: '', title: '📋 Comandos', description: 'Comandos aleatórios', id: `${prefix}menucmds` },
                { header: '', title: '👑 Dono', description: 'Comandos do dono da bot', id: `${prefix}menudono` },
                { header: '', title: '⬇️ Downloads', description: 'Comandos de downloads', id: `${prefix}menudownloads` },
                { header: '', title: '🎨 Efeitos', description: 'Efeitos de img e áudio', id: `${prefix}menuefeitos` },
                { header: '', title: '🤖 IA', description: 'Inteligência artificial', id: `${prefix}menuia` },
                { header: '', title: '🎬 Mídias', description: 'Mídias da bot', id: `${prefix}menumidias` },
                { header: '', title: '🎭 Brincadeiras', description: 'Etiquetas, ações e zoeira', id: `${prefix}menubrincadeira` },
                { header: '', title: '🧠 Quiz & Jogos', description: 'Quiz, forca, charadas e adivinha', id: `${prefix}menuquiz` },
                { header: '', title: '💞 Social', description: 'Relacionamentos e interação', id: `${prefix}menusocial` },
                { header: '', title: '🛠️ Ferramentas', description: 'Consultas, calculadoras e utilitários', id: `${prefix}menuferramentas` },
                { header: '', title: '🔍 Pesquisas', description: 'Deezer, TikTok, Wikipedia, anime e mais', id: `${prefix}menupesquisas` },
                { header: '', title: '💎 Premium', description: 'Comandos premium', id: `${prefix}menupremium` },
                { header: '', title: '⚔️ RPG', description: 'RPG completo da bot', id: `${prefix}menurpg` },
                { header: '', title: '🔞 +18', description: 'Conteúdo adulto (+18)', id: `${prefix}menu18` }
              ]
            },{
              title: '🎫 ALUGUEL DO BOT',
              rows: [
                { header: '', title: '📅 Semanal', description: 'Aluguel do bot por 7 dias', id: `${prefix}planoaluguel semanal` },
                { header: '', title: '📆 Mensal', description: 'Aluguel do bot por 30 dias', id: `${prefix}planoaluguel mensal` },
                { header: '', title: '✨ Vitalício', description: 'Acesso vitalício ao bot', id: `${prefix}planoaluguel vitalicio` }
              ]
            },{
              title: 'Utilidades',
              rows: [
                { header: '', title: '📶 Ping', description: 'Verificar latência do bot', id: `${prefix}ping` }
              ]
            }]
          })
        }]
      }
    }
  }

  const msgGerada = generateWAMessageFromContent(from, conteudoMensagem, {
    userJid: conn.user.id,
    messageId: generateMessageIDV2(conn.user.id)
  })

  await conn.relayMessage(from, msgGerada.message, {
    messageId: msgGerada.key.id,
    additionalNodes: nodeDoBotao(from)
  })
} catch (eBotao) {
  // Se o botão não for aceito nessa conta (ou tiver sido desligado manualmente
  // com !menubotoes off), cai pro texto completo — assim nunca fica sem resposta.
  if (eBotao?.message !== 'botoes_desligados_manual') {
    console.log('[menu] botão falhou, caindo pro texto:', eBotao?.message)
  }
  if (bufferMenu && tipoMidia === 'video') {
    await conn.sendMessage(from, { video: bufferMenu, gifPlayback: ehGifMenu, caption: listaCompleta, mentions: [sender] })
  } else if (bufferMenu && tipoMidia === 'image') {
    await conn.sendMessage(from, { image: bufferMenu, caption: listaCompleta, mentions: [sender] })
  } else {
    await conn.sendMessage(from, { text: listaCompleta, mentions: [sender] })
  }
}

} catch(e){
console.error(e)
await reply(caixaArlequina("menu", `Erro ao abrir o menu.`))
}
}
}
