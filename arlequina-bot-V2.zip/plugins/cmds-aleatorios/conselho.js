const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const CONSELHOS = [
  'Não deixe pra amanhã a paz que você pode fazer com alguém hoje.',
  'Quem cala nem sempre consente — às vezes só está escolhendo a paz.',
  'O tempo que você perde tentando mudar quem não quer mudar é tempo que você tira de quem já te ama do jeito certo.',
  'Ninguém é dono da verdade, mas todo mundo tem direito à própria versão dela.',
  'Cuide de quem cuida de você quando ninguém está olhando.',
  'A pressa é inimiga da perfeição, mas também é amiga de quem nunca começa.',
  'Errar faz parte — o problema é repetir o erro sabendo que é errado.',
  'Antes de julgar o passo de alguém, pergunte quantos tropeços vieram antes dele.',
  'Falar é fácil. Difícil é sustentar o que se fala com o que se faz.',
  'Descansar não é preguiça, é manutenção.',
  'Quem planta paciência colhe resultado — quem planta pressa colhe arrependimento.',
  'Nem toda batalha precisa ser vencida na hora — algumas só precisam ser sobrevividas.',
]

module.exports = {
  name: 'conselho',
  description: '💭 Um conselho aleatório',
  category: 'cmds-aleatorios',
  aliases: ['conselhos', 'conselhob'],
  async execute({ reply, reagir }) {
    await reagir('💭')
    const item = CONSELHOS[Math.floor(Math.random() * CONSELHOS.length)]
    await reply(caixaArlequina('conselho', `💭 *CONSELHO*\n\n"${item}"`))
  }
}
