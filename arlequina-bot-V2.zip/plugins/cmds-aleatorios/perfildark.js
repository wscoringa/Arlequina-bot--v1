const { criarPerfilCard } = require('../../arquivos/js/perfilCard.js')

module.exports = criarPerfilCard({
  name: 'perfildark',
  titulo: 'Perfil Sombrio',
  emoji: '🖤',
  aliases: [],
  traços: [
    { emoji: '🌑', label: 'Aura', opcoes: ['Trevas de Wi-Fi fraco', 'Sombra que trava no boleto', 'Caos organizado', 'Melancolia de segunda-feira', 'Vazio existencial passageiro'] },
    { emoji: '🕯️', label: 'Ritual noturno', opcoes: ['Rolar feed até 4h', 'Ouvir a mesma música 50x', 'Filosofar sobre a vida', 'Reler conversa antiga', 'Fingir que vai dormir cedo'] },
    { emoji: '⚔️', label: 'Arma sombria', opcoes: ['Indireta no status', 'Silêncio estratégico', 'Emoji de coração partido', 'Áudio de 10 segundos só suspirando', 'Print guardado pra usar depois'] },
    { emoji: '🩸', label: 'Fraqueza', opcoes: ['Luz do sol', 'Acordar cedo', 'Notificação de boleto', 'Pergunta "cadê você"', 'Chamada de vídeo surpresa'] },
    { emoji: '👑', label: 'Título das trevas', opcoes: ['Duque da Preguiça', 'Barão do Cancelamento', 'Conde do Textão', 'Senhor do Modo Avião', 'Imperador do Não Perturbe'] }
  ]
})
