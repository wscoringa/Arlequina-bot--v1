const axios = require('axios')
const donoState = require('../../arquivos/js/donoState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const { ehVip, msgSoVip } = require('../../arquivos/js/vipHelper.js')
const { API_URL, API_KEY } = require('../../arquivos/js/kimoriApi.js')

// Comandos que a API Kimori aceita
const KIMORI_HENTAI = [
  'ass', 'bdsm', 'blowjob', 'boobs', 'ganbganb', 'gangbang',
  'hentai', 'kasedaiki', 'masturbation', 'neko2', 'neko',
  'pussy', 'shotas', 'trap', 'yuri', 'zettai'
]

const YAOI = [
  'gojoyaoi', 'narutoyaoi', 'kakashiyaoi', 'sasukeyaoi',
  'luffyyaoi', 'gokuyaoi', 'jirayayaoi', 'saitamayaoi',
  'tanjiroyaoi', 'todorokiyaoi', 'vegetayaoi'
]

// Extras do Sandro + nomes comuns → mapeados pra APIs públicas
const PUBLIC_MAP = {
  hentai2: 'hentai',
  hentai3: 'hentai',
  hentai4: 'hentai',
  ero: 'hentai',
  foto18: 'hentai',
  video18: 'hentai',
  glasses: 'hentai',
  orgy: 'hentai',
  jahy: 'waifu',
  waifu: 'waifu',
  foot: 'hentai',
  gif: 'hentai',
  manga: 'hentai',
  beijo: 'kiss'
}

const TODOS = [...new Set([
  ...KIMORI_HENTAI,
  ...YAOI,
  ...Object.keys(PUBLIC_MAP),
  'hentai', 'neko', 'waifu'
])]

async function buscarPublico(tipo) {
  // waifu.pics nsfw
  const waifuMap = {
    waifu: 'https://api.waifu.pics/nsfw/waifu',
    neko: 'https://api.waifu.pics/nsfw/neko',
    trap: 'https://api.waifu.pics/nsfw/trap',
    blowjob: 'https://api.waifu.pics/nsfw/blowjob'
  }
  if (waifuMap[tipo]) {
    const r = await axios.get(waifuMap[tipo], { timeout: 15000 })
    if (r.data?.url) return { url: r.data.url, isVideo: false }
  }

  // nekobot
  const nekoTypes = ['hentai', 'ass', 'boobs', 'pussy', 'thigh', 'pgif', 'gonewild']
  if (nekoTypes.includes(tipo) || tipo === 'hentai') {
    const t = nekoTypes.includes(tipo) ? tipo : 'hentai'
    const r = await axios.get(`https://nekobot.xyz/api/image?type=${t}`, { timeout: 15000 })
    if (r.data?.message) return { url: r.data.message, isVideo: (r.data.message || '').includes('.gif') || (r.data.message || '').includes('.mp4') }
  }

  return null
}

module.exports = {
  name: 'hentai',
  description: 'Comandos de hentai / nsfw (+18)',
  category: 'cmds-aleatorios',
  aliases: TODOS,

  async execute(ctx) {
    const {
      arlequina, columbina, from, info, reply, reagir, prefix,
      command, sender, isGroup, isDono, config
    } = ctx

    if (!ehVip(sender, isDono)) {
      return reply(caixaArlequina('HENTAI', msgSoVip(prefix)))
    }

    const conn = arlequina || columbina
    let cmd = (command || '').toLowerCase()

    // Resolve aliases
    if (PUBLIC_MAP[cmd]) cmd = PUBLIC_MAP[cmd]

    if (!TODOS.includes(command?.toLowerCase()) && !KIMORI_HENTAI.includes(cmd) && !YAOI.includes(cmd)) {
      return reply(caixaArlequina('HENTAI', `Use um dos comandos do *${prefix}menu18*`))
    }

    if (isGroup) {
      const ativo = !!(donoState.modo18Grupos && donoState.modo18Grupos[from])
      if (!ativo && !isDono()) {
        return reply(caixaArlequina('HENTAI', `🔞 O *modo +18* está desativado neste grupo.\n\nPeça pra um ADM usar:\n*${prefix}modo18 1*`))
      }
    }

    await reagir('🔞')

    const nomeBot = config?.NomeDoBot || 'Arlequina'
    const nomeDono = config?.NomeDoDono || 'coringa'

    const frases = [
      `Perfeita pro seu safadinho 😈`,
      `Olha essa delícia hentai 🔥`,
      `Só pros olhos do safado 👀💜`,
      `Toma essa aí, safadinho 😏`,
      `Quente igual você gosta 🔥😈`,
      `Pro safadinho de plantão 💜`,
      `Direto pro PV do safado 🔥`,
      `Pra esquentar a noite 😈`,
      `Delícia liberada pro safado 😏`,
      `Com carinho da ${nomeBot} pro safadinho 🃏`
    ]
    const fraseAleatoria = frases[Math.floor(Math.random() * frases.length)]

    const caption = `╭─━━─🔞💜「 *${(command || cmd).toUpperCase()}* 」💜🔞─━━─╮

${fraseAleatoria}

💜 Feito com carinho pela *${nomeBot}*
👑 Dono: *${nomeDono}*

⚠️ Conteúdo +18 • Apenas para maiores de idade

╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
      🃏 *${nomeBot}* 💜😈`

    // Mensagem no grupo
    if (isGroup) {
      const msgsGrupo = [
        `Já tô enviando no seu privado, safadinha 😈💜`,
        `Olha o PV, safado… já mandei sua delícia 🔥`,
        `Chegando no seu privado agora, safadinho 😏`,
        `Mandei no PV, vai lá olhar seu presente 🔞💜`,
        `Já foi pro seu privado, safada 🔥`,
        `Seu conteúdo tá no PV, safadinho… corre lá 😈`
      ]
      try {
        await conn.sendMessage(from, {
          text: caixaArlequina('HENTAI', `${msgsGrupo[Math.floor(Math.random()*msgsGrupo.length)]}\n\n📁 *${command || cmd}*\n👤 @${sender.split('@')[0]}`),
          mentions: [sender]
        }, { quoted: info })
      } catch (_) {}
    }

    let enviou = false

    // 1) Tenta API Kimori
    if (KIMORI_HENTAI.includes(cmd) || YAOI.includes(cmd)) {
      try {
        const url = `${API_URL}/api/hentai/${cmd}?apikey=${API_KEY}`
        const response = await axios.get(url, { responseType: 'arraybuffer', timeout: 20000 })
        const buffer = Buffer.from(response.data)
        const contentType = (response.headers['content-type'] || '').toLowerCase()
        if (buffer.length > 1000) {
          if (contentType.includes('video')) {
            await conn.sendMessage(sender, { video: buffer, caption, mimetype: 'video/mp4' })
          } else {
            await conn.sendMessage(sender, { image: buffer, caption })
          }
          enviou = true
        }
      } catch (_) {}
    }

    // 2) Fallback APIs públicas
    if (!enviou) {
      try {
        const pub = await buscarPublico(cmd)
        if (pub?.url) {
          if (pub.isVideo) {
            await conn.sendMessage(sender, { video: { url: pub.url }, caption })
          } else {
            await conn.sendMessage(sender, { image: { url: pub.url }, caption })
          }
          enviou = true
        }
      } catch (_) {}
    }

    if (enviou) {
      await reagir('✅')
    } else {
      await reagir('❌')
      return reply(caixaArlequina('HENTAI', `❌ Não consegui buscar o conteúdo agora.\nTente outro comando ou mais tarde.`))
    }
  }
}
