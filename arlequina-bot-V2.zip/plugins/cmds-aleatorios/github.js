const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const REPO = 'https://github.com/wscoringa/Arlequina-bot--v1'

module.exports = {
  name: 'github',
  description: 'Link oficial do bot no GitHub (só dono)',
  category: 'dono',
  aliases: ['git', 'repo', 'repositorio', 'sc', 'script'],

  async execute({ reply, reagir, prefix, isDono }) {
    if (!isDono()) {
      return reply(caixaArlequina('GITHUB', '❌ Só o *dono* pode usar este comando.'))
    }
    await reagir('🐙')
    return reply(caixaArlequina('GITHUB', `🐙 *Arlequina Bot — GitHub*

🔗 ${REPO}

📥 Clonar:
git clone ${REPO}.git

🔄 Atualizar (se clonou com git):
*${prefix}gitpull*`))
  }
}
