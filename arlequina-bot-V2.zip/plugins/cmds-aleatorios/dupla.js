const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const { imagemDaBrincadeira } = require('../../arquivos/js/brincadeirasHelpers.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'dupla',
  description: 'Mostra seu status de casamento ou namoro',
  category: 'cmds-aleatorios',
  aliases: [],
  async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
    const usuarios = carregarUsuarios()
    const u = getUsuario(usuarios, sender)
    try {
      if (!u.casadoCom && !u.namorandoCom) {
        return reply(caixaArlequina("dupla", `💔 Você não é casado(a) nem está namorando com ninguém.`))
      }

      const ehCasamento = !!u.casadoCom
      const parceiro = ehCasamento ? u.casadoCom : u.namorandoCom
      const dataInicio = ehCasamento ? u.dataCasamento : u.dataNamoro
      const tempo = Math.floor((Date.now() - dataInicio) / 86400000)

      // BUGFIX: antes lia uma imagem fixa (midias/brincadeiras/casados.jpg)
      // que não existe no servidor — o comando quebrava sempre. Agora usa
      // o helper com busca de imagem online como reserva, igual os
      // outros comandos.
      const img = await imagemDaBrincadeira('casados')
      const texto = caixaArlequina("dupla", `${ehCasamento ? '💍 STATUS DO CASAMENTO' : '💜 STATUS DO NAMORO'}\n\n❤️ @${sender.split('@')[0]}\n${ehCasamento ? '💞' : '💜'}\n❤️ @${parceiro.split('@')[0]}\n\n📅 Juntos há:\n${tempo} dia(s)\n\n🥰 O amor continua firme!`)

      if (img) {
        await arlequina.sendMessage(from, { image: img, caption: texto, mentions: [sender, parceiro] }, { quoted: info })
      } else {
        await arlequina.sendMessage(from, { text: texto, mentions: [sender, parceiro] }, { quoted: info })
      }
    } catch (e) {
      console.log('❌ ERRO (dupla):', e?.message)
      await reply('❌ Não consegui executar esse comando agora.')
    } finally {
      salvarUsuarios(usuarios)
    }
  }
}
