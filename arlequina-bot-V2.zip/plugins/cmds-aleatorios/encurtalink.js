const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'encurtalink',
  description: '🔗 Encurta um link',
  category: 'cmds-aleatorios',
  aliases: ['shortlink', 'encurtar'],
  async execute({ q, args, reply, reagir, prefix }) {
    const link = (q || args.join(' ')).trim()
    if (!link || !/^https?:\/\//i.test(link)) return reply(caixaArlequina('encurtalink', `❌ Manda um link válido (começando com http/https).\n💡 Ex: *${prefix}encurtalink* https://exemplo.com`))
    try {
      await reagir('🔗')
      const { data } = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(link)}`, { timeout: 10000 })
      await reply(caixaArlequina('encurtalink', `🔗 *LINK ENCURTADO*\n\n${data}`))
    } catch (e) {
      await reply('❌ Não consegui encurtar esse link agora.')
    }
  }
}
