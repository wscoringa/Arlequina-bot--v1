/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: raspadinha
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'raspadinha',
description: "Raspadinha - tente ganhar um prêmio",
category: 'cmds-aleatorios',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const valor = parseInt(args[0])
  
  if (!valor || valor < 100) {
  return reply('🎟️ Use: !raspadinha 100')
  }
  
  if (usuarios[sender].saldo < valor) {
  return reply('❌ Saldo insuficiente.')
  }
  
  usuarios[sender].saldo -= valor
  
  const sorte = Math.random()
  
  let premio = 0
  
  if (sorte < 0.03) {
  premio = valor * 10
  } else if (sorte < 0.10) {
  premio = valor * 5
  } else if (sorte < 0.25) {
  premio = valor * 2
  }
  
  if (premio > 0) {
  usuarios[sender].saldo += premio
  
  await enviar({
  text: `${caixaArlequina("raspadinha", `🎟️ RASPADINHA
  
  ⬜ ⬜ 💰
  ⬜ 💰 ⬜
  💰 ⬜ ⬜
  
  🎉 PARABÉNS!
  
  💵 Aposta:
  R$ ${valor.toLocaleString('pt-BR')}
  
  🏆 Prêmio:
  R$ ${premio.toLocaleString('pt-BR')}
  
  💰 Saldo:
  R$ ${usuarios[sender].saldo.toLocaleString('pt-BR')}`)}`
  }, { quoted: msg })
  
  } else {
  
  await enviar({
  text: `🎟️ RASPADINHA
  
  ⬜ 🍌 ⬜
  🍋 ⬜ 🍒
  ⬜ 🍇 ⬜
  
  💀 Não foi premiada.
  
  💸 Perdeu:
  R$ ${valor.toLocaleString('pt-BR')}
  
  💰 Saldo:
  R$ ${usuarios[sender].saldo.toLocaleString('pt-BR')}`
  }, { quoted: msg })
  
  }
} catch (e) {
console.log('❌ ERRO (raspadinha):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
