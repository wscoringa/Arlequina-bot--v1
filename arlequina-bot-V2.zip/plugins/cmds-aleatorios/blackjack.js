/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: blackjack
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'blackjack',
description: "Jogo de blackjack (21)",
category: 'cmds-aleatorios',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const valor = parseInt(args[0])
  
  if (!valor || valor <= 0) {
  return enviar({
  text: '🃏 Use: !blackjack 100'
  }, { quoted: msg })
  }
  
  if (usuarios[sender].saldo < valor) {
  return enviar({
  text: '❌ Você não possui esse valor.'
  }, { quoted: msg })
  }
  
  const jogador = Math.floor(Math.random() * 11) + 11
  const dealer = Math.floor(Math.random() * 11) + 11
  
  if (jogador > dealer) {
  
  const premio = valor * 2
  
  usuarios[sender].saldo += valor
  
  await enviar({
  text: `${caixaArlequina("blackjack", `🃏 BLACKJACK
  
  🎴 Suas cartas: ${jogador}
  🤖 Dealer: ${dealer}
  
  🎉 VOCÊ GANHOU!
  
  💰 Lucro: R$ ${valor.toLocaleString('pt-BR')}
  
  👛 Carteira:
  R$ ${usuarios[sender].saldo.toLocaleString('pt-BR')}`)}`
  }, { quoted: msg })
  
  } else if (jogador === dealer) {
  
  await enviar({
  text: `
  🃏 BLACKJACK
  
  🎴 Suas cartas: ${jogador}
  🤖 Dealer: ${dealer}
  
  🤝 EMPATE!
  
  💰 Nenhum valor perdido.
  `
  }, { quoted: msg })
  
  } else {
  
  usuarios[sender].saldo -= valor
  
  await enviar({
  text: `
  🃏 BLACKJACK
  
  🎴 Suas cartas: ${jogador}
  🤖 Dealer: ${dealer}
  
  💀 VOCÊ PERDEU!
  
  💸 Prejuízo:
  R$ ${valor.toLocaleString('pt-BR')}
  
  👛 Carteira:
  R$ ${usuarios[sender].saldo.toLocaleString('pt-BR')}
  `
  }, { quoted: msg })
  
  }
} catch (e) {
console.log('❌ ERRO (blackjack):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
