const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const { sendImageAsSticker2, sendVideoAsSticker2 } = require('../../arquivos/js/exif2.js')

/*
  !criarpack / !packfig / !figpacote / !meupack

  Cria figurinha(s) com nome de pack personalizado.
  O autor/publisher puxa direto do Config (NomeDoBot).

  Como usar:
  1. Marque/responda uma foto ou vídeo com:  !criarpack NomeDoPack
  2. Ou envie a foto/vídeo com a legenda:     !criarpack NomeDoPack

  Pode repetir o comando várias vezes com o MESMO nome de pack
  para montar um pack com quantas figurinhas quiser — todas ficam
  agrupadas sob o mesmo nome no WhatsApp.
*/

const MAX_SEGUNDOS_VIDEO = 10

function desembrulhar(msg) {
  if (!msg) return null
  if (msg.ephemeralMessage) return desembrulhar(msg.ephemeralMessage.message)
  if (msg.viewOnceMessage) return desembrulhar(msg.viewOnceMessage.message)
  if (msg.viewOnceMessageV2) return desembrulhar(msg.viewOnceMessageV2.message)
  if (msg.viewOnceMessageV2Extension) return desembrulhar(msg.viewOnceMessageV2Extension.message)
  if (msg.documentWithCaptionMessage) return desembrulhar(msg.documentWithCaptionMessage.message)
  return msg
}

module.exports = {
  name: 'criarpack',
  description: 'Cria figurinhas com nome de pack personalizado (autor = NomeDoBot do config)',
  category: 'cmds-aleatorios',
  aliases: ['packfig', 'figpacote', 'meupack', 'packsticker'],

  async execute({
    arlequina, columbina, from, info, q, args, reply, reagir, prefix,
    pushname, sender, groupName, config, getFileBuffer
  }) {
    try {
      const nomePack = (q || args.join(' ') || '').trim()

      if (!nomePack) {
        return reply(caixaArlequina('CRIAR PACK',
`🎨 *Criar Pack de Figurinhas*

📌 *Como usar:*
• Responda uma foto/vídeo com:
  *${prefix}criarpack NomeDoPack*

• Ou mande a foto com legenda:
  *${prefix}criarpack NomeDoPack*

💡 Pode repetir várias vezes com o *mesmo nome*
pra montar o pack com quantas fotos quiser.

🤖 Autor do pack: *${config?.NomeDoBot || 'Arlequina'}*
(puxado direto do config.json)`))
      }

      if (nomePack.length > 32) {
        return reply('❌ Nome do pack muito longo! Máximo 32 caracteres.')
      }

      const quotedMsg = desembrulhar(info.message?.extendedTextMessage?.contextInfo?.quotedMessage)
      const mensagemAtual = desembrulhar(info.message)

      const imagem =
        quotedMsg?.imageMessage ||
        mensagemAtual?.imageMessage

      const video =
        quotedMsg?.videoMessage ||
        mensagemAtual?.videoMessage

      const documentoQuoted = quotedMsg?.documentMessage
      const documentoDireto = mensagemAtual?.documentMessage
      const imagemPorDocumento = documentoQuoted?.mimetype?.startsWith('image/') ? documentoQuoted
        : documentoDireto?.mimetype?.startsWith('image/') ? documentoDireto : null
      const videoPorDocumento = documentoQuoted?.mimetype?.startsWith('video/') ? documentoQuoted
        : documentoDireto?.mimetype?.startsWith('video/') ? documentoDireto : null

      const imagemFinal = imagem || imagemPorDocumento
      const videoFinal = video || videoPorDocumento

      if (!imagemFinal && !videoFinal) {
        return reply(caixaArlequina('CRIAR PACK',
`❌ Nenhuma foto/vídeo encontrada.

Marque uma imagem ou vídeo e use:
*${prefix}criarpack ${nomePack}*

Ou envie a mídia com essa legenda.`))
      }

      if (videoFinal && (videoFinal.seconds || 0) > MAX_SEGUNDOS_VIDEO) {
        return reply(`❌ Vídeo muito longo! Máximo *${MAX_SEGUNDOS_VIDEO} segundos*.`)
      }

      await reagir('🎨')

      // Pack name = o que a pessoa digitou
      // Author = NomeDoBot direto do config.json
      const meta = {
        packname: nomePack,
        author: config?.NomeDoBot || 'Arlequina 🃏💜'
      }

      const client = arlequina || columbina

      if (videoFinal) {
        const tipoDownload = videoFinal === videoPorDocumento ? 'document' : 'video'
        const buffer = await getFileBuffer(videoFinal, tipoDownload)
        await sendVideoAsSticker2(client, from, buffer, info, meta)
      } else {
        const tipoDownload = imagemFinal === imagemPorDocumento ? 'document' : 'image'
        const buffer = await getFileBuffer(imagemFinal, tipoDownload)
        await sendImageAsSticker2(client, from, buffer, info, meta)
      }

      await reagir('✅')
      await reply(caixaArlequina('CRIAR PACK',
`✅ Figurinha criada!

📦 Pack: *${nomePack}*
🤖 Autor: *${meta.author}*

💡 Mande mais fotos com *${prefix}criarpack ${nomePack}*
pra ir montando o pack completo.`))
    } catch (e) {
      console.error('❌ ERRO criarpack:', e?.message || e)
      await reply(`❌ Erro ao criar figurinha: ${e?.message || 'tente com outra imagem/vídeo'}`)
    }
  }
}
