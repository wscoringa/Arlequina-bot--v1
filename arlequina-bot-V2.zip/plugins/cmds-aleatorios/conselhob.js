const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const CONSELHOS = [
  'Tudo posso naquele que me fortalece. — Filipenses 4:13',
  'O Senhor é o meu pastor; nada me faltará. — Salmos 23:1',
  'Porque Deus amou o mundo de tal maneira que deu o seu Filho unigênito. — João 3:16',
  'Entrega o teu caminho ao Senhor; confia nele, e ele o fará. — Salmos 37:5',
  'Não temas, porque eu sou contigo. — Isaías 41:10',
  'Alegrai-vos sempre no Senhor; outra vez digo: alegrai-vos. — Filipenses 4:4',
  'Buscai primeiro o Reino de Deus, e a sua justiça. — Mateus 6:33',
  'O amor é paciente, o amor é bondoso. — 1 Coríntios 13:4',
  'Vinde a mim, todos os que estais cansados, e eu vos aliviarei. — Mateus 11:28',
  'Sede fortes e corajosos. Não temais. — Deuteronômio 31:6',
  'Aquele que habita no esconderijo do Altíssimo, à sombra do Onipotente descansará. — Salmos 91:1',
  'Lâmpada para os meus pés é a tua palavra. — Salmos 119:105',
  'Peça, e dar-se-vos-á; buscai, e encontrareis. — Mateus 7:7',
  'O fruto do Espírito é amor, alegria, paz, longanimidade... — Gálatas 5:22',
  'Castiga o teu filho enquanto há esperança. — Provérbios 19:18',
  'Melhor é o pouco com o temor do Senhor, do que grandes tesouros. — Provérbios 15:16',
  'Confia no Senhor de todo o teu coração. — Provérbios 3:5',
  'Não se turbe o vosso coração. — João 14:1',
  'Bem-aventurados os pacificadores. — Mateus 5:9',
  'Tudo tem o seu tempo determinado. — Eclesiastes 3:1'
]

module.exports = {
  name: 'conselhob',
  description: 'Conselho bíblico aleatório',
  category: 'cmds-aleatorios',
  aliases: ['conselhobiblico', 'conselhosb', 'versiculo', 'biblia'],
  async execute({ reply, reagir }) {
    await reagir('📖')
    const c = CONSELHOS[Math.floor(Math.random() * CONSELHOS.length)]
    return reply(caixaArlequina('CONSELHO BÍBLICO', `📖 ${c}`))
  }
}
