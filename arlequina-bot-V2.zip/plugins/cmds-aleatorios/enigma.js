const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const ENIGMAS = [
  { p: 'Quanto mais você tira, maior eu fico. O que sou?', r: 'buraco' },
  { p: 'Tenho cidades, mas não casas. Tenho montanhas, mas não árvores. Tenho água, mas não peixes. O que sou?', r: 'mapa' },
  { p: 'O que é que tem cabeça, mas não tem cérebro?', r: 'alho' },
  { p: 'Quanto mais seco, mais molhado fica. O que é?', r: 'toalha' },
  { p: 'Não tem vida, mas pode morrer. O que é?', r: 'bateria' },
  { p: 'O que sobe e nunca desce?', r: 'idade' },
  { p: 'Qual é a coisa que quanto mais tira, maior ela fica?', r: 'buraco' },
  { p: 'Tenho dentes mas não mordo. O que sou?', r: 'pente' },
  { p: 'O que anda sempre deitado e nunca se levanta?', r: 'estrada' },
  { p: 'Voa sem asas, chora sem olhos. O que é?', r: 'nuvem' },
  { p: 'Todo mundo tem, ninguém pode perder. O que é?', r: 'sombra' },
  { p: 'Quanto mais quente, mais fresco fica. O que é?', r: 'pão' },
]

module.exports = {
  name: 'enigma',
  description: '🧩 Um enigma pra você tentar resolver',
  category: 'cmds-aleatorios',
  aliases: ['charada'],
  async execute({ reply, reagir }) {
    await reagir('🧩')
    const item = ENIGMAS[Math.floor(Math.random() * ENIGMAS.length)]
    const respostaEscondida = item.r.split('').map(c => '‌' + c).join('') // caracteres invisíveis pra "esconder" um pouco no preview
    await reply(caixaArlequina('enigma', `🧩 *ENIGMA*\n\n${item.p}\n\n_Pensa antes de rolar pra ver a resposta..._\n\n.\n.\n.\n\n💡 Resposta: *${item.r}*`))
  }
}
