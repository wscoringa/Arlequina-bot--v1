/*
 !mochila — Mochila de treinador Pokémon: mostra quantas pokébolas
 (comum/super/ultra/mestra), poções, revives e pedras de evolução você
 tem guardadas.

 Compre pokébolas em !lojapokebola, e poções/revives/pedras em
 !pokeshop.
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const { POKEBOLAS, ORDEM_POKEBOLAS } = require('../../arquivos/js/pokebolas.js')
const { POKE_ITENS, ORDEM_ITENS } = require('../../arquivos/js/pokeItens.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'mochila',
  description: '🎒 Sua mochila de treinador: pokébolas, poções, revives e pedras',
  category: 'cmds-aleatorios',
  aliases: ['bagpokemon', 'inventariopoke'],
  async execute({ reply, reagir, sender, prefix }) {
    try {
      const usuarios = carregarUsuarios()
      const u = getUsuario(usuarios, sender)

      await reagir('🎒')

      const linhasBolas = ORDEM_POKEBOLAS
        .map(chave => {
          const b = POKEBOLAS[chave]
          const qtd = u.pokebolas?.[chave] || 0
          return `${b.emoji} ${b.label}: *${qtd}*`
        })
        .join('\n')

      const itensComQtd = ORDEM_ITENS.filter(chave => (u.pokeItens?.[chave] || 0) > 0)
      const linhasItens = itensComQtd.length
        ? itensComQtd.map(chave => `${POKE_ITENS[chave].label}: *${u.pokeItens[chave]}*`).join('\n')
        : '_Vazio — compre em !pokeshop_'

      const texto = caixaArlequina('mochila',
`🎒💜 *MOCHILA DE TREINADOR* 💜🎒

🔴🔵🟡🟣 *Pokébolas*
${linhasBolas}

🧪💊💠🔮 *Itens*
${linhasItens}

📌 Compre pokébolas em *${prefix}lojapokebola*
📌 Compre poções/revives/pedras em *${prefix}pokeshop*
📌 Use um item com *${prefix}usar <item> <número do pokémon>*`)

      await reply(texto)
    } catch (e) {
      console.log('❌ ERRO (mochila):', e?.message)
      await reply('❌ Não consegui abrir a mochila agora.')
    }
  }
}
