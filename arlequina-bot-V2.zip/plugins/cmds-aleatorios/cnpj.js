const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'cnpj',
  description: '🏢 Busca dados de uma empresa pelo CNPJ',
  category: 'cmds-aleatorios',
  aliases: ['cnpj2'],
  async execute({ args, reply, reagir, prefix }) {
    const cnpj = (args[0] || '').replace(/\D/g, '')
    if (!cnpj || cnpj.length !== 14) return reply(caixaArlequina('cnpj', `❌ CNPJ inválido.\n💡 Ex: *${prefix}cnpj* 00000000000191`))
    try {
      await reagir('🏢')
      const { data } = await axios.get(`https://brasilapi.com.br/api/cnpj/v1/${cnpj}`, { timeout: 15000 })
      await reply(caixaArlequina('cnpj', `🏢 *${data.razao_social}*\n\n📛 Fantasia: ${data.nome_fantasia || '—'}\n📅 Abertura: ${data.data_inicio_atividade || '—'}\n📍 ${data.municipio}/${data.uf}\n📌 Situação: ${data.descricao_situacao_cadastral || '—'}`))
    } catch (e) {
      await reply('❌ CNPJ não encontrado.')
    }
  }
}
