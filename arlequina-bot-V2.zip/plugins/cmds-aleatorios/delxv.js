const fs = require('fs')
const path = require('path')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const PASTA = path.join(__dirname, '../../arquivos/JSONS +18')

module.exports = {
  name: 'delxv',
  description: 'Dono: remove o último item ou apaga categoria +18',
  category: 'dono',
  aliases: ['del18', 'rmpack'],

  async execute({ reply, reagir, args, q, prefix, isDono }) {
    if (!isDono || (typeof isDono === 'function' && !isDono())) {
      return reply(caixaArlequina('+18', '❌ Só o *dono* pode usar este comando.'))
    }

    const nome = (args[0] || '').trim()
    if (!nome) {
      return reply(caixaArlequina('DEL XV', `📌 *Uso:*
*${prefix}delxv* NomeCategoria — remove o *último* link
*${prefix}delxv* NomeCategoria all — apaga a categoria inteira`))
    }

    const arquivos = fs.existsSync(PASTA) ? fs.readdirSync(PASTA).filter(f => f.endsWith('.json')) : []
    const arquivo = arquivos.find(f => path.basename(f, '.json').toLowerCase() === nome.toLowerCase())
    if (!arquivo) {
      return reply(caixaArlequina('DEL XV', `❌ Categoria *${nome}* não encontrada.`))
    }

    const file = path.join(PASTA, arquivo)
    const cat = path.basename(arquivo, '.json')

    if (String(args[1] || '').toLowerCase() === 'all') {
      fs.unlinkSync(file)
      await reagir('🗑️')
      return reply(caixaArlequina('DEL XV', `🗑️ Categoria *${cat}* apagada por completo.`))
    }

    let lista = []
    try { lista = JSON.parse(fs.readFileSync(file, 'utf8')) } catch { lista = [] }
    if (!Array.isArray(lista) || !lista.length) {
      return reply(caixaArlequina('DEL XV', `❌ *${cat}* já está vazia.`))
    }
    lista.pop()
    fs.writeFileSync(file, JSON.stringify(lista, null, 2), 'utf8')
    await reagir('✅')
    return reply(caixaArlequina('DEL XV', `✅ Removido o último link de *${cat}*.\n📦 Restam: *${lista.length}*`))
  }
}
