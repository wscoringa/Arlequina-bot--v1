const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const fs = require('fs')
const path = require('path')

// Config opcional: coloque sua API de like aqui
// Exemplo: { "url": "https://sua-api.com/like?uid={uid}", "method": "GET" }
const CONFIG_PATH = path.join(__dirname, '../../arquivos/json/fflike_config.json')

function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'))
    }
  } catch (_) {}
  return null
}

module.exports = {
  name: 'fflike',
  description: 'Envia likes no perfil Free Fire pelo UID',
  category: 'ferramentas',
  aliases: ['likeff', 'darlike', 'likesff'],

  async execute({ reply, reagir, prefix, args, q, isDono }) {
    const uid = (q || args[0] || '').replace(/\D/g, '')
    if (!uid || uid.length < 6) {
      return reply(caixaArlequina('FF LIKE', `❤️ *Uso:* ${prefix}fflike <UID>\n\nExemplo:\n${prefix}fflike 123456789\n\n⚠️ Likes dependem de API externa (guest accounts).\nDono pode configurar em:\n\`arquivos/json/fflike_config.json\``))
    }

    await reagir('❤️')

    const cfg = loadConfig()

    // 1) Se o dono configurou uma API própria
    if (cfg?.url) {
      try {
        const url = cfg.url.replace('{uid}', uid).replace('{UID}', uid)
        const method = (cfg.method || 'GET').toUpperCase()
        const res = method === 'POST'
          ? await axios.post(url, cfg.body || { uid }, { timeout: 25000, headers: cfg.headers || {} })
          : await axios.get(url, { timeout: 25000, headers: cfg.headers || {} })

        const d = res.data || {}
        const given = d.LikesGivenByAPI || d.likes_sent || d.likes || d.Likes || d.data?.likes_sent || '?'
        const after = d.LikesafterCommand || d.total_likes || d.data?.total_likes || '?'
        const nick = d.PlayerNickname || d.nickname || d.data?.nickname || '—'

        await reagir('✅')
        return reply(caixaArlequina('FF LIKE', `✅ *Likes enviados!*\n\n👤 Nick: *${nick}*\n🆔 UID: *${uid}*\n❤️ Enviados: *${given}*\n📊 Total agora: *${after}*`))
      } catch (e) {
        await reagir('❌')
        return reply(caixaArlequina('FF LIKE', `❌ Falha na API configurada.\n_${e?.message || 'erro'}_\n\nVerifique \`arquivos/json/fflike_config.json\``))
      }
    }

    // 2) Tentativa em endpoints públicos conhecidos (podem estar offline)
    const publicTries = [
      `https://ff-garena.run.place/sendLike?uid=${uid}&key=demo`,
      // Adicione aqui endpoints públicos se aparecerem
    ]

    for (const url of publicTries) {
      try {
        const res = await axios.get(url, { timeout: 15000, validateStatus: () => true })
        if (res.data && (res.data.status === 'success' || res.data.LikesGivenByAPI || res.data.likes_sent)) {
          const d = res.data
          await reagir('✅')
          return reply(caixaArlequina('FF LIKE', `✅ *Likes enviados!*\n\n🆔 UID: *${uid}*\n❤️ Resultado: ${JSON.stringify(d.data || d).slice(0, 200)}`))
        }
      } catch (_) {}
    }

    await reagir('⚠️')
    return reply(caixaArlequina('FF LIKE', `⚠️ *Nenhuma API de like gratuita está estável no momento.*

Para funcionar de verdade o *dono* precisa:

1️⃣ Subir uma API de like (ex: Free-Fire-Like-API no Vercel) com contas guest
2️⃣ Criar o arquivo:
\`arquivos/json/fflike_config.json\`

Exemplo:
\`\`\`json
{
  "url": "https://sua-api.vercel.app/like?uid={uid}",
  "method": "GET"
}
\`\`\`

Depois é só usar:
*${prefix}fflike ${uid}*

💡 Enquanto isso use *${prefix}ffinfo ${uid}* pra ver o perfil.`))
  }
}
