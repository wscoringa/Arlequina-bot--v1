const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const FATOS = [
  'O mel nunca estraga — arqueólogos já encontraram potes de mel com mais de 3.000 anos ainda comestíveis.',
  'Polvos têm três corações e sangue azul.',
  'Um dia em Vênus dura mais que um ano em Vênus.',
  'Bananas são tecnicamente frutinhas (berries), mas morangos não são.',
  'O coração de um camarão fica na cabeça.',
  'A Grande Muralha da China não é visível a olho nu do espaço, ao contrário do mito popular.',
  'Existem mais estrelas no universo do que grãos de areia em todas as praias da Terra.',
  'Ursos polares têm a pele preta por baixo do pelo branco.',
  'O Everest cresce cerca de 4mm por ano por causa do movimento das placas tectônicas.',
  'Golfinhos têm nomes próprios — assobios únicos que usam pra se identificar.',
  'A Torre Eiffel fica cerca de 15cm mais alta no verão por causa da dilatação térmica.',
  'Existem mais árvores na Terra do que estrelas na Via Láctea.',
  'O primeiro e-mail foi enviado em 1971.',
  'Formigas não têm pulmões — respiram por pequenos furinhos no corpo.',
  'Um raio é cerca de 5 vezes mais quente que a superfície do Sol.',
]

module.exports = {
  name: 'curiosidades',
  description: '🧠 Uma curiosidade aleatória',
  category: 'cmds-aleatorios',
  aliases: ['fatos', 'curiosidade', 'fato'],
  async execute({ reply, reagir }) {
    await reagir('🧠')
    const fato = FATOS[Math.floor(Math.random() * FATOS.length)]
    await reply(caixaArlequina('curiosidades', `🧠 *VOCÊ SABIA?*\n\n${fato}`))
  }
}
