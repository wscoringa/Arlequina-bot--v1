const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const { sendImageAsSticker2, sendVideoAsSticker2 } = require('../../arquivos/js/exif2.js')
const packSession = require('../../arquivos/js/packSession.js')

/*
  !figpack / !packfig / !figpacote / !criarpack / !meupack

  Cria figurinhas com as FOTOS/VÍDEOS que você manda.
  Nome do pack = o que digitar | Autor = NomeDoBot do config.json

  Uso fácil:
  • Mande as fotos COM a legenda:  !figpack NomeDoPack
    → já cria na hora

  • Ou: !figpack NomeDoPack  → manda as fotos → !figpack fim
*/

const MAX_SEGUNDOS_VIDEO = 10

function desembrulhar(msg) {
  if (!msg) return null
  if (msg.ephemeralMessage) return desembrulhar(msg.ephemeralMessage.message)
  if (msg.viewOnceMessage) return desembrulhar(msg.viewOnceMessage.message)
  if (msg.viewOnceMessageV2) return desembrulhar(msg.viewOnceMessageV2.message)
  if (msg.viewOnceMessageV2Extension) return desembrulhar(msg.viewOnceMessageV2Extension.message)
  if (msg.documentWithCaptionMessage) return desembrulhar(msg.documentWithCaptionMessage.message)
  return msg
}

function midiaDeMensagem(message) {
  const m = desembrulhar(message)
  if (!m) return null
  if (m.imageMessage) return { tipo: 'image', msg: m.imageMessage, viaDoc: false }
  if (m.videoMessage) return { tipo: 'video', msg: m.videoMessage, viaDoc: false }
  if (m.documentMessage?.mimetype?.startsWith('image/')) {
    return { tipo: 'image', msg: m.documentMessage, viaDoc: true }
  }
  if (m.documentMessage?.mimetype?.startsWith('video/')) {
    return { tipo: 'video', msg: m.documentMessage, viaDoc: true }
  }
  return null
}

function extrairMidias(info) {
  const lista = []
  const seen = new Set()

  const add = (item) => {
    if (!item) return
    // evita duplicar pelo mediaKey/fileSha256 se existir
    const id = item.msg?.mediaKey?.toString?.() || item.msg?.fileSha256?.toString?.() || Math.random()
    if (seen.has(id)) return
    seen.add(id)
    lista.push(item)
  }

  // mídia da mensagem atual
  add(midiaDeMensagem(info.message))

  // mídia citada
  const quoted = info.message?.extendedTextMessage?.contextInfo?.quotedMessage
    || info.message?.imageMessage?.contextInfo?.quotedMessage
    || info.message?.videoMessage?.contextInfo?.quotedMessage
  if (quoted) add(midiaDeMensagem(quoted))

  // lote do mesmo envio (várias fotos de uma vez)
  const lote = global.__ultimoUpsertMessages
  if (Array.isArray(lote)) {
    for (const msg of lote) {
      if (!msg?.message) continue
      // só do mesmo chat e mesmo remetente
      const mesmoChat = msg.key?.remoteJid === info.key?.remoteJid
      if (!mesmoChat) continue
      add(midiaDeMensagem(msg.message))
    }
  }

  return lista
}

function limparNomePack(texto) {
  return String(texto || '')
    .replace(/@\d+/g, '') // remove menções numéricas
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 32)
}

async function baixarEConverterWebp(item, getFileBuffer) {
  const tipoDl = item.viaDoc ? 'document' : item.tipo
  const buffer = item.buffer || await getFileBuffer(item.msg, tipoDl)
  if (!buffer || !buffer.length) return null
  return { buffer, isVideo: item.tipo === 'video', seconds: item.msg?.seconds || 0 }
}

async function tentarPackNativo(client, from, info, nomePack, autor, webps) {
  if (!webps.length) return false
  const cover = webps[0].buffer
  const stickers = webps.map((w) => ({
    data: w.buffer,
    emojis: ['🎨'],
    isAnimated: !!w.isVideo
  }))

  const tentativas = [
    {
      stickerPack: {
        name: nomePack,
        publisher: autor,
        description: nomePack,
        cover,
        stickers,
        packId: `arlequina-${Date.now()}`
      }
    },
    {
      cover,
      name: nomePack,
      publisher: autor,
      description: nomePack,
      stickers
    },
    {
      stickerPackMessage: {
        name: nomePack,
        publisher: autor,
        stickers: webps.map((w) => ({ buffer: w.buffer, emojis: ['🎨'] })),
        trayIcon: cover
      }
    }
  ]

  for (const payload of tentativas) {
    try {
      await client.sendMessage(from, payload, { quoted: info })
      return true
    } catch (e) {
      console.log('figpack pack nativo tentativa falhou:', e?.message || e)
    }
  }
  return false
}

async function processarPack(sessao, ctx) {
  const {
    arlequina, columbina, from, info, reply, reagir, getFileBuffer, config
  } = ctx
  const client = arlequina || columbina
  const meta = {
    packname: sessao.nomePack,
    author: config?.NomeDoBot || 'Arlequina 🃏💜'
  }

  await reagir('🎨')
  await reply(caixaArlequina('FIGPACK',
`🎨 Montando pack *${sessao.nomePack}*
📦 ${sessao.midias.length} mídia(s)
🤖 Autor: *${meta.author}*
⏳ Aguarde...`))

  const webps = []
  let falhaPrep = 0
  for (const item of sessao.midias) {
    try {
      if (item.tipo === 'video' && (item.msg.seconds || 0) > MAX_SEGUNDOS_VIDEO) {
        falhaPrep++
        continue
      }
      const conv = await baixarEConverterWebp(item, getFileBuffer)
      if (!conv) { falhaPrep++; continue }
      webps.push(conv)
    } catch (e) {
      console.error('figpack prep:', e?.message)
      falhaPrep++
    }
  }

  if (!webps.length) {
    await reagir('❌')
    return reply('❌ Não consegui processar nenhuma mídia do pack.')
  }

  // 1) Tenta pack nativo (card "Ver pacote de figurinhas")
  const nativoOk = await tentarPackNativo(client, from, info, meta.packname, meta.author, webps)
  if (nativoOk) {
    await reagir('✅')
    return reply(caixaArlequina('FIGPACK',
`✅ *Pack nativo enviado!*

📦 Nome: *${meta.packname}*
🤖 Autor: *${meta.author}*
✨ Figurinhas: *${webps.length}*

Toque em *Ver pacote de figurinhas* pra adicionar.`))
  }

  // 2) Fallback: figurinhas individuais com mesmo pack/autor
  await reply('⚠️ Pack nativo não suportado nesta versão do Baileys.\nEnviando figurinhas individuais com o mesmo pack...')
  let ok = 0
  let falha = falhaPrep
  for (const item of sessao.midias) {
    try {
      if (item.tipo === 'video' && (item.msg.seconds || 0) > MAX_SEGUNDOS_VIDEO) {
        falha++
        continue
      }
      const tipoDl = item.viaDoc ? 'document' : item.tipo
      const buffer = item.buffer || await getFileBuffer(item.msg, tipoDl)
      if (!buffer || !buffer.length) { falha++; continue }
      if (item.tipo === 'video') {
        await sendVideoAsSticker2(client, from, buffer, info, meta)
      } else {
        await sendImageAsSticker2(client, from, buffer, info, meta)
      }
      ok++
      await new Promise(r => setTimeout(r, 500))
    } catch (e) {
      console.error('figpack item erro:', e?.message || e)
      falha++
    }
  }

  await reagir(ok > 0 ? '✅' : '❌')
  await reply(caixaArlequina('FIGPACK',
`✅ Pack finalizado (modo individual)!

📦 Nome: *${meta.packname}*
🤖 Autor: *${meta.author}*
✨ Criadas: *${ok}*
${falha ? `⚠️ Falhas: *${falha}*` : ''}

💡 Todas com o mesmo nome de pack no tray.`))
}

module.exports = {
  name: 'figpack',
  description: 'Cria pack de figurinhas com suas fotos/vídeos (1–64). Autor = NomeDoBot',
  category: 'cmds-aleatorios',
  aliases: ['packfig', 'figpacote', 'criarpack', 'meupack', 'packsticker'],

  async execute(ctx) {
    const {
      from, info, q, args, reply, reagir, prefix, sender, config
    } = ctx

    try {
      // feedback imediato pra não parecer que "não foi"
      await reagir('🎨').catch(() => {})

      const textoRaw = (q || args.join(' ') || '').trim()
      const textoLow = textoRaw.toLowerCase()

      if (['fim', 'enviar', 'pronto', 'done', 'end', 'ok'].includes(textoLow)) {
        const sessao = packSession.finalizar(from, sender)
        if (!sessao || !sessao.midias.length) {
          return reply(caixaArlequina('FIGPACK',
`❌ Nenhuma sessão ativa ou sem fotos.

Use:
*${prefix}figpack NomeDoPack*
(mandando as fotos junto ou depois)`))
        }
        return await processarPack(sessao, ctx)
      }

      if (['cancelar', 'cancel', 'sair', 'stop'].includes(textoLow)) {
        const cancelou = packSession.cancelar(from, sender)
        return reply(cancelou
          ? caixaArlequina('FIGPACK', '🗑️ Sessão cancelada.')
          : caixaArlequina('FIGPACK', '❌ Nenhuma sessão ativa.'))
      }

      const midiasAgora = extrairMidias(info)
      const sessaoAtiva = packSession.get(from, sender)

      // Ajuda
      if (!textoRaw && !sessaoAtiva) {
        return reply(caixaArlequina('FIGPACK',
`🎨 *Criar Pack de Figurinhas*

📌 *Jeito mais fácil:*
Mande as fotos COM a legenda:
*${prefix}figpack NomeDoPack*

📌 *Ou em etapas:*
1. *${prefix}figpack NomeDoPack*
2. Mande as fotos
3. *${prefix}figpack fim*

🤖 Autor: *${config?.NomeDoBot || 'Arlequina'}*
📦 Até ${packSession.MAX_FOTOS} fotos/vídeos`))
      }

      // Sessão ativa + mais mídia
      if (sessaoAtiva && midiasAgora.length) {
        for (const m of midiasAgora) {
          const r = packSession.adicionar(from, sender, m)
          if (r?.cheio) break
        }
        const s = packSession.get(from, sender)
        // se já tem várias, processa na hora (não obriga digitar fim)
        if (s && s.midias.length >= 1 && textoRaw) {
          // se mandou nome de novo, ignora e só adiciona
        }
        // não spamma; finaliza sozinho em ~5s
        return
      }

      const nomePack = limparNomePack(textoRaw)
      if (!nomePack) {
        return reply(`❌ Digite o nome do pack.\nEx: *${prefix}figpack MeuPack*`)
      }

      // Inicia sessão
      const onTimeout = async (s) => {
        try {
          if (s.midias.length > 0) await processarPack(s, ctx)
        } catch (e) {
          console.error('figpack timeout:', e?.message)
        }
      }
      packSession.iniciar(from, sender, nomePack, onTimeout)

      for (const m of midiasAgora) {
        packSession.adicionar(from, sender, m)
      }

      const total = packSession.get(from, sender)?.midias.length || 0

      // Se já veio com foto(s), processa NA HORA
      if (total > 0) {
        const sessao = packSession.finalizar(from, sender)
        return await processarPack(sessao, ctx)
      }

      // Só o nome — espera fotos (finaliza sozinho em ~5s sem foto nova)
      return reply(caixaArlequina('FIGPACK',
`✅ Pack *${nomePack}* pronto pra receber fotos!
🤖 Autor: *${config?.NomeDoBot || 'Arlequina'}*

Manda as fotos agora — assim que parar, já gera sozinho.`))
    } catch (e) {
      console.error('❌ ERRO figpack:', e?.message || e)
      try {
        await reply(`❌ Erro no figpack: ${e?.message || 'tente de novo com as fotos'}`)
      } catch (_) {}
    }
  }
}
