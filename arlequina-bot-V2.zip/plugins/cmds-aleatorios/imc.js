const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'imc',
  description: '⚖️ Calcula seu IMC (peso e altura)',
  category: 'cmds-aleatorios',
  aliases: [],
  async execute({ args, reply, reagir, prefix }) {
    const peso = parseFloat((args[0] || '').replace(',', '.'))
    const altura = parseFloat((args[1] || '').replace(',', '.'))
    if (!peso || !altura) return reply(caixaArlequina('imc', `❌ Uso: *${prefix}imc* <peso em kg> <altura em metros>\n💡 Ex: *${prefix}imc* 70 1.75`))
    await reagir('⚖️')
    const alturaM = altura > 3 ? altura / 100 : altura // aceita "175" ou "1.75"
    const imc = peso / (alturaM * alturaM)
    let classificacao
    if (imc < 18.5) classificacao = 'Abaixo do peso'
    else if (imc < 25) classificacao = 'Peso normal ✅'
    else if (imc < 30) classificacao = 'Sobrepeso'
    else if (imc < 35) classificacao = 'Obesidade grau I'
    else if (imc < 40) classificacao = 'Obesidade grau II'
    else classificacao = 'Obesidade grau III'
    await reply(caixaArlequina('imc', `⚖️ *SEU IMC*\n\n📊 Resultado: *${imc.toFixed(1)}*\n📝 Classificação: ${classificacao}\n\n⚠️ Isso é só uma referência geral, não substitui avaliação médica.`))
  }
}
