const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'gerarqr',
  description: '🔳 Gera um QR Code a partir de um texto/link',
  category: 'cmds-aleatorios',
  aliases: ['qrcode', 'criarqr'],
  async execute({ arlequina, from, info, q, args, reply, reagir, prefix }) {
    const texto = (q || args.join(' ')).trim()
    if (!texto) return reply(caixaArlequina('gerarqr', `❌ Digite o texto/link.\n💡 Ex: *${prefix}gerarqr* https://exemplo.com`))
    try {
      await reagir('🔳')
      const url = `https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(texto)}`
      const { data } = await axios.get(url, { responseType: 'arraybuffer', timeout: 15000 })
      await arlequina.sendMessage(from, { image: Buffer.from(data), caption: `🔳 QR Code de:\n${texto}` }, { quoted: info })
    } catch (e) {
      await reply('❌ Não consegui gerar o QR Code agora.')
    }
  }
}
