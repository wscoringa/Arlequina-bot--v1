const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'criador',
  description: 'Mostra as informações fixas do criador e do bot',
  category: 'cmds-aleatorios',
  aliases: ['criadorbot'],

  async execute({ arlequina, from, info, reply }) {
    try {
      const texto = `
╭━━━🃏💜〔 👑 *CRIADOR DO BOT* 💜🃏━━━╮
┃
┃ 👑 CRIADOR & DESENVOLVEDOR
┃
┃ 🎭 Nome: 『𝙒𝙮𝙡𝙡𝙮𝙖𝙢 』🃏
┃ 📱 Contato: wa.me/553193358417
┃ 👑 Cargo: Criador Oficial
┃ 💻 Função: Desenvolvedor & Administrador
┃
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃
┃ 🃏 INFORMAÇÕES DO BOT
┃
┃ 💜 Nome:𝐀𝐑𝐋𝐄𝐐𝐔𝐈𝐍𝐀 𝐎𝐅𝐈𝐂𝐈𝐀𝐋 
┃ ⚡ Status: 🟢 ONLINE
┃ 🔧 Versão: V1
┃ 🤖 Sistema: WhatsApp Bot
┃ 💻 Desenvolvimento: Node.js
┃ 🛠️ Framework: Baileys
┃
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃
┃ ✨ RECURSOS
┃
┃ 🎮 Sistema RPG
┃ 🎁 Bônus & recompensas
┃ 🐾 Sistema Pokémon
┃ 🃏 Comandos exclusivos
┃ 🛡️ Sistema de administração
┃ 🎉 Eventos automáticos
┃ 💬 Diversos comandos interativos
┃
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃
┃ 👑 EQUIPE OFICIAL
┃
┃ 🃏 Criador: 『𝙒𝙮𝙡𝙡𝙮𝙖𝙢』
┃ 💻 Desenvolvedor: 『𝙒𝙮𝙡𝙡𝙮𝙖𝙢』
┃ 🤖 Bot: 愛ＡＲＬＥＱＵＩＮＡ
┃
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃
┃ 💜 ARLEQUINA BOT
┃ 🃏 Desenvolvido com dedicação
┃ ⚡ Sistema em constante evolução
┃
╰━━━〔 🃏💜 𝘽𝙊𝙏 𝙊𝙁𝙄𝘾𝙄𝘼𝙇 💜🃏 〕━━━╯
`.trim()

      await arlequina.sendMessage(
        from,
        { text: texto },
        { quoted: info }
      )
    } catch (e) {
      console.log('❌ ERRO (criador):', e?.message)
      await reply(caixaArlequina('criador', '❌ Não consegui mostrar essa informação agora.'))
    }
  }
}
