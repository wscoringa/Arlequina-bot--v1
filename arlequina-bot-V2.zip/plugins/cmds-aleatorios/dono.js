const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

/*
  🃏💜 ARLEQUINA BOT — COMANDO DONO

  Nome do dono, número e nome do bot NÃO ficam fixos aqui.
  O comando lê diretamente do config.js.
*/

module.exports = {
  name: 'dono',
  description: 'Mostra as informações do dono e do bot',
  category: 'cmds-aleatorios',
  aliases: ['owner'],

  async execute({ arlequina, from, info, reply, config }) {
    try {
      // Se o sistema já passou o config, usa ele.
      // Caso contrário, carrega diretamente o config.js da raiz do bot.
      let cfg = config

      if (!cfg) {
        try {
          cfg = require('../../config.js')
        } catch {
          try {
            cfg = require('../../config')
          } catch {
            cfg = {}
          }
        }
      }

      // Alguns config.js usam module.exports = {...}
      cfg = cfg?.default ?? cfg

      // DONO — puxado do config.js
      const nomeDono =
        cfg?.NomeDoDono ??
        cfg?.nomeDono ??
        cfg?.ownerName ??
        cfg?.nomeDonoBot ??
        cfg?.donoNome ??
        'Não definido'

      const numeroDono =
        cfg?.NumeroDoDono ??
        cfg?.numeroDono ??
        cfg?.ownerNumber ??
        cfg?.numeroDonoBot ??
        cfg?.donoNumero ??
        'Não definido'

      // BOT — puxado do config.js (não fica fixo como Arlequina)
      const nomeBot =
        cfg?.NomeDoBot ??
        cfg?.nomeDoBot ??
        cfg?.nomeBot ??
        cfg?.botName ??
        cfg?.nome_bot ??
        cfg?.bot ??
        'Arlequina'

      const numeroLimpo = String(numeroDono)
        .replace(/^wa\.me\//i, '')
        .replace(/[^\d]/g, '')

      const nome = String(nomeDono)
      const bot = String(nomeBot)

      const texto = `
╭━━━〔 👑🃏 𝘿𝙊𝙉𝙊 𝘼𝙏𝙐𝘼𝙇 🃏👑 〕━━━╮
┃
┃ 🎭 INFORMAÇÕES DO PROPRIETÁRIO
┃
┃ 👑 Nome:
┃    『${nome}』 🃏
┃
┃ 📱 Número:
┃    wa.me/${numeroLimpo || 'Não definido'}
┃
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃
┃ 💜 BOT SOB PROPRIEDADE
┃
┃ 🤖 Nome: ${bot}
┃ 🃏 Status: 🟢 ATIVO
┃ 👑 Proprietário: 『${nome}』
┃ 🔐 Acesso: Proprietário Oficial
┃
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃
┃ 🛡️ RESPONSABILIDADES
┃
┃ ⚙️ Gerenciamento do sistema
┃ 👥 Administração do bot
┃ 🔧 Configuração & manutenção
┃ 🃏 Controle dos recursos
┃ 📢 Gerenciamento oficial
┃
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃
┃ 💜 ${bot.toUpperCase()}
┃ 🃏 Propriedade Oficial
┃ ⚡ Sistema em constante evolução
┃ 🔐 Administração autorizada
┃
╰━━━〔 💜🃏 ${bot} 🃏💜 〕━━━╯
`.trim()

      await arlequina.sendMessage(
        from,
        { text: texto },
        { quoted: info }
      )
    } catch (e) {
      console.log('❌ ERRO (dono):', e?.message)
      await reply(
        caixaArlequina(
          'dono',
          '❌ Não consegui mostrar as informações do dono agora.'
        )
      )
    }
  }
}
