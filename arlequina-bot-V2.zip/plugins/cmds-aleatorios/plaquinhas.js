const axios = require('axios')
const donoState = require('../../arquivos/js/donoState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const { ehVip, msgSoVip } = require('../../arquivos/js/vipHelper.js')
const { API_URL, API_KEY } = require('../../arquivos/js/kimoriApi.js')

// Templates Sirv (do Sandro Bot) — funcionam sem key
const SIRV_TEMPLATES = {
  plaq: (t) => `https://raptibef.sirv.com/images%20(3).jpeg?text.0.text=${encodeURIComponent(t)}&text.0.position.gravity=center&text.0.position.x=19%25&text.0.size=45&text.0.color=000000&text.0.opacity=55&text.0.font.family=Crimson%20Text&text.0.font.weight=300&text.0.font.style=italic&text.0.outline.opacity=21`,

  plaq1: (t) => `https://umethroo.sirv.com/9152e7a9-7d49-48ef-b8ac-2e6149fda0b2.jpg?text.0.text=${encodeURIComponent(t)}&text.0.position.x=-70%25&text.0.position.y=-23%25&text.0.size=17&text.0.color=000000&text.0.font.family=Architects%20Daughter&text.0.font.weight=300`,
  plaq2: (t) => `https://clutamac.sirv.com/1011b781-bab1-49e3-89db-ee2c064868fa%20(1).jpg?text.0.text=${encodeURIComponent(t)}&text.0.position.gravity=northwest&text.0.position.x=22%25&text.0.position.y=60%25&text.0.size=12&text.0.color=000000&text.0.opacity=47&text.0.font.family=Roboto%20Mono&text.0.font.style=italic`,
  plaq3: (t) => `https://umethroo.sirv.com/Torcedora-da-sele%C3%A7%C3%A3o-brasileira-nua-mostrando-a-bunda-236x300.jpg?text.0.text=${encodeURIComponent(t)}&text.0.position.x=-64%25&text.0.position.y=-39%25&text.0.size=25&text.0.color=1b1a1a&text.0.font.family=Architects%20Daughter`,
  plaq4: (t) => `https://umethroo.sirv.com/9152e7a9-7d49-48ef-b8ac-2e6149fda0b2.jpg?text.0.text=${encodeURIComponent(t)}&text.0.position.x=-70%25&text.0.position.y=-23%25&text.0.size=17&text.0.color=000000&text.0.font.family=Architects%20Daughter&text.0.font.weight=300`,
  plaq5: (t) => `https://clutamac.sirv.com/1011b781-bab1-49e3-89db-ee2c064868fa%20(1).jpg?text.0.text=${encodeURIComponent(t)}&text.0.position.gravity=northwest&text.0.position.x=22%25&text.0.position.y=60%25&text.0.size=12&text.0.color=000000&text.0.opacity=47&text.0.font.family=Roboto%20Mono&text.0.font.style=italic`,
  plaq6: (t) => `https://umethroo.sirv.com/Torcedora-da-sele%C3%A7%C3%A3o-brasileira-nua-mostrando-a-bunda-236x300.jpg?text.0.text=${encodeURIComponent(t)}&text.0.position.x=-64%25&text.0.position.y=-39%25&text.0.size=25&text.0.color=1b1a1a&text.0.font.family=Architects%20Daughter`,
  plaq7: (t) => `https://umethroo.sirv.com/9152e7a9-7d49-48ef-b8ac-2e6149fda0b2.jpg?text.0.text=${encodeURIComponent(t)}&text.0.position.x=-70%25&text.0.position.y=-23%25&text.0.size=17&text.0.color=000000&text.0.font.family=Architects%20Daughter&text.0.font.weight=300`,
  plaq8: (t) => `https://clutamac.sirv.com/1011b781-bab1-49e3-89db-ee2c064868fa%20(1).jpg?text.0.text=${encodeURIComponent(t)}&text.0.position.gravity=northwest&text.0.position.x=22%25&text.0.position.y=60%25&text.0.size=12&text.0.color=000000&text.0.opacity=47&text.0.font.family=Roboto%20Mono&text.0.font.style=italic`,
  plaq9: (t) => `https://umethroo.sirv.com/Torcedora-da-sele%C3%A7%C3%A3o-brasileira-nua-mostrando-a-bunda-236x300.jpg?text.0.text=${encodeURIComponent(t)}&text.0.position.x=-64%25&text.0.position.y=-39%25&text.0.size=25&text.0.color=1b1a1a&text.0.font.family=Architects%20Daughter`
}

const PLAQS = ['plaq', 'plaq1', 'plaq2', 'plaq3', 'plaq4', 'plaq5', 'plaq6', 'plaq7', 'plaq8', 'plaq9']

module.exports = {
  name: 'plaq',
  description: 'Gera plaquinhas (+18)',
  category: 'cmds-aleatorios',
  aliases: PLAQS,

  async execute(ctx) {
    const {
      arlequina, columbina, from, info, reply, reagir, prefix,
      command, args, q, sender, isGroup, isDono, config
    } = ctx

    if (!ehVip(sender, isDono)) {
      return reply(caixaArlequina('PLAQUINHAS', msgSoVip(prefix)))
    }

    const conn = arlequina || columbina
    let cmd = (command || 'plaq1').toLowerCase()
    if (cmd === 'plaq') cmd = 'plaq1'

    if (isGroup) {
      const ativo = !!(donoState.modo18Grupos && donoState.modo18Grupos[from])
      if (!ativo && !isDono()) {
        return reply(caixaArlequina('PLAQUINHAS', `🔞 O *modo +18* está desativado neste grupo.\n\nPeça pra um ADM usar:\n*${prefix}modo18 1*`))
      }
    }

    const texto = (q || args.join(' ') || '').trim()
    if (!texto) {
      return reply(caixaArlequina('PLAQUINHAS', `❕ Cadê o texto?\n\nUse: *${prefix}${cmd} seu texto*\nMáximo 25 caracteres.`))
    }
    if (texto.length > 25) {
      return reply(caixaArlequina('PLAQUINHAS', '❗ Texto muito longo (máx. 25 caracteres).'))
    }

    await reagir('🔞')

    const nomeBot = config?.NomeDoBot || 'Arlequina'
    const nomeDono = config?.NomeDoDono || 'coringa'

    const caption = `╭─━━─🔞💜「 *PLAQUINHA* 」💜🔞─━━─╮

📝 ${texto}

💜 Feito com carinho pela *${nomeBot}*
👑 Dono: *${nomeDono}*

╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
      🃏 *${nomeBot}* 💜😈`

    // 1) Tenta API Kimori primeiro
    let enviou = false
    try {
      const url = `${API_URL}/api/${cmd}?query=${encodeURIComponent(texto)}&apikey=${API_KEY}`
      const response = await axios.get(url, { responseType: 'arraybuffer', timeout: 15000 })
      const buffer = Buffer.from(response.data)
      if (buffer && buffer.length > 500) {
        if (isGroup) {
          const msgs = [
            `Já tô enviando a plaquinha no seu privado, safadinha 😈💜`,
            `Plaquinha no PV, safado… corre lá 🔥`,
            `Mandei a plaquinha no privado 😏`,
            `Sua plaquinha chegou no PV 🔞💜`
          ]
          try {
            await conn.sendMessage(from, {
              text: caixaArlequina('PLAQUINHAS', `${msgs[Math.floor(Math.random()*msgs.length)]}\n\n📝 *${texto}*\n👤 @${sender.split('@')[0]}`),
              mentions: [sender]
            }, { quoted: info })
          } catch (_) {}
        }
        await conn.sendMessage(sender, { image: buffer, caption })
        enviou = true
        await reagir('✅')
      }
    } catch (_) {}

    // 2) Fallback Sirv (Sandro style)
    if (!enviou && SIRV_TEMPLATES[cmd]) {
      try {
        const imgUrl = SIRV_TEMPLATES[cmd](texto)
        if (isGroup) {
          try {
            await conn.sendMessage(from, {
              text: caixaArlequina('PLAQUINHAS', `Já tô enviando a plaquinha no seu privado, safadinha 😈💜\n\n📝 *${texto}*\n👤 @${sender.split('@')[0]}`),
              mentions: [sender]
            }, { quoted: info })
          } catch (_) {}
        }
        await conn.sendMessage(sender, { image: { url: imgUrl }, caption })
        enviou = true
        await reagir('✅')
      } catch (e2) {
        console.error('Erro Sirv plaq:', e2?.message)
      }
    }

    if (!enviou) {
      await reagir('❌')
      return reply(caixaArlequina('PLAQUINHAS', `❌ Não consegui gerar a plaquinha agora.\nTente de novo mais tarde.`))
    }
  }
}
