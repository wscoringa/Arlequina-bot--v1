const os = require('os')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'ping',
  description: 'Mostra velocidade e status do bot',
  category: 'cmds-aleatorios',
  aliases: ['velocidade', 'pong'],

  async execute({ arlequina, from, info, reply, reagir, config }) {
    try {
      await reagir('🏓')

      const inicio = Date.now()

      // Mensagem inicial
      const enviada = await arlequina.sendMessage(
        from,
        {
          text: caixaArlequina(
            'ping',
            `🃏💜 *ARLEQUINA CRIME SYSTEM* 💜🃏

      🩸 *P I N G* 🩸

「 *SYSTEM CONNECTED* 」

⏳ *Executando diagnóstico...*
🔐 *Verificando conexão...*
📡 *Calculando latência...*`
          )
        },
        { quoted: info }
      )

      // Calcula latência
      const latencia = Date.now() - inicio

      // Memória
      const memoriaMB = (
        process.memoryUsage().rss /
        1024 /
        1024
      ).toFixed(1)

      const memoriaTotal = (
        os.totalmem() /
        1024 /
        1024 /
        1024
      ).toFixed(1)

      const memoriaLivre = (
        os.freemem() /
        1024 /
        1024 /
        1024
      ).toFixed(1)

      // CPU
      const cpu = (os.loadavg()[0] || 0).toFixed(2)

      // Uptime
      const uptimeSeg = Math.floor(process.uptime())

      const d = Math.floor(uptimeSeg / 86400)
      const h = Math.floor((uptimeSeg % 86400) / 3600)
      const m = Math.floor((uptimeSeg % 3600) / 60)
      const s = uptimeSeg % 60

      const uptime = [
        d > 0 ? `${d}d` : null,
        h > 0 ? `${h}h` : null,
        m > 0 ? `${m}m` : null,
        `${s}s`
      ]
        .filter(Boolean)
        .join(' ')

      // Status da conexão
      let emoji = '🟢'
      let status = 'EXCELENTE'
      let barra = '██████████'

      if (latencia > 300) {
        emoji = '🟡'
        status = 'BOA'
        barra = '████████░░'
      }

      if (latencia > 700) {
        emoji = '🟠'
        status = 'MÉDIA'
        barra = '██████░░░░'
      }

      if (latencia > 1500) {
        emoji = '🔴'
        status = 'LENTA'
        barra = '████░░░░░░'
      }

      if (latencia > 3000) {
        emoji = '💀'
        status = 'CRÍTICA'
        barra = '██░░░░░░░░'
      }

      const nomeBot = config?.NomeDoBot || 'Arlequina'

      const texto = caixaArlequina(
        'ping',
        `╔══════════════════════════════╗
║ 🃏💜 𝐀𝐑𝐋𝐄𝐐𝐔𝐈𝐍𝐀 💜🃏       ║
║   「 𝐎𝐅𝐅𝐈𝐂𝐈𝐀𝐋 𝐂𝐑𝐈𝐌𝐄 𝐒𝐘𝐒𝐓𝐄𝐌 」 ║
╚══════════════════════════════╝

      🩸 𝐏 𝐈 𝐍 𝐆 🩸
  「 𝐒𝐘𝐒𝐓𝐄𝐌 𝐂𝐎𝐍𝐍𝐄𝐂𝐓𝐄𝐃 」

╭━━━〔 🃏 𝐑𝐄𝐒𝐏𝐎𝐒𝐓𝐀 〕━━━╮
┃ 🏓 PONG       » *${latencia}ms*
┃ ${emoji} Velocidade » *${status}*
┃ 📶 Sinal      » ${barra}
╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯

╭━━━━〔 🩸 𝐒𝐈𝐒𝐓𝐄𝐌𝐀 〕━━━━╮
┃ ⏱️ Uptime    » *${uptime}*
┃ 💾 Memória   » *${memoriaMB} MB*
┃ 🗄️ RAM       » *${memoriaLivre} / ${memoriaTotal} GB*
┃ 🧠 Node      » *${process.version}*
┃ 🖥️ Sistema   » *${process.platform}*
┃ 📱 Arch      » *${os.arch()}*
┃ ⚙️ CPU       » *${cpu}*
╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯

╭━━━━〔 💜 𝐂𝐎𝐍𝐓𝐑𝐎𝐋𝐄 〕━━━━╮
┃ 🟢 Status      » *ONLINE*
┃ 🃏 Núcleo      » *ARLEQUINA*
┃ 🔐 Segurança   » *ATIVA*
┃ 👑 Acesso      » *OFICIAL*
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

        🩸 𝐂𝐑𝐈𝐌𝐄 𝐍𝐄𝐓𝐖𝐎𝐑𝐊 🩸

   🃏💜 *NINGUÉM PARA A ARLEQUINA* 💜🃏

╔══════════════════════════════╗
║    『 𝐀𝐑𝐋𝐄𝐐𝐔𝐈𝐍𝐀 』 🃏💜    ║
║       𝐂𝐑𝐈𝐌𝐄 𝐒𝐘𝐒𝐓𝐄𝐌       ║
╚══════════════════════════════╝

🤖 *${nomeBot}*`
      )

      // Tenta editar a mensagem inicial
      try {
        await arlequina.sendMessage(from, {
          text: texto,
          edit: enviada.key
        })
      } catch (_) {
        // Caso a edição não seja suportada
        await arlequina.sendMessage(
          from,
          { text: texto },
          { quoted: info }
        )
      }

    } catch (e) {
      console.log('❌ ERRO ping:', e?.message)

      try {
        await reply(
          caixaArlequina(
            'ping',
            `🃏💜 *ARLEQUINA CRIME SYSTEM* 💜🃏

🩸 *FALHA NO DIAGNÓSTICO*

❌ Não consegui medir o ping agora.

🔐 *Sistema:* ARLEQUINA
🟠 *Status:* ERRO DE CONEXÃO`
          )
        )
      } catch (_) {}
    }
  }
}
