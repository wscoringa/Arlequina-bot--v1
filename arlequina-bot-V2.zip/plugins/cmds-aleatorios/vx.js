const fs = require('fs')
const path = require('path')
const donoState = require('../../arquivos/js/donoState.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')
const { ehVip, msgSoVip } = require('../../arquivos/js/vipHelper.js')

const JSON_DIR = path.join(__dirname, '../../arquivos/JSONS +18')
const VIDEO_CATS = ['PornoVid', 'Amador', 'EgirlVid', 'Onlyfans']

const FRASES_PV = [
  '🔥 Pra você no privado, safadinho(a)...',
  '😈 Só no PV, como você gosta.',
  '🔞 Entrega especial no seu privado.',
  '💦 Chegou no PV, aproveita.',
  '😏 Pediu, tá servido no privado.'
]

const FRASES_GRUPO = [
  '😈 Já tô enviando no seu privado, safadinha...',
  '🔥 Olha o PV, tá indo o vídeo...',
  '🔞 Mandei no privado, confere aí.',
  '💦 Foi pro seu PV, abre lá.',
  '😏 Entrega no privado feita.'
]

function carregarTodosVideos() {
  const urls = []
  for (const cat of VIDEO_CATS) {
    const file = path.join(JSON_DIR, `${cat}.json`)
    if (!fs.existsSync(file)) continue
    try {
      const arr = JSON.parse(fs.readFileSync(file, 'utf8'))
      if (Array.isArray(arr)) {
        for (const u of arr) {
          if (typeof u === 'string' && (u.includes('.mp4') || u.includes('telegra') || u.includes('http'))) {
            urls.push(u)
          }
        }
      }
    } catch (_) {}
  }
  return urls
}

function pickN(arr, n) {
  const copy = [...arr]
  const out = []
  while (out.length < n && copy.length) {
    const i = Math.floor(Math.random() * copy.length)
    out.push(copy.splice(i, 1)[0])
  }
  return out
}

module.exports = {
  name: 'vx',
  description: 'Envia vídeo(s) +18 no PV de quem pediu',
  category: 'cmds-aleatorios',
  aliases: ['xvideos', 'xv', 'pornovideo', 'videox'],

  async execute({ arlequina, from, info, reply, reagir, sender, isGroup, args, prefix, config, isDono }) {
    if (!ehVip(sender, isDono)) {
      return reply(caixaArlequina('+18', msgSoVip(prefix)))
    }
    // Em grupo: exige modo18 ativo
    if (isGroup) {
      const ativo = !!(donoState.modo18Grupos && donoState.modo18Grupos[from])
      if (!ativo) {
        return reply(caixaArlequina('+18', `🔞 O *modo +18* está desativado neste grupo.\n\nADM: *${prefix}modo18 1*`))
      }
    }

    let qtd = parseInt(args[0], 10)
    if (isNaN(qtd) || qtd < 1) qtd = 1
    if (qtd > 5) qtd = 5 // limite pra não estourar WhatsApp / flood

    const pool = carregarTodosVideos()
    if (!pool.length) {
      return reply(caixaArlequina('+18', '❌ Nenhum vídeo +18 encontrado nos packs do bot.'))
    }

    await reagir('🔞')
    const escolhidos = pickN(pool, qtd)
    const userJid = sender
    const nomeBot = config?.NomeDoBot || 'Arlequina'
    const nomeDono = config?.NomeDoDono || 'Dono'

    if (isGroup) {
      const msgG = FRASES_GRUPO[Math.floor(Math.random() * FRASES_GRUPO.length)]
      await reply(msgG)
    } else {
      await reply('🔥 Enviando...')
    }

    let ok = 0
    for (let i = 0; i < escolhidos.length; i++) {
      const link = escolhidos[i]
      const frase = FRASES_PV[Math.floor(Math.random() * FRASES_PV.length)]
      const caption = `*🔞 Vídeo +18*\n${frase}\n\n🤖 Bot: ${nomeBot}\n👑 Dono: ${nomeDono}\n📦 ${i + 1}/${escolhidos.length}`
      try {
        await arlequina.sendMessage(userJid, {
          video: { url: link },
          caption
        })
        ok++
        if (i < escolhidos.length - 1) await new Promise(r => setTimeout(r, 1500))
      } catch (e) {
        console.log('vx send erro:', e?.message)
      }
    }

    if (!ok) {
      return reply(caixaArlequina('+18', '❌ Não consegui enviar os vídeos agora. Tenta de novo.'))
    }

    if (isGroup) {
      // confirmação leve se quiser; já avisou antes
    }
  }
}
