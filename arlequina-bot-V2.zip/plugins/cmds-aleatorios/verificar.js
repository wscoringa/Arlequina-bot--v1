/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: verificar
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'verificar',
description: "Verifica informações de um número/grupo",
category: 'cmds-aleatorios',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const groupMetadata = await sock.groupMetadata(from)
  
  const alvo =
  msg.message?.extendedTextMessage?.contextInfo?.participant ||
  msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
  
  if (!alvo)
  return reply('❌ Marque uma pessoa.\n\nEx: !verificar @membro')
  
  const numeroAlvo = alvo.split('@')[0]
  
  const avisos = donoState.avisos[from]?.[numeroAlvo] || 0
  const muteFixo = !!adminState.mutados[from]?.[numeroAlvo]
  const muteTemp = adminState.muteTemporario[from]?.[numeroAlvo]
  const naListaNegra = adminState.listanegra[from]?.includes(numeroAlvo)
  const totalNotas = donoState.historicoMod?.[from]?.[numeroAlvo]?.length || 0
  
  let statusMute = '❌ Não'
  if (muteFixo) statusMute = '✅ Sim (permanente)'
  else if (muteTemp && Date.now() < muteTemp) {
  const restante = Math.ceil((muteTemp - Date.now()) / 60000)
  statusMute = `✅ Sim (${restante} min restantes)`
  }
  
  await enviar({
  text: `${caixaArlequina("verificar", `🔎 VERIFICAÇÃO: @${numeroAlvo}
  
  ⚠️ Avisos: ${avisos}/${donoState.avisosMaximo[from] || 3}
  🔇 Mutado: ${statusMute}
  🚫 Lista negra: ${naListaNegra ? '✅ Sim' : '❌ Não'}
  📝 Notas registradas: ${totalNotas}`)}`,
  mentions: [alvo]
  })
} catch (e) {
console.log('❌ ERRO (verificar):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
