const { criarPerfilCard } = require('../../arquivos/js/perfilCard.js')

module.exports = criarPerfilCard({
  name: 'perfilrico',
  titulo: 'Perfil Milionário',
  emoji: '💰',
  aliases: [],
  traços: [
    { emoji: '🏦', label: 'Patrimônio', opcoes: ['R$ 2 no Pix', 'Fiado no mercado', 'Herança imaginária', 'Bolsa da vovó', 'Salário já comprometido'] },
    { emoji: '🚗', label: 'Garagem', opcoes: ['Bike emprestada', 'Carona todo dia', 'Ônibus lotado 6h', 'Patinete quebrado', 'Uber no fiado'] },
    { emoji: '🏝️', label: 'Última viagem', opcoes: ['Quintal de casa', 'Vizinho de bairro', 'Google Maps modo satélite', 'Sonho de consumo', 'Feira do rolo'] },
    { emoji: '💳', label: 'Cartão', opcoes: ['Limite de R$ 50', 'Bloqueado', 'Só débito mesmo', 'Nem tem conta', 'Fatura vencida'] },
    { emoji: '👔', label: 'Estilo de vida', opcoes: ['Rei da promoção', 'Assinante do 2x1', 'Compra parcelado em 1x', 'Investidor no fiado', 'CEO do "depois eu pago"'] }
  ]
})
