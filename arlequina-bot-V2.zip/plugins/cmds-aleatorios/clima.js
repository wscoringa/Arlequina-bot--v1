const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'clima',
  description: '☁️ Previsão do tempo de uma cidade',
  category: 'cmds-aleatorios',
  aliases: ['tempo'],
  async execute({ q, args, reply, reagir, prefix }) {
    const cidade = (q || args.join(' ')).trim()
    if (!cidade) return reply(caixaArlequina('clima', `❌ Digite uma cidade.\n💡 Ex: *${prefix}clima* São Paulo`))
    try {
      await reagir('☁️')
      const { data } = await axios.get(`https://wttr.in/${encodeURIComponent(cidade)}?format=j1&lang=pt`, { timeout: 15000, headers: { 'User-Agent': 'curl' } })
      const atual = data.current_condition[0]
      const hoje = data.weather[0]
      await reply(caixaArlequina('clima', `☁️ *Clima em ${cidade}*\n\n🌡️ Agora: ${atual.temp_C}°C (sensação ${atual.FeelsLikeC}°C)\n📝 ${atual.lang_pt?.[0]?.value || atual.weatherDesc[0].value}\n💧 Umidade: ${atual.humidity}%\n💨 Vento: ${atual.windspeedKmph} km/h\n\n📅 Hoje: mín ${hoje.mintempC}°C / máx ${hoje.maxtempC}°C`))
    } catch (e) {
      console.log('❌ ERRO clima:', e?.message)
      await reply('❌ Não consegui buscar o clima dessa cidade agora.')
    }
  }
}
