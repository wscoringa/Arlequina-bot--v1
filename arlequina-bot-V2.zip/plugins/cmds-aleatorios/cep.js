const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'cep',
  description: '📮 Busca endereço pelo CEP',
  category: 'cmds-aleatorios',
  aliases: ['cep2', 'cep3'],
  async execute({ args, reply, reagir, prefix }) {
    const cep = (args[0] || '').replace(/\D/g, '')
    if (!cep || cep.length !== 8) return reply(caixaArlequina('cep', `❌ CEP inválido.\n💡 Ex: *${prefix}cep* 01310930`))
    try {
      await reagir('📮')
      const { data } = await axios.get(`https://viacep.com.br/ws/${cep}/json/`, { timeout: 10000 })
      if (data.erro) return reply('❌ CEP não encontrado.')
      await reply(caixaArlequina('cep', `📮 *CEP ${data.cep}*\n\n🏠 Rua: ${data.logradouro || '—'}\n🏘️ Bairro: ${data.bairro || '—'}\n🏙️ Cidade: ${data.localidade}/${data.uf}\n📍 DDD: ${data.ddd || '—'}`))
    } catch (e) {
      console.log('❌ ERRO cep:', e?.message)
      await reply('❌ Não consegui buscar esse CEP agora.')
    }
  }
}
