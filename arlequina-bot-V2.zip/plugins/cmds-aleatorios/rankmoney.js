/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: rankmoney
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'rankmoney',
description: "Rank dos mais ricos",
category: 'cmds-aleatorios',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson, groupMembers }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

if (!isGroup) {
return reply(caixaArlequina("rankmoney", `❌ Este comando só funciona em grupos.`))
}

// BUGFIX: antes esse rank pegava TODOS os usuários do bot (de
// qualquer grupo em que ele estivesse), não só desse grupo aqui.
const membrosDoGrupo = new Set(
(groupMembers || []).flatMap(p => [p.phoneNumber, p.id].filter(Boolean))
)

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const ranking = Object.entries(usuarios)
  .filter(([jid]) => membrosDoGrupo.has(jid))
  .sort((a,b)=>(b[1].saldo||0)-(a[1].saldo||0))
  .slice(0,10)

  if (ranking.length === 0) {
    return reply('📋 Nenhum membro desse grupo tem saldo registrado ainda.')
  }
  
  let texto = '💰 RANK MONEY\n\n'
  let mencoes = []
  
  ranking.forEach((u,i)=>{
  
  texto += `${i+1}° 👑 @${u[0].split('@')[0]}
  💵 R$ ${(u[1].saldo||0).toLocaleString('pt-BR')}
  
  `
  
  mencoes.push(u[0])
  
  })
  
  await enviar({
  text:texto,
  mentions:mencoes
  },{quoted:msg})
} catch (e) {
console.log('❌ ERRO (rankmoney):', e?.message)
await reply(caixaArlequina("rankmoney", `❌ Não consegui executar esse comando agora.`))
} finally {
salvarUsuarios(usuarios)
}

}
}
