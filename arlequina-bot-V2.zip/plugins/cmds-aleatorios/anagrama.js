const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

function normalizar(txt) {
  return txt.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '').split('').sort().join('')
}

module.exports = {
  name: 'anagrama',
  description: '🔤 Verifica se duas palavras/frases são anagramas',
  category: 'cmds-aleatorios',
  aliases: [],
  async execute({ q, args, reply, reagir, prefix }) {
    const texto = q || args.join(' ')
    const partes = texto.split(',').map(s => s.trim()).filter(Boolean)
    if (partes.length !== 2) return reply(caixaArlequina('anagrama', `❌ Uso: *${prefix}anagrama* palavra1, palavra2\n💡 Ex: *${prefix}anagrama* roma, amor`))
    await reagir('🔤')
    const saoAnagramas = normalizar(partes[0]) === normalizar(partes[1])
    await reply(caixaArlequina('anagrama', `🔤 "${partes[0]}" e "${partes[1]}"\n\n${saoAnagramas ? '✅ São anagramas!' : '❌ Não são anagramas.'}`))
  }
}
