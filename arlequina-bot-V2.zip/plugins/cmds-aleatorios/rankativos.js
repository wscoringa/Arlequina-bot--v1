/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: rankativos
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'rankativos',
description: "Rank dos mais ativos do grupo",
category: 'cmds-aleatorios',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  if (!from.endsWith('@g.us'))
  return reply(caixaArlequina("rankativos", `❌ Apenas em grupos.`))
  
  const grupo = await sock.groupMetadata(from)
  
  const ranking = grupo.participants.map(p => {
  
  const dados = donoState.ativos?.[p.id] || {
  mensagens: 0,
  comandos: 0,
  figurinhas: 0
  }
  
  const total =
  dados.mensagens +
  dados.comandos +
  dados.figurinhas
  
  return {
  jid: p.id,
  total,
  mensagens: dados.mensagens,
  comandos: dados.comandos,
  figurinhas: dados.figurinhas
  }
  
  }).sort((a,b) => b.total - a.total)
  
  let texto = `🏆 RANK ATIVOS DO GRUPO 🏆\n\n`
  
  const mentions = []
  
  ranking.forEach((u, i) => {
  
  mentions.push(u.jid)
  
  texto += `
  ${i + 1}° ➤ @${u.jid.split('@')[0]}
  
  💬 Mensagens: ${u.mensagens}
  ⌨️ Comandos: ${u.comandos}
  🖼️ Figurinhas: ${u.figurinhas}
  📊 Total: ${u.total}
  
  `
  })
  
  await enviar({
  text: texto,
  mentions
  },{quoted:msg})
} catch (e) {
console.log('❌ ERRO (rankativos):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
