const fs = require('fs')
const path = require('path')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

const PASTA = path.join(__dirname, '../../arquivos/JSONS +18')

function nomeArquivoSeguro(nome) {
  let n = String(nome || '').trim()
  n = n.normalize('NFD').replace(/\p{M}/gu, '')
  n = n.replace(/[^a-zA-Z0-9_\-]/g, '')
  if (!n) n = 'Extras'
  return n.charAt(0).toUpperCase() + n.slice(1)
}

/** Aceita praticamente qualquer URL */
function extrairUrls(texto) {
  const t = String(texto || '')
  const encontrados = []
  const re = /https?:\/\/[^\s<>"')\]]+/gi
  let m
  while ((m = re.exec(t)) !== null) {
    let u = m[0].replace(/[.,;:!?]+$/g, '')
    encontrados.push(u)
  }
  const re2 = /(?:^|\s)(www\.[^\s<>"')\]]+)/gi
  while ((m = re2.exec(t)) !== null) {
    let u = m[1].replace(/[.,;:!?]+$/g, '')
    encontrados.push('https://' + u)
  }
  return [...new Set(encontrados)]
}

function carregar(file) {
  try {
    if (!fs.existsSync(file)) return []
    const data = JSON.parse(fs.readFileSync(file, 'utf8'))
    return Array.isArray(data) ? data : []
  } catch {
    return []
  }
}

function salvar(file, arr) {
  fs.mkdirSync(path.dirname(file), { recursive: true })
  fs.writeFileSync(file, JSON.stringify(arr, null, 2), 'utf8')
}

function chuteTipo(url) {
  const u = (url || '').toLowerCase()
  if (/\.(mp4|webm|mov|m4v|mkv)(\?|$)/i.test(u) || u.includes('.mp4')) return 'video'
  if (/\.(jpg|jpeg|png|gif|webp|bmp)(\?|$)/i.test(u)) return 'image'
  return 'auto'
}

async function tentarResolver(url) {
  try {
    const res = await axios.get(url, {
      timeout: 12000,
      maxRedirects: 5,
      validateStatus: () => true,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
      },
      responseType: 'stream',
      maxContentLength: 500000
    })
    const finalUrl = res.request?.res?.responseUrl || res.request?.responseURL || url
    const ct = (res.headers['content-type'] || '').toLowerCase()
    try { res.data.destroy() } catch (_) {}
    let tipo = 'auto'
    if (ct.includes('video')) tipo = 'video'
    else if (ct.includes('image')) tipo = 'image'
    else tipo = chuteTipo(finalUrl)
    return { url: finalUrl || url, tipo, contentType: ct }
  } catch {
    return { url, tipo: chuteTipo(url), contentType: '' }
  }
}

module.exports = {
  name: 'addxv',
  description: 'Dono: adiciona qualquer link (foto/vídeo) numa categoria +18',
  category: 'dono',
  aliases: ['add18', 'addpack', 'addfoto18', 'addvideo18'],

  async execute({ reply, reagir, args, q, prefix, isDono }) {
    if (!isDono || (typeof isDono === 'function' && !isDono())) {
      return reply(caixaArlequina('+18', '❌ Só o *dono* pode usar este comando.'))
    }

    const texto = (q || args.join(' ') || '').trim()
    if (!texto) {
      return reply(caixaArlequina('ADD XV', `📌 *Uso (dono):*

*${prefix}addxv* NomeCategoria link
*${prefix}addxv* link

Aceita **qualquer link** http/https (e www.).

Exemplos:
*${prefix}addxv* Gabriela https://telegra.ph/file/xxx.jpg
*${prefix}addxv* Hentai https://cdn.site.com/a.mp4
*${prefix}addxv* https://qualquer.coisa/arquivo

⚠️ Na hora de *enviar*, o WhatsApp precisa baixar a mídia.
Preferira link *direto* de foto/vídeo.`))
    }

    const urls = extrairUrls(texto)
    if (!urls.length) {
      return reply(caixaArlequina('ADD XV', '❌ Não achei nenhum link. Use http:// ou https://'))
    }

    let nomeBruto = texto
    for (const u of urls) {
      nomeBruto = nomeBruto.replace(u, ' ')
    }
    nomeBruto = nomeBruto.replace(/\s+/g, ' ').trim()
    const categoria = nomeArquivoSeguro(nomeBruto || 'Extras')

    await reagir('📥')

    const file = path.join(PASTA, `${categoria}.json`)
    const lista = carregar(file)
    const adicionados = []
    const repetidos = []

    for (const raw of urls) {
      const resolvido = await tentarResolver(raw)
      const linkFinal = resolvido.url || raw
      if (lista.includes(linkFinal) || lista.includes(raw)) {
        repetidos.push(raw)
        continue
      }
      lista.push(linkFinal)
      adicionados.push({ link: linkFinal, tipo: resolvido.tipo })
    }

    if (!adicionados.length) {
      return reply(caixaArlequina('ADD XV', `⚠️ Nenhum link novo em *${categoria}*.`))
    }

    salvar(file, lista)

    const linhas = adicionados.map((a, i) => {
      const emoji = a.tipo === 'video' ? '🎥' : a.tipo === 'image' ? '🖼️' : '🔗'
      const short = a.link.length > 55 ? a.link.slice(0, 55) + '…' : a.link
      return `${emoji} ${i + 1}. ${short}`
    }).join('\n')

    return reply(caixaArlequina('ADD XV', `✅ *Salvo em ${categoria}*

${linhas}

📦 Total: *${lista.length}*
${repetidos.length ? `⚠️ Repetidos ignorados: ${repetidos.length}` : ''}

• Menu: *${prefix}menu18*
• Direto: *${prefix}${categoria}* _(reinicie se categoria nova)_`))
  }
}
