/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: ativo
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'ativo',
description: "Marca você como ativo",
category: 'cmds-aleatorios',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const senderAfkKey = (numeroReal || sender).replace(/[^0-9]/g, '')
  
  if (!donoState.afk || !donoState.afk[senderAfkKey]) {
  return reply('✅ Você não está AFK.')
  }
  
  const tempo = Date.now() - donoState.afk[senderAfkKey].inicio
  const minutos = Math.floor(tempo / 60000)
  
  delete donoState.afk[senderAfkKey]
  
  await enviar({
  text: `${caixaArlequina("ativo", `🔥 MODO ATIVO
  
  ⏳ Você ficou AFK por:
  ${minutos} minuto(s)
  
  ✅ Seu status AFK foi removido com sucesso.`)}`,
  mentions: [jidReal || jid]
  }, { quoted: msg })
} catch (e) {
console.log('❌ ERRO (ativo):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
