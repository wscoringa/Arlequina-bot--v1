const fs = require('fs')
const path = require('path')
const axios = require('axios')
const FormData = require('form-data')
const uploadImgbb = require('../../arquivos/js/imgbb.js')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'gerarlink',
description: 'Gera link de imagem ou vídeo usando Catbox',
category: 'cmds-aleatorios',
aliases: ['catbox', 'upload'],
async execute({ columbina, from, info, reply, reagir, getFileBuffer }) {

if (!info || !info.message) {
return reply('❌ Erro: mensagem não encontrada!')
}

var RSM = info.message?.extendedTextMessage?.contextInfo?.quotedMessage

var imagem = RSM?.imageMessage || 
info.message?.imageMessage || 
RSM?.viewOnceMessageV2?.message?.imageMessage || 
info.message?.viewOnceMessageV2?.message?.imageMessage || 
info.message?.viewOnceMessage?.message?.imageMessage || 
RSM?.viewOnceMessage?.message?.imageMessage

var video = RSM?.videoMessage || 
info.message?.videoMessage || 
RSM?.viewOnceMessageV2?.message?.videoMessage || 
info.message?.viewOnceMessageV2?.message?.videoMessage || 
info.message?.viewOnceMessage?.message?.videoMessage || 
RSM?.viewOnceMessage?.message?.videoMessage

async function uploadCatbox(buffer, ext) {
const tempPath = path.join(__dirname, `temp_${Date.now()}.${ext}`)

fs.writeFileSync(tempPath, buffer)

try {
const form = new FormData()

form.append('reqtype', 'fileupload')
form.append('fileToUpload', fs.createReadStream(tempPath))

const { data } = await axios.post(
'https://catbox.moe/user/api.php',
form,
{
headers: {
...form.getHeaders(),
'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0 Mobile Safari/537.36'
},
timeout: 30000
}
)

fs.unlinkSync(tempPath)

// BUGFIX: o Catbox às vezes responde 200 OK com um texto de erro (ou
// vazio) em vez do link — antes o bot mandava isso direto sem checar,
// por isso às vezes chegava "Link da imagem:" sem link nenhum. Agora
// valida se realmente veio uma URL antes de aceitar a resposta.
if (typeof data === 'string' && data.trim().startsWith('http')) return data.trim()
throw new Error(`Catbox não retornou um link válido (respondeu: "${String(data).slice(0, 100)}")`)
} catch (err) {
if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath)
throw err
}
}

// Serviço alternativo (0x0.st), usado só se o Catbox falhar — pra não
// deixar a pessoa sem link nenhum se um dos dois estiver fora do ar.
async function uploadAlternativo(buffer, ext) {
const form = new FormData()
form.append('file', buffer, `arquivo.${ext}`)
const { data } = await axios.post('https://0x0.st', form, {
headers: { ...form.getHeaders(), 'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0 Mobile Safari/537.36' },
timeout: 30000
})
if (typeof data === 'string' && data.trim().startsWith('http')) return data.trim()
throw new Error('Serviço alternativo também não retornou um link válido.')
}

async function gerarLinkComFallback(buffer, ext, ehImagem) {
  const erros = []
  try {
    return await uploadCatbox(buffer, ext)
  } catch (eCatbox) {
    erros.push(`Catbox: ${eCatbox?.message}`)
  }

  try {
    return await uploadAlternativo(buffer, ext)
  } catch (eAlt) {
    erros.push(`0x0.st: ${eAlt?.message}`)
  }

  // imgbb só aceita imagem, não vídeo — é a última tentativa
  if (ehImagem) {
    try {
      const resultado = await uploadImgbb(buffer)
      if (resultado?.url) return resultado.url
      erros.push('imgbb: não retornou link válido')
    } catch (eImgbb) {
      erros.push(`imgbb: ${eImgbb?.message}`)
    }
  }

  console.log('❌ Todos os serviços de upload falharam:', erros.join(' | '))
  throw new Error(`Todos os serviços de upload estão fora do ar ou bloqueando agora. Tenta de novo em alguns minutos.`)
}

try {

if (imagem) {
await reagir('⏰')

const buffer = await getFileBuffer(imagem, 'image')

let mimetype = imagem.mimetype || 'image/png'
let ext = mimetype.split('/')[1]

const link = await gerarLinkComFallback(buffer, ext, true)

await reagir('✅')

return reply(`${caixaArlequina("gerarlink", `🖼️ Link da imagem:\n${link}`)}`)
}

else if (video) {
await reagir('⏰')

const buffer = await getFileBuffer(video, 'video')

let mimetype = video.mimetype || 'video/mp4'
let ext = mimetype.split('/')[1]

const link = await gerarLinkComFallback(buffer, ext, false)

await reagir('✅')

return reply(`🎥 Link do vídeo:\n${link}`)
}

else {
return reply('❌ Envie ou marque uma imagem/vídeo com o comando!')
}

} catch (err) {
console.error('Erro gerarlink:', err)
reply(`❌ Erro ao gerar link:\n${err.message}`)
}

}
}