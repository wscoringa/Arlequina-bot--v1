/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: usar
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'usar',
description: "Usa um item do seu inventário",
category: 'cmds-aleatorios',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const item = args[0]?.toLowerCase()
  
  if (!item)
  return
  
  const pos =
  usuarios[sender].inventario.indexOf(item)
  
  if (pos === -1) {
  return enviar({
  text:'❌ Você não possui esse item.'
  },{quoted:msg})
  }
  
  if (item === 'pocao') {
  
  usuarios[sender].vida += 50
  
  } else if (item === 'superpocao') {
  
  usuarios[sender].vida += 150
  
  } else if (item === 'espada') {
  
  usuarios[sender].forca += 10
  
  } else if (item === 'katana') {
  
  usuarios[sender].forca += 25
  
  } else if (item === 'excalibur') {
  
  usuarios[sender].forca += 60
  
  } else if (item === 'escudo') {
  
  usuarios[sender].defesa += 8
  
  } else if (item === 'armadura') {
  
  usuarios[sender].defesa += 20
  
  } else if (item === 'anel') {
  
  usuarios[sender].xp += 500
  
  } else if (item === 'amuleto') {
  
  usuarios[sender].xp += 1000
  
  }
  
  usuarios[sender].inventario.splice(pos,1)
  
  await enviar({
  text:`${caixaArlequina("usar", `⚡ ITEM UTILIZADO
  
  📦 ${item}
  
  ✅ Efeito aplicado com sucesso.`)}`
  },{quoted:msg})
} catch (e) {
console.log('❌ ERRO (usar):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
