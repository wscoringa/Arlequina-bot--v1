const { criarPerfilCard } = require('../../arquivos/js/perfilCard.js')

module.exports = criarPerfilCard({
  name: 'perfilzoeira',
  titulo: 'Perfil Zoeira',
  emoji: '🤡',
  aliases: [],
  traços: [
    { emoji: '🧠', label: 'Apelido', opcoes: ['Lenda da Praça', 'Cringe Nível Máximo', 'Mente Iluminada (SQN)', 'Rei do Ctrl+C Ctrl+V', 'Gado Certificado 🐄', 'Zé das Figurinhas'] },
    { emoji: '❌', label: 'Ponto fraco', opcoes: ['Trava até em "kkk"', 'Confunde tudo com fake news', 'Vive no visto', 'Só sabe mandar áudio de 5 min', 'Levou ban em 3 grupos essa semana'] },
    { emoji: '📱', label: 'Hobby', opcoes: ['Dormir em call', 'Ver status alheio 24h', 'Reenviar corrente antiga', 'Brigar em comentário', 'Print de conversa sem contexto'] },
    { emoji: '🗯️', label: 'Frase clássica', opcoes: ['"Tamo junto é nóis"', '"Fala tu, patrão"', '"Nunca critiquei ninguém"', '"Isso não é comigo"', '"Depois eu leio"'] },
    { emoji: '🍽️', label: 'Comida favorita', opcoes: ['Miojo cru', 'Água com açúcar', 'Pizza fria de ontem', 'Salgadinho com refri quente', 'Bolacha com café requentado'] }
  ]
})
