const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'ddd',
  description: '📞 Descobre estado/cidades de um DDD',
  category: 'cmds-aleatorios',
  aliases: ['dddlist'],
  async execute({ args, reply, reagir, prefix }) {
    const ddd = (args[0] || '').replace(/\D/g, '')
    if (!ddd || ddd.length !== 2) return reply(caixaArlequina('ddd', `❌ DDD inválido.\n💡 Ex: *${prefix}ddd* 31`))
    try {
      await reagir('📞')
      const { data } = await axios.get(`https://brasilapi.com.br/api/ddd/v1/${ddd}`, { timeout: 10000 })
      const cidades = data.cities.slice(0, 15).join(', ')
      await reply(caixaArlequina('ddd', `📞 *DDD ${ddd}*\n\n🗺️ Estado: ${data.state}\n🏙️ Cidades: ${cidades}${data.cities.length > 15 ? '...' : ''}`))
    } catch (e) {
      await reply('❌ DDD não encontrado ou serviço fora do ar.')
    }
  }
}
