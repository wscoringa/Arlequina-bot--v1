const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
  name: 'idade',
  description: '🎂 Calcula sua idade a partir da data de nascimento',
  category: 'cmds-aleatorios',
  aliases: [],
  async execute({ args, reply, reagir, prefix }) {
    const dataStr = args[0]
    if (!dataStr || !/^\d{2}\/\d{2}\/\d{4}$/.test(dataStr)) {
      return reply(caixaArlequina('idade', `❌ Uso: *${prefix}idade* dd/mm/aaaa\n💡 Ex: *${prefix}idade* 15/03/2000`))
    }
    const [dia, mes, ano] = dataStr.split('/').map(Number)
    const nascimento = new Date(ano, mes - 1, dia)
    if (isNaN(nascimento.getTime()) || nascimento > new Date()) return reply('❌ Data inválida.')

    await reagir('🎂')
    const hoje = new Date()
    let idade = hoje.getFullYear() - nascimento.getFullYear()
    const aindaNaoFezAniversario = (hoje.getMonth() < nascimento.getMonth()) ||
      (hoje.getMonth() === nascimento.getMonth() && hoje.getDate() < nascimento.getDate())
    if (aindaNaoFezAniversario) idade--

    const proximoAniversario = new Date(hoje.getFullYear(), nascimento.getMonth(), nascimento.getDate())
    if (proximoAniversario < hoje) proximoAniversario.setFullYear(hoje.getFullYear() + 1)
    const diasFaltando = Math.ceil((proximoAniversario - hoje) / (1000 * 60 * 60 * 24))

    await reply(caixaArlequina('idade', `🎂 *SUA IDADE*\n\n🎈 Você tem *${idade} anos*\n📅 Faltam *${diasFaltando} dias* pro seu próximo aniversário`))
  }
}
