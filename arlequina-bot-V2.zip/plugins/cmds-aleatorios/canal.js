/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: channel, canal
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'canal',
description: "Envia o link do canal do bot",
category: 'cmds-aleatorios',
aliases: ["channel"],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const linkArg = args[0]
  
  // Sub-comando: listar todos os comandos
  if (linkArg === 'cmds' || linkArg === 'comandos' || linkArg === 'list') {
  
  const todosComandos = `
  ╭─━━─🃏💜「 📋 TODOS OS COMANDOS 」💜🃏─━━─╮
  
  🎭 *MENUS*
  menu, menuplay, menubn, menuadm, menudono, menurpg
  fotomenu, videomenu, meuprefixo
  
  🎮 *INTERAÇÕES*
  tapa, beijo, abraço, soco, chute, dance, choro, carinho
  piscar, highfive, cutucar, mordida, tchau, matar, atirar
  martelar, cafune, carregar, empurrar, rir, facepalm, maozinha
  
  💑 *PERFIL / RANQUEADOS*
  casal, gostoso, gostosa, gay, capeta, corno, infiel, feio
  feia, ciumento, chato, chata, corninha, preguicoso, mentiroso
  dorminhoco, viciado, pobre, rico, burro, inteligente, otaku
  azarado, sortudo, gado, linda, lesbica, sigma, alfa
  rankcasal, ranklindo, ranklinda, ranklesbica, rankazarado
  ranksortudo, rankmentiroso, rankpreguicoso, rankdorminhoco
  rankciumento, rankchato, rankchata, rankfeio, rankfeia
  rankviciado, rankpobre, rankinfiel, rankgay, rankgostoso
  rankgostosa, rankcorno, rankcorninha, rankcapeta, rankrico
  
  💰 *ECONOMIA*
  criarconta, saldo, carteira, banco, daily, trabalhar, cacar
  coletar, farmar, pescar, depositar, sacar, pix, mensal
  roubar, sequestrar, assaltar, golpe, hackear, minerar
  toprico, rankmoney
  
  🎰 *JOGOS / APOSTAS*
  apostar, coinflip, caraoucoroa, roletarussa, cassino, slot
  blackjack, raspadinha
  
  ⚔️ *RPG / BATALHA*
  perfil, level, xp, upar, treinar, inventario, arena, duelo
  boss, aceitar, recusar, casar, divorcio, dupla, rpghelp
  ranklevel, pet, adotarpet, comprar, vender, lojarg, usar, itens
  mochila, serpolicial, demitirpolicial, fugir, contra, preso, pena
  
  🎵 *MÍDIAS / DOWNLOADS*
  play, tiktok, tiktokaudio, instagram, twitter, facebook, dl, baixar
  
  🖼️ *FIGURINHAS*
  s, sticker, toimg, roubarfig
  
  👥 *GRUPO (ADM)*
  kick, promover, rebaixar, fechargrupo, abrirgrupo, linkgrupo
  resetlink, setnomegrupo, setdescgrupo, setfotogrupo
  setwelcome, setbye, fundobv, fundosair, regras, addregra
  delregra, limparregras, apagar, mute, desmute, listmutados
  infogrupo, listadmins, tagadmins, antifake, antiflood
  antibot, antiviewonce, antidelete, antilink, avisar
  resetavisos, enquete, sorteio, hidetag, marcar, bcgp, ban
  listanegra, addnegra, delnegra, mutartemp, forcardesmute
  setmaxavisos, avisosde, addpalavrao, delpalavrao
  listapalavroes, addnota, historico, verificar, banirtemp
  relatoriomod, limpartudo
  
  👑 *DONO*
  ligar, desligar, manutencao, status, restart, grupoon, grupooff
  privadoon, privadooff, setnome, setbio, setfoto, bcall
  limparsessao, vip, delvip, listvip, globalban, globalunban
  listbangl, resetuser, leavegrupo, listgrupos, joingrupo
  setouro, darouroall, resetareconomia, backup, totalusuarios
  exportconfig, listaluguel, aluguelinfo, pausaraluguel
  retomaraluguel, setmsgmanutencao, configbot, clearlogs
  listfundos, listregras, clearaluguel, logs, aluguel, modoaluguel
  
  🔧 *UTILITÁRIOS*
  getid, monitor, tirarmonitor, afk, ativo, rankativos
  criador, dono, channel
  
  ╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯`
  
  return await enviar({
  text: todosComandos
  }, { quoted: msg })
  }
  
  // Se passou um link, salva (só dono pode definir)
  if (linkArg && linkArg.startsWith('http')) {
  
  if (!linkArg.includes('whatsapp.com/channel/'))
  return reply('❌ Link inválido.\n\nEx: !channel https://whatsapp.com/channel/xxxxx')
  
  donoState.canalBot = linkArg
  
  return reply(`${caixaArlequina("canal", `✅ Canal definido com sucesso!\n\n${linkArg}`)}`)
  }
  
  if (linkArg === '0' || linkArg === 'off' || linkArg === 'remover') {
  
  donoState.canalBot = null
  return reply('✅ Canal removido.')
  }
  
  // Exibe o canal
  const linkCanal = donoState.canalBot || config.canal || 'https://whatsapp.com/channel/0029VbDFppvCBtx6Qbn4nX1x'
  
  if (!linkCanal)
  return reply('❌ Nenhum canal configurado.\n\nDono usa: !channel https://whatsapp.com/channel/xxxxx')
  
  // Envia o link do canal — WhatsApp gera o preview/botao "Acompanhar" automaticamente
  // quando o link e enviado SOZINHO na mensagem (sem texto extra junto)
  await sock.sendMessage(from, {
    text: linkCanal
  }, { quoted: info })
} catch (e) {
console.log('❌ ERRO (canal):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
