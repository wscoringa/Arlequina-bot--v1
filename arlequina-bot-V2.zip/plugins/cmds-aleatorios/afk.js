/*
 Convertido automaticamente do connect.js (bot antigo monolitico) para
 o sistema de plugins da Arlequina Bot. Comando original: afk
*/
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('../../arquivos/js/rpgDB.js')
const adminState = require('../../arquivos/js/adminState.js')
const donoState = require('../../arquivos/js/donoState.js')
const { imagemDaBrincadeira, buscarImagemAleatoria } = require('../../arquivos/js/brincadeirasHelpers.js')
const fs = require('fs')
const axios = require('axios')
const { caixaArlequina } = require('../../arquivos/js/estiloArlequina')

module.exports = {
name: 'afk',
description: "Marca você como ausente (AFK)",
category: 'cmds-aleatorios',
aliases: [],
async execute({ arlequina, from, info, args, q, reply, reagir, prefix, sender, pushname, isGroup, donoJid, commandManager, config, getFileBuffer, sleep, fetchJson }) {

const sock = arlequina
const msg = info
const jid = sender
const jidReal = sender
const numeroReal = String(sender || '').split('@')[0]
const isGrupo = isGroup
const nome = pushname
const texto = q || args.join(' ')
const baixarMidia = (mediaMsg, tipo) => getFileBuffer(mediaMsg, tipo)

const ehDono = (jidAlvo, numeroAlvo) => {
const donoNum = String(donoJid || '').replace(/[^0-9]/g, '')
const num = String(numeroAlvo || '').replace(/[^0-9]/g, '')
return (donoNum && num === donoNum) || jidAlvo === donoJid
}

const usuarios = carregarUsuarios()
getUsuario(usuarios, sender)

const enviar = async (conteudo, _opcoes) => {
if (typeof conteudo === 'string') return reply(conteudo)
try {
return await sock.sendMessage(from, conteudo, { quoted: info })
} catch (e) {
const fallback = conteudo?.caption || conteudo?.text || '✅'
return reply(fallback)
}
}

try {
  const motivo = args.join(' ') || 'Sem motivo informado'

  // BUGFIX: o WhatsApp às vezes identifica a mesma pessoa com IDs
  // diferentes dependendo de onde a mensagem vem (número de telefone
  // "normal" vs o novo "LID" de privacidade). Antes só guardava o AFK
  // sob um formato só, então se uma marcação (@) ou a mensagem de volta
  // chegasse com o outro formato, o bot não reconhecia. Agora guarda o
  // mesmo registro sob todos os IDs que a gente conseguir identificar.
  const candidatos = new Set()
  const addCandidato = (jidLike) => {
    const num = String(jidLike || '').split('@')[0].replace(/[^0-9]/g, '')
    if (num) candidatos.add(num)
  }
  addCandidato(sender)
  addCandidato(numeroReal)
  addCandidato(msg?.key?.participant)
  addCandidato(msg?.key?.participantAlt)
  if (!isGrupo) {
    addCandidato(msg?.key?.remoteJid)
    addCandidato(msg?.key?.remoteJidAlt)
  }

  const registroAfk = {
  inicio: Date.now(),
  motivo,
  jid: jidReal || jid
  }

  // Guarda o AFK separado por chat (grupo/DM onde foi ativado), não mais
  // um único registro global — assim, ficar AFK no Grupo A não é afetado
  // por mandar mensagem no Grupo B.
  for (const num of candidatos) {
    if (!donoState.afk[num] || typeof donoState.afk[num].inicio === 'number') donoState.afk[num] = {}
    donoState.afk[num][from] = registroAfk
  }
  if (typeof donoState.salvar === 'function') donoState.salvar()

  await enviar({
  text: `${caixaArlequina("afk", `😴 MODO AFK ATIVADO
  
  👤 ${nome}
  📝 Motivo: ${motivo}
  
  💜 Se alguém te marcar, eu aviso que você está AFK.
  Quando voltar, é só mandar qualquer mensagem.`)}`
  }, { quoted: msg })
} catch (e) {
console.log('❌ ERRO (afk):', e?.message)
await reply('❌ Não consegui executar esse comando agora.')
} finally {
salvarUsuarios(usuarios)
}

}
}
