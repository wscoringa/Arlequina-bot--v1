const { criarPerfilCard } = require('../../arquivos/js/perfilCard.js')

module.exports = criarPerfilCard({
  name: 'perfilgenio',
  titulo: 'Perfil Gênio',
  emoji: '🧠',
  aliases: ['perfilgênio'],
  traços: [
    { emoji: '📚', label: 'QI estimado', opcoes: ['Consultou o Google 5x', 'Sabe o resultado antes da conta', 'Chuta e acerta', 'Copia e cola com estilo', 'Nasceu sabendo (talvez)'] },
    { emoji: '🔬', label: 'Área de estudo', opcoes: ['Física quântica do boteco', 'Filosofia de grupo de zap', 'Matemática do fiado', 'Engenharia de desculpa', 'Doutorado em enrolar'] },
    { emoji: '💡', label: 'Última descoberta', opcoes: ['Que café não substitui sono', 'Que segunda-feira sempre chega', 'Que wi-fi cai na pior hora', 'A fórmula de nunca errar (mentira)', 'Que procrastinar também é arte'] },
    { emoji: '🏅', label: 'Prêmio', opcoes: ['Nobel do Óbvio', 'Medalha de Participação', 'Troféu de Última Hora', 'Diploma de Google Acadêmico', 'Certificado de Sabe Tudo (SQN)'] },
    { emoji: '🗣️', label: 'Frase icônica', opcoes: ['"Eu já sabia disso"', '"Isso é básico"', '"Deixa que eu explico"', '"Na teoria funciona"', '"Confia no processo"'] }
  ]
})
