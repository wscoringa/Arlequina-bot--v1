require('./arquivos/js/suprimirLogsSensiveis.js')
const { caixaElegante } = require('./arquivos/js/estiloArlequina.js')
const fs = require('fs')
const path = require('path')
const colors = require('colors')
const moment = require('moment')
const { exec } = require('child_process')
const chokidar = require('chokidar')
const axios = require('axios')

const config = JSON.parse(fs.readFileSync('./database/config.json'))
const GerenciadorDeCmds = require('./comandos.js')
const startConnection = require('./conexao.js')
const { AddWhatsAppuser, convertWhatsAppUser, getname } = require('./arquivos/js/userManager.js')
const { registrarAtividade } = require('./arquivos/js/atividadeManager.js')
const { podeSpawnar, criarSpawn, DURACAO_EVENTO_MS } = require('./arquivos/js/eventosRPG.js')
const { porNome: pokePorNome, imagemUrl: pokeImagemUrl, buscarDexIdOnline: pokeBuscarDexIdOnline } = require('./arquivos/js/pokedexData.js')
const { formatarDuracao } = require('./arquivos/js/afkHelper.js')
const { sessoesQuiz, sessoesHangman, sessoesAdivinha, adicionarPonto } = require('./arquivos/js/quizManager.js')
const { enviarQuizImg, jogadaForca, MAX_ERROS } = require('./arquivos/js/quizImagem.js')
const { getGroupAdmins, getMembros, getPhoneNumberFromId, getMemberName, getFileBuffer, sleep, fetchJson, getRandom, addNumberMais, identArroba, inputToJid } = require('./arquivos/js/exports.js')
const { CyanLog, RedLog, GreenLog } = require('./arquivos/js/logger.js')
const { sendImageAsSticker2, sendVideoAsSticker2 } = require('./arquivos/js/exif2.js')
const { aplicarVerCanal } = require('./arquivos/js/verCanal.js')
const { aplicarMetaMark } = require('./arquivos/js/metaMark.js')
if (typeof global.ENABLE_CHANNEL === 'undefined') global.ENABLE_CHANNEL = true
const donoState = require('./arquivos/js/donoState.js')
const adminState = require('./arquivos/js/adminState.js')
const antideleteCache = require('./arquivos/js/antideleteCache.js')
const { reenviarMensagemApagada } = require('./arquivos/js/antideleteHandler.js')
const { detectarLink, linkBloqueado, pareceOutroBot, extrairTextoProfundo, ehMensagemPagamento, registrarAdvertencia } = require('./arquivos/js/protecoes.js')
const antipyHandler = require('./arquivos/js/antipyHandler.js')
const parceirosDB = require('./arquivos/js/parceirosDB.js')
const { iniciarAgendaGrupoScheduler } = require('./arquivos/js/agendaGrupoManager.js')

const gerenciadorComandos = new GerenciadorDeCmds()
gerenciadorComandos.carregarPlugins()

const donoJid = identArroba(config.NumeroDoDono)






global.lidParaNumero = global.lidParaNumero || {}

let columbina = null


const criticalFiles = [
'./index.js',
'./database/config.json',
'./conexao.js',
'./arquivos/js/exports.js',
'./comandos.js',
'./arquivos/js/userManager.js',
'./arquivos/js/logger.js',
'./arquivos/js/exif2.js'
]

const criticalWatcher = chokidar.watch(criticalFiles, { 
persistent: true, 
ignoreInitial: true,
awaitWriteFinish: true
})

criticalWatcher.on('change', (filePath) => {
const fileName = path.basename(filePath)
CyanLog(`💜Arquivo critico alterado: ${fileName}`)
CyanLog(`🃏 Reiniciando Arlequina em 2 segundos para aplicar mudancas...`) 

if (columbina) {
try {
const donoId = donoJid || (columbina.user?.id?.split(':')[0] + '@s.whatsapp.net')
columbina.sendMessage(donoId, {text: `🔄 *ARQUIVO CRITICO ALTERADO*\n\n📁 Arquivo: \`${fileName}\`\n⏰ Arlequina sera reiniciada em 2 segundos.\n\n📌 Use \`sh start.sh\` ou \`sh start.sh cod\` para iniciar novamente.` 
}).catch(() => {})
} catch(e) {}
}

setTimeout(() => {
CyanLog(`💜 Encerrando processo para reiniciar...`)
process.exit(0)
}, 2000)
})

criticalWatcher.on('add', (filePath) => {
if (criticalFiles.includes(filePath)) {
CyanLog(`📁 Arquivo crítico adicionado: ${path.basename(filePath)}`)
setTimeout(() => process.exit(0), 2000)
}
})

criticalWatcher.on('unlink', (filePath) => {
if (criticalFiles.includes(filePath)) {
CyanLog(`🗑️ Arquivo critico removido: ${path.basename(filePath)}`)
setTimeout(() => process.exit(0), 2000)
}
})


const watcher = chokidar.watch('./plugins', { 
persistent: true, 
ignoreInitial: true,
depth: 99,
awaitWriteFinish: true
})

watcher.on('add', (filePath) => {
if (filePath.endsWith('.js')) {
CyanLog(`📁 Plugin adicionado: ${path.basename(filePath)}`)
Object.keys(require.cache).forEach(key => {
if (key.includes(filePath)) delete require.cache[key]
})
gerenciadorComandos.carregarPlugins()
}
})

watcher.on('change', (filePath) => {
if (filePath.endsWith('.js')) {
CyanLog(`📝 Plugin alterado: ${path.basename(filePath)}`)
Object.keys(require.cache).forEach(key => {
if (key.includes(filePath)) delete require.cache[key]
})
gerenciadorComandos.carregarPlugins()
}
})

watcher.on('unlink', (filePath) => {
if (filePath.endsWith('.js')) {
CyanLog(`🗑️ Plugin removido: ${path.basename(filePath)}`)
gerenciadorComandos.carregarPlugins()
}
})


const logMessage = (type, data) => {
const agora = new Date()
const dataStr = agora.toLocaleDateString('pt-BR')
const horaStr = agora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })

const logTemplate = (nome, grupo, pv, comando, mensagem) => {
const NomeColorido = `\x1b[34m${nome}\x1b[0m`
const GrupoColorido = grupo ? `\x1b[32m${grupo}\x1b[0m` : ''
const PvColorido = pv ? `\x1b[34mPV\x1b[0m` : ''
const ComandoColorido = comando ? `\x1b[33m${comando}\x1b[0m` : ''
const MensagemColorida = mensagem ? `\x1b[34m${mensagem}\x1b[0m` : ''
const DataColorida = `\x1b[34m${dataStr}\x1b[0m`
const HoraColorida = `\x1b[34m${horaStr}\x1b[0m`

if (type === 'comando_grupo') {
console.log(`\n╭──────────────────᯽\n│💜╭─────────────ᝰ\n│🃏│NOME: ${NomeColorido}\n│💜│GRUPO: ${GrupoColorido}\n│🃏│COMANDO: ${ComandoColorido}\n│💜│DATA: ${DataColorida}\n│🃏│HORA: ${HoraColorida}\n│💜╰────────────ᝰ\n╰──────────────────᯽`)
} else if (type === 'comando_pv') {
console.log(`\n╭──────────────────᯽\n│🃏╭─────────────ᝰ\n│💜│NOME: ${NomeColorido}\n│🃏│PV: ${PvColorido}\n│💜│COMANDO: ${ComandoColorido}\n│🃏│DATA: ${DataColorida}\n│💜│HORA: ${HoraColorida}\n│🃏╰────────────ᝰ\n╰──────────────────᯽`)
} else if (type === 'msg_grupo') {
console.log(`\n╭──────────────────᯽\n│💜╭─────────────ᝰ\n│🃏│NOME: ${NomeColorido}\n│💜│GRUPO: ${GrupoColorido}\n│🃏│MENSAGEM: ${MensagemColorida}\n│💜│DATA: ${DataColorida}\n│🃏│HORA: ${HoraColorida}\n│💜╰────────────ᝰ\n╰──────────────────᯽`)
} else if (type === 'msg_pv') {
console.log(`\n╭──────────────────᯽\n│🃏╭─────────────ᝰ\n│💜│NOME: ${NomeColorido}\n│🃏│PV: ${PvColorido}\n│💜│MENSAGEM: ${MensagemColorida}\n│🃏│DATA: ${DataColorida}\n│💜│HORA: ${HoraColorida}\n│🃏╰────────────ᝰ\n╰──────────────────᯽`)
}
}

if (type === 'comando_grupo') {
logTemplate(data.nome, data.grupo, null, data.comando, null)
} else if (type === 'comando_pv') {
logTemplate(data.nome, null, 'PV', data.comando, null)
} else if (type === 'msg_grupo') {
logTemplate(data.nome, data.grupo, null, null, data.mensagem)
} else if (type === 'msg_pv') {
logTemplate(data.nome, null, 'PV', null, data.mensagem)
}
}

const AudioMisheru = async (source, quotedMsg, from) => {
if (!columbina || !from) return
try {
if (!fs.existsSync('./temp')) fs.mkdirSync('./temp')
let inputFile
if (source.includes("http")) {
const response = await axios({ url: source, method: 'GET', responseType: 'arraybuffer' })
inputFile = `./temp/src_${Date.now()}.mp3`
fs.writeFileSync(inputFile, response.data)
} else {
inputFile = path.resolve(source)
}
const outputFile = `./temp/voice_${Date.now()}.ogg`
await new Promise((resolve, reject) => {
const ffChild = exec(`ffmpeg -i "${inputFile}" -vn -c:a libopus -b:a 128k "${outputFile}"`, { timeout: 15000, killSignal: 'SIGKILL' }, (err) => {
if (err) return reject(err)
resolve()
})
setTimeout(() => { try { ffChild.kill('SIGKILL') } catch(_) {} }, 17000)
})
const audioBuffer = fs.readFileSync(outputFile)
await columbina.sendMessage(from, {audio: audioBuffer, mimetype: 'audio/ogg; codecs=opus', ptt: true}, {quoted: quotedMsg})
if (inputFile.includes('./temp/') && fs.existsSync(inputFile)) fs.unlinkSync(inputFile)
if (fs.existsSync(outputFile)) fs.unlinkSync(outputFile)
} catch (err) { RedLog(`AudioMisheru error: ${err}`) }
}

const reagir = async (emj, from, info) => {
if (!columbina || !from) return
try {
await columbina.sendMessage(from, {react: {text: emj, key: info.key}})
} catch (e) {}
}

const reply = (text, from, info) => {
if (!columbina || !from) return





const numerosEncontrados = [...String(text).matchAll(/@(\d{7,15})/g)].map(m => m[1])
const mentions = numerosEncontrados.length
  ? [...new Set(numerosEncontrados)].map(n => `${n}@s.whatsapp.net`)
  : undefined
columbina.sendMessage(from, mentions ? { text, mentions } : { text })
}

const enviar = reply

const mencionarIMG = async (teks, Url, ms, from, columbina) => {
let memberr = []
let vy = teks.includes('\n') ? teks.split('\n') : [teks]
for (let vz of vy) {
for (let zn of vz.split(' ')) {
if (zn.includes('@')) memberr.push(identArroba(zn.split('@')[1]))
}
}
await columbina.sendMessage(from, {image: {url: Url}, caption: teks.trim(), mentions: memberr}, {quoted: ms})
}

const getBotNumber = () => columbina?.user?.id?.split(':')[0] || ''

const isDono = (sender) => {
const senderNum = String(sender || '').split('@')[0].replace(/[^0-9]/g, '')
if (!senderNum) return false
const donoNum = String(donoJid || '').split('@')[0].replace(/[^0-9]/g, '')
if (senderNum === donoNum) return true

const extras = donoState.donosExtras || {}
return Object.values(extras).some(num => num && String(num).replace(/[^0-9]/g, '') === senderNum)
}

const isAdm = (sender, groupAdmins) => {
if (isDono(sender)) return true
return groupAdmins?.includes(sender) || false
}

process.on('uncaughtException', (err) => RedLog(`Uncaught Exception: ${err.message}`))
process.on('unhandledRejection', (reason) => RedLog(`Unhandled Rejection: ${reason}`))

async function processMessage(upsert, conn) {
columbina = conn
aplicarVerCanal(columbina)
aplicarMetaMark(columbina)

const isBotLigado = global.botLigado !== undefined ? global.botLigado : true

const messages = upsert.messages
const info = messages[0]


try { global.__ultimoUpsertMessages = messages } catch (_) {}

if (!info.message) return







if (!global.mensagensProcessadas) global.mensagensProcessadas = new Set()
const idMensagemAtual = info.key?.id
if (idMensagemAtual) {
if (global.mensagensProcessadas.has(idMensagemAtual)) return
global.mensagensProcessadas.add(idMensagemAtual)

if (global.mensagensProcessadas.size > 2000) {
  global.mensagensProcessadas = new Set(Array.from(global.mensagensProcessadas).slice(-1000))
}
}

const pushname = info.pushName || 'Usuário'
const from = info.key.remoteJid
const isGroup = from?.endsWith('@g.us') || false
const type = Object.keys(info.message)[0]






if (info.message.protocolMessage?.type === 0 && isGroup && adminState.antidelete?.[from]) {
  try {
    const idApagada = info.message.protocolMessage.key?.id
    const mensagemOriginal = idApagada ? antideleteCache.buscar(idApagada) : null
    const quemApagou = info.key.participant || info.participant || info.key.remoteJid
    if (mensagemOriginal && quemApagou) {
      await reenviarMensagemApagada(columbina, from, quemApagou, mensagemOriginal)
    }
  } catch (eAntidelete) {
    console.log('❌ ERRO (antidelete):', eAntidelete?.message)
  }
  return
}
if (isGroup) antideleteCache.guardar(info)

let body = ""

try {
body =
info.message?.conversation || info.message?.extendedTextMessage?.text || info.message?.imageMessage?.caption || info.message?.videoMessage?.caption || info.message?.documentWithCaptionMessage?.message?.documentMessage?.caption || info.message?.viewOnceMessageV2?.message?.imageMessage?.caption || info.message?.viewOnceMessageV2?.message?.videoMessage?.caption || info.message?.viewOnceMessage?.message?.imageMessage?.caption || info.message?.viewOnceMessage?.message?.videoMessage?.caption || info.message?.buttonsResponseMessage?.selectedButtonId || info.message?.listResponseMessage?.singleSelectReply?.selectedRowId || info.message?.templateButtonReplyMessage?.selectedId || info.message?.editedMessage?.message?.protocolMessage?.editedMessage?.extendedTextMessage?.text || info.message?.editedMessage?.message?.protocolMessage?.editedMessage?.imageMessage?.caption || JSON.parse(info.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson || '{}')?.id || JSON.parse(info.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson || '{}')?.selectedId || info?.text ||
""
} catch {
body = ""
}





if (!body && info.message) {
  try { body = extrairTextoProfundo(info.message) } catch (_e) {}
}



if (isGroup && !info.key?.fromMe && body) {
  try {
    const { carregarUsuarios, salvarUsuarios, getUsuario } = require('./arquivos/js/rpgDB.js')
    const usuariosMsgCount = carregarUsuarios()
    const uMsgCount = getUsuario(usuariosMsgCount, sender)
    uMsgCount.mensagensContadas = (uMsgCount.mensagensContadas || 0) + 1
    salvarUsuarios(usuariosMsgCount)
  } catch (_eContador) {}
}


if (donoState.botStatus?.modoVisualGlobal && !info.key?.fromMe) {
  try {
    await columbina.readMessages([info.key])
  } catch (_eVis) {}
} else if (isGroup && donoState.botStatus?.modoVisualGrupos?.[from] && !info.key?.fromMe) {
  try {
    await columbina.readMessages([info.key])
  } catch (_eVis) {}
}


const botNumber = getBotNumber()

let prefix = config.prefix
if (isGroup) {
const groupPrefix = gerenciadorComandos.ObterPrefixoGrupo(from)
if (groupPrefix) prefix = groupPrefix
}

const quotedMsg = info.message?.extendedTextMessage?.contextInfo?.quotedMessage
const isQuotedSticker = !!quotedMsg?.stickerMessage
const isQuotedImage = !!quotedMsg?.imageMessage
const isQuotedVideo = !!quotedMsg?.videoMessage
const isQuotedAudio = !!quotedMsg?.audioMessage
const isQuotedDocument = !!quotedMsg?.documentMessage






if (!body && info.message?.stickerMessage) {
  try {
    const { buscarComando } = require('./arquivos/js/figComandos.js')
    const comandoDaFig = buscarComando(info.message.stickerMessage)
    if (comandoDaFig) body = `${prefix}${comandoDaFig}`
  } catch (eFig) {
    console.log('❌ ERRO ao checar figurinha registrada:', eFig?.message)
  }
}





if (body && body.trim().toLowerCase() === 'b') {
  const temAlvo = info.message?.extendedTextMessage?.contextInfo?.participant ||
    info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
  if (temAlvo) body = `${prefix}ban`
}

const bodyOriginal = body || ""
const isCommand = bodyOriginal.startsWith(prefix)





if (info.key?.fromMe && !bodyOriginal.startsWith(prefix)) return

const budy = bodyOriginal
.normalize('NFD')
.replace(/[\u0300-\u036f]/g,'')






let sender = info?.key?.fromMe
  ? (conn?.user?.id || info?.key?.participant || info?.key?.remoteJid)
  : (info?.key?.participantAlt || info?.key?.remoteJidAlt || info?.key?.participant || info?.key?.remoteJid)

let groupMetadata = null
let groupName = ''
let groupDesc = ''
let groupMembers = []
let groupAdmins = []
let somembros = []
let isBotGroupAdmins = false
let isGroupAdmins = false

try {
if (isGroup) {



let tentativas = 0
while (!groupMetadata && tentativas < 2) {
try {
groupMetadata = await columbina.groupMetadata(from)
} catch (eMeta) {
tentativas++
if (tentativas >= 2) throw eMeta
await new Promise(r => setTimeout(r, 600))
}
}

groupName = groupMetadata.subject
groupDesc = groupMetadata.desc || ''
groupMembers = groupMetadata.participants
groupAdmins = getGroupAdmins(groupMembers)
somembros = getMembros(groupMembers)








const adminsPendentesLid = groupAdmins.filter(a => a.toString().endsWith('@lid'))
if (adminsPendentesLid.length) {
  await Promise.all(adminsPendentesLid.map(async (adminLid) => {
    try {
      const pn = await columbina.signalRepository?.lidMapping?.getPNForLID(adminLid)
      if (pn) {
        const pnJid = pn.includes('@') ? pn : `${pn}@s.whatsapp.net`
        groupAdmins = groupAdmins.map(a => a === adminLid ? pnJid : a)
      }
    } catch (eAdmLid) {
      console.log('Erro ao resolver LID de admin:', eAdmLid?.message)
    }
  }))
}







if (sender && sender.endsWith('@lid')) {
const cacheado = global.lidParaNumero[sender]
if (cacheado) {
sender = cacheado
} else {
const senderRawId = info?.key?.participant || info?.key?.remoteJid
const participanteAtual = groupMembers.find(p => p.id === senderRawId || p.id === sender)
if (participanteAtual?.phoneNumber) {
sender = participanteAtual.phoneNumber
if (senderRawId) global.lidParaNumero[senderRawId] = sender
}
}
}

const botNumberPure = botNumber.split('@')[0].replace(/[^0-9]/g, '')
isBotGroupAdmins = groupAdmins.some(admin => {
const adminPure = admin.toString().split('@')[0].replace(/[^0-9]/g, '')
return adminPure === botNumberPure
})

const senderPure = sender.split('@')[0].replace(/[^0-9]/g, '')
isGroupAdmins = groupAdmins.some(admin => {
const adminPure = admin.toString().split('@')[0].replace(/[^0-9]/g, '')
return adminPure === senderPure
})






if (!isGroupAdmins) {
const senderRawId2 = info?.key?.participant || info?.key?.remoteJid
const participanteBruto = groupMembers.find(p => p.id === senderRawId2 || p.id === sender || p.phoneNumber === sender)
if (participanteBruto && (participanteBruto.admin === 'admin' || participanteBruto.admin === 'superadmin')) {
isGroupAdmins = true
}
}
}
} catch (e) {
console.log('Erro ao pegar metadata do grupo:', e)
}




if (sender && sender.endsWith('@lid')) {
try {
const pn = await columbina.signalRepository?.lidMapping?.getPNForLID(sender)
if (pn) {
const resolvido = pn.includes('@') ? pn : `${pn}@s.whatsapp.net`
global.lidParaNumero[sender] = resolvido
sender = resolvido
}
} catch (eLid) {
console.log('Erro ao resolver LID do sender:', eLid?.message)
}
}





if (sender) {
sender = sender.replace(/:\d+(?=@)/, '')

// JID de quem executou o comando para o Meta AI Mark
global.META_MARK_SENDER = sender
// Nome de quem executou o comando
global.META_MARK_NAME = pushname || ''
}

/*
 * META AI MARK
 * Usuário da mensagem atual.
 */
if (columbina) {
  columbina.__metaMarkUsuario = {
    jid: sender,
    nome: info?.pushName || null
  }
}



if (isGroup && isDono(sender)) {
isGroupAdmins = true
}

await AddWhatsAppuser(columbina, info)


try {

  

  const candidatosSender = new Set()
  const addCand = (jidLike, destino) => {
    const num = String(jidLike || '').split('@')[0].replace(/[^0-9]/g, '')
    if (num) destino.add(num)
  }
  addCand(sender, candidatosSender)
  addCand(info.key?.participant, candidatosSender)
  addCand(info.key?.participantAlt, candidatosSender)
  if (!isGroup) {
    addCand(info.key?.remoteJid, candidatosSender)
    addCand(info.key?.remoteJidAlt, candidatosSender)
  }
  const senderPuro = [...candidatosSender][0] || ''


  

  if (body) {
    const chaveAtiva = [...candidatosSender].find(num => donoState.afk[num] && typeof donoState.afk[num] === 'object' && typeof donoState.afk[num].inicio !== 'number' && donoState.afk[num][from])
    if (chaveAtiva) {
      const registro = donoState.afk[chaveAtiva][from]
      const duracao = formatarDuracao(Date.now() - registro.inicio)

      for (const num of candidatosSender) {
        if (donoState.afk[num] && typeof donoState.afk[num] === 'object') delete donoState.afk[num][from]
      }
      if (typeof donoState.salvar === 'function') donoState.salvar()
      await columbina.sendMessage(from, {
        text: `💜 Bem-vindo(a) de volta, ${pushname}!\n⏰ Você ficou ausente por *${duracao}*.`
      }, { quoted: info })
    }
  }


  const mencoesInfo = info.message?.extendedTextMessage?.contextInfo
  const jidsMarcados = [
    ...(mencoesInfo?.mentionedJid || []),
    ...(mencoesInfo?.participant ? [mencoesInfo.participant] : [])
  ]

  for (const jidMarcado of new Set(jidsMarcados)) {
    const numeroPuro = String(jidMarcado || '').split('@')[0].replace(/[^0-9]/g, '')
    const registroDoChat = numeroPuro && donoState.afk[numeroPuro] && typeof donoState.afk[numeroPuro] === 'object' ? donoState.afk[numeroPuro][from] : null
    if (numeroPuro && !candidatosSender.has(numeroPuro) && registroDoChat) {
      const duracao = formatarDuracao(Date.now() - registroDoChat.inicio)
      await columbina.sendMessage(from, {
        text: `😴 @${numeroPuro} está AFK há *${duracao}*.\n📝 Motivo: ${registroDoChat.motivo}`,
        mentions: [jidMarcado]
      }, { quoted: info })
    }
  }
} catch (eAfk) {
  console.log('❌ ERRO checagem AFK:', eAfk?.message)
}


if (isGroup) {
  try {
    const isStickerMsg = !!(info.message?.stickerMessage)
    if (isStickerMsg) {
      registrarAtividade(from, sender, pushname, 'sticker')
    } else if (body) {
      registrarAtividade(from, sender, pushname, 'msg')
    }
  } catch(_e) {}


  

  
  if (body && !donoState.botStatus?.eventorpgAutoOff?.[from] && Math.random() < 0.03 && podeSpawnar(from)) {
    try {
      const { evento } = criarSpawn(from)
      const segundos = Math.floor(DURACAO_EVENTO_MS / 1000)
      const textoEvento = `╭━━━〔 🃏 POKÉMON SELVAGEM 〕━━━╮\n\n⚡ Um Pokémon apareceu!\n\n${evento.emoji} Pokémon: ${evento.nome}\n🌟 Raridade: ${evento.raridade}\n🔰 Nível: ${evento.nivel}\n❤️ Vida: ${evento.vidaAtual.toLocaleString('pt-BR')} / ${evento.vidaMax.toLocaleString('pt-BR')}\n⚔️ Força: ${evento.forca.toLocaleString('pt-BR')}\n🛡️ Defesa: ${evento.defesa.toLocaleString('pt-BR')}\n💨 Velocidade: ${evento.velocidade.toLocaleString('pt-BR')}\n🔥 Tipo: ${evento.tipo}\n\n🎯 Quem capturar primeiro ganha!\n👉 Digite ${prefix}pegar\n\n⏰ Tempo restante: ${segundos} segundos\n╰━━━━━━━━━━━━━━━━━━━━╯`

      let dexId = pokePorNome(evento.nome)?.id
      if (!dexId) dexId = await pokeBuscarDexIdOnline(evento.nome)

      if (dexId) {
        try {
          await columbina.sendMessage(from, { image: { url: pokeImagemUrl(dexId) }, caption: textoEvento })
        } catch (_) {
          await columbina.sendMessage(from, { text: textoEvento })
        }
      } else {
        await columbina.sendMessage(from, { text: textoEvento })
      }
    } catch (eSpawn) {
      console.log('❌ ERRO spawn automático:', eSpawn?.message)
    }
  }
}


if (isGroup && global.dominioAtivo && global.dominioAtivo[from]) {
  const dominio = global.dominioAtivo[from]
  if (Date.now() >= dominio.ate) {
    delete global.dominioAtivo[from]
    try {
      await columbina.sendMessage(from, {
        text: `🌀 A Expansão de Domínio foi desfeita.\n\nO grupo voltou ao normal.`
      })
    } catch (_e) {}
  } else if (sender !== dominio.permitido && !isDono(sender)) {
    try { await columbina.sendMessage(from, { delete: info.key }) } catch (_e) {}
    return
  }
}









if (isGroup) {
  try {

    
    const tipoMsgAntiPy = info?.message ? Object.keys(info.message)[0] : '(sem message)'
    console.log(`[antipy] verificando mensagem (tipo: ${tipoMsgAntiPy}) em ${from}`)
    const dadosAntiPy = {
      info, from, sender, isGroup, isGroupAdmins,
      ehDono: (jid) => { try { return isDono(jid) } catch (_e) { return false } },
      isBotGroupAdmins, groupMembers
    }
    if (await antipyHandler.tratarDenuncia(columbina, dadosAntiPy)) return
    if (await antipyHandler.tratar(columbina, dadosAntiPy)) return
  } catch (eAntiPy) {

    
    console.log('❌ ERRO antipy:', eAntiPy?.stack || eAntiPy?.message)
    try {
      await columbina.sendMessage(from, {
        text: `⚠️ *ANTI-PY* deu erro ao tentar analisar uma mensagem:\n${eAntiPy?.message || 'erro desconhecido'}\n\nMande esse texto pra quem configurou o bot.`
      })
    } catch (_eAviso) {}

  }
}



if (isGroup && adminState.antiflood[from]?.ligado && !isGroupAdmins && !isDono(sender) && (body || info.message?.stickerMessage)) {
  try {
    const cfgFlood = adminState.antiflood[from]
    const janelaMs = (cfgFlood.janelaSeg || 10) * 1000

    if (!global.floodTracker) global.floodTracker = {}
    const chaveFlood = from + sender
    const historico = (global.floodTracker[chaveFlood] || []).filter(t => Date.now() - t < janelaMs)
    historico.push(Date.now())
    global.floodTracker[chaveFlood] = historico

    if (historico.length > (cfgFlood.maxMsgs || 6)) {
      global.floodTracker[chaveFlood] = [] 
      try { await columbina.sendMessage(from, { delete: info.key }) } catch (_e) {}

      const { adicionarAdvertencia, zerarAdvertencias } = require('./arquivos/js/advertencias.js')
      const numeroPuroFlood = String(sender || '').split('@')[0].replace(/[^0-9]/g, '')
      const { total, deveBanir } = adicionarAdvertencia(from, numeroPuroFlood, cfgFlood.maxAdvertencias || 3)

      if (deveBanir) {
        zerarAdvertencias(from, numeroPuroFlood)
        try {
          await columbina.groupParticipantsUpdate(from, [sender], 'remove')
          await columbina.sendMessage(from, { text: `🌊🔨 *ANTIFLOOD* — @${sender.split('@')[0]} atingiu o limite de advertências e foi banido(a) por flood!`, mentions: [sender] }, { quoted: info })
        } catch (eBanFlood) {
          await columbina.sendMessage(from, { text: `🌊 *ANTIFLOOD* — @${sender.split('@')[0]} atingiu o limite, mas não consegui banir (confira se sou admin).`, mentions: [sender] }, { quoted: info })
        }
      } else {
        await columbina.sendMessage(from, { text: `🌊 *ANTIFLOOD* — @${sender.split('@')[0]}, calma com as mensagens!\n⚠️ Advertência ${total}/${cfgFlood.maxAdvertencias || 3}.`, mentions: [sender] }, { quoted: info })
      }
      return
    }
  } catch (eFlood) { console.log('❌ ERRO antiflood (deteccao):', eFlood?.message) }
}


if (isGroup && adminState.antispam?.[from] && !isGroupAdmins && !isDono(sender) && body) {
  try {
    if (!global.spamTracker) global.spamTracker = {}
    const chave = from + sender
    const registro = global.spamTracker[chave]
    if (registro && registro.texto === body && (Date.now() - registro.quando) < 30000) {
      registro.count = (registro.count || 1) + 1
      registro.quando = Date.now()
      if (registro.count >= 3) {
        try { await columbina.sendMessage(from, { delete: info.key }) } catch (_e) {}
        if (!global.spamAvisoRecente) global.spamAvisoRecente = {}
        if (!global.spamAvisoRecente[chave] || Date.now() - global.spamAvisoRecente[chave] > 10000) {
          global.spamAvisoRecente[chave] = Date.now()
          await columbina.sendMessage(from, { text: `🚫 *ANTISPAM* — @${sender.split('@')[0]}, para de repetir a mesma mensagem!`, mentions: [sender] }, { quoted: info })
        }
        return
      }
    } else {
      global.spamTracker[chave] = { texto: body, quando: Date.now(), count: 1 }
    }
  } catch (eSpam) { console.log('❌ ERRO antispam (deteccao):', eSpam?.message) }
}





if (isGroup && body && !isGroupAdmins && !isDono(sender)) {
  try {
    const numeroPuro = String(sender || '').split('@')[0].replace(/[^0-9]/g, '')


    
    const { estaAtivo } = require('./arquivos/js/kurokamiState.js')
    if (estaAtivo(from, numeroPuro)) {
      try { await columbina.sendMessage(from, { delete: info.key }) } catch (_e) {}
      try {
        await columbina.sendMessage(from, { text: 'ele e gay 🏳️‍🌈 ', mentions: [sender] })
      } catch (_e2) {}
      return
    }


    
    if (adminState.muteTemporario?.[from]?.[numeroPuro]) {
      if (Date.now() >= adminState.muteTemporario[from][numeroPuro]) {
        delete adminState.muteTemporario[from][numeroPuro]
        try {
          await columbina.sendMessage(from, {
            text: `╭─━━─🃏💜「 🔊💜 *MUTE ACABOU* 💜🔊 」💜🃏─━━─╮\n┃ ✅ @${numeroPuro} já pode falar de novo!\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯`,
            mentions: [sender]
          })
        } catch (_eAviso) {}
      } else {
        try { await columbina.sendMessage(from, { delete: info.key }) } catch (_e) {}
        return
      }
    }


    if (adminState.mutados?.[from]?.[numeroPuro]) {
      try { await columbina.sendMessage(from, { delete: info.key }) } catch (_e) {}
      return
    }
  } catch (eMute) { console.log('❌ ERRO mute (deteccao):', eMute?.message) }
}


if (isGroup && adminState.antibot[from] && !isGroupAdmins && !isDono(sender)) {
  try {
    const textoBot = bodyOriginal || body || ''

    let detectado = pareceOutroBot(textoBot)


    if (!detectado && info.message) {
      const m = info.message
      if (
        m.buttonsMessage || m.listMessage || m.templateMessage ||
        m.interactiveMessage || m.viewOnceMessageV2Extension ||
        m.buttonsResponseMessage || m.listResponseMessage ||
        m.templateButtonReplyMessage || m.highlyStructuredMessage
      ) {

        
        if (pareceOutroBot(textoBot) || (textoBot && textoBot.split('\n').length >= 4)) {
          detectado = true
        }
      }
    }


    if (!detectado && pushname && /\b(bot|robot)\b/i.test(pushname) && pareceOutroBot(textoBot)) {
      detectado = true
    }

    if (detectado) {
      try { await columbina.sendMessage(from, { delete: info.key }) } catch(_e) {}
      try {
        await columbina.groupParticipantsUpdate(from, [sender], 'remove')
        await columbina.sendMessage(from, {
          text: `🤖 *ANTIBOT* — Bot detectado!\n🚫 @${String(sender).split('@')[0]} foi *banido* do grupo.`,
          mentions: [sender]
        }, { quoted: info })
      } catch (eKick) {
        await columbina.sendMessage(from, {
          text: `🤖 *ANTIBOT* — Mensagem de bot apagada!\n⚠️ Não consegui banir — me coloque como *admin* do grupo.`,
          mentions: [sender]
        }, { quoted: info })
      }
      return
    }
  } catch (eAntibot) { console.log('❌ ERRO antibot (deteccao):', eAntibot?.message) }
}


if (isGroup && adminState.antidoc[from] && !isGroupAdmins && !isDono(sender)) {
  try {
    if (info.message?.documentMessage || info.message?.documentWithCaptionMessage) {
      try { await columbina.sendMessage(from, { delete: info.key }) } catch(_e) {}
      await columbina.sendMessage(from, { text: `📄 *ANTIDOC* — Documento apagado!\n@${sender.split('@')[0]}, arquivos não são permitidos aqui.`, mentions: [sender] }, { quoted: info })
      return
    }
  } catch (eAntidoc) { console.log('❌ ERRO antidoc:', eAntidoc?.message) }
}


if (isGroup && adminState.antiimagem[from] && !isGroupAdmins && !isDono(sender)) {
  try {
    if (info.message?.imageMessage) {
      try { await columbina.sendMessage(from, { delete: info.key }) } catch(_e) {}
      await columbina.sendMessage(from, { text: `🖼️ *ANTIIMAGEM* — Foto apagada!\n@${sender.split('@')[0]}, fotos não são permitidas aqui.`, mentions: [sender] }, { quoted: info })
      return
    }
  } catch (eAntiimagem) { console.log('❌ ERRO antiimagem:', eAntiimagem?.message) }
}


if (isGroup && adminState.anticontato[from] && !isGroupAdmins && !isDono(sender)) {
  try {
    if (info.message?.contactMessage || info.message?.contactsArrayMessage) {
      try { await columbina.sendMessage(from, { delete: info.key }) } catch(_e) {}
      await columbina.sendMessage(from, { text: `📇 *ANTICONTATO* — Contato apagado!\n@${sender.split('@')[0]}, não é permitido mandar contato aqui.`, mentions: [sender] }, { quoted: info })
      return
    }
  } catch (eAnticontato) { console.log('❌ ERRO anticontato:', eAnticontato?.message) }
}


if (isGroup && adminState.antinota[from] && !isGroupAdmins && !isDono(sender)) {
  try {
    if (info.message?.audioMessage) {
      try { await columbina.sendMessage(from, { delete: info.key }) } catch(_e) {}
      await columbina.sendMessage(from, { text: `🎤 *ANTINOTA* — Áudio apagado!\n@${sender.split('@')[0]}, notas de voz/áudio não são permitidas aqui.`, mentions: [sender] }, { quoted: info })
      return
    }
  } catch (eAntinota) { console.log('❌ ERRO antinota:', eAntinota?.message) }
}


if (isGroup && adminState.antiloc[from] && !isGroupAdmins && !isDono(sender)) {
  try {
    if (info.message?.locationMessage || info.message?.liveLocationMessage) {
      try { await columbina.sendMessage(from, { delete: info.key }) } catch(_e) {}
      await columbina.sendMessage(from, { text: `📍 *ANTILOC* — Localização apagada!\n@${sender.split('@')[0]}, não é permitido compartilhar localização aqui.`, mentions: [sender] }, { quoted: info })
      return
    }
  } catch (eAntiloc) { console.log('❌ ERRO antiloc:', eAntiloc?.message) }
}



if (isGroup && adminState.antipalavra[from]?.ligado && !isGroupAdmins && !isDono(sender)) {
  try {
    const cfgPalavra = adminState.antipalavra[from]
    const textoChecar = (bodyOriginal || body || '').toLowerCase()
    const palavraAchada = cfgPalavra.palavras.find(p => textoChecar.includes(p))
    if (palavraAchada) {
      try { await columbina.sendMessage(from, { delete: info.key }) } catch(_e) {}

      const { adicionarAdvertencia, zerarAdvertencias } = require('./arquivos/js/advertencias.js')
      const numeroPuroPalavra = String(sender || '').split('@')[0].replace(/[^0-9]/g, '')
      const { total, deveBanir } = adicionarAdvertencia(from, numeroPuroPalavra, cfgPalavra.maxAdvertencias || 3)

      if (deveBanir) {
        zerarAdvertencias(from, numeroPuroPalavra)
        try {
          await columbina.groupParticipantsUpdate(from, [sender], 'remove')
          await columbina.sendMessage(from, { text: `🚫🔨 *ANTIPALAVRA* — @${sender.split('@')[0]} atingiu o limite de advertências e foi banido(a)!`, mentions: [sender] }, { quoted: info })
        } catch (eBanPalavra) {
          await columbina.sendMessage(from, { text: `🚫 *ANTIPALAVRA* — @${sender.split('@')[0]} atingiu o limite, mas não consegui banir (confira se sou admin).`, mentions: [sender] }, { quoted: info })
        }
      } else {
        await columbina.sendMessage(from, { text: `🚫 *ANTIPALAVRA* — Mensagem apagada!\n@${sender.split('@')[0]}, essa palavra não é permitida aqui.\n⚠️ Advertência ${total}/${cfgPalavra.maxAdvertencias || 3}.`, mentions: [sender] }, { quoted: info })
      }
      return
    }
  } catch (eAntipalavra) { console.log('❌ ERRO antipalavra:', eAntipalavra?.message) }
}


if (isGroup && isCommand && adminState.antispamcmd[from]?.ligado && !isGroupAdmins && !isDono(sender)) {
  try {
    const cfgSpam = adminState.antispamcmd[from]
    const agora = Date.now()
    const frasesSpamCmd = [
      'cuidado, você está fazendo comando muito rápido!',
      'ei, calma com os comandos, respira um pouco 😅',
      'devagar aí, tá parecendo robozinho de tanto comando!',
      'opa, comando demais em pouco tempo — dá uma pausa!',
      'ninguém aguenta esse tanto de comando de uma vez, relaxa!'
    ]
    const fraseSpamCmd = frasesSpamCmd[Math.floor(Math.random() * frasesSpamCmd.length)]

    if (cfgSpam.modo === 'cooldown') {

      cfgSpam.ultimoUso = cfgSpam.ultimoUso || {}
      const ultimo = cfgSpam.ultimoUso[sender] || 0
      const faltam = cfgSpam.cooldownMs - (agora - ultimo)
      if (faltam > 0) {
        try { await columbina.sendMessage(from, { delete: info.key }) } catch(_e) {}
        const faltamSeg = Math.ceil(faltam / 1000)
        await columbina.sendMessage(from, { text: `⏱️ *ANTISPAMCMD*\n@${sender.split('@')[0]}, ${fraseSpamCmd}\n⌛ Espera mais ${faltamSeg}s antes do próximo comando.`, mentions: [sender] }, { quoted: info })
        return
      }
      cfgSpam.ultimoUso[sender] = agora
    } else {

      cfgSpam.registro = cfgSpam.registro || {}
      if (!cfgSpam.registro[sender]) cfgSpam.registro[sender] = []
      cfgSpam.registro[sender] = cfgSpam.registro[sender].filter(t => agora - t < 60000)
      cfgSpam.registro[sender].push(agora)
      if (cfgSpam.registro[sender].length > (cfgSpam.limite || 8)) {
        try { await columbina.sendMessage(from, { delete: info.key }) } catch(_e) {}
        await columbina.sendMessage(from, { text: `⏱️ *ANTISPAMCMD*\n@${sender.split('@')[0]}, ${fraseSpamCmd}`, mentions: [sender] }, { quoted: info })
        return
      }
    }
  } catch (eAntispamcmd) { console.log('❌ ERRO antispamcmd:', eAntispamcmd?.message) }
}


if (isGroup && !isGroupAdmins && !isDono(sender)) {
  const cfgLink = adminState.antilink[from]
  if (cfgLink) {
    try {
      const tipoLink = detectarLink(bodyOriginal || body)

      
      const ehParceiroComCota = tipoLink && parceirosDB.ehParceiro(from, sender) && parceirosDB.consumirCotaLink(from, sender)
      if (tipoLink && linkBloqueado(tipoLink, cfgLink) && !ehParceiroComCota) {
        try { await columbina.sendMessage(from, { delete: info.key }) } catch(_e) {}
        const numeroPuro = String(sender || '').split('@')[0].replace(/[^0-9]/g, '')

        if (cfgLink.acao === 'ban') {
          try {
            await columbina.groupParticipantsUpdate(from, [sender], 'remove')
            await columbina.sendMessage(from, { text: `🔗 *ANTILINK* — Link de *${tipoLink}* detectado!\n🚫 Removido(a) do grupo.`, mentions: [sender] }, { quoted: info })
          } catch (eKick) {
            await columbina.sendMessage(from, { text: `🔗 *ANTILINK* — Link de *${tipoLink}* apagado!\n⚠️ Não consegui remover, confira se eu sou admin do grupo.`, mentions: [sender] }, { quoted: info })
          }
        } else {

          

          const total = registrarAdvertencia(from, numeroPuro)
          const maxAdv = cfgLink.maxAdv || 3
          if (total >= maxAdv) {
            try {
              await columbina.groupParticipantsUpdate(from, [sender], 'remove')
              await columbina.sendMessage(from, { text: `🔗 *ANTILINK* — Link de *${tipoLink}* apagado!\n🔨 @${numeroPuro} atingiu *${total}/${maxAdv}* advertências e foi *removido(a)*.`, mentions: [sender] }, { quoted: info })
            } catch (eKick) {
              await columbina.sendMessage(from, { text: `🔗 *ANTILINK* — Link de *${tipoLink}* apagado!\n⚠️ @${numeroPuro} atingiu *${total}/${maxAdv}* advertências, mas não consegui remover — confira se eu sou admin do grupo.`, mentions: [sender] }, { quoted: info })
            }
          } else {
            await columbina.sendMessage(from, { text: `🃏💜 *ANTILINK* — Link de *${tipoLink}* apagado!\n⚠️ @${numeroPuro} levou advertência *${total}/${maxAdv}*.\n😜 Nada de link aqui, vamos brincar de outra coisa~`, mentions: [sender] }, { quoted: info })
          }
        }
        return
      }
    } catch (eAntilink) { console.log('❌ ERRO antilink (deteccao):', eAntilink?.message) }
  }
}





if (isGroup && !isGroupAdmins && !isDono(sender)) {
  const cfgPag = adminState.antipagamento[from]
  if (cfgPag?.ativo) {
    try {
      const detectou = ehMensagemPagamento(info.message)
      if (!detectou) {

        

        console.log('[antipagamento][debug] tipos da mensagem:', Object.keys(info.message || {}))
      }
      if (detectou) {

        

        

        

        try {
          await columbina.sendMessage(from, {
            delete: {
              remoteJid: from,
              id: info.key.id,
              fromMe: false,
              participant: info.key.participant || sender
            }
          })
        } catch (eDel) {
          console.log('❌ ANTIPAGAMENTO (falha ao apagar mensagem):', eDel?.message || eDel)
        }
        const numeroPuro = String(sender || '').split('@')[0].replace(/[^0-9]/g, '')

        let jidBan = info.key.participant || sender
        try {
          const membros = groupMembers || []
          const candidato = membros.find(m => {
            const mid = String(m.id || m.jid || m.lid || '')
            return mid === sender || mid === info.key.participant ||
              mid.split('@')[0] === numeroPuro ||
              String(m.phoneNumber || '').includes(numeroPuro)
          })
          if (candidato) jidBan = candidato.id || candidato.jid || candidato.lid || jidBan
        } catch (_) {}

        async function tentarBanirAntiPag() {
          const tentativas = [jidBan, sender, info.key.participant].filter(Boolean)
          let lastErr = null
          for (const j of [...new Set(tentativas)]) {
            try {
              await columbina.groupParticipantsUpdate(from, [j], 'remove')
              return true
            } catch (e) { lastErr = e }
          }
          console.log('❌ ANTIPAGAMENTO ban falhou:', lastErr?.message || lastErr)
          return false
        }

        if (cfgPag.acao === 'ban') {
          const ok = await tentarBanirAntiPag()
          if (ok) {
            await columbina.sendMessage(from, { text: `💳 *ANTIPAGAMENTO* — msg invisível/pagamento detectada!\n🚫 Removido(a) do grupo.`, mentions: [sender] }, { quoted: info })
          } else {
            await columbina.sendMessage(from, { text: `💳 *ANTIPAGAMENTO* — mensagem apagada!\n⚠️ Não consegui remover (preciso ser admin e o alvo não pode ser admin).`, mentions: [sender] }, { quoted: info })
          }
        } else {
          const total = registrarAdvertencia(from, numeroPuro)
          const maxAdv = cfgPag.maxAdv || 3
          if (total >= maxAdv) {
            const ok = await tentarBanirAntiPag()
            await columbina.sendMessage(from, { text: ok
              ? `💳 *ANTIPAGAMENTO* — mensagem apagada!\n🔨 @${numeroPuro} atingiu *${total}/${maxAdv}* advertências e foi *removido(a)*.`
              : `💳 *ANTIPAGAMENTO* — mensagem apagada!\n⚠️ @${numeroPuro} atingiu *${total}/${maxAdv}* advertências, mas não consegui remover.`, mentions: [sender] }, { quoted: info })
          } else {
            await columbina.sendMessage(from, { text: `💳 *ANTIPAGAMENTO* — mensagem suspeita apagada!\n⚠️ @${numeroPuro} levou advertência *${total}/${maxAdv}*.`, mentions: [sender] }, { quoted: info })
          }
        }
        return
      }
    } catch (eAntipag) { console.log('❌ ERRO antipagamento (deteccao):', eAntipag?.message) }
  }
}



if (
budy.startsWith('>') &&
!budy.startsWith('>>') &&
!budy.startsWith('(>')
) {
if (!isDono(sender)) return
try {
const evalCode = budy.slice(1).trim()
if (!evalCode) return
let result = eval(evalCode)
if (result instanceof Promise) {
result = await result
}
let output =
typeof result === 'object'
? JSON.stringify(result, null, 2)
: String(result)
if (output === undefined) output = 'undefined'
if (output === '') output = '(empty)'
await reply(output, from, info)
await reagir('✅', from, info)
} catch (e) {
await reply(e.stack || e.message, from, info)
await reagir('❌', from, info)
}
return
}

if (budy.startsWith('(>')) {
if (!isDono(sender)) return
try {
const evalCode = budy.slice(2).trim()
if (!evalCode) return
const asyncResult = await eval(`(async () => {\n${evalCode}\n})()`)
if (asyncResult !== undefined) {
let output =
typeof asyncResult === 'object'
? JSON.stringify(asyncResult, null, 2)
: String(asyncResult)
if (output === undefined) output = 'undefined'
if (output === '') output = '(empty)'
await reply(output, from, info)
} else {
await reply('executado', from, info)
}
await reagir('✅', from, info)
} catch (e) {
await reply(e.stack || e.message, from, info)
await reagir('❌', from, info)
}
return
}







if (!isGroup && donoState.botStatus?.antipv && !isDono(sender)) {
  if (!global.__antipvAvisados) global.__antipvAvisados = {}
  const agora = Date.now()
  const ultimoAviso = global.__antipvAvisados[sender] || 0
  if (agora - ultimoAviso > 60000) {
    global.__antipvAvisados[sender] = agora
    const numeroDono = config.NumeroDoDono || donoJid.split('@')[0]
    await reply(`❌ Não pode mandar mensagem para o bot, ele está programado para não responder, tente falar com meu dono... ;)\n\n📲 *wa.me/${numeroDono}*`, from, info)
  }
  return
}


if (!isCommand) {



try {
  const packSession = require('./arquivos/js/packSession.js')
  const sessaoPack = packSession.get(from, sender)
  if (sessaoPack) {
    const candidatas = [info, ...(Array.isArray(messages) ? messages : [])]
    let adicionadas = 0
    for (const msgObj of candidatas) {
      const msg = msgObj?.message || {}
      const img = msg.imageMessage
      const vid = msg.videoMessage
      const doc = msg.documentMessage
      let item = null
      if (img) item = { tipo: 'image', msg: img, viaDoc: false }
      else if (vid) item = { tipo: 'video', msg: vid, viaDoc: false }
      else if (doc?.mimetype?.startsWith('image/')) item = { tipo: 'image', msg: doc, viaDoc: true }
      else if (doc?.mimetype?.startsWith('video/')) item = { tipo: 'video', msg: doc, viaDoc: true }
      if (!item) continue
      const r = packSession.adicionar(from, sender, item)
      if (r) adicionadas++
      if (r?.cheio) break
    }
    if (adicionadas > 0) {

      try { await columbina.sendMessage(from, { react: { text: '🎨', key: info.key } }) } catch (_) {}
      return
    }
  }
} catch (ePackSess) {
  console.log('⚠️ packSession:', ePackSess?.message)
}


if (bodyOriginal.trim().toLowerCase() === 'bot') {
  if (!isBotLigado && !isDono(sender)) return
  const frasesBot = require('./arquivos/js/frasesBot.js')
  const frase = frasesBot[Math.floor(Math.random() * frasesBot.length)]
  await columbina.sendMessage(from, { text: frase }, { quoted: info })
  return
}




async function mandarCartaoMenuRapido(textoCorpo) {
  try {
    const { generateWAMessageFromContent, generateMessageIDV2, isJidGroup } = require('@whiskeysockets/baileys')

    const conteudoMenuRapido = {
      interactiveMessage: {
        contextInfo: {
          stanzaId: info.key.id,
          participant: info.key.participant || info.key.remoteJid,
          quotedMessage: info.message,
          mentionedJid: [sender]
        },
        body: { text: textoCorpo },
        footer: { text: '💜🃏 Arlequina Bot' },
        nativeFlowMessage: {
          buttons: [
            {
              name: 'cta_copy',
              buttonParamsJson: JSON.stringify({
                display_text: '📌 Copiar prefixo',
                id: 'copiar_prefixo',
                copy_code: prefix
              })
            },
            {
              name: 'quick_reply',
              buttonParamsJson: JSON.stringify({
                display_text: '📖 Abrir Menu',
                id: `${prefix}menu`
              })
            }
          ]
        }
      }
    }


    

    const nodeBotao = {
      tag: 'biz',
      attrs: {},
      content: [{
        tag: 'interactive',
        attrs: { type: 'native_flow', v: '1' },
        content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }]
      }]
    }
    const nodesExtras = [nodeBotao]
    if (!isJidGroup(from)) nodesExtras.push({ tag: 'bot', attrs: { biz_bot: '1' } })

    const msgGerada = generateWAMessageFromContent(from, conteudoMenuRapido, {
      userJid: columbina.user.id,
      messageId: generateMessageIDV2(columbina.user.id)
    })

    await columbina.relayMessage(from, msgGerada.message, {
      messageId: msgGerada.key.id,
      additionalNodes: nodesExtras
    })
  } catch (eMenuRapido) {
    console.log('❌ ERRO cartão menu rápido (sem prefixo):', eMenuRapido?.message)
    await columbina.sendMessage(from, { text: `⚡ Sistema online.\n📌 Prefixo atual: *${prefix}*\n📖 Digite *${prefix}menu* pra ver todos os comandos.` }, { quoted: info })
  }
}




if (bodyOriginal.trim().toLowerCase() === 'menu') {
  if (!isBotLigado && !isDono(sender)) return
  await mandarCartaoMenuRapido(`╭━━━┳━━━┳━━━╮\n┃💜┃🃏┃💜┃ ARLEQUINA BOT\n╰━━━┻━━━┻━━━╯\n\n┏━━━━━━━━━━┓\n┃  Oi, *${pushname}*!\n┃\n┗━━━━━━━━━━━━━━━━━━┛\n\n┌─[ 💋 INFORMAÇÕES ]─┐\n│\n│ 🃏 *Usuário:* ${pushname}\n│ 💜 *Bot:* ${config?.NomeDoBot || 'Arlequina Bot'}\n│ ⚡ *Status:* Online\n│ 📌 *Prefixo:* ${prefix}\n│ 🔮 *Versão:* 3.0 Premium\n│\n└────────────────┘\n\n╔═════[ 💜 MENU ]═════╗\n║                                                  ║\n║  👇 Toque no botão       ║\n║  abaixo para abrir          ║\n║  meu menu completo  ║\n║                                                  ║\n╚══════════════════════╝\n\n> _Pudim, não sou só um bot..._\n> _Eu sou a SUA Arlequina._ 😈💜`)
  return
}




if (bodyOriginal.trim().toLowerCase() === 'prefixo') {
  if (!isBotLigado && !isDono(sender)) return
  await mandarCartaoMenuRapido(`╭━━━┳━━━┳━━━╮\n┃💜┃🃏┃💜┃ ARLEQUINA BOT\n╰━━━┻━━━┻━━━╯\n\n┏━━━━━━━━━━┓\n┃  Oi, *${pushname}*!\n┃\n┗━━━━━━━━━━━━━━━━━━┛\n\n┌─[ 💋 INFORMAÇÕES ]─┐\n│\n│ 🃏 *Usuário:* ${pushname}\n│ 💜 *Bot:* ${config?.NomeDoBot || 'Arlequina Bot'}\n│ ⚡ *Status:* Online\n│ 📌 *Prefixo:* ${prefix}\n│ 🔮 *Versão:* 3.0 Premium\n│\n└────────────────┘\n\n╔═════[ 💜 MENU ]═════╗\n║                                                  ║\n║  👇 Toque no botão       ║\n║  abaixo para abrir          ║\n║  meu menu completo  ║\n║                                                  ║\n╚══════════════════════╝\n\n> _Pudim, não sou só um bot..._\n> _Eu sou a SUA Arlequina._ 😈💜`)
  return
}





if (isGroup) {
  const textoUnico = bodyOriginal.trim().toLowerCase()
  const podeUsarAtalho = isGroupAdmins || isDono(sender) || isSenderMonitor()

  if (['a', 'f', 'd'].includes(textoUnico) && podeUsarAtalho) {
    if (!isBotGroupAdmins) {
      await reply('❌ Eu preciso ser administradora do grupo pra fazer isso.', from, info)
      return
    }

    if (textoUnico === 'a') {
      try {
        await columbina.groupSettingUpdate(from, 'not_announcement')
        await reply(`╭─━━─🃏💜「 🔓💜 *GRUPO ABERTO* 💜🔓 」💜🃏─━━─╮\n┃ ✅ Todos podem enviar mensagens\n┃ agora!\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯`, from, info)
      } catch (e) {
        await reply('❌ Não consegui abrir o grupo.', from, info)
      }
      return
    }

    if (textoUnico === 'f') {
      try {
        await columbina.groupSettingUpdate(from, 'announcement')
        await reply(`╭─━━─🃏💜「 🔒💜 *GRUPO FECHADO* 💜🔒 」💜🃏─━━─╮\n┃ ❌ Só administradores podem\n┃ enviar mensagens agora.\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯`, from, info)
      } catch (e) {
        await reply('❌ Não consegui fechar o grupo.', from, info)
      }
      return
    }

    if (textoUnico === 'd') {

      
      let quoted = null
      for (const valor of Object.values(info.message || {})) {
        if (valor && typeof valor === 'object' && valor.contextInfo?.stanzaId) {
          quoted = valor.contextInfo
          break
        }
      }
      if (!quoted) {
        await reply('❌ Responda a mensagem que deseja apagar (digitando só "d" na resposta)!', from, info)
        return
      }
      try {
        const { resolverJidReal } = require('./arquivos/js/lidHelper.js')
        const participantReal = await resolverJidReal(columbina, quoted.participant)
        await columbina.sendMessage(from, {
          delete: { remoteJid: from, fromMe: false, id: quoted.stanzaId, participant: participantReal }
        })
        await reagir('🗑️', from, info)
      } catch (e) {
        await reply(`❌ Não foi possível apagar a mensagem! (${e?.message || 'erro desconhecido'})`, from, info)
      }
      return
    }
  }
}




if (isGroup && !isCommand && donoState.botStatus?.autoStickerGrupos?.[from]) {
  const imgMsgAuto = info.message?.imageMessage
  const vidMsgAuto = info.message?.videoMessage
  if (imgMsgAuto || vidMsgAuto) {
    (async () => {
      try {
        const { sendImageAsSticker2, sendVideoAsSticker2 } = require('./arquivos/js/exif2.js')
        const { metaFigurinha } = require('./arquivos/js/stickerMeta.js')
        const meta = metaFigurinha({ pushname, sender, groupName, config })
        if (vidMsgAuto) {
          if ((vidMsgAuto.seconds || 0) <= 13) {
            const buffer = await getFileBuffer(vidMsgAuto, 'video')
            await sendVideoAsSticker2(columbina, from, buffer, info, meta)
          }
        } else {
          const buffer = await getFileBuffer(imgMsgAuto, 'image')
          await sendImageAsSticker2(columbina, from, buffer, info, meta)
        }
      } catch (eAuto) {
        console.log('❌ ERRO autosticker automático:', eAuto?.message)
      }
    })()
  }
}


if (isGroup) {
  const bodyLower = bodyOriginal.trim().toLowerCase()


  if (sessoesAdivinha[from]) {
    const numTentativa = parseInt(bodyLower)
    if (!isNaN(numTentativa) && numTentativa >= 1 && numTentativa <= 100) {
      const sess = sessoesAdivinha[from]
      sess.tentativas++
      if (numTentativa === sess.numero) {
        clearTimeout(sess.timeout)
        delete sessoesAdivinha[from]
        const pts = adicionarPonto(from, sender, pushname, 2)
        await enviarQuizImg(columbina, from, info, 'chute_certo', `🎉 *ACERTOU!* @${sender.split('@')[0]}\nO número era: *${sess.numero}*\nTentativas: ${sess.tentativas}\n⭐ +2 pontos! Total: ${pts}`, { mentions: [sender] })
      } else if (sess.tentativas >= 10) {
        clearTimeout(sess.timeout)
        delete sessoesAdivinha[from]
        await enviarQuizImg(columbina, from, null, 'chute_perdeu', `💀 *GAME OVER!*\nAcabaram as tentativas! O número era: *${sess.numero}*`)
      } else {
        const dicaNum = numTentativa < sess.numero ? '📈 Maior!' : '📉 Menor!'
        await enviarQuizImg(columbina, from, info, numTentativa < sess.numero ? 'chute_maior' : 'chute_menor', `${dicaNum} Tentativa ${sess.tentativas}/10`)
      }
      return
    }
  }


  
  if (global.sessoesPlay && global.sessoesPlay[from]) {
    const opcoes = ['1','2','3','áudio','audio','vídeo','video','documento']
    const semPrefix = bodyLower.replace(/^[#!/.]/,'').trim()
    if (opcoes.includes(semPrefix)) {
      const sess = global.sessoesPlay[from]

      const tipo = ['1','áudio','audio'].includes(semPrefix) ? 'audio'
                 : ['2','vídeo','video'].includes(semPrefix) ? 'video'
                 : 'documento'
      const { baixarEnviarPlay } = require('./plugins/downloads/play.js')
      await baixarEnviarPlay(columbina, from, info, (t) => reply(t, from, info), (e) => reagir(e, from, info), sess, tipo)
      return
    }
  }


  if (sessoesQuiz[from] && bodyLower.length > 1 && !bodyLower.startsWith(prefix)) {
    const sess = sessoesQuiz[from]
    if (bodyLower === sess.resposta || (sess.resposta.length > 4 && sess.resposta.includes(bodyLower) && bodyLower.length > 3)) {
      clearTimeout(sess.timeout)
      delete sessoesQuiz[from]
      const pts = adicionarPonto(from, sender, pushname)
      await enviarQuizImg(columbina, from, info, 'resposta_certa', `✅ *CORRETO!* @${sender.split('@')[0]}\n\n🎉 Resposta: *${sess.resposta}*\n⭐ Seus pontos: *${pts}*`, { mentions: [sender] })
      return
    }
  }


  if (global.sessoesVelha && global.sessoesVelha[from]) {
    const sessV = global.sessoesVelha[from]
    const bodyV = bodyOriginal.trim()
    const bodyVL = bodyV.toLowerCase()


    if (bodyV === '#rv' || bodyV === '!rv') {
      clearTimeout(sessV.timeout)
      delete global.sessoesVelha[from]
      await columbina.sendMessage(from, { text: 'Jogo da velha resetado com sucesso nesse grupo!' })
      return
    }


    if (sessV.aguardando) {
      if (sender !== sessV.p2.jid) {  }
      else if (/^(s|sim|aceitar|yes)$/i.test(bodyVL)) {
        sessV.aguardando = false
        clearTimeout(sessV.timeout)
        const txt = `『 🎮 』*JOGO DA VELHA* 『 🤗 』\n\n❌ : @${sessV.p1.jid.split('@')[0]}\n⭕ : @${sessV.p2.jid.split('@')[0]}\n• Sua vez : @${sessV.p1.jid.split('@')[0]}\n\nEscolha uma posição (1-9):\n\n1️⃣2️⃣3️⃣\n4️⃣5️⃣6️⃣\n7️⃣8️⃣9️⃣`
        await columbina.sendMessage(from, { text: txt, mentions: [sessV.p1.jid, sessV.p2.jid] })
        return
      } else if (/^(n|nao|não|no|rejeitar)$/i.test(bodyVL)) {
        clearTimeout(sessV.timeout)
        delete global.sessoesVelha[from]
        await columbina.sendMessage(from, { text: `❌ @${sender.split('@')[0]} rejeitou o convite do jogo da velha.`, mentions: [sender] })
        return
      }
    }


    if (!sessV.aguardando) {
      const num = parseInt(bodyV)
      const vezJid = sessV.vez === 'X' ? sessV.p1.jid : sessV.p2.jid
      if (!isNaN(num) && num >= 1 && num <= 9 && sender === vezJid) {
        const idx = num - 1
        if (sessV.board[idx] === 'X' || sessV.board[idx] === 'O') {
          await columbina.sendMessage(from, { text: `❌ Essa posição já foi jogada! Escolha outra.` }, { quoted: info })
          return
        }
        sessV.board[idx] = sessV.vez

        const { renderBoard: rb, checkWin: cw, buildMsg: bm } = (() => {
          const icons = { X:'❌', O:'⭕', 1:'1️⃣', 2:'2️⃣', 3:'3️⃣', 4:'4️⃣', 5:'5️⃣', 6:'6️⃣', 7:'7️⃣', 8:'8️⃣', 9:'9️⃣' }
          const rb = b => [b.slice(0,3), b.slice(3,6), b.slice(6,9)].map(r => r.map(c => icons[c]).join('')).join('\n')
          const cw = (b, s) => [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]].some(([a,x,c]) => b[a]===s && b[x]===s && b[c]===s)
          return { renderBoard: rb, checkWin: cw, buildMsg: null }
        })()

        if (cw(sessV.board, sessV.vez)) {
          const vencedor = sessV.vez === 'X' ? sessV.p1 : sessV.p2
          const perdedor = sessV.vez === 'X' ? sessV.p2 : sessV.p1
          delete global.sessoesVelha[from]
          await columbina.sendMessage(from, {
            text: `『 🎮 』*JOGO DA VELHA* 『 🏆 』\n\n${rb(sessV.board)}\n\n🏆 *@${vencedor.jid.split('@')[0]} VENCEU!*\n💀 @${perdedor.jid.split('@')[0]} perdeu!`,
            mentions: [vencedor.jid, perdedor.jid]
          })
          return
        }

        if (sessV.board.every(c => c === 'X' || c === 'O')) {
          delete global.sessoesVelha[from]
          await columbina.sendMessage(from, {
            text: `『 🎮 』*JOGO DA VELHA* 『 🤝 』\n\n${rb(sessV.board)}\n\n🤝 *EMPATE!* Nenhum vencedor dessa vez.`,
            mentions: [sessV.p1.jid, sessV.p2.jid]
          })
          return
        }

        sessV.vez = sessV.vez === 'X' ? 'O' : 'X'
        const proxJid = sessV.vez === 'X' ? sessV.p1.jid : sessV.p2.jid
        await columbina.sendMessage(from, {
          text: `『 🎮 』*JOGO DA VELHA* 『 🤗 』\n\n❌ : @${sessV.p1.jid.split('@')[0]}\n⭕ : @${sessV.p2.jid.split('@')[0]}\n• Sua vez : @${proxJid.split('@')[0]}\n\n${rb(sessV.board)}`,
          mentions: [sessV.p1.jid, sessV.p2.jid, proxJid]
        })
        return
      }
    }
  }


  if (sessoesHangman[from] && bodyLower.length === 1 && /[a-záàãâéêíóôõúüç]/i.test(bodyLower)) {
    const sess = sessoesHangman[from]
    const letra = bodyLower
    if (!sess.letrasUsadas.includes(letra)) {
      const r = jogadaForca(sess, letra)
      if (r.ganhou) {
        clearTimeout(sess.timeout)
        delete sessoesHangman[from]
        const pts = adicionarPonto(from, sender, pushname, 3)
        await enviarQuizImg(columbina, from, info, r.img, `🎉 *ACERTOU!* @${sender.split('@')[0]}\nA palavra era: *${sess.palavra}*\n⭐ +3 pontos! Total: ${pts}`, { mentions: [sender] })
      } else if (r.perdeu) {
        clearTimeout(sess.timeout)
        delete sessoesHangman[from]
        await enviarQuizImg(columbina, from, info, r.img, `💀 *GAME OVER!*\nA palavra era: *${sess.palavra}*\nErros: ${sess.erros}/${MAX_ERROS}`)
      } else {
        const status = r.certa ? `✅ *${letra}* está na palavra!` : `❌ *${letra}* não está.`
        await enviarQuizImg(columbina, from, info, r.img, `🪤 *FORCA*\n\n${status}\n\nPalavra: *${r.oculta}*\nLetras usadas: ${sess.letrasUsadas.join(', ')}\n${r.vidas}  Erros: ${sess.erros}/${MAX_ERROS}`)
      }
      return
    }
  }
}


if (bodyOriginal.trim().toLowerCase() === 'prefixo') {
await columbina.sendMessage(from, {
text: `╭━━━〔 🃏 愛ＡＲＬＥＱＵＩＮＡ 〕━━━⬣\n┃ 💜 Esse é o meu prefixo atual:\n┃ ➜ 「 ${prefix} 」\n┃\n┃ ⚠️ Não esqueça! Use meu prefixo\n┃ antes de cada comando.\n╰━━━━━━━━━━━━━━━━━━⬣`
}, { quoted: info })
return
}

if (isGroup) {
logMessage('msg_grupo', {
nome: pushname,
grupo: groupName,
mensagem: body.length > 50 ? body.substring(0, 50) + '...' : body
})



try {
  const modomoneyLigadoNoGrupo = donoState.botStatus.modomoney?.[from] !== false
  if (isGroup && modomoneyLigadoNoGrupo) {
    const { carregarUsuarios, salvarUsuarios, getUsuario, verificarLevel } = require('./arquivos/js/rpgDB.js')
    const { caixaBonusDiario } = require('./arquivos/js/estiloArlequina.js')
    const usuarios = carregarUsuarios()
    getUsuario(usuarios, sender)
    const u = usuarios[sender]


    const agora = new Date(Date.now() - 3 * 3600000)
    const hoje = agora.toISOString().slice(0, 10)
    const ontem = new Date(agora.getTime() - 86400000).toISOString().slice(0, 10)
    const ultimoDia = u.ultimoBomDia || ''

    if (ultimoDia !== hoje) {
      u.streakBomDia = ultimoDia === ontem ? (u.streakBomDia || 0) + 1 : 1
      u.ultimoBomDia = hoje

      const valor = 500
      const xpGanho = 100
      u.saldo = (u.saldo || 0) + valor
      u.xp = (u.xp || 0) + xpGanho
      let subiu = 0
      while (verificarLevel(u)) subiu++
      salvarUsuarios(usuarios)

      const frasesBomDia = [
        ['🃏 "Todo dia é uma nova', '   chance de ficar rico..."'],
        ['🃏 "O caos recompensa quem', '   acorda cedo..."'],
        ['🃏 "Hoje é seu dia de sorte,', '   aproveita..."']
      ]
      const fraseEscolhida = frasesBomDia[Math.floor(Math.random() * frasesBomDia.length)]

      const texto = caixaBonusDiario({
        nomeUsuario: `@${sender.split('@')[0]}`,
        recompensas: [
          `💰 +${valor.toLocaleString('pt-BR')} MOEDAS`,
          `✨ +${xpGanho} XP`,
          `🔥 STREAK: ${u.streakBomDia} DIA${u.streakBomDia > 1 ? 'S' : ''}`
        ],
        saldo: u.saldo.toLocaleString('pt-BR'),
        nivel: u.level || 1,
        frase: fraseEscolhida
      })

      await columbina.sendMessage(from, {
        text: texto + (subiu > 0 ? `\n\n🆙 Você também subiu ${subiu} nível(is)!` : ''),
        mentions: [sender]
      }, { quoted: info })
    }
  }
} catch (e) {
  console.error('ERRO sistema bom dia:', e?.message)
}

} else {
logMessage('msg_pv', {
nome: pushname,
mensagem: body.length > 50 ? body.substring(0, 50) + '...' : body
})
}
return
}

const fullCommand = bodyOriginal.slice(prefix.length)
const args = fullCommand.split(' ')
const command = (args.shift() || '').toLowerCase()
const q = args.join(' ')
let qOriginal = ''
try {
const bodyOriginal = 
info.message?.conversation || info.message?.extendedTextMessage?.text || info.message?.imageMessage?.caption || info.message?.videoMessage?.caption || ""

if (bodyOriginal && bodyOriginal.startsWith(prefix)) {
const fullCommandOriginal = bodyOriginal.slice(prefix.length)
const argsOriginal = fullCommandOriginal.split(' ')
argsOriginal.shift()
qOriginal = argsOriginal.join(' ')
}
} catch(e) {
qOriginal = q
}


if (isGroup) {
logMessage('comando_grupo', {
nome: pushname,
grupo: groupName,
comando: command
})
try { registrarAtividade(from, sender, pushname, 'cmd') } catch(_e) {}
} else {
logMessage('comando_pv', {
nome: pushname,
comando: command
})
}

if (!isBotLigado && !isDono(sender)) {
return reply('💜Arlequina esta desligada! Apenas o dono pode usar comandos.', from, info)
}




if (donoState.botStatus?.manutencao && !isDono(sender)) {
return reply('🛠️ Arlequina está em manutenção no momento!\n\nApenas o dono pode usar comandos agora. Tente novamente mais tarde.', from, info)
}



if (isGroup && donoState.botStatus?.soDonoGrupos?.[from] && !isDono(sender)) {
return
}



if (isGroup && donoState.botStatus?.soAdmGrupos?.[from] && !isDono(sender) && !isGroupAdmins) {
return
}


if (isGroup && donoState.botStatus?.gruposBanidos?.[from] && !isDono(sender)) {
const numeroDonoBan = config.NumeroDoDono || config.numeroDono || ''
const linhaContatoBan = numeroDonoBan
  ? `┃ 👑 ${config.NomeDoDono || 'o dono do bot'}\n┃ 📱 wa.me/${numeroDonoBan}`
  : `┃ 👑 ${config.NomeDoDono || 'o dono do bot'}`
return reply(`╭━━〔 🔒💜 *GRUPO BANIDO* 💜🔒 〕━━⬣\n┃ ❌ Este grupo está banido de usar meus comandos.\n┃\n┃ 📩 Fale com meu dono se quiser resolver isso:\n${linhaContatoBan}\n╰━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n💜🃏 _Arlequina Bot_ 😈`, from, info)
}

if (isGroup && !isDono(sender) && !donoState.aluguel.modoGlobalDesativado) {
const aluguelGrupo = donoState.aluguel.grupos[from]
const expirado = !!(aluguelGrupo?.fim && Date.now() > aluguelGrupo.fim)
if (expirado && aluguelGrupo) aluguelGrupo.ativo = false
const registrado = !!(aluguelGrupo?.ativo) && !expirado
if (!registrado) {
const numeroDono = config.NumeroDoDono || config.numeroDono || ''
const linhaContato = numeroDono
  ? `┃ 👑 ${config.NomeDoDono || 'o dono do bot'}\n┃ 📱 wa.me/${numeroDono}`
  : `┃ 👑 ${config.NomeDoDono || 'o dono do bot'}`
return reply(`╭━━〔 🃏💜 *ARLEQUINA BOT* 💜🃏 〕━━⬣\n┃ ❌ *Grupo não registrado!*\n┃ Esse grupo não tem aluguel ativo.\n┃\n┃ 📩 Entre em contato com meu dono:\n${linhaContato}\n╰━━━━━━━━━━━━━━━━━━━━━━━━━━⬣\n💜🃏 _Arlequina Bot_ 😈`, from, info)
}
}

const targetPlugin = gerenciadorComandos.ObterComando(command)

if (!targetPlugin) {


function levenshtein(a, b) {
  const m = a.length, n = b.length
  const dp = Array.from({length: m+1}, (_, i) => Array.from({length: n+1}, (_, j) => i===0?j:j===0?i:0))
  for (let i=1;i<=m;i++) for (let j=1;j<=n;j++) dp[i][j]=a[i-1]===b[j-1]?dp[i-1][j-1]:1+Math.min(dp[i-1][j],dp[i][j-1],dp[i-1][j-1])
  return dp[m][n]
}
const todosComandos = gerenciadorComandos.ObterTodosComandos ? gerenciadorComandos.ObterTodosComandos() : []
let melhorCmd = null, melhorDist = 99
for (const cmd of todosComandos) {
  const nome = cmd.name || cmd
  const dist = levenshtein(command.toLowerCase(), nome.toLowerCase())
  if (dist < melhorDist) { melhorDist = dist; melhorCmd = nome }
}
const similaridade = melhorCmd ? Math.max(0, Math.round((1 - melhorDist / Math.max(command.length, melhorCmd.length)) * 100)) : 0
const temSugestao = melhorCmd && similaridade > 30




const linhasErro = [`🥷 ❌ *Digitou:* \`${prefix}${command}\``]
if (temSugestao) {
  linhasErro.push(`🥷 💡 *Quis dizer:* \`${prefix}${melhorCmd}\``)
  linhasErro.push(`🥷 🎯 *Semelhança:* ${similaridade}%`)
} else {
  linhasErro.push(`🥷 💡 *Dica:* use ${prefix}menu pra ver todos os comandos`)
}

const erroCaption = caixaElegante('𝐂𝐌𝐃 𝐈𝐍𝐕𝐀𝐋𝐈𝐃𝐎', '❌', linhasErro)


const _imgPath = './arquivos/imagem/menu.jpg'
const _imgBuf = require('fs').existsSync(_imgPath) ? require('fs').readFileSync(_imgPath) : null

try {

  
  const { prepareWAMessageMedia, generateWAMessageFromContent, generateMessageIDV2, isJidGroup } = require('@whiskeysockets/baileys')

  const mediaErro = _imgBuf ? await prepareWAMessageMedia({ image: _imgBuf }, { upload: columbina.waUploadToServer }) : null

  const conteudoErro = {
    interactiveMessage: {
      contextInfo: {
        stanzaId: info.key.id,
        participant: info.key.participant || info.key.remoteJid,
        quotedMessage: info.message,
        mentionedJid: [sender]
      },
      header: {
        hasMediaAttachment: !!mediaErro,
        imageMessage: mediaErro ? mediaErro.imageMessage : undefined
      },
      body: { text: erroCaption },
      footer: { text: '💜🃏 Arlequina Bot' },
      nativeFlowMessage: {
        buttons: [{
          name: 'quick_reply',
          buttonParamsJson: JSON.stringify({
            display_text: '📖 Abrir Menu',
            id: `${prefix}menu`
          })
        }]
      }
    }
  }

  const nodeBotaoErro = {
    tag: 'biz',
    attrs: {},
    content: [{
      tag: 'interactive',
      attrs: { type: 'native_flow', v: '1' },
      content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }]
    }]
  }
  const nodesExtrasErro = [nodeBotaoErro]
  if (!isJidGroup(from)) nodesExtrasErro.push({ tag: 'bot', attrs: { biz_bot: '1' } })

  const msgGeradaErro = generateWAMessageFromContent(from, conteudoErro, {
    userJid: columbina.user.id,
    messageId: generateMessageIDV2(columbina.user.id)
  })

  await columbina.relayMessage(from, msgGeradaErro.message, {
    messageId: msgGeradaErro.key.id,
    additionalNodes: nodesExtrasErro
  })
} catch(errCard) {
  RedLog(`[erro-cmd] botão falhou, caindo pro texto/imagem simples: ${errCard?.message}`)
  try {
    if (_imgBuf) {
      await columbina.sendMessage(from, { image: _imgBuf, caption: erroCaption, mentions: [sender] }, { quoted: info })
    } else {
      await columbina.sendMessage(from, { text: erroCaption, mentions: [sender] }, { quoted: info })
    }
  } catch(_) {
    try { await reply(erroCaption, from, info) } catch(_e2) {}
  }
}
return
}

const isOwnerCmd = targetPlugin.category === 'dono'
const isAdminCmd = targetPlugin.category === 'admin'
const isMonitorCmd = targetPlugin.category === 'monitor'
const isResenhaCmd = targetPlugin.category === 'resenha'
const isPremiumCmd = targetPlugin.category === 'premium'
const isBrincadeiraCmd = targetPlugin.category === 'brincadeiras'
const isRpgCmd = targetPlugin.category === 'rpg'


function isSenderMonitor() {
  try {
    const fs = require('fs')
    const { dbPath } = require('./arquivos/js/rpgDB.js')
    const u = fs.existsSync(dbPath) ? JSON.parse(fs.readFileSync(dbPath)) : {}
    return !!u[sender]?.monitor
  } catch { return false }
}

if (isOwnerCmd && !isDono(sender)) {
return reply('🤬Este comando é apenas para o dono do bot!', from, info)
}

if (isAdminCmd && !isGroup) {
return reply('😒 Este comando só pode ser usado em grupos!', from, info)
}

if (isAdminCmd && !isGroupAdmins && !isDono(sender) && !isSenderMonitor()) {
return reply('🤬 Este comando é apenas para administradores do grupo!', from, info)
}

if (isMonitorCmd && !isGroup) {
return reply('❌ Este comando só funciona em grupos!', from, info)
}

if (isMonitorCmd && !isGroupAdmins && !isDono(sender) && !isSenderMonitor()) {
return reply('🛡️ Este comando é apenas para Monitores, Admins ou Dono!', from, info)
}

if (isResenhaCmd && !gerenciadorComandos.ResenhaAtiva.get(from)) {
return reply('🥲 O modo resenha não está ativo neste grupo!', from, info)
}

if (isBrincadeiraCmd && isGroup && donoState.botStatus.brincadeiraGrupos[from] === false && !isDono(sender) && !isGroupAdmins) {
return reply(`🃏 *modobn* tá desativado! Peça um ADM para usar *${prefix}modobn 1* e liberar as brincadeiras 😈`, from, info)
}

if (isRpgCmd && isGroup && donoState.botStatus.rpgGrupos[from] === false && !isDono(sender) && !isGroupAdmins) {
return reply(`🎲 *modorpg* tá desligado nesse grupo! Peça um ADM para usar *${prefix}modorpg 1* e liberar o RPG 😈`, from, info)
}

if (isPremiumCmd && !gerenciadorComandos.isPremium(sender, donoJid)) {
return reply('👿 Este comando é apenas para usuarios premium!', from, info)
}







if (targetPlugin.needBotAdmin && !isBotGroupAdmins) {
return reply('🤧 Arlequina precisa ser administradora do grupo para executar este comando!\n\nAdicione Arlequina como ADMIN no grupo e tente novamente.', from, info)
}

try {
  // META AI MARK: contexto EXATO do usuário que executou este comando.
  // Atualizado imediatamente antes do plugin para evitar dados de outro grupo/mensagem.
  global.META_MARK_SENDER = sender
  global.META_MARK_NAME = pushname || info?.pushName || 'Usuário'
  if (columbina) {
    columbina.__metaMarkUsuario = {
      jid: sender,
      nome: global.META_MARK_NAME
    }
  }

await targetPlugin.execute({
columbina, arlequina: columbina, from, info, args, q, qOriginal, command, prefix,
reply: (text) => reply(text, from, info),
enviar: (text) => reply(text, from, info),
reagir: (emj) => reagir(emj, from, info),
mencionarIMG: (teks, Url) => mencionarIMG(teks, Url, info, from, columbina),
AudioMisheru: (source) => AudioMisheru(source, info, from),
isGroup, isDono: () => isDono(sender), 
isAdm: isGroupAdmins, 
isMonitor: isSenderMonitor(),
isBotAdm: isBotGroupAdmins,
sender, pushname, groupName, groupDesc, groupMembers, groupAdmins,
botNumber, donoJid, getFileBuffer, sleep, fetchJson, getRandom,
getMemberName, getPhoneNumberFromId, convertWhatsAppUser, getname,
isQuotedSticker, isQuotedImage, isQuotedVideo, isQuotedAudio, isQuotedDocument,
commandManager: gerenciadorComandos, config, inputToJid
})
} catch (err) {
RedLog(`Erro no comando ${command}: ${err.message}`)
reply(`😭 Erro ao executar comando: ${err.message}`, from, info)
}
}

async function main() {
columbina = await startConnection(gerenciadorComandos, config)

if (!columbina) {
RedLog('Vish pae, falha ao conectar')
setTimeout(main, 5000)
return
}



/*
 VIGIA DE CONEXÃO ZUMBI — às vezes o WhatsApp derruba a conexão sem
 avisar o bot (acontece muito quando o celular fica um tempo com a
 tela apagada / sem internet): o socket acha que ainda tá "aberto",
 não entra no "connection.update" de close, e o bot fica ligado mas
 travado, sem responder NADA, pra sempre. Aqui a gente marca toda vez
 que algo realmente acontece na conexão, e de tempos em tempos checa:
 se faz tempo demais sem nenhum sinal de vida (ou o socket não tá mais
 realmente aberto), reinicia o processo sozinho — o start.sh já tem o
 loop que reabre na hora.
*/
let ultimaAtividadeConexao = Date.now()
const LIMITE_SILENCIO_MS = 6 * 60 * 1000 // 6 minutos sem nenhum sinal de vida
columbina.ev.on('connection.update', () => { ultimaAtividadeConexao = Date.now() })
columbina.ev.on('messages.upsert', () => { ultimaAtividadeConexao = Date.now() })

const vigiaConexao = setInterval(() => {
  const socketRealmenteAberto = columbina?.ws?.readyState === undefined || columbina.ws.readyState === 1
  const semSinalDeVidaHaMuitoTempo = (Date.now() - ultimaAtividadeConexao) > LIMITE_SILENCIO_MS

  if (!socketRealmenteAberto || semSinalDeVidaHaMuitoTempo) {
    RedLog(`💜 Vigia detectou conexão travada (socket aberto? ${socketRealmenteAberto} | silêncio: ${Math.round((Date.now() - ultimaAtividadeConexao) / 1000)}s). Reiniciando pra reconectar do zero...`)
    clearInterval(vigiaConexao)
    setTimeout(() => process.exit(1), 500)
  }
}, 2 * 60 * 1000) // checa a cada 2 minutos

columbina.ev.on('messages.upsert', async (upsert) => {
if (upsert.type === 'notify' || upsert.type === 'append') {







for (const mensagemDoLote of upsert.messages || []) {
try {
await processMessage({ ...upsert, messages: [mensagemDoLote] }, columbina)
} catch (eLote) {
console.log('❌ ERRO ao processar mensagem do lote:', eLote?.message)
}
}
}
})



iniciarAgendaGrupoScheduler(() => columbina)
}

main()