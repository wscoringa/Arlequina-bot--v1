/*
            ARLEQUINA BOT

[=====/=====/=====/=====/=====/=====/=====/]
Bot criado e personalizado por 『𝙒𝙮𝙡𝙡𝙮𝙖𝙢』, com foco em desempenho,
organização e facilidade na criação de comandos via plugins.

Cada comando funciona em módulos/plugins independentes, deixando a
base mais limpa, rápida e fácil de editar.

Criador: 『𝙒𝙮𝙡𝙡𝙮𝙖𝙢』
Número: +55 31 9335-8417

Faça um bom proveito da base 🃏💜
[=====/=====/=====/=====/=====/=====/=====/]
*/

const fs = require('fs')
const path = require('path')
const colors = require('colors')
const { CyanLog, RedLog } = require('./arquivos/js/logger.js')
const { convertWhatsAppUser } = require('./arquivos/js/userManager.js')

class NucleoDeCmds {
constructor() {
this.commands = new Map()
this.categories = ['admin', 'dono', 'cmds-aleatorios', 'resenha', 'downloads', 'efeitos', 'midias', 'inteligencia-ia', 'rpg', 'quiz', 'social', 'brincadeiras', 'premium', 'menu', 'pesquisas']
this.ResenhaAtiva = new Map()
this.UsuariosPremium = new Map() // jid -> expiraEm (timestamp ms) | null = permanente
this.CarregarPremium()
this.CarregarPrefixosGrupo()
}

CarregarPremium() {
try {
if (fs.existsSync('./arquivos/json/premium.json')) {
const data = JSON.parse(fs.readFileSync('./arquivos/json/premium.json'))
this.UsuariosPremium.clear()

// Formato ANTIGO: { users: ["jid", "jid", ...] } -> todo mundo vira
// premium permanente (compatibilidade com quem já tinha o bot).
if (Array.isArray(data.users)) {
for (const user of data.users) {
if (user && user.endsWith('@s.whatsapp.net')) {
this.UsuariosPremium.set(user, null)
}
}
} else if (data.users && typeof data.users === 'object') {
// Formato NOVO: { users: { "jid": expiraEmTimestamp | null } }
for (const [user, expiraEm] of Object.entries(data.users)) {
if (user && user.endsWith('@s.whatsapp.net')) {
this.UsuariosPremium.set(user, expiraEm)
}
}
}
CyanLog(`💜 Premium carregado: ${this.UsuariosPremium.size} usuarios`)
} else {
fs.writeFileSync('./arquivos/json/premium.json', JSON.stringify({ users: {} }, null, 2))
}
} catch (e) {
RedLog('Erro ao carregar premium.json')
this.UsuariosPremium = new Map()
}
}

SalvarPremium() {
try {
const usersToSave = Object.fromEntries(this.UsuariosPremium)
fs.writeFileSync('./arquivos/json/premium.json', JSON.stringify({ users: usersToSave }, null, 2))
CyanLog(`💾 Premium salvo: ${this.UsuariosPremium.size} usuarios`)
} catch (e) {
RedLog('Erro ao salvar premium.json')
}
}

normalizar(userId) {
if (!userId) return null
if (userId.endsWith('@s.whatsapp.net')) {
return userId
}
try {
const convertido = convertWhatsAppUser(userId, 'jid')
if (convertido && typeof convertido === 'string' && convertido.endsWith('@s.whatsapp.net')) {
return convertido
}
} catch(e) {}
if (userId.endsWith('@lid')) {
const numero = userId.replace('@lid', '')
if (numero && numero.length >= 10) {
return `${numero}@s.whatsapp.net`
}
}
if (!userId.includes('@') && userId.length >= 10) {
return `${userId}@s.whatsapp.net`
}
return null
}

addPremium(userId, dias) {
if (!userId) return false

let normalizedJid = userId
if (!userId.includes('@s.whatsapp.net')) {
normalizedJid = this.normalizar(userId)
if (!normalizedJid) {
RedLog(`Formato invalido para premium: ${userId}`)
return false
}
}

// dias undefined/0/null -> premium permanente (expiraEm = null)
// dias > 0 -> expira em X dias a partir de AGORA (não soma em cima de
// um premium anterior — cada "addprm" reseta a contagem pra evitar
// confusão de "quantos dias ainda faltam")
const expiraEm = (dias && dias > 0) ? (Date.now() + dias * 24 * 60 * 60 * 1000) : null

const jaEraPremium = this.UsuariosPremium.has(normalizedJid)
this.UsuariosPremium.set(normalizedJid, expiraEm)
this.SalvarPremium()
CyanLog(`🤑 Usuario premium ${jaEraPremium ? 'atualizado' : 'adicionado'}: ${normalizedJid} (${expiraEm ? new Date(expiraEm).toLocaleString('pt-BR') : 'permanente'})`)
return true
}

removePremium(userId) {
if (!userId) return false
const normalizedJid = this.normalizar(userId)
if (!normalizedJid) {
return false
}
if (this.UsuariosPremium.has(normalizedJid)) {
this.UsuariosPremium.delete(normalizedJid)
this.SalvarPremium()
CyanLog(`🗑️ Usuario premium removido: ${normalizedJid}`)
return true
}
return false
}

isPremium(userId, donoId) {
if (!userId) return false
const normalizedUserId = this.normalizar(userId)
if (!normalizedUserId) return false
let normalizedDonoId = donoId
if (donoId && !donoId.includes('@')) {
normalizedDonoId = `${donoId}@s.whatsapp.net`
}
if (normalizedUserId === normalizedDonoId) return true

if (!this.UsuariosPremium.has(normalizedUserId)) return false

const expiraEm = this.UsuariosPremium.get(normalizedUserId)
if (expiraEm && expiraEm <= Date.now()) {
// Premium venceu -> remove automaticamente e trata como não-premium
this.UsuariosPremium.delete(normalizedUserId)
this.SalvarPremium()
return false
}
return true
}

// Retorna [{ jid, expiraEm }] — expiraEm é null pra premium permanente.
// Já limpa quem venceu antes de devolver a lista.
getPremiumUsers() {
const agora = Date.now()
let mudou = false
for (const [jid, expiraEm] of this.UsuariosPremium.entries()) {
if (expiraEm && expiraEm <= agora) {
this.UsuariosPremium.delete(jid)
mudou = true
}
}
if (mudou) this.SalvarPremium()
return Array.from(this.UsuariosPremium.entries()).map(([jid, expiraEm]) => ({ jid, expiraEm }))
}

CarregarPrefixosGrupo() {
try {
if (fs.existsSync('./arquivos/json/prefixos_grupo.json')) {
const data = JSON.parse(fs.readFileSync('./arquivos/json/prefixos_grupo.json'))
this.prefixosGrupo = data
CyanLog(`📋 Carregados ${Object.keys(this.prefixosGrupo).length} prefixos de grupos`)
} else {
this.prefixosGrupo = {}
fs.writeFileSync('./arquivos/json/prefixos_grupo.json', JSON.stringify({}, null, 2))
}
} catch (e) {
RedLog('Erro ao carregar prefixos_grupo.json')
this.prefixosGrupo = {}
}
}

SalvarPrefixosGrupo() {
try {
fs.writeFileSync('./arquivos/json/prefixos_grupo.json', JSON.stringify(this.prefixosGrupo, null, 2))
} catch (e) {
RedLog('Erro ao salvar prefixos_grupo.json')
}
}

ObterPrefixoGrupo(groupId) {
return this.prefixosGrupo[groupId] || null
}

DefinirPrefixoGrupo(groupId, prefixo) {
if (!prefixo || prefixo.length !== 1) {
return false
}
this.prefixosGrupo[groupId] = prefixo
this.SalvarPrefixosGrupo()
return true
}

RemoverPrefixoGrupo(groupId) {
if (this.prefixosGrupo[groupId]) {
delete this.prefixosGrupo[groupId]
this.SalvarPrefixosGrupo()
return true
}
return false
}

carregarPlugins() {
CyanLog('📂 Carregando plugins...')
this.commands.clear()
let totalCarregado = 0
const carregarDaPasta = (dir, category) => {
if (!fs.existsSync(dir)) return
const files = fs.readdirSync(dir)
for (const file of files) {
const fullPath = path.join(dir, file)
const stat = fs.statSync(fullPath)
if (stat.isDirectory()) {
carregarDaPasta(fullPath, category)
} else if (file.endsWith('.js')) {
try {
delete require.cache[require.resolve(fullPath)]
const plugin = require(fullPath)
if (plugin.name && plugin.execute) {
this.commands.set(plugin.name, {
...plugin,
category,
file: fullPath
})
if (plugin.aliases && Array.isArray(plugin.aliases)) {
for (const alias of plugin.aliases) {
if (!this.commands.has(alias)) {
this.commands.set(alias, {
...plugin,
name: alias,
category,
file: fullPath,
isAlias: true,
originalName: plugin.name
})
}
}
}
CyanLog(`💜 Comando carregado: ${plugin.name} (${category})`)
totalCarregado++
} else {
RedLog(`❌ Plugin invalido: ${file} - faltando name ou execute`)
}
} catch (e) {
RedLog(`❌ Erro ao carregar ${file}: ${e.message}`)
}
}
}
}
for (const category of this.categories) {
const pluginDir = path.join(__dirname, 'plugins', category)
carregarDaPasta(pluginDir, category)
}
CyanLog(`💜🃏 Total de comandos carregados: ${totalCarregado} 🃏💜`)
}

ResenhaAtiva(grupoId) {
return this.ResenhaAtiva.get(grupoId) === true
}

DefinirResenhaAtiva(grupoId, ativa) {
this.ResenhaAtiva.set(grupoId, ativa)
}

ObterComando(cmd) {
return this.commands.get(cmd)
}

ObterTodosComandos() {
return Array.from(this.commands.values())
}

ObterComandosPorCategoria(category) {
return this.ObterTodosComandos().filter(cmd => cmd.category === category && !cmd.isAlias)
}
}

module.exports = NucleoDeCmds
