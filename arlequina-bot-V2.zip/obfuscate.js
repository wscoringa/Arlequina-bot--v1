/**
 * obfuscate.js
 * Ofusca o código do Arlequina Bot antes de publicar, mantendo o bot 100% funcional.
 *
 * COMO USAR:
 *   1. Coloque este arquivo na RAIZ do projeto (mesma pasta do index.js e package.json)
 *   2. Instale a dependência (só uma vez):
 *        npm install --save-dev javascript-obfuscator
 *   3. Rode:
 *        node obfuscate.js
 *   4. O resultado ofuscado vai para a pasta ./dist
 *      Copie database/, midias/, package.json, package-lock.json, node_modules,
 *      start.sh e LICENSE para dentro de dist/ antes de publicar (o script já
 *      copia os principais automaticamente, veja abaixo).
 *
 * O que NÃO é ofuscado (de propósito):
 *   - database/config.json e qualquer coisa em database/ (dados/configuração, não código)
 *   - node_modules (bibliotecas de terceiros — não são suas para ofuscar)
 *   - package.json / package-lock.json
 *   - LICENSE (mantenha o aviso de copyright original — a base é MIT)
 */

const fs = require("fs");
const path = require("path");
const JavaScriptObfuscator = require("javascript-obfuscator");

const ROOT = __dirname;
const OUT = path.join(ROOT, "dist");

// Pastas/arquivos que contêm CÓDIGO e devem ser ofuscados
const CODE_TARGETS = ["index.js", "conexao.js", "comandos.js", "plugins"];

// Coisas que devem ser copiadas sem alteração para dist/
const COPY_AS_IS = [
  "package.json",
  "package-lock.json",
  "LICENSE",
  "README.md",
  "start.sh",
  "limpar-sessao.sh",
  "database",
  "midias",
  "arquivos",
  "temp",
];

const OBFUSCATOR_OPTIONS = {
  compact: true,
  controlFlowFlattening: true,
  controlFlowFlatteningThreshold: 0.75,
  deadCodeInjection: true,
  deadCodeInjectionThreshold: 0.3,
  debugProtection: false, // deixe "false" pra não travar em VPS/Termux com pouco recurso
  disableConsoleOutput: false, // "true" some com console.log — deixe false pra manter seus logs de debug
  identifierNamesGenerator: "hexadecimal",
  numbersToExpressions: true,
  renameGlobals: false,
  selfDefending: true, // quebra o código se alguém tentar reformatar/prettify
  simplify: true,
  splitStrings: true,
  splitStringsChunkLength: 8,
  stringArray: true,
  stringArrayEncoding: ["base64"],
  stringArrayThreshold: 0.75,
  transformObjectKeys: true,
  target: "node",
};

function walk(rel) {
  const abs = path.join(ROOT, rel);
  const stat = fs.statSync(abs);
  if (stat.isDirectory()) {
    let files = [];
    for (const entry of fs.readdirSync(abs)) {
      files = files.concat(walk(path.join(rel, entry)));
    }
    return files;
  }
  if (rel.endsWith(".js")) return [rel];
  return [];
}

function ensureDir(p) {
  fs.mkdirSync(p, { recursive: true });
}

function copyRecursive(src, dest) {
  if (!fs.existsSync(src)) return;
  const stat = fs.statSync(src);
  if (stat.isDirectory()) {
    ensureDir(dest);
    for (const entry of fs.readdirSync(src)) {
      copyRecursive(path.join(src, entry), path.join(dest, entry));
    }
  } else {
    ensureDir(path.dirname(dest));
    fs.copyFileSync(src, dest);
  }
}

function main() {
  if (fs.existsSync(OUT)) fs.rmSync(OUT, { recursive: true, force: true });
  ensureDir(OUT);

  // 1. Ofusca os arquivos de código
  let jsFiles = [];
  for (const target of CODE_TARGETS) {
    if (fs.existsSync(path.join(ROOT, target))) {
      jsFiles = jsFiles.concat(walk(target));
    }
  }

  console.log(`Encontrados ${jsFiles.length} arquivos .js para ofuscar...`);

  for (const rel of jsFiles) {
    const srcPath = path.join(ROOT, rel);
    const destPath = path.join(OUT, rel);
    const code = fs.readFileSync(srcPath, "utf8");
    try {
      const result = JavaScriptObfuscator.obfuscate(code, OBFUSCATOR_OPTIONS);
      ensureDir(path.dirname(destPath));
      fs.writeFileSync(destPath, result.getObfuscatedCode(), "utf8");
      console.log(`  ok: ${rel}`);
    } catch (err) {
      console.error(`  FALHOU em ${rel}: ${err.message}`);
      console.error("  -> copiando o arquivo original sem ofuscar para não quebrar o bot.");
      ensureDir(path.dirname(destPath));
      fs.copyFileSync(srcPath, destPath);
    }
  }

  // 2. Copia o resto sem mexer
  for (const item of COPY_AS_IS) {
    copyRecursive(path.join(ROOT, item), path.join(OUT, item));
  }

  console.log("\nPronto! Código protegido gerado em ./dist");
  console.log("Rode `npm install` dentro de dist/ (ou copie node_modules pra lá) e teste com `sh start.sh` antes de publicar.");
}

main();
