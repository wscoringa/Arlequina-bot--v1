/*
 Gerar uma imagem a partir de uma descrição livre (tipo "Arlequina e
 Coringa na chuva") exige um modelo de IA de difusão de verdade — isso
 não roda localmente num celular/VPS comum, não existe jeito 100%
 offline/sem-internet de fazer isso (diferente do áudio, que dá pra
 fazer local com espeak-ng).

 Por isso esse helper usa o Pollinations.ai: é gratuito, não pede
 chave, token nem cadastro — só uma requisição http simples. É o mais
 perto que existe de "sem API" pra gerar imagem de verdade a partir de
 texto.
*/
const axios = require('axios')

async function gerarImagem(prompt, { largura = 768, altura = 768 } = {}) {
  const seed = Math.floor(Math.random() * 1_000_000)
  const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=${largura}&height=${altura}&nologo=true&seed=${seed}`

  const resp = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout: 60000,
    headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0 Mobile Safari/537.36' }
  })
  const buffer = Buffer.from(resp.data)
  if (!buffer || buffer.length < 1000) throw new Error('Imagem vazia.')
  return buffer
}

module.exports = { gerarImagem }
