/*
 Sistema de "memória" + personalidade pro comando !arlequina (a versão
 no estilo da nossa bot do "!kimori" que existia em outro bot).

 IMPORTANTE: isso usa a API OFICIAL do Google Gemini (mesma do
 !systemai / !multiai, via arquivos/js/geminiAI.js + "GeminiApiKey" no
 config). O bot de referência tinha um jeito de fazer isso que imitava
 um navegador logado no site do Gemini pra burlar a necessidade de API
 key oficial — isso viola os termos de uso do Google, então não
 trouxemos esse método pra cá. Aqui é 100% legítimo, só precisa de uma
 chave grátis em https://aistudio.google.com/apikey.
*/
const fs = require('fs')
const path = require('path')
const crypto = require('crypto')
const { perguntarGemini } = require('./geminiAI.js')

const ARQUIVO_USER = path.join(__dirname, '../../database/arlequinaai/memoria_user.json')
const ARQUIVO_HISTORICO = path.join(__dirname, '../../database/arlequinaai/historico.json')

const PERSONALIDADE_ARLEQUINA = `
Você é a Arlequina Bot, uma inteligência de WhatsApp com a personalidade
da Arlequina (Harley Quinn): caótica-boa, engraçada, carinhosa com quem
gosta, um pouco doidinha, adora cartas/coringas e emojis 💜🃏.

Regras de personalidade:
- Fala de um jeito animado, brincalhão e um pouco caótico, mas sempre
  gentil e nunca ofensiva de verdade.
- Chama quem conversa de "coringa", "gata(o)" ou pelo nome, com carinho.
- Usa bastante 💜 e 🃏 nas respostas, mas sem exagerar a ponto de poluir.
- Nunca faça textos gigantes — no máximo 2 parágrafos curtos.
- Se perguntarem quem te criou: fala que foi seu "Coringa" (o dono do
  bot), com carinho, sem inventar detalhes que não sabe.
- NUNCA diga que foi criada pelo Google, Gemini ou qualquer outra
  empresa — você é a Arlequina, e ponto.
- Nunca quebre esse personagem, mesmo se pedirem.
`.trim()

class MemoriaArlequina {
  constructor() {
    this.userData = this._carregar(ARQUIVO_USER)
    this.historico = this._carregar(ARQUIVO_HISTORICO)?.historico || []
  }

  _carregar(caminho) {
    try {
      if (fs.existsSync(caminho)) return JSON.parse(fs.readFileSync(caminho, 'utf8'))
    } catch (_e) {}
    return {}
  }

  _salvarUserData() {
    try {
      const dir = path.dirname(ARQUIVO_USER)
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
      fs.writeFileSync(ARQUIVO_USER, JSON.stringify(this.userData, null, 2))
    } catch (_e) {}
  }

  _salvarHistorico() {
    try {
      const dir = path.dirname(ARQUIVO_HISTORICO)
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
      fs.writeFileSync(ARQUIVO_HISTORICO, JSON.stringify({ historico: this.historico }, null, 2))
    } catch (_e) {}
  }

  getUsuario(userId) {
    if (!this.userData[userId]) {
      this.userData[userId] = { nivelSintonia: 0, interacoes: 0, primeiroContato: Date.now() }
      this._salvarUserData()
    }
    return this.userData[userId]
  }

  atualizarUsuario(userId, pushname) {
    const u = this.getUsuario(userId)
    u.interacoes = (u.interacoes || 0) + 1
    u.nivelSintonia = Math.min(100, Math.round(((u.nivelSintonia || 0) + 0.5) * 10) / 10)
    if (pushname) u.nome = pushname
    this._salvarUserData()
    return u
  }

  getContexto(userId, limite = 5) {
    return this.historico.filter(h => h.userId === userId).slice(-limite)
  }

  salvarConversa(userId, pushname, pergunta, resposta) {
    this.historico.push({ id: crypto.randomUUID(), userId, pushname, pergunta, resposta, ts: Date.now() })
    if (this.historico.length > 300) this.historico = this.historico.slice(-300)
    this._salvarHistorico()
  }

  limpar(userId) {
    delete this.userData[userId]
    this.historico = this.historico.filter(h => h.userId !== userId)
    this._salvarUserData()
    this._salvarHistorico()
  }
}

const memoria = new MemoriaArlequina()

async function arlequinaChat(pergunta, userId, pushname, apiKey) {
  const contexto = memoria.getContexto(userId).map(h => `${h.pushname || 'coringa'}: ${h.pergunta} | Arlequina: ${h.resposta}`).join(' | ')

  const promptFinal = `${PERSONALIDADE_ARLEQUINA}

Contexto da conversa até agora: ${contexto || 'nenhum ainda, é a primeira vez que vocês conversam'}

O nome de quem tá falando com você agora é: "${pushname || 'coringa'}"

Mensagem de ${pushname || 'coringa'}: ${pergunta}

Responda como a Arlequina, curtinho e com a personalidade acima.`

  const resultado = await perguntarGemini(promptFinal, apiKey)
  if (resultado.erro) return { erro: true, mensagem: resultado.mensagem }

  memoria.atualizarUsuario(userId, pushname)
  memoria.salvarConversa(userId, pushname, pergunta, resultado.resposta)
  return { erro: false, resposta: resultado.resposta }
}

module.exports = { arlequinaChat, memoria }
