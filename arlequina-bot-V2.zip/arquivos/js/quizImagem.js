// Helper de fotos do menu QUIZ. A foto pode ser:
//  • uma chave de arquivos/js/quizFotos.js (ex: 'tempo', 'forca_3')
//  • um link  https://...
//  • uma imagem embutida  data:image/jpeg;base64,...
const { FOTOS } = require('./quizFotos.js')

const MAX_ERROS = 6 // cabeça, corpo, braço, braço, perna, perna

function resolverFoto(foto) {
  const f = FOTOS[foto] || foto
  if (typeof f !== 'string') return null
  if (f.startsWith('data:')) return { image: Buffer.from(f.split(',')[1], 'base64') }
  if (/^https?:\/\//i.test(f)) return { image: { url: f } }
  return null
}

// Manda a foto do comando com a legenda. `extra` aceita { mentions: [...] }.
async function enviarQuizImg(arlequina, from, info, foto, texto, extra = {}) {
  const opts = info ? { quoted: info } : undefined
  try {
    const img = resolverFoto(foto)
    if (img) {
      await arlequina.sendMessage(from, { ...img, caption: texto, ...extra }, opts)
      return
    }
  } catch (e) {
    console.log('⚠️ quizImagem:', e?.message)
  }
  await arlequina.sendMessage(from, { text: texto, ...extra }, opts)
}

// Processa uma letra na forca: atualiza a sessão e diz qual foto usar.
// O boneco vai sendo desenhado a cada erro: forca_1 (cabeça) ... forca_6 (completo).
function jogadaForca(sess, letra) {
  sess.letrasUsadas.push(letra)
  const certa = sess.palavra.includes(letra)
  if (!certa) sess.erros++
  const oculta = sess.palavra.split('').map(l => sess.letrasUsadas.includes(l) ? l : '_').join(' ')
  const ganhou = !oculta.includes('_')
  const perdeu = !ganhou && sess.erros >= MAX_ERROS
  const vidas = '💜'.repeat(Math.max(0, MAX_ERROS - sess.erros)) + '🖤'.repeat(Math.min(MAX_ERROS, sess.erros))
  const img = ganhou ? 'forca_win' : perdeu ? 'forca_lose' : `forca_${sess.erros}`
  return { certa, oculta, ganhou, perdeu, vidas, img }
}

module.exports = { enviarQuizImg, jogadaForca, MAX_ERROS }
