/*
 Sistema de "figurinha vira comando" (tipo !rgfig / !delfig do print que
 o dono mandou). Registra uma figurinha específica (pelo hash único
 dela) apontando pra um comando do bot. Depois, sempre que alguém mandar
 aquela MESMA figurinha no grupo, o bot executa o comando registrado
 automaticamente — sem precisar digitar nada.
*/
const fs = require('fs')
const path = require('path')

const DB_PATH = path.join(__dirname, '../../database/figComandos.json')

function carregar() {
  try {
    if (!fs.existsSync(DB_PATH)) return {}
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'))
  } catch {
    return {}
  }
}

function salvar(dados) {
  try {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true })
    fs.writeFileSync(DB_PATH, JSON.stringify(dados, null, 2))
  } catch (e) {
    console.log('❌ ERRO ao salvar figComandos:', e?.message)
  }
}

// Gera o ID único da figurinha a partir do hash do arquivo (fileSha256).
// Duas figurinhas iguais (mesmo arquivo) sempre geram o mesmo ID.
function idDaFigurinha(stickerMessage) {
  if (!stickerMessage?.fileSha256) return null
  return Buffer.from(stickerMessage.fileSha256).toString('base64')
}

function registrar(stickerMessage, comando) {
  const id = idDaFigurinha(stickerMessage)
  if (!id) return null
  const dados = carregar()
  dados[id] = comando
  salvar(dados)
  return id
}

function remover(stickerMessage) {
  const id = idDaFigurinha(stickerMessage)
  if (!id) return null
  const dados = carregar()
  if (!dados[id]) return null
  const comandoRemovido = dados[id]
  delete dados[id]
  salvar(dados)
  return comandoRemovido
}

function buscarComando(stickerMessage) {
  const id = idDaFigurinha(stickerMessage)
  if (!id) return null
  const dados = carregar()
  return dados[id] || null
}

module.exports = { idDaFigurinha, registrar, remover, buscarComando }
