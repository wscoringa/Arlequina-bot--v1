/*
  Sistema de lembretes por grupo (/lembrete, /resetelbt)
  Guardado em memória (Map). Como não é persistido em disco, os lembretes
  ativos são perdidos se o bot reiniciar antes de disparar.
*/
const timers = new Map() // groupJid -> [{ id, timeoutRef, texto, sender, disparaEm }]

function addLembrete(groupJid, texto, sender, delayMs, onDisparar) {
  if (!timers.has(groupJid)) timers.set(groupJid, [])
  const id = Date.now() + '_' + Math.floor(Math.random() * 10000)
  const timeoutRef = setTimeout(async () => {
    const lista = timers.get(groupJid) || []
    timers.set(groupJid, lista.filter(l => l.id !== id))
    try { await onDisparar() } catch (e) {}
  }, delayMs)
  timers.get(groupJid).push({ id, timeoutRef, texto, sender, disparaEm: Date.now() + delayMs })
  return id
}

function listarLembretes(groupJid) {
  return timers.get(groupJid) || []
}

function resetarLembretes(groupJid) {
  const lista = timers.get(groupJid) || []
  for (const l of lista) clearTimeout(l.timeoutRef)
  const total = lista.length
  timers.set(groupJid, [])
  return total
}

module.exports = { addLembrete, listarLembretes, resetarLembretes }
