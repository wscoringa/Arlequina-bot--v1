/*
  Sistema de rastreamento de atividade por grupo
  Arlequina Bot - coringa</>
  Registra: mensagens, comandos, figurinhas
  Armazena em: database/atividade/<groupJid>.json
*/
const fs = require('fs')
const path = require('path')

const DIR = './database/atividade'
if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true })

function arquivoGrupo(groupJid) {
  const safe = groupJid.replace(/[^a-zA-Z0-9]/g, '_')
  return path.join(DIR, `${safe}.json`)
}

function carregarGrupo(groupJid) {
  const f = arquivoGrupo(groupJid)
  try {
    if (fs.existsSync(f)) return JSON.parse(fs.readFileSync(f, 'utf-8'))
  } catch (e) {}
  return {}
}

function salvarGrupo(groupJid, dados) {
  fs.writeFileSync(arquivoGrupo(groupJid), JSON.stringify(dados, null, 2))
}

// Registra atividade de um usuário em um grupo
// tipo: 'msg' | 'cmd' | 'sticker'
function registrarAtividade(groupJid, userJid, nome, tipo) {
  if (!groupJid || !userJid) return
  const dados = carregarGrupo(groupJid)
  if (!dados[userJid]) {
    dados[userJid] = { nome: nome || userJid.split('@')[0], msgs: 0, cmds: 0, stickers: 0, total: 0 }
  }
  // Atualiza nome se tiver
  if (nome) dados[userJid].nome = nome

  if (tipo === 'msg')     dados[userJid].msgs++
  if (tipo === 'cmd')     dados[userJid].cmds++
  if (tipo === 'sticker') dados[userJid].stickers++

  dados[userJid].total = (dados[userJid].msgs || 0) + (dados[userJid].cmds || 0) + (dados[userJid].stickers || 0)
  salvarGrupo(groupJid, dados)
}

// Retorna top N usuários do grupo ordenados por total decrescente
function topAtivos(groupJid, n = 10) {
  const dados = carregarGrupo(groupJid)
  return Object.entries(dados)
    .map(([jid, d]) => ({ jid, ...d }))
    .sort((a, b) => b.total - a.total)
    .slice(0, n)
}

// Zera atividade de um grupo
function zerarAtividade(groupJid) {
  salvarGrupo(groupJid, {})
}

// Retorna os membros do grupo (excluindo admins e o próprio bot, se informado)
// ordenados pela atividade em ordem CRESCENTE (os mais inativos primeiro).
// Membros que nunca interagiram (sem registro) entram com total 0.
function topInativos(groupJid, groupMembers = [], n = 10, ignorarJids = []) {
  const dados = carregarGrupo(groupJid)
  const lista = (groupMembers || [])
    .map(m => {
      // BUGFIX: quem registra atividade (registrarAtividade) usa o
      // número de telefone JÁ RESOLVIDO (sender pós-lid). Mas o "id" do
      // participante aqui pode vir como "@lid" (não resolvido) quando o
      // grupo usa o sistema de privacidade novo do WhatsApp. Se a gente
      // buscar só pelo "id", quase todo mundo aparece com 0 interações
      // mesmo tendo mandado mensagem, porque a chave nunca bate. Por
      // isso preferimos o phoneNumber (o mesmo formato usado ao gravar).
      const idPreferido = m.phoneNumber || m.id || m.jid || m.lid
      const idAlternativo = m.id || m.jid || m.lid
      return { idPreferido, idAlternativo }
    })
    .filter(o => o.idPreferido)
    .filter(o => !ignorarJids.includes(o.idPreferido) && !ignorarJids.includes(o.idAlternativo))
    .map(({ idPreferido, idAlternativo }) => {
      // Tenta achar o registro tanto pelo número resolvido quanto pelo
      // id bruto (cobre os dois jeitos que a atividade pode ter sido
      // salva, em bots que rodaram antes desse fix).
      const d = dados[idPreferido] || dados[idAlternativo]
      return {
        jid: idPreferido,
        nome: d?.nome || idPreferido.split('@')[0],
        msgs: d?.msgs || 0,
        cmds: d?.cmds || 0,
        stickers: d?.stickers || 0,
        total: d?.total || 0
      }
    })
    .sort((a, b) => a.total - b.total)
    .slice(0, n)
  return lista
}

// Retorna a atividade individual de um usuário em um grupo
function getAtividadeUsuario(groupJid, userJid) {
  const dados = carregarGrupo(groupJid)
  const d = dados[userJid]
  return {
    jid: userJid,
    msgs: d?.msgs || 0,
    cmds: d?.cmds || 0,
    stickers: d?.stickers || 0,
    total: d?.total || 0
  }
}

module.exports = { registrarAtividade, topAtivos, topInativos, getAtividadeUsuario, zerarAtividade }
