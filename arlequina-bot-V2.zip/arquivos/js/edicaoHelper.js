/*
  Helper de "edição" de foto/vídeo pra Arlequina Bot.
  Usa fluent-ffmpeg (já é dependência do projeto) pra aplicar efeitos de
  verdade (cor, flash, flicker) no estilo "edit" que rola no TikTok/CapCut.

  Não gera vídeo/movimento a partir de texto livre (isso exigiria uma IA de
  geração de vídeo, que não está disponível aqui) — mas reconhece um
  conjunto de PALAVRAS-CHAVE de efeito (fogo, explosão, gelo, neon, sombrio)
  no texto digitado e aplica o efeito de verdade correspondente. O resto do
  texto (o que não é palavra-chave de efeito) vira legenda estampada no
  vídeo.
*/
const fs = require('fs')
const ff = require('fluent-ffmpeg')
const path = require('path')
const os = require('os')
const { Jimp, loadFont, HorizontalAlign } = require('jimp')

// Cada efeito é um filtro de vídeo (ffmpeg) validado manualmente.
const EFEITOS = {
  fogo: {
    aliases: ['fogo', 'fire', 'chamas', 'incendio', 'incêndio'],
    emoji: '🔥',
    filtro: "eq=eval=frame:brightness='0.08*sin(2*PI*t*6)':contrast=1.25:saturation=1.5,curves=r='0/0 0.5/0.68 1/1':g='0/0 0.5/0.32 1/0.75':b='0/0 0.5/0.10 1/0.4'"
  },
  explosao: {
    aliases: ['explosao', 'explosão', 'explosion', 'bomba'],
    emoji: '💥',
    filtro: "eq=eval=frame:brightness='if(lt(t,0.2),0.9*(1-t/0.2),0)':contrast=1.3,curves=r='0/0.05 1/1':g='0/0.02 1/0.95':b='0/0 1/0.85'"
  },
  gelo: {
    aliases: ['gelo', 'ice', 'frio', 'congelado'],
    emoji: '🧊',
    filtro: "curves=r='0/0 1/0.75':g='0/0 1/0.9':b='0/0.1 1/1',eq=contrast=1.15:saturation=1.1"
  },
  neon: {
    aliases: ['neon', 'cyberpunk'],
    emoji: '💜',
    filtro: "eq=saturation=1.8:contrast=1.3,curves=r='0/0.05 1/1':g='0/0 1/0.9':b='0/0.1 1/1'"
  },
  sombrio: {
    aliases: ['sombrio', 'dark', 'trevas', 'sombra'],
    emoji: '🌑',
    filtro: 'eq=brightness=-0.08:contrast=1.3:saturation=0.7,vignette=PI/3'
  }
}

function normalizar(txt) {
  return String(txt || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
}

// Procura uma palavra-chave de efeito no texto digitado. Retorna a chave do
// efeito encontrado (ou null), o filtro ffmpeg correspondente, e o texto que
// sobrou (sem a palavra-chave) pra usar como legenda.
function detectarEfeito(textoDigitado) {
  const original = String(textoDigitado || '')
  const normalizado = normalizar(original)

  for (const [chave, dados] of Object.entries(EFEITOS)) {
    for (const alias of dados.aliases) {
      const aliasNorm = normalizar(alias)
      const regex = new RegExp(`\\b${aliasNorm}\\b`, 'i')
      if (regex.test(normalizado)) {
        const textoRestante = original
          .replace(new RegExp(alias, 'ig'), '')
          .replace(/\s+/g, ' ')
          .trim()
        return { chave, emoji: dados.emoji, filtro: dados.filtro, textoRestante }
      }
    }
  }
  return { chave: null, emoji: null, filtro: '', textoRestante: original.trim() }
}

function listarEfeitosDisponiveis() {
  return Object.entries(EFEITOS).map(([chave, d]) => `${d.emoji} ${chave}`).join(', ')
}

function caminhoFonte(tamanho) {
  const pkgPath = require.resolve('@jimp/plugin-print/package.json')
  const fontDir = path.dirname(pkgPath)
  return path.join(fontDir, `dist/fonts/open-sans/open-sans-${tamanho}-white/open-sans-${tamanho}-white.fnt`)
}

// Gera um PNG transparente com o texto (fundo preto semi-transparente atrás
// pra ficar legível em cima de qualquer vídeo), do tamanho exato da largura
// do vídeo de destino.
async function gerarLegendaPNG(texto, largura) {
  const tamanhoFonte = largura >= 900 ? 64 : 32
  const font = await loadFont(caminhoFonte(tamanhoFonte))

  const altura = Math.round(tamanhoFonte * 2.4)
  const img = new Jimp({ width: largura, height: altura, color: 0x00000000 })
  const faixa = new Jimp({ width: largura, height: altura, color: 0x000000aa })
  img.composite(faixa, 0, 0)

  img.print({
    x: 0,
    y: Math.round(altura * 0.2),
    font,
    text: { text: texto, alignmentX: HorizontalAlign.CENTER },
    maxWidth: largura
  })

  const tmpPng = path.join(os.tmpdir(), `edit_legenda_${Date.now()}_${Math.random().toString(36).slice(2)}.png`)
  await img.write(tmpPng)
  return tmpPng
}

function limparArquivos(...arquivos) {
  for (const a of arquivos) {
    try { if (a && fs.existsSync(a)) fs.unlinkSync(a) } catch (e) {}
  }
}

// Transforma uma FOTO num vídeo curto animado (efeito "Ken Burns": zoom lento
// + cor mais viva + fade de entrada/saída). Duração, efeito e legenda vêm do
// texto digitado (ex: "fogo", "explosão feliz aniversário").
async function criarEditImagem(buffer, duracaoSegundos, textoDigitado) {
  const tmpIn = path.join(os.tmpdir(), `edit_img_in_${Date.now()}_${Math.random().toString(36).slice(2)}.jpg`)
  const tmpOut = path.join(os.tmpdir(), `edit_img_out_${Date.now()}_${Math.random().toString(36).slice(2)}.mp4`)
  fs.writeFileSync(tmpIn, buffer)

  const DURACAO = Math.min(Math.max(Number(duracaoSegundos) || 4, 2), 60)
  const FPS = 25
  const FRAMES = Math.round(DURACAO * FPS)
  const LARGURA = 768

  const { chave: efeitoAplicado, emoji, filtro: filtroEfeito, textoRestante } = detectarEfeito(textoDigitado)

  let legendaPng = null
  if (textoRestante) {
    try {
      legendaPng = await gerarLegendaPNG(textoRestante, LARGURA)
    } catch (e) {
      console.error('ERRO ao gerar legenda (imagem):', e?.message)
    }
  }

  const filtroCor = filtroEfeito || 'eq=saturation=1.5:contrast=1.15:brightness=0.02'
  const filtroBase = `scale=${LARGURA}:-2,zoompan=z='min(zoom+0.0018,1.25)':d=${FRAMES}:s=${LARGURA}x1024:fps=${FPS},${filtroCor},fade=in:0:12,fade=out:st=${DURACAO - 0.5}:d=0.5`

  const outputOptions = ['-t', String(DURACAO), '-pix_fmt', 'yuv420p', '-movflags', 'faststart']

  try {
    await new Promise((resolve, reject) => {
      const comando = ff(tmpIn).loop(DURACAO)

      if (legendaPng) {
        comando.input(legendaPng)
        outputOptions.unshift(
          '-filter_complex',
          `[0:v]${filtroBase}[base];[base][1:v]overlay=0:main_h-overlay_h-40[vout]`,
          '-map', '[vout]'
        )
      } else {
        outputOptions.unshift('-vf', filtroBase)
      }

      comando
        .on('error', reject)
        .on('end', () => resolve(true))
        .addOutputOptions(outputOptions)
        .save(tmpOut)
    })
    return { buffer: fs.readFileSync(tmpOut), efeitoAplicado, emoji }
  } finally {
    limparArquivos(tmpIn, tmpOut, legendaPng)
  }
}

// Aplica um efeito de "edit" num VÍDEO já existente: cor/flash/flicker de
// acordo com a palavra-chave detectada no texto, fade de entrada/saída, leve
// acelerada e legenda opcional. Se não passar duração, usa o vídeo inteiro.
async function criarEditVideo(buffer, duracaoSegundos, textoDigitado) {
  const tmpIn = path.join(os.tmpdir(), `edit_vid_in_${Date.now()}_${Math.random().toString(36).slice(2)}.mp4`)
  const tmpOut = path.join(os.tmpdir(), `edit_vid_out_${Date.now()}_${Math.random().toString(36).slice(2)}.mp4`)
  fs.writeFileSync(tmpIn, buffer)

  const duracaoCustom = Number(duracaoSegundos) || null
  const DURACAO_FIXA = duracaoCustom ? Math.min(Math.max(duracaoCustom, 2), 120) : null

  // Descobre duração e largura reais do vídeo (precisa da largura pra gerar
  // a legenda do tamanho certo, e da duração pra calcular o fade-out).
  const infoVideo = await new Promise((resolve) => {
    ff.ffprobe(tmpIn, (err, meta) => {
      if (err) return resolve({ duracao: 8, largura: 720 })
      const streamVideo = meta?.streams?.find(s => s.codec_type === 'video')
      resolve({
        duracao: meta?.format?.duration || 8,
        largura: streamVideo?.width || 720
      })
    })
  })

  const duracaoReal = DURACAO_FIXA || infoVideo.duracao
  const fadeOutStart = Math.max(duracaoReal - 0.6, 0.1)

  const { chave: efeitoAplicado, emoji, filtro: filtroEfeito, textoRestante } = detectarEfeito(textoDigitado)

  let legendaPng = null
  if (textoRestante) {
    try {
      legendaPng = await gerarLegendaPNG(textoRestante, infoVideo.largura)
    } catch (e) {
      console.error('ERRO ao gerar legenda (vídeo):', e?.message)
    }
  }

  const filtroCor = filtroEfeito || 'eq=saturation=1.6:contrast=1.15:brightness=0.03,vignette'
  const filtroBase = `${filtroCor},fade=in:0:15,fade=out:st=${fadeOutStart}:d=0.6,setpts=0.926*PTS`

  const outputOptions = ['-map', '0:a?', '-af', 'atempo=1.08', '-pix_fmt', 'yuv420p', '-movflags', 'faststart']
  if (DURACAO_FIXA) outputOptions.push('-t', String(DURACAO_FIXA))

  if (legendaPng) {
    outputOptions.unshift(
      '-filter_complex',
      `[0:v]${filtroBase}[base];[base][1:v]overlay=0:main_h-overlay_h-40[vout]`,
      '-map', '[vout]'
    )
  } else {
    outputOptions.unshift('-vf', filtroBase, '-map', '0:v')
  }

  try {
    await new Promise((resolve, reject) => {
      const comando = ff(tmpIn)
      if (legendaPng) comando.input(legendaPng)

      comando
        .on('error', reject)
        .on('end', () => resolve(true))
        .addOutputOptions(outputOptions)
        .save(tmpOut)
    })
    return { buffer: fs.readFileSync(tmpOut), efeitoAplicado, emoji }
  } finally {
    limparArquivos(tmpIn, tmpOut, legendaPng)
  }
}

module.exports = { criarEditImagem, criarEditVideo, listarEfeitosDisponiveis }
