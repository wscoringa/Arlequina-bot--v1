/*
 Helper de estilo visual padrão da Arlequina Bot.
 Usado pra deixar TODOS os comandos com a mesma moldura do menu:

 ╭─━━─🃏💜「 *TITULO* 」💜🃏─━━─╮

 conteúdo...

 ╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
       🃏 *Arlequina Bot* 💜😈
*/

// Envolve um texto qualquer na moldura padrão. `titulo` vira o cabeçalho,
// `corpo` é o conteúdo (pode já vir com quebras de linha formatadas).
function caixaArlequina(titulo, corpo) {
  const t = (titulo || 'ARLEQUINA').toString().toUpperCase()
  return `╭─━━─🃏💜「 *${t}* 」💜🃏─━━─╮

${corpo}

╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
      🃏 *Arlequina Bot* 💜😈`
}

// Mesma coisa, mas pra cada linha já formatada (usa quando corpo é uma
// lista de linhas simples, não um texto livre).
function caixaArlequinaLista(titulo, linhas) {
  const corpo = linhas.map(l => `│ 💜🃏 ${l}`).join('\n')
  return caixaArlequina(titulo, corpo)
}

/*
 Moldura ornamentada alternativa (a pedido do dono), pro estilo:

 ┏═•✭･ﾟ✧*･ﾟ| ♡ |*✭˚･ﾟ✧･ﾟ•═┓
 ┣⋆⃟ۣۜ᭪➣ 𖡦 𝐓𝐈𝐓𝐔𝐋𝐎【✅】
 ┗═•✭･ﾟ✧*･ﾟ| ♡ |*✭˚･ﾟ✧･ﾟ•═┛
 ╎
 ┏═•✭･ﾟ✧*･ﾟ| ♡ |*✭˚･ﾟ✧･ﾟ•═┓
 ┃╭─── ≪ ❖ ◦ ✦ ◦ ❖ ≫ ───╮
 ┃✧ ✧ ✧ ✧ ✧
 ┃linhas...
 ┃✧ ✧ ✧ ✧ ✧
 ┃╰─── ≪ ❖ ◦ ✦ ◦ ❖ ≫ ───╯
 ┗═•✭･ﾟ✧*･ﾟ| ♡ |*✭˚･ﾟ✧･ﾟ•═┛

 titulo: texto do cabeçalho (ex: "ALUGUEL ATIVADO")
 emojiStatus: emoji dentro do 【 】 (ex: '✅', '❌')
 linhas: array de strings, uma por linha do corpo
*/
function caixaElegante(titulo, emojiStatus, linhas) {
  const cabecalho =
`┏═•✭･ﾟ✧*･ﾟ| ♡ |*✭˚･ﾟ✧･ﾟ•═┓
┣⋆⃟ۣۜ᭪➣ 𖡦 💜🃏 ${titulo} 🃏💜【${emojiStatus}】
┗═•✭･ﾟ✧*･ﾟ| ♡ |*✭˚･ﾟ✧･ﾟ•═┛`

  const corpo = linhas.map(l => `┃✦𝆺𝅥˚ ஓீᤢ✧͢⃟ᤢ${l}`).join('\n')

  return `${cabecalho}
╎
┏═•✭･ﾟ✧*･ﾟ| ♡ |*✭˚･ﾟ✧･ﾟ•═┓
┃╭─── ≪ ❖ ◦ ✦ ◦ ❖ ≫ ───╮
┃✧ ✧ ✧ ✧ ✧
${corpo}
┃✧ ✧ ✧ ✧ ✧
┃╰─── ≪ ❖ ◦ ✦ ◦ ❖ ≫ ───╯
┗═•✭･ﾟ✧*･ﾟ| ♡ |*✭˚･ﾟ✧･ﾟ•═┛
      🃏 *Arlequina Bot* 💜😈`
}

/*
 Converte texto normal (A-Z, a-z) pro estilo "matemático negrito itálico"
 usado nos títulos da moldura fancy abaixo (ex: BRINCADEIRAS -> 𝑩𝑹𝑰𝑵𝑪𝑨𝑫𝑬𝑰𝑹𝑨𝑺).
 Números, espaços, emojis e acentos passam direto, sem conversão.
*/
function paraItalicoNegrito(texto) {
  return String(texto).split('').map(ch => {
    const code = ch.codePointAt(0)
    if (code >= 0x41 && code <= 0x5A) return String.fromCodePoint(code + 0x1D427) // A-Z
    if (code >= 0x61 && code <= 0x7A) return String.fromCodePoint(code + 0x1D421) // a-z
    return ch
  }).join('')
}

/*
 Moldura fancy nova (a pedido do dono), estilo:

 ┏┉∴°𝄪⸗.⠡∝┅┈°.ᰔᩚ.°┈┅∝⠡.⸗𝄪°∴┉┓
 ┋𝄪°⠡⸗𝄪﹝𝑰𝑵𝑭𝑶𝒔 𝑩𝑶𝑻 𝑼𝑺𝑬𝑹﹞
 ┣┉∴°𝄪⸗.⠡∝┅┈°.ᰔᩚ.°┈┅∝⠡.⸗𝄪°∴┉┛
 ┣┉∴°𝄪⠡∝┅┈°.ᩚ⠤⠩⠥⠠⠦⠫⠰⠰
 ┋°‧․ˑ⃟⠥ʿ *Bot*: ...
 ┗┉∴°𝄪⸗.⠡∝┅┈°.ᰔᩚ.°┈┅∝⠡.⸗𝄪°∴┉┛
*/
const BORDA_TOPO_FANCY = '┏┉∴°𝄪⸗.⠡∝┅┈°.ᰔᩚ.°┈┅∝⠡.⸗𝄪°∴┉┓'
const BORDA_MEIO_FANCY = '┣┉∴°𝄪⸗.⠡∝┅┈°.ᰔᩚ.°┈┅∝⠡.⸗𝄪°∴┉┛'
const BORDA_BASE_FANCY = '┗┉∴°𝄪⸗.⠡∝┅┈°.ᰔᩚ.°┈┅∝⠡.⸗𝄪°∴┉┛'

// Caixa de infos do usuário/bot, pra colocar no topo de qualquer menu.
// ctx: { nomeBot, numeroUsuario, nomeDono, cargo, vip }
function caixaInfoUsuario({ nomeBot, numeroUsuario, nomeDono, cargo, vip }) {
  return `${BORDA_TOPO_FANCY}
┋𝄪°⠡⸗𝄪﹝${paraItalicoNegrito('INFOs BOT USER')}﹞
${BORDA_MEIO_FANCY}
┣┉∴°𝄪⠡∝┅┈°.ᩚ⠤⠩⠥⠠⠦⠫⠰⠰
┋°‧․ˑ💜🃏⃟⠥ʿ *Bot*: ${nomeBot}
┋°‧․ˑ💜🃏⃟⠥ʿ *Usuário*: @${numeroUsuario}
┋°‧․ˑ💜🃏⃟⠥ʿ *Dono*: ${nomeDono}
┋°‧․ˑ💜🃏⃟⠥ʿ *Cargo*: ${cargo}
┋°‧․ˑ💜🃏⃟⠥ʿ *Vip*: ${vip}
${BORDA_BASE_FANCY}`
}

// Caixa de menu com o mesmo estilo, uma ou mais seções de comandos.
// titulo: nome do menu (ex: "BRINCADEIRAS")
// secoes: array de { nome?: string, comandos: string[] } — `nome` é opcional,
// se não passar nenhuma seção com nome vira uma lista só (igual o exemplo do dono).
function caixaMenuFancy(titulo, secoes) {
  const tituloEstilizado = paraItalicoNegrito(titulo)
  let icone = 0
  const icones = ['🃏', '💜']
  let corpo = ''
  for (const secao of secoes) {
    if (secao.nome) {
      corpo += `\n┋𝄪⠡⸗ ‹ *${secao.nome}* › ⸗⠡𝄪\n`
    }
    for (const cmd of secao.comandos) {
      corpo += `┋°‧․ˑ${icones[icone % 2]}⃟⠥ʿ ${cmd}\n`
      icone++
    }
  }
  return `${BORDA_TOPO_FANCY}
┋𝄪°⠡⸗𝄪﹝${tituloEstilizado}【💜】﹞
${BORDA_MEIO_FANCY}
${corpo.trimEnd()}
${BORDA_BASE_FANCY}
      🃏 *Arlequina Bot* 💜😈`
}


const fs = require('fs')
const path = require('path')

async function enviarComBanner(sock, from, info, caption, mentions) {
  const caminhoImagem = path.join(__dirname, '../imagem/menu.jpg')
  try {
    if (fs.existsSync(caminhoImagem)) {
      const buffer = fs.readFileSync(caminhoImagem)
      return await sock.sendMessage(from, { image: buffer, caption, mentions }, { quoted: info })
    }
  } catch (e) {
    console.log('❌ ERRO enviarComBanner:', e?.message)
  }
  return await sock.sendMessage(from, { text: caption, mentions }, { quoted: info })
}

/*
 Caixas no estilo "moldura dupla" (╭━━━╮ / ┃ / ╰━━━╯), usadas pelo
 bônus diário, level up e !perfilrpg. Preenche cada linha até uma
 largura fixa pra ficar alinhado — não é perfeito em 100% dos
 aparelhos (o WhatsApp não garante fonte monoespaçada em todo device),
 mas fica bom na esmagadora maioria.
*/
const LARGURA_CAIXA_DUPLA = 30

function linhaCaixaDupla(conteudo = '', centralizar = false) {
  const texto = String(conteudo)
  if (texto.length >= LARGURA_CAIXA_DUPLA) return `┃${texto.slice(0, LARGURA_CAIXA_DUPLA)}┃`
  const espacoTotal = LARGURA_CAIXA_DUPLA - texto.length
  if (centralizar) {
    const esq = Math.floor(espacoTotal / 2)
    const dir = espacoTotal - esq
    return `┃${' '.repeat(esq)}${texto}${' '.repeat(dir)}┃`
  }
  return `┃${texto}${' '.repeat(espacoTotal)}┃`
}

function tituloCaixaDupla(titulo) {
  return linhaCaixaDupla(titulo, true)
}

function abrirCaixaDupla() { return `╭${'━'.repeat(LARGURA_CAIXA_DUPLA)}╮` }
function fecharCaixaDupla() { return `╰${'━'.repeat(LARGURA_CAIXA_DUPLA)}╯` }
function divisorCaixaDupla() { return `┣${'━'.repeat(LARGURA_CAIXA_DUPLA)}┫` }
function linhaVaziaCaixaDupla() { return linhaCaixaDupla('') }

// Caixinha interna (o "box dentro do box" que aparece nas recompensas)
function caixaInternaDupla(linhas) {
  const LARGURA_INTERNA = LARGURA_CAIXA_DUPLA - 4
  const topo = linhaCaixaDupla(` ╭${'─'.repeat(LARGURA_INTERNA)}╮ `)
  const base = linhaCaixaDupla(` ╰${'─'.repeat(LARGURA_INTERNA)}╯ `)
  const meio = linhas.map(l => {
    const texto = String(l)
    const espaco = Math.max(0, LARGURA_INTERNA - texto.length)
    return linhaCaixaDupla(` │ ${texto}${' '.repeat(Math.max(0, espaco - 2))}│ `)
  })
  return [topo, ...meio, base].join('\n')
}

/*
 !daily / bônus da primeira mensagem do dia
 dados: { titulo, nomeUsuario, streak, recompensas: [linhas], saldo, nivel, frase }
*/
function caixaBonusDiario({ titulo = 'BÔNUS DIÁRIO', nomeUsuario, recompensas = [], saldo, nivel, frase }) {
  const linhas = [
    abrirCaixaDupla(),
    tituloCaixaDupla(`🌙 ${titulo} 🃏💜`),
    divisorCaixaDupla(),
    linhaVaziaCaixaDupla(),
    linhaCaixaDupla(` 👤 USUÁRIO: ${nomeUsuario}`),
    linhaCaixaDupla(` 🎁 PRIMEIRA MENSAGEM DO DIA!`),
    linhaVaziaCaixaDupla(),
    caixaInternaDupla(recompensas),
    linhaVaziaCaixaDupla(),
  ]
  if (saldo !== undefined) linhas.push(linhaCaixaDupla(` 💰 SALDO: 『 ${saldo} 』`))
  if (nivel !== undefined) linhas.push(linhaCaixaDupla(` ⭐ NÍVEL: 『 ${nivel} 』`))
  linhas.push(linhaVaziaCaixaDupla())
  if (frase) {
    linhas.push(divisorCaixaDupla())
    for (const l of frase) linhas.push(linhaCaixaDupla(l))
    linhas.push(linhaVaziaCaixaDupla())
  }
  linhas.push(tituloCaixaDupla('💜 ARLEQUINA 🃏'))
  linhas.push(fecharCaixaDupla())
  return linhas.join('\n')
}

/*
 Level up — dados: { nomeUsuario, nivelAntigo, nivelNovo, xpAtual, xpNecessario, recompensas: [linhas], frase: [linhas] }
*/
function caixaLevelUp({ nomeUsuario, nivelAntigo, nivelNovo, xpAtual, xpNecessario, recompensas = [], frase }) {
  const progresso = xpNecessario ? Math.min(1, xpAtual / xpNecessario) : 1
  const totalBarras = 20
  const cheias = Math.round(progresso * totalBarras)
  const barra = '█'.repeat(cheias) + '░'.repeat(totalBarras - cheias)
  const pct = Math.round(progresso * 100)

  const linhas = [
    abrirCaixaDupla(),
    tituloCaixaDupla('🃏💜 LEVEL UP! 💜🃏'),
    divisorCaixaDupla(),
    linhaVaziaCaixaDupla(),
    linhaCaixaDupla(` 👤 USUÁRIO: ${nomeUsuario}`),
    linhaVaziaCaixaDupla(),
    tituloCaixaDupla('⭐ EVOLUÇÃO ⭐'),
    linhaVaziaCaixaDupla(),
    tituloCaixaDupla(`『 ${nivelAntigo} 』 ➜ 『 ${nivelNovo} 』`),
    linhaVaziaCaixaDupla(),
  ]
  if (xpNecessario) {
    linhas.push(linhaCaixaDupla(` ✨ XP: ${xpAtual} / ${xpNecessario}`))
    linhas.push(linhaCaixaDupla(` ${barra} ${pct}%`))
    linhas.push(linhaVaziaCaixaDupla())
  }
  if (recompensas.length) {
    linhas.push(divisorCaixaDupla())
    linhas.push(linhaVaziaCaixaDupla())
    linhas.push(tituloCaixaDupla('🎁 RECOMPENSA'))
    linhas.push(linhaVaziaCaixaDupla())
    for (const r of recompensas) linhas.push(linhaCaixaDupla(` ${r}`))
    linhas.push(linhaVaziaCaixaDupla())
  }
  if (frase) {
    linhas.push(divisorCaixaDupla())
    for (const l of frase) linhas.push(linhaCaixaDupla(l))
    linhas.push(linhaVaziaCaixaDupla())
  }
  linhas.push(tituloCaixaDupla('— ARLEQUINA 💜'))
  linhas.push(fecharCaixaDupla())
  return linhas.join('\n')
}

/*
 !perfilrpg — dados: { nomeUsuario, titulo, id, nivel, xpAtual, xpNecessario,
 carteira, banco, diamantes, streak, mensagens, dailyDisponivel,
 conquistas, proximaConquista, frase: [linhas] }
*/
function caixaPerfilRpg(d) {
  const progresso = d.xpNecessario ? Math.min(1, d.xpAtual / d.xpNecessario) : 1
  const totalBarras = 20
  const cheias = Math.round(progresso * totalBarras)
  const barra = '█'.repeat(cheias) + '░'.repeat(totalBarras - cheias)
  const pct = Math.round(progresso * 100)

  const linhas = [
    abrirCaixaDupla(),
    tituloCaixaDupla('🃏💜 PERFIL RPG 💜🃏'),
    divisorCaixaDupla(),
    linhaVaziaCaixaDupla(),
    linhaCaixaDupla(` 👤 USUÁRIO: ${d.nomeUsuario}`),
    linhaCaixaDupla(` 🏷️ TÍTULO: ${d.titulo}`),
    linhaCaixaDupla(` 🆔 ID: #${d.id}`),
    linhaVaziaCaixaDupla(),
    divisorCaixaDupla(),
    tituloCaixaDupla('⭐ NÍVEL'),
    linhaVaziaCaixaDupla(),
    tituloCaixaDupla(String(d.nivel)),
    linhaVaziaCaixaDupla(),
    linhaCaixaDupla(` ✨ XP: ${d.xpAtual} / ${d.xpNecessario}`),
    linhaCaixaDupla(` ${barra} ${pct}%`),
    linhaVaziaCaixaDupla(),
    divisorCaixaDupla(),
    tituloCaixaDupla('💰 ECONOMIA'),
    linhaVaziaCaixaDupla(),
    linhaCaixaDupla(` 💵 CARTEIRA: ${d.carteira}`),
    linhaCaixaDupla(` 🏦 BANCO: ${d.banco}`),
    linhaCaixaDupla(` 💎 DIAMANTES: ${d.diamantes}`),
    linhaVaziaCaixaDupla(),
    divisorCaixaDupla(),
    tituloCaixaDupla('🔥 ATIVIDADE'),
    linhaVaziaCaixaDupla(),
    linhaCaixaDupla(` 🔥 STREAK: ${d.streak} DIAS`),
    linhaCaixaDupla(` 💬 MENSAGENS: ${d.mensagens}`),
    linhaCaixaDupla(` 🎁 DAILY: ${d.dailyDisponivel ? 'DISPONÍVEL' : 'JÁ RESGATADO'}`),
    linhaVaziaCaixaDupla(),
    divisorCaixaDupla(),
    tituloCaixaDupla('🏆 CONQUISTAS'),
    linhaVaziaCaixaDupla(),
    linhaCaixaDupla(` 🏆 DESBLOQUEADAS: ${d.conquistas}`),
    linhaCaixaDupla(` 🔒 PRÓXIMA: ${d.proximaConquista}`),
    linhaVaziaCaixaDupla(),
  ]
  if (d.frase) {
    linhas.push(divisorCaixaDupla())
    linhas.push(linhaVaziaCaixaDupla())
    for (const l of d.frase) linhas.push(linhaCaixaDupla(l))
    linhas.push(linhaVaziaCaixaDupla())
  }
  linhas.push(tituloCaixaDupla('💜 ARLEQUINA 🃏'))
  linhas.push(fecharCaixaDupla())
  return linhas.join('\n')
}

module.exports = { caixaArlequina, caixaArlequinaLista, caixaElegante, enviarComBanner, paraItalicoNegrito, caixaInfoUsuario, caixaMenuFancy, caixaBonusDiario, caixaLevelUp, caixaPerfilRpg }
