// API usada para Hentai e Plaquinhas (extraída do Kimori Bot)
// Se parar de funcionar, troque a URL/key ou use APIs públicas.
module.exports = {
  API_URL: 'https://beta-api.orbitalcode.online',
  API_KEY: '2010matheuss'
}
