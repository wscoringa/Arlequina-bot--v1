const { execFile } = require('child_process')
const fs = require('fs')
const path = require('path')

const BASE_DIR = path.resolve(
  __dirname,
  '../../tmp-audio'
)

if (!fs.existsSync(BASE_DIR)) {
  fs.mkdirSync(BASE_DIR, {
    recursive: true
  })
}

function rodar(cmd, args) {
  return new Promise((resolve, reject) => {
    execFile(
      cmd,
      args,
      {
        timeout: 30000,
        maxBuffer: 20 * 1024 * 1024
      },
      (err, stdout, stderr) => {
        if (err) {
          err.stdout = stdout
          err.stderr = stderr
          reject(err)
          return
        }

        resolve({
          stdout,
          stderr
        })
      }
    )
  })
}

async function sintetizarWav(
  texto,
  wavPath,
  configuracao = {}
) {
  const voz =
    configuracao.voz || 'pt-br'

  const velocidade =
    Number(configuracao.velocidade) || 160

  const pitch =
    Number(configuracao.pitch) || 50

  /*
   * Primeira tentativa:
   * usa a variante específica, por exemplo:
   *
   * pt-br+f1
   * pt-br+f2
   * pt-br+m1
   * pt-br+m2
   */

  const tentativas = [
    {
      cmd: 'espeak',
      args: [
        '-v', voz,
        '-s', String(velocidade),
        '-p', String(pitch),
        '-w', wavPath,
        texto
      ]
    },

    /*
     * Fallback para pt-br puro caso alguma
     * instalação não tenha a variante solicitada.
     */
    {
      cmd: 'espeak',
      args: [
        '-v', 'pt-br',
        '-s', String(velocidade),
        '-p', String(pitch),
        '-w', wavPath,
        texto
      ]
    },

    /*
     * Último fallback.
     */
    {
      cmd: 'espeak',
      args: [
        '-v', 'pt',
        '-s', String(velocidade),
        '-p', String(pitch),
        '-w', wavPath,
        texto
      ]
    }
  ]

  let ultimoErro = null

  for (const tentativa of tentativas) {
    try {
      if (fs.existsSync(wavPath)) {
        try {
          fs.unlinkSync(wavPath)
        } catch (_) {}
      }

      await rodar(
        tentativa.cmd,
        tentativa.args
      )

      if (
        fs.existsSync(wavPath) &&
        fs.statSync(wavPath).size > 200
      ) {
        return true
      }
    } catch (err) {
      ultimoErro = err
    }
  }

  if (ultimoErro) {
    console.log(
      '❌ ESPEAK:',
      ultimoErro.stderr || ultimoErro.message
    )
  }

  return false
}

async function textoParaFala(
  texto,
  configuracao = {}
) {
  const id =
    `${Date.now()}_${Math.random()
      .toString(36)
      .slice(2)}`

  const wavPath =
    path.join(
      BASE_DIR,
      `tts_${id}.wav`
    )

  const oggPath =
    path.join(
      BASE_DIR,
      `tts_${id}.ogg`
    )

  const ok = await sintetizarWav(
    texto,
    wavPath,
    configuracao
  )

  if (!ok) {
    throw new Error(
      'motor_ausente'
    )
  }

  try {
    /*
     * OGG/Opus direto pelo FFmpeg.
     * Não usa fluent-ffmpeg.
     */
    await rodar(
      'ffmpeg',
      [
        '-y',
        '-i', wavPath,
        '-vn',
        '-c:a', 'libopus',
        '-b:a', '64k',
        '-application', 'voip',
        oggPath
      ]
    )

    if (
      !fs.existsSync(oggPath) ||
      fs.statSync(oggPath).size < 200
    ) {
      throw new Error(
        'áudio convertido veio vazio'
      )
    }

    return fs.readFileSync(
      oggPath
    )
  } finally {
    try {
      fs.unlinkSync(wavPath)
    } catch (_) {}

    try {
      fs.unlinkSync(oggPath)
    } catch (_) {}
  }
}

module.exports = {
  textoParaFala
}
