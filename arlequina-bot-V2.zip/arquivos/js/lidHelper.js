/*
 O WhatsApp vem usando dois formatos de identificar a mesma pessoa: o
 "normal" (baseado no número, ex: 5511999999999@s.whatsapp.net) e um
 novo "LID" de privacidade (ex: 139801722376211@lid). Quando alguém é
 marcado com @ numa mensagem, às vezes o WhatsApp manda o LID em vez do
 número — e se um comando salva um pedido usando o LID mas depois a
 pessoa responde usando o número normal (ou vice-versa), o bot "não
 reconhece" que é a mesma pessoa.

 Esse helper resolve isso: se o jid for um LID, tenta converter pro
 número de telefone de verdade usando o mapa que o próprio Baileys já
 mantém internamente. Se não conseguir resolver, devolve o jid
 original (não quebra nada, só não corrige).
*/
const { isLidUser } = require('@whiskeysockets/baileys')

async function resolverJidReal(sock, jid) {
  try {
    if (!jid) return jid

    if (isLidUser(jid)) {
      const pn = await sock?.signalRepository?.lidMapping?.getPNForLID(jid)
      jid = pn || jid
    }

    // BUGFIX: além do LID, o WhatsApp às vezes manda o jid com o
    // sufixo de dispositivo (ex: "558598261859:0@s.whatsapp.net" em vez
    // de "558598261859@s.whatsapp.net"). Isso fazia a @menção aparecer
    // "crua" no chat (tipo "@558598261859:0") e, pior, o pedido de
    // namoro/casamento era salvo com essa chave "suja" — só que quando
    // a pessoa respondia com !aceitar, o index.js já entrega o sender
    // dela SEM o ":0" (ele limpa isso lá), então a busca nunca batia
    // com o que foi salvo aqui. Removendo o ":N" sempre, os dois lados
    // passam a usar exatamente a mesma chave.
    jid = jid.replace(/:\d+(?=@)/, '')

    return jid
  } catch (e) {
    return jid
  }
}

module.exports = { resolverJidReal }
