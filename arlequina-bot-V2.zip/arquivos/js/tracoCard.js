/*
 Fábrica de comandos de "traço aleatório" (tipo !nerd @pessoa, !forte
 @pessoa) — marca alguém (ou usa quem mandou, se não marcar ninguém) e
 solta uma frase aleatória daquele tema.
*/
const { caixaArlequina } = require('./estiloArlequina')

function criarTracoCard({ name, emoji, titulo, frases, aliases = [] }) {
  return {
    name,
    description: `${emoji} Brincadeira: ${titulo}`,
    category: 'brincadeiras',
    aliases,
    async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
      if (!isGroup) return reply('❌ Use em grupos!')
      try {
        const mencionado = info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] ||
          info.message?.extendedTextMessage?.contextInfo?.participant || sender

        await reagir(emoji)
        const frase = frases[Math.floor(Math.random() * frases.length)]
        const texto = caixaArlequina(name, `${emoji} @${mencionado.split('@')[0]} ${frase}`)
        await arlequina.sendMessage(from, { text: texto, mentions: [mencionado] }, { quoted: info })
      } catch (e) {
        console.error(`ERRO ${name}:`, e?.message)
        await reply('❌ Erro. Tente novamente.')
      }
    }
  }
}

module.exports = { criarTracoCard }
