const fs = require('fs'), path = require('path')
const DIR = './database/reputacao'
if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true })
const load = p => { try { return fs.existsSync(p) ? JSON.parse(fs.readFileSync(p)) : {} } catch { return {} } }
const save = (p, d) => { try { fs.writeFileSync(p, JSON.stringify(d, null, 2)) } catch {} }
const safe = g => g.replace(/[^a-z0-9]/gi,'_')
const repFile   = g => path.join(DIR, safe(g)+'_rep.json')
const karmaFile = g => path.join(DIR, safe(g)+'_karma.json')
const famFile   = g => path.join(DIR, safe(g)+'_familia.json')

function getRep(g,u)     { return (load(repFile(g))[u]||{rep:0}).rep }
function addRep(g,u,n,q=1){ const d=load(repFile(g)); if(!d[u])d[u]={nome:n,rep:0}; d[u].rep+=q; d[u].nome=n; save(repFile(g),d); return d[u].rep }
function topRep(g,n=10)  { return Object.entries(load(repFile(g))).map(([jid,d])=>({jid,...d})).sort((a,b)=>b.rep-a.rep).slice(0,n) }
function getKarma(g,u)   { return (load(karmaFile(g))[u]||{karma:0}).karma }
function addKarma(g,u,n,q=1){ const d=load(karmaFile(g)); if(!d[u])d[u]={nome:n,karma:0}; d[u].karma+=q; d[u].nome=n; save(karmaFile(g),d); return d[u].karma }
function setRelacao(g,u1,u2,tipo){ const d=load(famFile(g)); d[`${u1}|${u2}`]={tipo,u1,u2,desde:Date.now()}; save(famFile(g),d) }
function getRelacoes(g,u){ return Object.values(load(famFile(g))).filter(r=>r.u1===u||r.u2===u) }
function removeRelacao(g,u1,u2){ const d=load(famFile(g)); delete d[`${u1}|${u2}`]; delete d[`${u2}|${u1}`]; save(famFile(g),d) }
module.exports = { getRep, addRep, topRep, getKarma, addKarma, setRelacao, getRelacoes, removeRelacao }
