/*
 Base de dados dos Pokémon do RPG — fonte única usada por !pokegacha,
 !cacapokemon (via eventosRPG.js), !pokedex, !evoluir, !fundir, arena
 etc. Assim todo mundo lê a MESMA lista de espécies/tipos/raridade, em
 vez de cada comando ter sua própria lista solta (o que gerava
 divergência antes).

 Imagem: usa direto o CDN de sprites oficiais do PokeAPI (não precisa
 chamar API nenhuma, é só uma URL de imagem estática por dexId).

 Status base: em vez de digitar HP/ATK/DEF/SPD catados a dedo pra cada
 espécie (~100 entradas), cada raridade tem uma FAIXA (igual o sistema
 de spawn selvagem já usava) e cada espécie "rola" um valor fixo e
 determinístico dentro dessa faixa a partir do próprio dexId — ou seja,
 o MESMO Charmander sempre nasce com o mesmo status base, mas cada
 espécie dentro da mesma raridade tem variação (não são todas clones).
*/

const RARIDADES_ORDEM = ['comum', 'raro', 'epico', 'lendario', 'mitico', 'supremo', 'divino']

const LABEL_RARIDADE = {
  comum: 'Comum', raro: 'Raro', epico: 'Épico', lendario: 'Lendário',
  mitico: 'Mítico', supremo: 'Supremo', divino: 'Divino'
}

const EMOJI_RARIDADE = {
  comum: '⚪', raro: '🔵', epico: '🟣', lendario: '🟡',
  mitico: '🟢', supremo: '🔴', divino: '✨'
}

// peso = chance relativa de sair no gacha/spawn selvagem
const FAIXAS_RARIDADE = {
  comum:    { peso: 38, hp: [140, 260],  atk: [30, 60],   def: [25, 55],   spd: [25, 55] },
  raro:     { peso: 25, hp: [260, 420],  atk: [55, 95],   def: [50, 90],   spd: [50, 90] },
  epico:    { peso: 16, hp: [420, 620],  atk: [90, 135],  def: [85, 125],  spd: [85, 125] },
  lendario: { peso: 10, hp: [620, 850],  atk: [130, 175], def: [120, 160], spd: [120, 160] },
  mitico:   { peso: 6,  hp: [820, 1050], atk: [165, 205], def: [150, 190], spd: [150, 190] },
  supremo:  { peso: 3,  hp: [1000, 1250],atk: [195, 240], def: [180, 220], spd: [180, 220] },
  divino:   { peso: 2,  hp: [1300, 1600],atk: [240, 300], def: [220, 280], spd: [220, 280] },
}

// Lista de espécies. "evolui" = { dexId, nivel } (evolução por XP/nível)
// ou { dexId, pedra: 'chave-do-item' } (evolução por pedra — ver pokeItens.js)
const POKEDEX = [
  // ── COMUM ──────────────────────────────────────────────────────
  { id: 10,  nome: 'Caterpie',   tipos: ['Inseto'],            raridade: 'comum', evolui: { dexId: 11, nivel: 7 } },
  { id: 11,  nome: 'Metapod',    tipos: ['Inseto'],            raridade: 'raro',  evolui: { dexId: 12, nivel: 10 } },
  { id: 13,  nome: 'Weedle',     tipos: ['Inseto', 'Veneno'],  raridade: 'comum', evolui: { dexId: 14, nivel: 7 } },
  { id: 16,  nome: 'Pidgey',     tipos: ['Normal', 'Voador'],  raridade: 'comum', evolui: { dexId: 17, nivel: 12 } },
  { id: 19,  nome: 'Rattata',    tipos: ['Normal'],            raridade: 'comum', evolui: { dexId: 20, nivel: 10 } },
  { id: 21,  nome: 'Spearow',    tipos: ['Normal', 'Voador'],  raridade: 'comum', evolui: { dexId: 22, nivel: 12 } },
  { id: 23,  nome: 'Ekans',      tipos: ['Veneno'],            raridade: 'comum', evolui: { dexId: 24, nivel: 14 } },
  { id: 25,  nome: 'Pikachu',    tipos: ['Elétrico'],          raridade: 'raro',  evolui: { dexId: 26, pedra: 'pedra-trovao' } },
  { id: 27,  nome: 'Sandshrew',  tipos: ['Terra'],             raridade: 'comum', evolui: { dexId: 28, nivel: 14 } },
  { id: 29,  nome: 'Nidoran-F',  tipos: ['Veneno'],            raridade: 'comum', evolui: { dexId: 30, nivel: 12 } },
  { id: 32,  nome: 'Nidoran-M',  tipos: ['Veneno'],            raridade: 'comum', evolui: { dexId: 33, nivel: 12 } },
  { id: 35,  nome: 'Clefairy',   tipos: ['Fada'],              raridade: 'raro',  evolui: { dexId: 36, pedra: 'pedra-lua' } },
  { id: 37,  nome: 'Vulpix',     tipos: ['Fogo'],              raridade: 'raro',  evolui: { dexId: 38, pedra: 'pedra-fogo' } },
  { id: 41,  nome: 'Zubat',      tipos: ['Veneno', 'Voador'],  raridade: 'comum', evolui: { dexId: 42, nivel: 22 } },
  { id: 43,  nome: 'Oddish',     tipos: ['Grama', 'Veneno'],   raridade: 'comum', evolui: { dexId: 44, nivel: 21 } },
  { id: 46,  nome: 'Paras',      tipos: ['Inseto', 'Grama'],   raridade: 'comum', evolui: { dexId: 47, nivel: 24 } },
  { id: 48,  nome: 'Venonat',    tipos: ['Inseto', 'Veneno'],  raridade: 'comum', evolui: { dexId: 49, nivel: 31 } },
  { id: 50,  nome: 'Diglett',    tipos: ['Terra'],             raridade: 'comum', evolui: { dexId: 51, nivel: 26 } },
  { id: 52,  nome: 'Meowth',     tipos: ['Normal'],            raridade: 'comum', evolui: { dexId: 53, nivel: 28 } },
  { id: 54,  nome: 'Psyduck',    tipos: ['Água'],              raridade: 'comum', evolui: { dexId: 55, nivel: 33 } },
  { id: 58,  nome: 'Growlithe',  tipos: ['Fogo'],              raridade: 'raro',  evolui: { dexId: 59, pedra: 'pedra-fogo' } },
  { id: 60,  nome: 'Poliwag',    tipos: ['Água'],              raridade: 'comum', evolui: { dexId: 61, nivel: 25 } },
  { id: 63,  nome: 'Abra',       tipos: ['Psíquico'],          raridade: 'raro',  evolui: { dexId: 64, nivel: 16 } },
  { id: 66,  nome: 'Machop',     tipos: ['Lutador'],           raridade: 'comum', evolui: { dexId: 67, nivel: 28 } },
  { id: 69,  nome: 'Bellsprout', tipos: ['Grama', 'Veneno'],   raridade: 'comum', evolui: { dexId: 70, nivel: 21 } },
  { id: 72,  nome: 'Tentacool',  tipos: ['Água', 'Veneno'],    raridade: 'comum', evolui: { dexId: 73, nivel: 30 } },
  { id: 74,  nome: 'Geodude',    tipos: ['Pedra', 'Terra'],    raridade: 'comum', evolui: { dexId: 75, nivel: 25 } },
  { id: 77,  nome: 'Ponyta',     tipos: ['Fogo'],              raridade: 'raro',  evolui: { dexId: 78, nivel: 40 } },
  { id: 79,  nome: 'Slowpoke',   tipos: ['Água', 'Psíquico'],  raridade: 'comum', evolui: { dexId: 80, nivel: 37 } },
  { id: 81,  nome: 'Magnemite',  tipos: ['Elétrico', 'Aço'],   raridade: 'comum', evolui: { dexId: 82, nivel: 30 } },
  { id: 84,  nome: 'Doduo',      tipos: ['Normal', 'Voador'],  raridade: 'comum', evolui: { dexId: 85, nivel: 31 } },
  { id: 90,  nome: 'Shellder',   tipos: ['Água'],              raridade: 'comum', evolui: { dexId: 91, pedra: 'pedra-agua' } },
  { id: 92,  nome: 'Gastly',     tipos: ['Fantasma', 'Veneno'],raridade: 'comum', evolui: { dexId: 93, nivel: 25 } },
  { id: 96,  nome: 'Drowzee',    tipos: ['Psíquico'],          raridade: 'comum', evolui: { dexId: 97, nivel: 26 } },
  { id: 98,  nome: 'Krabby',     tipos: ['Água'],              raridade: 'comum', evolui: { dexId: 99, nivel: 28 } },
  { id: 100, nome: 'Voltorb',    tipos: ['Elétrico'],          raridade: 'comum', evolui: { dexId: 101, nivel: 30 } },
  { id: 116, nome: 'Horsea',     tipos: ['Água'],              raridade: 'comum', evolui: { dexId: 117, nivel: 32 } },
  { id: 129, nome: 'Magikarp',   tipos: ['Água'],              raridade: 'comum', evolui: { dexId: 130, nivel: 20 } },
  { id: 133, nome: 'Eevee',      tipos: ['Normal'],            raridade: 'raro',  evolui: { dexId: 134, pedra: 'pedra-agua' } },
  { id: 147, nome: 'Dratini',    tipos: ['Dragão'],            raridade: 'raro',  evolui: { dexId: 148, nivel: 30 } },
  { id: 172, nome: 'Pichu',      tipos: ['Elétrico'],          raridade: 'comum', evolui: { dexId: 25, nivel: 12 } },
  { id: 252, nome: 'Treecko',    tipos: ['Grama'],             raridade: 'comum', evolui: { dexId: 253, nivel: 16 } },
  { id: 255, nome: 'Torchic',    tipos: ['Fogo'],              raridade: 'comum', evolui: { dexId: 256, nivel: 16 } },
  { id: 258, nome: 'Mudkip',     tipos: ['Água'],              raridade: 'comum', evolui: { dexId: 259, nivel: 16 } },
  { id: 396, nome: 'Starly',     tipos: ['Normal', 'Voador'],  raridade: 'comum', evolui: { dexId: 397, nivel: 14 } },
  { id: 399, nome: 'Bidoof',     tipos: ['Normal'],            raridade: 'comum', evolui: { dexId: 400, nivel: 15 } },
  { id: 447, nome: 'Riolu',      tipos: ['Lutador'],           raridade: 'raro',  evolui: { dexId: 448, nivel: 30 } },
  { id: 495, nome: 'Snivy',      tipos: ['Grama'],             raridade: 'comum', evolui: { dexId: 496, nivel: 17 } },
  { id: 498, nome: 'Tepig',      tipos: ['Fogo'],              raridade: 'comum', evolui: { dexId: 499, nivel: 17 } },
  { id: 501, nome: 'Oshawott',   tipos: ['Água'],              raridade: 'comum', evolui: { dexId: 502, nivel: 17 } },

  // ── RARO (segunda evolução / naturalmente fortinhos) ────────────
  { id: 2,   nome: 'Ivysaur',    tipos: ['Grama', 'Veneno'],   raridade: 'raro', evolui: { dexId: 3, nivel: 32 } },
  { id: 5,   nome: 'Charmeleon', tipos: ['Fogo'],              raridade: 'raro', evolui: { dexId: 6, nivel: 36 } },
  { id: 8,   nome: 'Wartortle',  tipos: ['Água'],              raridade: 'raro', evolui: { dexId: 9, nivel: 36 } },
  { id: 17,  nome: 'Pidgeotto',  tipos: ['Normal', 'Voador'],  raridade: 'raro', evolui: { dexId: 18, nivel: 36 } },
  { id: 42,  nome: 'Golbat',     tipos: ['Veneno', 'Voador'],  raridade: 'raro' },
  { id: 61,  nome: 'Poliwhirl',  tipos: ['Água'],              raridade: 'raro', evolui: { dexId: 62, pedra: 'pedra-agua' } },
  { id: 64,  nome: 'Kadabra',    tipos: ['Psíquico'],          raridade: 'raro', evolui: { dexId: 65, nivel: 40 } },
  { id: 67,  nome: 'Machoke',    tipos: ['Lutador'],           raridade: 'raro', evolui: { dexId: 68, nivel: 40 } },
  { id: 75,  nome: 'Graveler',   tipos: ['Pedra', 'Terra'],    raridade: 'raro', evolui: { dexId: 76, nivel: 40 } },
  { id: 93,  nome: 'Haunter',    tipos: ['Fantasma', 'Veneno'],raridade: 'raro', evolui: { dexId: 94, nivel: 38 } },
  { id: 134, nome: 'Vaporeon',   tipos: ['Água'],              raridade: 'epico' },
  { id: 135, nome: 'Jolteon',    tipos: ['Elétrico'],          raridade: 'epico' },
  { id: 136, nome: 'Flareon',    tipos: ['Fogo'],              raridade: 'epico' },
  { id: 148, nome: 'Dragonair',  tipos: ['Dragão'],            raridade: 'raro', evolui: { dexId: 149, nivel: 55 } },
  { id: 158, nome: 'Totodile',   tipos: ['Água'],              raridade: 'raro', evolui: { dexId: 159, nivel: 18 } },
  { id: 155, nome: 'Cyndaquil',  tipos: ['Fogo'],              raridade: 'raro', evolui: { dexId: 156, nivel: 14 } },
  { id: 152, nome: 'Chikorita',  tipos: ['Grama'],             raridade: 'raro', evolui: { dexId: 153, nivel: 16 } },
  { id: 448, nome: 'Lucario',    tipos: ['Lutador', 'Aço'],    raridade: 'epico' },
  { id: 725, nome: 'Litten',     tipos: ['Fogo'],              raridade: 'raro', evolui: { dexId: 726, nivel: 17 } },
  { id: 810, nome: 'Grookey',    tipos: ['Grama'],             raridade: 'raro', evolui: { dexId: 811, nivel: 16 } },

  // ── ÉPICO (totens/fortes já evoluídos) ──────────────────────────
  { id: 3,   nome: 'Venusaur',   tipos: ['Grama', 'Veneno'],   raridade: 'epico' },
  { id: 6,   nome: 'Charizard',  tipos: ['Fogo', 'Voador'],    raridade: 'epico' },
  { id: 9,   nome: 'Blastoise',  tipos: ['Água'],              raridade: 'epico' },
  { id: 18,  nome: 'Pidgeot',    tipos: ['Normal', 'Voador'],  raridade: 'epico' },
  { id: 65,  nome: 'Alakazam',   tipos: ['Psíquico'],          raridade: 'epico' },
  { id: 68,  nome: 'Machamp',    tipos: ['Lutador'],           raridade: 'epico' },
  { id: 94,  nome: 'Gengar',     tipos: ['Fantasma', 'Veneno'],raridade: 'epico' },
  { id: 130, nome: 'Gyarados',   tipos: ['Água', 'Voador'],    raridade: 'epico' },
  { id: 143, nome: 'Snorlax',    tipos: ['Normal'],            raridade: 'epico' },
  { id: 149, nome: 'Dragonite',  tipos: ['Dragão', 'Voador'],  raridade: 'epico' },
  { id: 248, nome: 'Tyranitar',  tipos: ['Sombrio', 'Pedra'],  raridade: 'epico' },
  { id: 445, nome: 'Garchomp',   tipos: ['Dragão', 'Terra'],   raridade: 'epico' },
  { id: 462, nome: 'Magnezone',  tipos: ['Elétrico', 'Aço'],   raridade: 'epico' },
  { id: 609, nome: 'Chandelure', tipos: ['Fantasma', 'Fogo'],  raridade: 'epico' },
  { id: 887, nome: 'Dragapult',  tipos: ['Dragão', 'Fantasma'],raridade: 'epico' },

  // ── LENDÁRIO ─────────────────────────────────────────────────────
  { id: 144, nome: 'Articuno',   tipos: ['Gelo', 'Voador'],    raridade: 'lendario' },
  { id: 145, nome: 'Zapdos',     tipos: ['Elétrico', 'Voador'],raridade: 'lendario' },
  { id: 146, nome: 'Moltres',    tipos: ['Fogo', 'Voador'],    raridade: 'lendario' },
  { id: 243, nome: 'Raikou',     tipos: ['Elétrico'],          raridade: 'lendario' },
  { id: 244, nome: 'Entei',      tipos: ['Fogo'],              raridade: 'lendario' },
  { id: 245, nome: 'Suicune',    tipos: ['Água'],              raridade: 'lendario' },
  { id: 249, nome: 'Lugia',      tipos: ['Psíquico', 'Voador'],raridade: 'lendario' },
  { id: 250, nome: 'Ho-Oh',      tipos: ['Fogo', 'Voador'],    raridade: 'lendario' },
  { id: 377, nome: 'Regirock',   tipos: ['Pedra'],             raridade: 'lendario' },
  { id: 380, nome: 'Latias',     tipos: ['Dragão', 'Psíquico'],raridade: 'lendario' },

  // ── MÍTICO ───────────────────────────────────────────────────────
  { id: 151, nome: 'Mew',        tipos: ['Psíquico'],          raridade: 'mitico' },
  { id: 251, nome: 'Celebi',     tipos: ['Grama', 'Psíquico'], raridade: 'mitico' },
  { id: 385, nome: 'Jirachi',    tipos: ['Aço', 'Psíquico'],   raridade: 'mitico' },
  { id: 386, nome: 'Deoxys',     tipos: ['Psíquico'],          raridade: 'mitico' },
  { id: 490, nome: 'Manaphy',    tipos: ['Água'],              raridade: 'mitico' },
  { id: 491, nome: 'Darkrai',    tipos: ['Sombrio'],           raridade: 'mitico' },
  { id: 492, nome: 'Shaymin',    tipos: ['Grama'],             raridade: 'mitico' },
  { id: 494, nome: 'Victini',    tipos: ['Psíquico', 'Fogo'],  raridade: 'mitico' },

  // ── SUPREMO ──────────────────────────────────────────────────────
  { id: 150, nome: 'Mewtwo',     tipos: ['Psíquico'],          raridade: 'supremo' },
  { id: 384, nome: 'Rayquaza',   tipos: ['Dragão', 'Voador'],  raridade: 'supremo' },
  { id: 382, nome: 'Kyogre',     tipos: ['Água'],              raridade: 'supremo' },
  { id: 383, nome: 'Groudon',    tipos: ['Terra'],             raridade: 'supremo' },
  { id: 483, nome: 'Dialga',     tipos: ['Aço', 'Dragão'],     raridade: 'supremo' },

  // ── DIVINO ───────────────────────────────────────────────────────
  { id: 493, nome: 'Arceus',     tipos: ['Normal'],            raridade: 'divino' },
  { id: 890, nome: 'Eternatus',  tipos: ['Veneno', 'Dragão'],  raridade: 'divino' },
]

const POR_ID = new Map(POKEDEX.map(p => [p.id, p]))
const POR_NOME = new Map(POKEDEX.map(p => [p.nome.toLowerCase(), p]))

function porId(dexId) { return POR_ID.get(Number(dexId)) || null }
function porNome(nome) { return POR_NOME.get(String(nome || '').toLowerCase()) || null }
function porRaridade(raridade) { return POKEDEX.filter(p => p.raridade === raridade) }

function imagemUrl(dexId) {
  // jsdelivr é um CDN espalhado pelo mundo — costuma ser bem mais
  // rápido/alcançável que baixar direto do raw.githubusercontent.com
  // em conexões mais instáveis (ex: internet móvel/Termux).
  return `https://cdn.jsdelivr.net/gh/PokeAPI/sprites@master/sprites/pokemon/other/official-artwork/${dexId}.png`
}
function imagemUrlAlternativa(dexId) {
  return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${dexId}.png`
}

// Sprite ANIMADO (gif de batalha do Pokémon Showdown) — cobre praticamente
// o Pokédex inteiro, ao contrário do animado clássico (só ia até geração 5).
function gifUrl(dexId) {
  return `https://cdn.jsdelivr.net/gh/PokeAPI/sprites@master/sprites/pokemon/other/showdown/${dexId}.gif`
}
function gifUrlAlternativa(dexId) {
  return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/showdown/${dexId}.gif`
}

// ── Fallback online ──────────────────────────────────────────────
// Cobre espécies capturadas no mato (!cacapokemon) que não estão na
// nossa lista curada de ~110 (essa lista é só a base "rica" com
// evolução/status). Busca o dexId pelo NOME na PokeAPI só pra
// conseguir a foto oficial — com cache em memória pra não bater na
// API de novo pro mesmo nome, e timeout curto pra nunca travar o bot.
const _cacheIdOnline = new Map()
async function buscarDexIdOnline(nome) {
  const chave = String(nome || '').toLowerCase().trim()
  if (!chave) return null
  if (_cacheIdOnline.has(chave)) return _cacheIdOnline.get(chave)
  try {
    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), 6000)
    const resp = await fetch(`https://pokeapi.co/api/v2/pokemon/${chave}`, { signal: controller.signal })
    clearTimeout(timeout)
    if (!resp.ok) { _cacheIdOnline.set(chave, null); return null }
    const data = await resp.json()
    _cacheIdOnline.set(chave, data.id)
    return data.id
  } catch (_) {
    _cacheIdOnline.set(chave, null)
    return null
  }
}

// "Rola" o status base da espécie de forma determinística (mesmo
// dexId sempre cai no mesmo valor dentro da faixa da raridade dele).
function seedPseudoAleatorio(seed) {
  const x = Math.sin(seed * 999331) * 10000
  return x - Math.floor(x)
}
function statusBase(pokemonDex) {
  const faixa = FAIXAS_RARIDADE[pokemonDex.raridade]
  const pick = (chave, offset) => {
    const [min, max] = faixa[chave]
    const r = seedPseudoAleatorio(pokemonDex.id * 7 + offset)
    return Math.round(min + r * (max - min))
  }
  return { hp: pick('hp', 1), atk: pick('atk', 2), def: pick('def', 3), spd: pick('spd', 4) }
}

// Escala o status base pro nível atual do Pokémon (cresce ~9% por nível)
function calcularStats(base, nivel, fusionTier = 0) {
  const mult = 1 + (Math.max(1, nivel) - 1) * 0.09
  const bonusFusao = 1 + (fusionTier * 0.3) // cada fusão dá +30%
  return {
    hpMax: Math.max(1, Math.round(base.hp * mult * bonusFusao)),
    atk: Math.max(1, Math.round(base.atk * mult * bonusFusao)),
    def: Math.max(1, Math.round(base.def * mult * bonusFusao)),
    spd: Math.max(1, Math.round(base.spd * mult * bonusFusao)),
  }
}

function sortearRaridadeGacha() {
  const total = Object.values(FAIXAS_RARIDADE).reduce((s, r) => s + r.peso, 0)
  let roll = Math.random() * total
  for (const chave of RARIDADES_ORDEM) {
    const peso = FAIXAS_RARIDADE[chave].peso
    if (roll < peso) return chave
    roll -= peso
  }
  return 'comum'
}

function sortearEspeciePorRaridade(raridade) {
  const lista = porRaridade(raridade)
  return lista[Math.floor(Math.random() * lista.length)]
}

// Pequena tabela de vantagem de tipo (não é o jogo oficial completo,
// só uma versão enxuta pra dar sabor às batalhas da arena)
const VANTAGEM_TIPO = {
  'Fogo': ['Grama', 'Inseto', 'Gelo', 'Aço'],
  'Água': ['Fogo', 'Terra', 'Pedra'],
  'Grama': ['Água', 'Terra', 'Pedra'],
  'Elétrico': ['Água', 'Voador'],
  'Gelo': ['Grama', 'Terra', 'Voador', 'Dragão'],
  'Lutador': ['Normal', 'Sombrio', 'Pedra', 'Aço', 'Gelo'],
  'Veneno': ['Grama', 'Fada'],
  'Terra': ['Fogo', 'Elétrico', 'Veneno', 'Pedra', 'Aço'],
  'Voador': ['Grama', 'Lutador', 'Inseto'],
  'Psíquico': ['Lutador', 'Veneno'],
  'Inseto': ['Grama', 'Psíquico', 'Sombrio'],
  'Pedra': ['Fogo', 'Gelo', 'Voador', 'Inseto'],
  'Fantasma': ['Psíquico', 'Fantasma'],
  'Dragão': ['Dragão'],
  'Sombrio': ['Psíquico', 'Fantasma'],
  'Aço': ['Gelo', 'Pedra', 'Fada'],
  'Fada': ['Lutador', 'Dragão', 'Sombrio'],
  'Normal': [],
}

function multiplicadorTipo(tiposAtacante, tiposDefensor) {
  let mult = 1
  for (const tAtk of tiposAtacante || []) {
    const forteContra = VANTAGEM_TIPO[tAtk] || []
    for (const tDef of tiposDefensor || []) {
      if (forteContra.includes(tDef)) mult = Math.max(mult, 1.5)
    }
  }
  return mult
}

// Classifica a raridade de um Pokémon vindo AO VIVO da PokeAPI (usado
// pelo !pokegacha, que cobre as 1025 espécies, não só as ~110 daqui de
// cima). Usa os mesmos 7 níveis do resto do sistema, pra !pokedex,
// !evoluir, arena etc. tratarem igual não importa de onde ele veio.
const DEX_IDS_SUPREMO = [150, 384, 382, 383, 483]
const DEX_IDS_DIVINO = [493, 890]
function classificarRaridadeAPI(dexId, species) {
  if (DEX_IDS_DIVINO.includes(dexId)) return 'divino'
  if (DEX_IDS_SUPREMO.includes(dexId)) return 'supremo'
  if (species?.is_mythical) return 'mitico'
  if (species?.is_legendary) return 'lendario'
  const taxaCaptura = Number(species?.capture_rate ?? 255)
  if (taxaCaptura <= 3) return 'epico'
  if (taxaCaptura <= 45) return 'raro'
  return 'comum'
}

module.exports = {
  POKEDEX, RARIDADES_ORDEM, LABEL_RARIDADE, EMOJI_RARIDADE, FAIXAS_RARIDADE,
  porId, porNome, porRaridade, imagemUrl, imagemUrlAlternativa, gifUrl, gifUrlAlternativa, statusBase, calcularStats,
  sortearRaridadeGacha, sortearEspeciePorRaridade, multiplicadorTipo, buscarDexIdOnline,
  classificarRaridadeAPI
}
