const axios = require('axios')

/*
 * ==========================================
 * META AI
 * ==========================================
 *
 * Este JID é mantido para preservar:
 *
 * Meta AI 🔵 • Status
 *
 * Os dados do CONTATO, porém, serão
 * puxados do próprio BOT conectado.
 */

const META_JID = '13135550002@s.whatsapp.net'


const IGNORAR = [
  'react',
  'delete',
  'forward',
  'disappearingMessagesInMessage',
  'pin',
  'edit'
]


const fotoCache = new Map()

const FOTO_CACHE_MS =
  60 * 1000


/*
 * ==========================================
 * NORMALIZAR JID
 * ==========================================
 */

function normalizarJid(jid) {

  if (
    !jid ||
    typeof jid !== 'string'
  ) {
    return null
  }

  jid = jid.trim()

  return jid.replace(
    /:\d+(?=@)/,
    ''
  )
}


/*
 * ==========================================
 * PEGAR JID DO BOT CONECTADO
 * ==========================================
 */

async function obterJidDoBot(sock) {

  let jid =
    sock?.user?.id ||
    sock?.user?.jid ||
    sock?.user?.phoneNumber ||
    null


  if (!jid) {
    return null
  }


  jid =
    normalizarJid(jid)


  /*
   * Se for LID, tenta converter
   * para o número real.
   */

  if (
    jid &&
    jid.endsWith('@lid')
  ) {

    try {

      const numero =
        await sock
          ?.signalRepository
          ?.lidMapping
          ?.getPNForLID(jid)


      if (numero) {

        jid =
          normalizarJid(
            numero
          )
      }

    } catch (_) {}
  }


  return jid
}


/*
 * ==========================================
 * PEGAR NÚMERO DO BOT
 * ==========================================
 */

async function obterNumeroDoBot(sock) {

  const jid =
    await obterJidDoBot(sock)


  if (!jid) {
    return null
  }


  const numero =
    jid
      .split('@')[0]
      .split(':')[0]
      .replace(/\D/g, '')


  return numero || null
}


/*
 * ==========================================
 * PEGAR NOME DO BOT
 * ==========================================
 */

function obterNomeDoBot(sock) {

  /*
   * Primeiro tenta o nome que o próprio
   * WhatsApp entregou para a conta conectada.
   */

  const nomes = [

    sock?.user?.name,

    sock?.user?.notify,

    global.NomeDoBot,

    global.nomeDoBot,

    global.nomeBot,

    global.BOT_NAME,

    global.botName,

    global.config?.NomeDoBot,

    global.config?.nomeDoBot,

    global.Config?.NomeDoBot,

    global.Config?.nomeDoBot
  ]


  for (
    const nome of nomes
  ) {

    if (
      typeof nome === 'string' &&
      nome.trim()
    ) {

      return nome.trim()
    }
  }


  return 'ARLEQUINA BOT'
}


/*
 * ==========================================
 * PEGAR FOTO DO BOT
 * ==========================================
 */

async function obterFotoDoBot(sock) {

  try {

    const botJid =
      await obterJidDoBot(sock)


    if (!botJid) {

      console.log(
        '⚠️ Meta Mark: JID do bot não encontrado.'
      )

      return null
    }


    /*
     * Cache.
     */

    const antiga =
      fotoCache.get(
        botJid
      )


    if (
      antiga &&
      Date.now() - antiga.time <
      FOTO_CACHE_MS
    ) {

      return antiga.buffer
    }


    /*
     * Busca a foto do PERFIL DO BOT.
     */

    const url =
      await sock.profilePictureUrl(
        botJid,
        'image'
      )


    if (!url) {

      console.log(
        '⚠️ Meta Mark: o bot não possui foto.'
      )

      return null
    }


    /*
     * Baixa a imagem.
     */

    const resposta =
      await axios.get(
        url,
        {
          responseType:
            'arraybuffer',

          timeout:
            10000
        }
      )


    const foto =
      Buffer.from(
        resposta.data
      )


    if (
      !foto ||
      !foto.length
    ) {

      return null
    }


    fotoCache.set(
      botJid,
      {
        buffer: foto,
        time: Date.now()
      }
    )


    console.log(
      `🖼️ Meta Mark: foto do BOT carregada: ${botJid}`
    )


    return foto

  } catch (erro) {

    console.log(
      '⚠️ Meta Mark: erro ao buscar foto:',
      erro?.message ||
      erro
    )

    return null
  }
}


/*
 * ==========================================
 * CRIAR CONTATO
 * ==========================================
 */

async function criarFakeMeta(sock) {

  /*
   * NÚMERO REAL DO BOT
   */

  const numeroBot =
    await obterNumeroDoBot(sock)


  if (!numeroBot) {

    throw new Error(
      'Número do bot não encontrado.'
    )
  }


  /*
   * NOME REAL DO BOT
   */

  const nomeBot =
    obterNomeDoBot(sock)


  /*
   * FOTO REAL DO BOT
   */

  const foto =
    await obterFotoDoBot(sock)


  /*
   * ========================================
   * VCARD
   * ========================================
   *
   * Aqui está a parte principal:
   *
   * FN = nome do BOT
   * TEL = número do BOT
   *
   * Não é Meta AI.
   */

  const vcard =
    'BEGIN:VCARD\n' +
    'VERSION:3.0\n' +
    `N:;${nomeBot};;;\n` +
    `FN:${nomeBot}\n` +
    `item1.TEL;waid=${numeroBot}:+${numeroBot}\n` +
    'item1.X-ABLabel:Celular\n' +
    'END:VCARD'


  const contactMessage = {

    /*
     * Isso faz aparecer:
     *
     * Contato: NOME DO BOT
     */

    displayName:
      nomeBot,

    vcard
  }


  /*
   * Coloca também a FOTO DO BOT
   * dentro do cartão.
   */

  if (foto) {

    contactMessage.jpegThumbnail =
      foto
  }


  /*
   * ========================================
   * MENSAGEM FALSA
   * ========================================
   *
   * IMPORTANTE:
   *
   * META_JID continua aqui.
   *
   * É ele que mantém:
   *
   * Meta AI 🔵 • Status
   */

  return {

    key: {

      fromMe:
        false,

      participant:
        META_JID,

      remoteJid:
        'status@broadcast'
    },


    message: {

      contactMessage
    }
  }
}


/*
 * ==========================================
 * APLICAR META MARK
 * ==========================================
 */

function aplicarMetaMark(sock) {

  if (!sock) {
    return
  }


  /*
   * Evita instalar duas vezes.
   */

  if (
    sock.__metaMarkAplicado
  ) {

    return
  }


  const originalSendMessage =
    sock.sendMessage.bind(sock)


  sock.sendMessage =
    async (
      jid,
      content,
      options = {}
    ) => {


      /*
       * Pode desligar globalmente:
       *
       * global.ENABLE_META_MARK = false
       */

      const ligado =
        global.ENABLE_META_MARK !== false


      /*
       * Não aplicar em ações especiais.
       */

      const ignorar =
        !content ||

        IGNORAR.some(
          chave =>
            Object.prototype
              .hasOwnProperty
              .call(
                content,
                chave
              )
        ) ||

        jid ===
          'status@broadcast'


      if (
        !ligado ||
        ignorar
      ) {

        return originalSendMessage(
          jid,
          content,
          options
        )
      }


      try {

        /*
         * Cria o cartão usando:
         *
         * NOME DO BOT
         * NÚMERO DO BOT
         * FOTO DO BOT
         */

        const fakeMeta =
          await criarFakeMeta(
            sock
          )


        /*
         * Mantém a mensagem citada.
         */

        return originalSendMessage(
          jid,
          content,
          {
            ...options,

            quoted:
              fakeMeta
          }
        )


      } catch (erro) {

        console.log(
          '⚠️ Meta Mark:',
          erro?.message ||
          erro
        )


        /*
         * Se alguma coisa falhar,
         * não impede o bot de enviar.
         */

        return originalSendMessage(
          jid,
          content,
          options
        )
      }
    }


  sock.__metaMarkAplicado =
    true


  /*
   * ========================================
   * LOG
   * ========================================
   */

  console.log(
    '🤖 Meta AI Mark ativado.'
  )


  console.log(
    `👤 Contato do BOT: ${obterNomeDoBot(sock)}`
  )


  obterJidDoBot(sock)
    .then(jid => {

      console.log(
        `📱 Número/JID do BOT: ${jid || 'não encontrado'}`
      )

    })
    .catch(() => {})


  /*
   * Testa/carrega a foto uma vez
   * depois que a conexão estiver pronta.
   */

  obterFotoDoBot(sock)
    .then(foto => {

      if (foto) {

        console.log(
          '🖼️ Foto do BOT pronta para o Meta Mark.'
        )

      } else {

        console.log(
          '⚠️ Foto do BOT não foi encontrada.'
        )
      }

    })
    .catch(() => {})
}


/*
 * ==========================================
 * EXPORTS
 * ==========================================
 */

module.exports = {

  aplicarMetaMark,

  criarFakeMeta,

  obterFotoDoBot,

  obterJidDoBot,

  obterNumeroDoBot,

  obterNomeDoBot
}
