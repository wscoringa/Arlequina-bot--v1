/*
  Sistema de advertências manuais (/adv, /rmadv, /listaadv)
  Separado do sistema automático do antilink para não misturar contadores.
  Armazena em: database/avisos.json
*/
const fs = require('fs')
const PATH = './database/avisos.json'

function carregar() {
  try {
    return fs.existsSync(PATH) ? JSON.parse(fs.readFileSync(PATH, 'utf-8')) : {}
  } catch (e) {
    return {}
  }
}

function salvar(dados) {
  try {
    fs.writeFileSync(PATH, JSON.stringify(dados, null, 2))
  } catch (e) {}
}

function addAviso(groupJid, userJid, maxAvisos = 3) {
  const dados = carregar()
  if (!dados[groupJid]) dados[groupJid] = {}
  const atual = (dados[groupJid][userJid] || 0) + 1
  dados[groupJid][userJid] = atual
  salvar(dados)
  return { total: atual, atingiuLimite: atual >= maxAvisos }
}

function rmAviso(groupJid, userJid) {
  const dados = carregar()
  if (!dados[groupJid] || !dados[groupJid][userJid]) return 0
  dados[groupJid][userJid] = Math.max(0, dados[groupJid][userJid] - 1)
  if (dados[groupJid][userJid] === 0) delete dados[groupJid][userJid]
  salvar(dados)
  return dados[groupJid]?.[userJid] || 0
}

function listarAvisos(groupJid) {
  const dados = carregar()
  return dados[groupJid] || {}
}

function resetAviso(groupJid, userJid) {
  const dados = carregar()
  if (dados[groupJid] && dados[groupJid][userJid] !== undefined) {
    delete dados[groupJid][userJid]
    salvar(dados)
  }
}

module.exports = { addAviso, rmAviso, resetAviso, listarAvisos }
