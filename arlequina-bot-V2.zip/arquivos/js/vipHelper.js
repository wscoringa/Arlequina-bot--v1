const donoState = require('./donoState.js')

function soDigitos(s) {
  return String(s || '').split('@')[0].replace(/[^0-9]/g, '')
}

function numeroDo(sender) {
  return soDigitos(sender)
}

/** Todas as chaves possíveis de um jid/numero */
function chavesDe(id) {
  const n = soDigitos(id)
  return n ? [n] : []
}

function acharChaveVip(num) {
  const vips = donoState.vips || {}
  if (!num) return null
  if (vips[num] !== undefined && vips[num] !== null) return num
  for (const k of Object.keys(vips)) {
    if (soDigitos(k) === num) return k
    const reg = vips[k]
    if (reg && typeof reg === 'object' && Array.isArray(reg.ids)) {
      if (reg.ids.some(id => soDigitos(id) === num)) return k
    }
  }
  return null
}

function getVipInfo(sender) {
  const num = numeroDo(sender)
  if (!num) return null
  const chave = acharChaveVip(num)
  if (!chave) return null

  let reg = donoState.vips[chave]

  if (reg === true || reg === 1) {
    return { chave, desde: null, expira: 0, permanente: true }
  }

  if (!reg || typeof reg !== 'object') {
    if (reg) return { chave, desde: null, expira: 0, permanente: true }
    return null
  }

  const expira = Number(reg.expira) || 0
  if (expira > 0 && Date.now() > expira) {
    // remove todas as chaves espelho
    for (const id of (reg.ids || [chave])) {
      try { delete donoState.vips[soDigitos(id)] } catch (_) {}
    }
    delete donoState.vips[chave]
    try { donoState.salvar && donoState.salvar() } catch (_) {}
    return null
  }

  return {
    chave,
    desde: reg.desde || null,
    expira,
    permanente: expira === 0,
    ids: reg.ids || [chave]
  }
}

function ehVip(sender, isDonoFn) {
  try {
    if (typeof isDonoFn === 'function' && isDonoFn()) return true
  } catch (_) {}
  return !!getVipInfo(sender)
}

/**
 * Define VIP e grava em TODAS as identidades passadas (telefone + lid).
 * dias = 0 → permanente
 */
function setVip(ids, dias) {
  const lista = (Array.isArray(ids) ? ids : [ids])
    .map(soDigitos)
    .filter(Boolean)
  if (!lista.length) return null

  const unicos = [...new Set(lista)]
  const d = Number(dias)
  const permanente = !d || d <= 0
  const agora = Date.now()
  const reg = {
    desde: agora,
    expira: permanente ? 0 : (agora + d * 24 * 60 * 60 * 1000),
    ids: unicos
  }

  // mesma entrada em cada id — assim telefone OU lid encontra
  for (const id of unicos) {
    donoState.vips[id] = reg
  }
  try { donoState.salvar && donoState.salvar() } catch (_) {}
  return reg
}

function delVip(numero) {
  const num = soDigitos(numero)
  const chave = acharChaveVip(num)
  if (!chave) return false
  const reg = donoState.vips[chave]
  const ids = (reg && typeof reg === 'object' && reg.ids) ? reg.ids : [chave]
  for (const id of ids) {
    delete donoState.vips[soDigitos(id)]
  }
  delete donoState.vips[chave]
  try { donoState.salvar && donoState.salvar() } catch (_) {}
  return true
}

function formatarValidade(info) {
  if (!info) return '—'
  if (info.permanente || !info.expira) return '♾️ Permanente'
  const ms = info.expira - Date.now()
  if (ms <= 0) return '❌ Expirado'
  const dias = Math.ceil(ms / (24 * 60 * 60 * 1000))
  const data = new Date(info.expira).toLocaleDateString('pt-BR')
  return `📅 ${dias} dia(s) restantes (até ${data})`
}

function msgSoVip(prefix) {
  return `😈 *Calma aí,*

Esse comando é só pra VIP.
Sem VIP, sem festa. 🃏💜`
}

function listarVips() {
  const vips = donoState.vips || {}
  const vistos = new Set()
  const out = []
  for (const k of Object.keys(vips)) {
    const info = getVipInfo(k)
    if (!info) continue
    const id = info.chave || k
    if (vistos.has(id)) continue
    vistos.add(id)
    if (info.ids) info.ids.forEach(i => vistos.add(soDigitos(i)))
    out.push({ numero: id, ...info })
  }
  return out
}

module.exports = { ehVip, msgSoVip, getVipInfo, setVip, delVip, formatarValidade, listarVips, numeroDo, soDigitos }
