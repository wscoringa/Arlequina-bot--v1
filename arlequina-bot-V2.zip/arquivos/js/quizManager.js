/*
  Sistema de Quiz/Jogos de Resposta — Arlequina Bot
  Gerencia sessões ativas por grupo, pontuação, hangman, forca e adivinha
*/
const fs = require('fs')
const path = require('path')

const DIR = './database/quiz'
if (!fs.existsSync(DIR)) fs.mkdirSync(DIR, { recursive: true })

// ─── Sessões em memória ───────────────────────────────────────────
const sessoesQuiz     = {}  // groupJid → { pergunta, resposta, tema, dica, iniciador, timeout }
const sessoesHangman  = {}  // groupJid → { palavra, letrasUsadas, erros, iniciador, timeout }
const sessoesAdivinha = {}  // groupJid → { numero, tentativas, iniciador, timeout }
const sessoesFrase    = {}  // groupJid → { frase, resposta, iniciador, timeout }

// ─── Pontuação persistida por grupo ─────────────────────────────
function scorePath(groupJid) {
  const safe = groupJid.replace(/[^a-zA-Z0-9]/g, '_')
  return path.join(DIR, `${safe}_score.json`)
}
function carregarScore(groupJid) {
  try { const f = scorePath(groupJid); return fs.existsSync(f) ? JSON.parse(fs.readFileSync(f)) : {} } catch { return {} }
}
function salvarScore(groupJid, dados) {
  try { fs.writeFileSync(scorePath(groupJid), JSON.stringify(dados, null, 2)) } catch {}
}
function adicionarPonto(groupJid, userJid, nome, qtd = 1) {
  const s = carregarScore(groupJid)
  if (!s[userJid]) s[userJid] = { nome, pontos: 0 }
  s[userJid].pontos += qtd
  s[userJid].nome = nome
  salvarScore(groupJid, s)
  return s[userJid].pontos
}
function topScore(groupJid, n = 10) {
  const s = carregarScore(groupJid)
  return Object.entries(s).map(([jid, d]) => ({ jid, ...d })).sort((a, b) => b.pontos - a.pontos).slice(0, n)
}
function zerarScore(groupJid) { salvarScore(groupJid, {}) }

// ─── Banco de perguntas ──────────────────────────────────────────
const PERGUNTAS = {
  geral: [
    { p: '🌍 Qual é o maior país do mundo em extensão territorial?', r: 'rússia', d: 'Fica na Europa/Ásia' },
    { p: '🧪 Qual é o símbolo químico do ouro?', r: 'au', d: 'Na tabela periódica' },
    { p: '🎸 Quem é conhecido como "Rei do Rock"?', r: 'elvis presley', d: 'Elvis ...' },
    { p: '🌊 Qual é o maior oceano do mundo?', r: 'pacífico', d: 'Separa Ásia das Américas' },
    { p: '🦁 Qual animal é chamado de "Rei da Selva"?', r: 'leão', d: 'Felino com juba' },
    { p: '📚 Quem escreveu Dom Quixote?', r: 'cervantes', d: 'Escritor espanhol' },
    { p: '🎨 Quem pintou a Mona Lisa?', r: 'leonardo da vinci', d: 'Italiano renascentista' },
    { p: '🚀 Em que ano o homem pisou na Lua pela primeira vez?', r: '1969', d: 'Apollo 11' },
    { p: '⚽ Quantos jogadores tem um time de futebol em campo?', r: '11', d: 'Número de titulares' },
    { p: '🌡️ A que temperatura a água ferve (em °C)?', r: '100', d: 'Graus Celsius' },
    { p: '🎭 Quem escreveu Romeu e Julieta?', r: 'shakespeare', d: 'Dramaturgo inglês' },
    { p: '🌙 Quantos dias dura uma volta da Lua ao redor da Terra?', r: '27', d: 'Aproximadamente 27-28 dias' },
    { p: '🐘 Qual é o maior animal terrestre?', r: 'elefante', d: 'Mamífero cinza e enorme' },
    { p: '⚡ Qual é a unidade de medida da velocidade da luz?', r: 'c', d: 'Letra usada em física' },
    { p: '🏔️ Qual é a montanha mais alta do mundo?', r: 'everest', d: 'Fica no Himalaia' },
    { p: '🎨 Quem pintou "A Noite Estrelada"?', r: 'van gogh', d: 'Pintor holandês pós-impressionista' },
    { p: '🦴 Qual é o menor osso do corpo humano?', r: 'estribo', d: 'Fica dentro do ouvido' },
    { p: '🦴 Quantos ossos tem o corpo humano adulto?', r: '206', d: 'Bebês nascem com bem mais' },
    { p: '🇦🇺 Qual é a capital da Austrália? (dica: não é Sydney)', r: 'camberra', d: 'Canberra em inglês' },
    { p: '📖 Quem escreveu o livro "1984"?', r: 'george orwell', d: 'Autor britânico' },
    { p: '⚛️ Qual é o elemento químico mais leve da tabela periódica?', r: 'hidrogênio', d: 'Símbolo H' },
    { p: '🎸 Quantas cordas tem um violão clássico?', r: '6', d: 'Padrão da maioria dos violões' },
    { p: '🧱 Em que ano caiu o Muro de Berlim?', r: '1989', d: 'Fim da Guerra Fria se aproximando' },
    { p: '💴 Qual é a moeda oficial do Japão?', r: 'iene', d: 'Símbolo ¥' },
    { p: '🩸 Qual é o tipo sanguíneo considerado "doador universal"?', r: 'o negativo', d: 'Pode doar para quase todo mundo' },
  ],
  animal: [
    { p: '🐧 Qual ave não consegue voar mas nada muito bem?', r: 'pinguim', d: 'Vive em clima frio' },
    { p: '🦒 Qual é o animal terrestre mais alto do mundo?', r: 'girafa', d: 'Pescoço enorme' },
    { p: '🐬 Os golfinhos são mamíferos ou peixes?', r: 'mamíferos', d: 'Respiram ar' },
    { p: '🕷️ Quantas patas tem uma aranha?', r: '8', d: 'Aracnídeo' },
    { p: '🦋 Como se chama o processo de transformação da borboleta?', r: 'metamorfose', d: 'Lagarta → casulo → borboleta' },
    { p: '🐊 Qual é o maior réptil do mundo?', r: 'crocodilo', d: 'Vive em rios e lagos' },
    { p: '🦈 Quantas fileiras de dentes o tubarão pode ter?', r: '7', d: 'Até 7 fileiras' },
    { p: '🦜 Qual ave é conhecida por imitar sons humanos?', r: 'papagaio', d: 'Ave colorida falante' },
    { p: '🐘 Quantos anos um elefante pode viver?', r: '70', d: 'Cerca de 60-70 anos' },
    { p: '🦁 Como se chama o grupo de leões?', r: 'alcateia', d: 'Também chamado de bando ou matilha' },
    { p: '🐆 Qual é o mamífero terrestre mais rápido do mundo?', r: 'guepardo', d: 'Chega a 110 km/h' },
    { p: '🐙 Quantos corações tem um polvo?', r: '3', d: 'Dois bombeiam pras guelras' },
    { p: '🥚 Qual ave põe o maior ovo do mundo?', r: 'avestruz', d: 'Também é a maior ave viva' },
    { p: '🦇 Qual é o único mamífero capaz de voar de verdade?', r: 'morcego', d: 'Outros só planam' },
    { p: '🦐 Quantas patas tem um camarão?', r: '10', d: 'Crustáceo decápode' },
    { p: '🐴 Qual animal é capaz de dormir em pé?', r: 'cavalo', d: 'Trava as pernas pra não cair' },
    { p: '🦈 Qual é o maior peixe do mundo?', r: 'tubarão-baleia', d: 'Gigante e inofensivo' },
    { p: '🦎 Qual animal muda de cor pra se camuflar?', r: 'camaleão', d: 'Réptil com olhos independentes' },
  ],
  filme: [
    { p: '🎬 Em qual filme a personagem Simba é o protagonista?', r: 'o rei leão', d: 'Animação da Disney' },
    { p: '🕷️ Qual ator interpretou o Homem-Aranha em 2002?', r: 'tobey maguire', d: 'Versão Sam Raimi' },
    { p: '🧙 Quem é o bruxo de Hogwarts?', r: 'harry potter', d: 'Cicatriz em forma de raio' },
    { p: '🤖 Qual é o nome do robô azul em Star Wars?', r: 'r2d2', d: 'Companheiro de C-3PO' },
    { p: '🦁 Em qual animação aparecem Timão e Pumba?', r: 'o rei leão', d: 'Javali e suricato' },
    { p: '🧊 Qual é o nome da rainha de gelo em Frozen?', r: 'elsa', d: 'Tem poderes de gelo' },
    { p: '🧱 Qual filme tem a frase "Houston, temos um problema"?', r: 'apollo 13', d: 'Filme espacial' },
    { p: '🦸 Quem é o Homem de Ferro na Marvel?', r: 'tony stark', d: 'Bilionário com armadura' },
    { p: '🚢 Em qual filme Jack e Rose vivem um romance trágico?', r: 'titanic', d: 'Navio afundando' },
    { p: '🧸 Qual boneco assusta crianças em filmes de terror?', r: 'chucky', d: 'Boneco de pano assassino' },
    { p: '🎬 Quem dirigiu o filme "Tubarão" (1975)?', r: 'steven spielberg', d: 'Também dirigiu Jurassic Park' },
    { p: '⚔️ Em qual saga aparece a frase "Que a Força esteja com você"?', r: 'star wars', d: 'Guerra nas Estrelas' },
    { p: '🐷 Qual é o nome do porquinho-cofre em "Toy Story"?', r: 'hamm', d: 'Fala com voz grossa' },
    { p: '🎭 Quem interpretou o Coringa no filme de 2019?', r: 'joaquin phoenix', d: 'Ganhou o Oscar pelo papel' },
    { p: '🚢 Qual filme sobre o naufrágio de 1912 venceu 11 Oscars em 1998?', r: 'titanic', d: 'De James Cameron' },
    { p: '🦈 Qual era o apelido do tubarão mecânico usado nas filmagens de "Tubarão"?', r: 'bruce', d: 'Em homenagem ao advogado de Spielberg' },
    { p: '💊 Em "Matrix", qual pílula Neo escolhe pra descobrir a verdade?', r: 'vermelha', d: 'A azul o manteria na ilusão' },
  ],
  pokemon: [
    { p: '⚡ Qual é o Pokémon elétrico mais famoso?', r: 'pikachu', d: 'Mascote da franquia' },
    { p: '🔥 Qual Pokémon de fogo evolui de Charmander?', r: 'charmeleon', d: 'Segunda forma' },
    { p: '💧 Qual é o Pokémon aquático inicial de Kanto?', r: 'squirtle', d: 'Tartaruga azul' },
    { p: '🌿 Qual Pokémon inicial da planta de Johto?', r: 'chikorita', d: 'Folha na cabeça' },
    { p: '🐉 Qual é o Pokémon lendário de Kanto com três formas?', r: 'mewtwo', d: 'Criado geneticamente' },
    { p: '👻 Qual Pokémon fantasma assusta treinadores dormindo?', r: 'gengar', d: 'Sorriso largo roxo' },
    { p: '🧊 Qual Pokémon de gelo tem formato de animal marinho?', r: 'lapras', d: 'Parece um plesiossauro' },
    { p: '⚡ Qual é a evolução final de Pikachu?', r: 'raichu', d: 'Precisa de Pedra Trovão' },
    { p: '🔮 Qual Pokémon psíquico parece uma colher?', r: 'alakazam', d: 'Segura duas colheres' },
    { p: '🏆 Qual Pokémon é chamado de "Pokémon Deuses"?', r: 'arceus', d: 'Criou o universo Pokémon' },
    { p: '🔥 Qual é o Pokémon inicial de fogo de Kanto?', r: 'charmander', d: 'Fogo na pontinha do rabo' },
    { p: '🎽 Quem é o rival de Ash no anime clássico?', r: 'gary', d: 'Também chamado de Gary Oak' },
    { p: '⏳ Qual Pokémon lendário representa o tempo?', r: 'dialga', d: 'Da região de Sinnoh' },
    { p: '🔢 Quantos tipos de Pokémon existem atualmente?', r: '18', d: 'Fogo, água, planta, etc.' },
    { p: '🧑‍🔬 Quem entrega os Pokémon iniciais em Kanto?', r: 'professor carvalho', d: 'Também conhecido como Professor Oak' },
    { p: '❄️ Qual é a evolução de Eevee ligada ao gelo?', r: 'glaceon', d: 'Precisa de uma Pedra Gelo' },
  ],
  anime: [
    { p: '🍊 Qual é o nome do protagonista de Naruto?', r: 'naruto uzumaki', d: 'Quer ser Hokage' },
    { p: '⚔️ Qual é o nome do protagonista de Demon Slayer?', r: 'tanjiro kamado', d: 'Mata demônios com espada' },
    { p: '🏴‍☠️ Qual é o sonho de Monkey D. Luffy?', r: 'rei dos piratas', d: 'One Piece' },
    { p: '🌙 Qual princesa guerreira usa manto e capuz roxo?', r: 'sailor moon', d: 'Guerreira da lua' },
    { p: '🐉 Como se chama a escola de Goku em Dragon Ball?', r: 'kame house', d: 'Do Mestre Kame' },
    { p: '⚔️ Qual personagem de Attack on Titan é chamado de Humanidade mais Forte?', r: 'levi ackerman', d: 'Capitão' },
    { p: '🔮 Qual é o nome da espada de Ichigo em Bleach?', r: 'zangetsu', d: 'Zanpakutou negra' },
    { p: '🧠 Qual gênio usa um caderno da morte em Death Note?', r: 'light yagami', d: 'Quer criar um mundo perfeito' },
    { p: '🐱 Qual gato falante aparece em Sailor Moon?', r: 'luna', d: 'Gato preto' },
    { p: '👊 Qual herói em My Hero Academia tem poderes de Superman?', r: 'deku', d: 'One For All' },
    { p: '⛩️ Qual é o nome da vila de Naruto?', r: 'konoha', d: 'Vila da Folha' },
    { p: '🌀 Qual é a técnica mais famosa de Naruto?', r: 'rasengan', d: 'Esfera giratória de chakra' },
    { p: '⚗️ Quais são os nomes dos irmãos protagonistas de Fullmetal Alchemist?', r: 'edward e alphonse', d: 'Edward e Alphonse Elric' },
    { p: '👻 Qual é o nome do Shinigami que dá o caderno pra Light em Death Note?', r: 'ryuk', d: 'Adora maçãs' },
    { p: '🪐 De qual planeta destruído vem Goku?', r: 'vegeta', d: 'Planeta natal dos Saiyajins' },
    { p: '🐉 Qual é o nome do dragão que realiza desejos em Dragon Ball?', r: 'shenlong', d: 'Invocado com as 7 esferas' },
  ],
  kpop: [
    { p: '🎤 Qual grupo tem os membros V, Jimin, Jungkook, Jin, Suga, J-Hope e RM?', r: 'bts', d: 'Grupo mais famoso do K-pop' },
    { p: '🎵 Como se chama o fandom do BTS?', r: 'army', d: 'Sigla em inglês' },
    { p: '👑 Qual idol tem o nome artístico "IU"?', r: 'lee ji eun', d: 'Cantora e atriz coreana' },
    { p: '🌹 Qual grupo feminino inclui Jennie, Lisa, Jisoo e Rosé?', r: 'blackpink', d: 'YG Entertainment' },
    { p: '🎶 Qual música do PSY viralizou com dança de cavalo?', r: 'gangnam style', d: '2012, bilhões de views' },
    { p: '💜 Em qual cidade fica a sede da HYBE?', r: 'seul', d: 'Capital da Coreia do Sul' },
    { p: '🏆 Como se chama o prêmio mais importante do K-pop?', r: 'daesang', d: 'Prêmio grande' },
    { p: '🐱 Qual grupo tem a música "Dynamite"?', r: 'bts', d: 'Primeira música em inglês' },
    { p: '💫 Qual idol do BLACKPINK é tailandesa?', r: 'lisa', d: 'Lisa Manoban' },
    { p: '🎤 Qual grupo tem a música "Fancy"?', r: 'twice', d: 'JYP Entertainment' },
    { p: '💿 Qual grupo lançou o álbum "Love Yourself"?', r: 'bts', d: 'Trilogia de álbuns' },
    { p: '👥 Quantos membros tem o grupo SEVENTEEN?', r: '13', d: 'Dividido em 3 subunidades' },
    { p: '💗 Como se chama o fandom do BLACKPINK?', r: 'blink', d: 'Junção de "black" e "pink"' },
    { p: '🏢 Qual é a gravadora atual do BTS?', r: 'hybe', d: 'Antes chamada Big Hit' },
    { p: '👑 Quem é o líder do BTS?', r: 'rm', d: 'Também é o rapper principal' },
    { p: '👥 Quantos membros tinha o EXO originalmente?', r: '12', d: 'Dividido em EXO-K e EXO-M' },
  ],
  futebol: [
    { p: '⚽ Quantas Copas do Mundo o Brasil ganhou?', r: '5', d: 'Pentacampeão' },
    { p: '🏆 Qual país sediou a Copa do Mundo de 2014?', r: 'brasil', d: 'No Brasil' },
    { p: '⚽ Quem é o maior artilheiro da história do Brasil?', r: 'pelé', d: 'Rei do Futebol' },
    { p: '🌟 Quantas Bolas de Ouro Messi ganhou até 2023?', r: '8', d: 'Recorde mundial' },
    { p: '🏟️ Qual é o maior estádio do Brasil?', r: 'maracanã', d: 'Fica no Rio de Janeiro' },
    { p: '⚽ Qual clube tem mais títulos da Champions League?', r: 'real madrid', d: 'Clube espanhol' },
    { p: '👕 Qual é a cor da camisa titular da Seleção Brasileira?', r: 'amarela', d: 'Verde e amarelo' },
    { p: '🏆 Em qual ano o Brasil ganhou sua primeira Copa?', r: '1958', d: 'Na Suécia' },
    { p: '⚽ Quem é o maior artilheiro da história da Champions?', r: 'cristiano ronaldo', d: 'CR7' },
    { p: '🌍 Quantas seleções participam da Copa do Mundo?', r: '32', d: 'Formato atual' },
    { p: '⚽ Qual jogador brasileiro é conhecido como "O Fenômeno"?', r: 'ronaldo', d: 'Ronaldo Nazário' },
    { p: '🏟️ Em que ano o Brasil sediou a primeira Copa do Mundo?', r: '1950', d: 'No Maracanã' },
    { p: '🏟️ Qual é o nome do estádio do Barcelona?', r: 'camp nou', d: 'Um dos maiores da Europa' },
    { p: '⏱️ Quantos minutos dura uma partida de futebol no tempo normal?', r: '90', d: 'Dois tempos de 45' },
    { p: '🏆 Qual seleção venceu a primeira Copa do Mundo, em 1930?', r: 'uruguai', d: 'Sediada no próprio país' },
    { p: '🌎 Quais 3 países sediarão a Copa do Mundo de 2026?', r: 'estados unidos, méxico e canadá', d: 'Primeira Copa com 3 sedes' },
  ],
  harrypotter: [
    { p: '🧙 Em qual casa Harry Potter foi selecionado?', r: 'grifinória', d: 'Coragem' },
    { p: '🦉 Qual é o nome da coruja de Harry?', r: 'edwiges', d: 'Coruja branca' },
    { p: '🔮 Qual é o nome do vilão principal da saga?', r: 'voldemort', d: 'Aquele que não deve ser nomeado' },
    { p: '🧙 Qual é o nome completo de Hermione?', r: 'hermione granger', d: 'A mais inteligente da turma' },
    { p: '🏰 Como se chama a escola de magia?', r: 'hogwarts', d: 'Escola de Magia e Bruxaria' },
    { p: '⚡ O que significa a cicatriz de Harry?', r: 'raio', d: 'Em formato de relâmpago' },
    { p: '🏆 Como se chama o esporte bruxo jogado em vassouras?', r: 'quadribol', d: 'Quaffle, Bludger, Pomo' },
    { p: '🐍 Qual casa representa a serpente em Hogwarts?', r: 'sonserina', d: 'Rivaliza com Grifinória' },
    { p: '🪄 Como se chama o feitiço de expulsão?', r: 'expelliarmus', d: 'Feitiço favorito de Harry' },
    { p: '🦁 Qual professor ensina Defesa Contra as Artes das Trevas no livro 3?', r: 'lupin', d: 'Professor Lupin' },
    { p: '🧦 Qual elfo doméstico Harry liberta no segundo livro?', r: 'dobby', d: 'Ganha uma meia de presente' },
    { p: '🐉 Qual criatura gigante guarda os cofres de Gringotes?', r: 'dragão', d: 'Banco dos bruxos' },
    { p: '👴 Quem é o diretor de Hogwarts durante quase toda a saga?', r: 'dumbledore', d: 'Alvo Dumbledore' },
    { p: '🦌 Qual animal representa o Patrono de Harry Potter?', r: 'cervo', d: 'Igual ao do pai dele' },
    { p: '😆 Qual feitiço faz o alvo sentir cócegas?', r: 'rictusempra', d: 'Feitiço de ataque leve' },
  ],
  marvel: [
    { p: '🦸 Qual herói usa um escudo de vibranium?', r: 'capitão américa', d: 'Steve Rogers' },
    { p: '🕷️ Qual é o nome real do Homem-Aranha?', r: 'peter parker', d: 'Estudante de escola' },
    { p: '💚 O Hulk fica verde quando sente qual emoção?', r: 'raiva', d: 'Quanto mais bravo mais forte' },
    { p: '⚡ Qual deus nórdico aparece na Marvel?', r: 'thor', d: 'Deus do trovão' },
    { p: '🦸 Qual heroína tem poderes de magia e feitiçaria?', r: 'feiticeira escarlate', d: 'Wanda Maximoff' },
    { p: '🤖 Qual é o nome do robô criado por Tony Stark?', r: 'ultron', d: 'Vilão de Age of Ultron' },
    { p: '🌌 Qual personagem coleciona as Pedras do Infinito?', r: 'thanos', d: 'Vilão de Endgame' },
    { p: '🐝 Qual super-herói pode diminuir de tamanho?', r: 'homem formiga', d: 'Scott Lang' },
    { p: '🌙 Qual herói possui o traje de vibranium e é rei do Wakanda?', r: 'pantera negra', d: 'T\'Challa' },
    { p: '🌀 Qual herói é "O Feiticeiro Supremo"?', r: 'doutor estranho', d: 'Médico virou mago' },
    { p: '👴 Quem é o pai biológico de Thor?', r: 'odin', d: 'Rei de Asgard' },
    { p: '🛡️ Qual metal indestrutível forma o escudo do Capitão América?', r: 'vibranium', d: 'Também usado em Wakanda' },
    { p: '🌍 Qual é o país fictício, lar de Pantera Negra?', r: 'wakanda', d: 'Rico em vibranium' },
    { p: '💔 Quem é o tio de Peter Parker que morre no primeiro filme dele?', r: 'tio ben', d: '"Com grandes poderes..."' },
    { p: '🦴 Qual é o verdadeiro nome do Wolverine?', r: 'logan', d: 'Também conhecido como James Howlett' },
  ],
  geografia: [
    { p: '🌍 Qual é a capital do Brasil?', r: 'brasília', d: 'Não é São Paulo nem Rio!' },
    { p: '🗼 Qual é a capital da França?', r: 'paris', d: 'Cidade da Torre Eiffel' },
    { p: '🌏 Qual é o país mais populoso do mundo?', r: 'índia', d: 'Ultrapassou a China em 2023' },
    { p: '🌊 Qual é o maior rio do mundo em extensão?', r: 'nilo', d: 'No continente africano' },
    { p: '🏔️ Em qual continente fica o Monte Everest?', r: 'ásia', d: 'Himalaia' },
    { p: '🌎 Qual é o menor país do mundo?', r: 'vaticano', d: 'Dentro de Roma' },
    { p: '🌡️ Qual é o deserto mais quente do mundo?', r: 'saara', d: 'Norte da África' },
    { p: '🌊 Quantos oceanos existem no mundo?', r: '5', d: 'Incluindo o Ártico' },
    { p: '🗾 Qual é a capital do Japão?', r: 'tóquio', d: 'Maior cidade do mundo' },
    { p: '🏙️ Qual é o maior país da América do Sul?', r: 'brasil', d: 'Ocupa metade do continente' },
    { p: '🕐 Qual país tem mais fusos horários do mundo (contando territórios)?', r: 'frança', d: 'Por causa dos territórios ultramarinos' },
    { p: '⛰️ Qual é a cordilheira mais extensa do mundo?', r: 'andes', d: 'Atravessa vários países da América do Sul' },
    { p: '🌏 Qual é o único país que ocupa um continente inteiro?', r: 'austrália', d: 'País-continente' },
    { p: '🇷🇺 Qual é a capital da Rússia?', r: 'moscou', d: 'Maior cidade do país' },
    { p: '🌊 Qual estreito separa a Europa da África?', r: 'gibraltar', d: 'Liga o Atlântico ao Mediterrâneo' },
    { p: '👢 Qual país europeu tem o formato de uma bota?', r: 'itália', d: 'Fácil de reconhecer no mapa' },
    { p: '🍁 Qual é a capital do Canadá? (dica: não é Toronto)', r: 'ottawa', d: 'Cidade menor que Toronto' },
  ],
  ciencia: [
    { p: '⚛️ Qual é o menor componente de um átomo?', r: 'quark', d: 'Componente dos prótons/nêutrons' },
    { p: '🧬 Qual molécula carrega a informação genética?', r: 'dna', d: 'Dupla hélice' },
    { p: '🌡️ Qual é a temperatura do zero absoluto em °C?', r: '-273', d: 'Zero Kelvin' },
    { p: '⚡ Quem descobriu a eletricidade?', r: 'benjamin franklin', d: 'Com uma pipa e raio' },
    { p: '🍎 Que força Newton descobriu ao ver uma maçã cair?', r: 'gravidade', d: 'Atração entre massas' },
    { p: '🔬 Quem inventou a penicilina?', r: 'alexander fleming', d: 'Antibiótico descoberto por acidente' },
    { p: '☀️ Qual é o elemento mais abundante no Sol?', r: 'hidrogênio', d: 'H na tabela periódica' },
    { p: '🧲 Qual é o metal mais magnético?', r: 'ferro', d: 'Fe na tabela periódica' },
    { p: '💡 Quem inventou a lâmpada elétrica?', r: 'thomas edison', d: 'Inventor americano' },
    { p: '🌌 Qual é o planeta mais próximo do Sol?', r: 'mercúrio', d: 'Primeiro planeta' },
    { p: '🦴 Qual é o osso mais forte do corpo humano?', r: 'fêmur', d: 'Osso da coxa' },
    { p: '🪐 Quantos planetas existem no Sistema Solar atualmente?', r: '8', d: 'Plutão foi reclassificado em 2006' },
    { p: '💨 Qual gás as plantas absorvem na fotossíntese?', r: 'gás carbônico', d: 'Também chamado de CO2' },
    { p: '❤️ Qual órgão é responsável por bombear o sangue?', r: 'coração', d: 'Bate cerca de 100 mil vezes por dia' },
    { p: '🍎 Quem formulou as três leis do movimento e a gravitação universal?', r: 'isaac newton', d: 'Físico inglês' },
    { p: '💪 Qual é a unidade de medida de força no Sistema Internacional?', r: 'newton', d: 'Em homenagem ao físico' },
  ],
  historia: [
    { p: '🏛️ Em qual ano o Brasil se tornou independente?', r: '1822', d: 'Dom Pedro I às margens do Ipiranga' },
    { p: '⚔️ Quem foi o primeiro imperador romano?', r: 'augusto', d: 'Sobrinho-neto de Júlio César' },
    { p: '🌍 Em qual ano começou a Segunda Guerra Mundial?', r: '1939', d: 'Invasão da Polônia' },
    { p: '🏰 Qual civilização construiu as pirâmides do Egito?', r: 'egípcios', d: 'Faraós e hieróglifos' },
    { p: '🚢 Em que ano o Titanic afundou?', r: '1912', d: 'Primeira viagem' },
    { p: '🌕 Em que ano o homem foi à Lua?', r: '1969', d: 'Apollo 11' },
    { p: '🐉 Qual imperador unificou a China pela primeira vez?', r: 'qin shi huang', d: 'Construiu a Grande Muralha' },
    { p: '✊ Quem liderou a Revolução Francesa?', r: 'robespierre', d: 'Período do Terror' },
    { p: '🎖️ Quem foi o primeiro presidente dos EUA?', r: 'george washington', d: 'Pai fundador' },
    { p: '🌊 Em qual ano Cristóvão Colombo chegou à América?', r: '1492', d: 'Viagem pelas Índias' },
    { p: '🌕 Quem foi o primeiro homem a pisar na Lua?', r: 'neil armstrong', d: 'Missão Apollo 11' },
    { p: '🕊️ Em que ano terminou a Segunda Guerra Mundial?', r: '1945', d: 'Com a rendição do Japão' },
    { p: '⛓️ Em que ano o Brasil aboliu oficialmente a escravidão?', r: '1888', d: 'Lei Áurea' },
    { p: '👑 Quem foi o primeiro imperador do Brasil?', r: 'dom pedro i', d: 'Proclamou a Independência' },
    { p: '🏰 Em que ano a Bastilha foi tomada, iniciando a Revolução Francesa?', r: '1789', d: 'Marco do fim do Antigo Regime' },
    { p: '👸 Quem foi a última faraó do Egito Antigo?', r: 'cleópatra', d: 'Governou ao lado de Roma' },
  ],
  // Banco extra: perguntas bem mais difíceis, usado pelo !quizdificil e por quem quiser um desafio maior
  dificil: [
    { p: '🦆 Qual é o único mamífero capaz de botar ovos?', r: 'ornitorrinco', d: 'Também tem veneno na pata' },
    { p: '🇲🇳 Qual é a capital da Mongólia?', r: 'ulan bator', d: 'Uma das capitais mais frias do mundo' },
    { p: '📜 Quem escreveu o poema épico "Os Lusíadas"?', r: 'luís de camões', d: 'Sobre as grandes navegações portuguesas' },
    { p: '⚛️ Qual é o símbolo químico do estanho?', r: 'sn', d: 'Do latim "stannum"' },
    { p: '📜 Em que ano foi assinada a Magna Carta na Inglaterra?', r: '1215', d: 'Limitou o poder do rei' },
    { p: '🏝️ Qual é o menor país da África em extensão territorial?', r: 'seychelles', d: 'Arquipélago no Oceano Índico' },
    { p: '👑 Quem foi o primeiro imperador do Sacro Império Romano-Germânico?', r: 'carlos magno', d: 'Coroado no ano 800' },
    { p: '✍️ Qual tratado pôs fim oficialmente à Primeira Guerra Mundial?', r: 'tratado de versalhes', d: 'Assinado em 1919' },
    { p: '🇰🇿 Qual é a capital do Cazaquistão?', r: 'astana', d: 'Já teve outros nomes no passado' },
    { p: '🖋️ Qual filósofo renascentista escreveu "O Príncipe"?', r: 'maquiavel', d: 'Obra sobre política e poder' },
    { p: '🏔️ Qual civilização construiu Machu Picchu?', r: 'inca', d: 'Nas montanhas do Peru' },
    { p: '⛰️ Qual é a montanha mais alta da América do Sul?', r: 'aconcágua', d: 'Fica na Argentina' },
    { p: '🏭 Em que década se costuma marcar o início da Revolução Industrial?', r: '1760', d: 'Começou na Inglaterra' },
    { p: '🧪 Qual cientista russo criou a tabela periódica dos elementos?', r: 'mendeleiev', d: 'Organizou os elementos por propriedades' },
    { p: '🇳🇿 Qual é a capital da Nova Zelândia? (dica: não é Auckland)', r: 'wellington', d: 'Cidade menor, mas é a capital' },
    { p: '🎨 Quem pintou o famoso quadro "Guernica"?', r: 'picasso', d: 'Retrata os horrores da Guerra Civil Espanhola' },
    { p: '🌋 Qual vulcão destruiu a cidade de Pompeia em 79 d.C.?', r: 'vesúvio', d: 'Fica perto de Nápoles, na Itália' },
    { p: '🇧🇹 Qual é a capital do Butão?', r: 'timphu', d: 'País no Himalaia' },
    { p: '📚 Quem escreveu "Cem Anos de Solidão"?', r: 'garcía márquez', d: 'Escritor colombiano, Nobel de Literatura' },
    { p: '🌊 Qual é o maior arquipélago do mundo em número de ilhas?', r: 'indonésia', d: 'Mais de 17 mil ilhas' },
  ],
}

// Perguntas de idiomas
const PERGUNTAS_IDIOMA = {
  pt: [
    { p: '🇧🇷 Como se escreve corretamente: "meia" ou "meia"?', r: 'meia', d: '6 ou feminino de meio' },
    { p: '🇧🇷 Qual palavra é um substantivo: "bonito", "correr", "casa"?', r: 'casa', d: 'Coisa, lugar ou pessoa' },
    { p: '🇧🇷 Complete: "Mais vale um pássaro na mão do que ___"', r: 'dois voando', d: 'Provérbio popular' },
    { p: '🇧🇷 Qual é o plural de "anão"?', r: 'anões', d: 'Terminação irregular' },
    { p: '🇧🇷 Qual é o antônimo de "alegre"?', r: 'triste', d: 'Sentimento oposto' },
  ],
  en: [
    { p: '🇺🇸 What is the opposite of "happy"?', r: 'sad', d: 'Feeling the opposite' },
    { p: '🇺🇸 How do you say "obrigado" in English?', r: 'thank you', d: 'Expression of gratitude' },
    { p: '🇺🇸 What is the plural of "child"?', r: 'children', d: 'Irregular plural' },
    { p: '🇺🇸 How do you say "casa" in English?', r: 'house', d: 'Where you live' },
    { p: '🇺🇸 What does "beautiful" mean in Portuguese?', r: 'bonito', d: 'Adjetivo de beleza' },
  ],
  es: [
    { p: '🇪🇸 ¿Cómo se dice "obrigado" en español?', r: 'gracias', d: 'Agradecimiento' },
    { p: '🇪🇸 ¿Cuál es el plural de "mujer"?', r: 'mujeres', d: 'Femenino plural' },
    { p: '🇪🇸 ¿Cómo se dice "casa" en español?', r: 'casa', d: 'Es igual em português!' },
    { p: '🇪🇸 ¿Cómo se dice "bom dia" en español?', r: 'buenos días', d: 'Saludo matutino' },
    { p: '🇪🇸 ¿Cuál es el opuesto de "frío"?', r: 'caliente', d: 'Temperatura alta' },
  ],
  coreano: [
    { p: '🇰🇷 Como se diz "olá" em coreano?', r: '안녕하세요', d: 'Annyeonghaseyo' },
    { p: '🇰🇷 Como se escreve "amor" em coreano?', r: '사랑', d: 'Sarang' },
    { p: '🇰🇷 O que significa "감사합니다"?', r: 'obrigado', d: 'Gamsahamnida' },
    { p: '🇰🇷 Como se diz "sim" em coreano?', r: '네', d: 'Ne ou Ye' },
    { p: '🇰🇷 O que significa "화이팅"?', r: 'força', d: 'Hwaiting — expressão de encorajamento' },
  ],
  japones: [
    { p: '🇯🇵 Como se diz "obrigado" em japonês?', r: 'arigatou', d: 'Arigato gozaimasu formal' },
    { p: '🇯🇵 O que significa "Sakura"?', r: 'flor de cerejeira', d: 'Símbolo do Japão' },
    { p: '🇯🇵 Como se diz "sim" em japonês?', r: 'hai', d: 'Pronuncia-se "rai"' },
    { p: '🇯🇵 O que significa "Kawaii"?', r: 'fofo', d: 'Palavra muito usada em anime' },
    { p: '🇯🇵 Como se diz "amor" em japonês?', r: 'ai', d: 'Também pode ser "koi"' },
  ],
  russo: [
    { p: '🇷🇺 Como se diz "olá" em russo?', r: 'privet', d: 'Привет — informal' },
    { p: '🇷🇺 O que significa "спасибо"?', r: 'obrigado', d: 'Spasibo' },
    { p: '🇷🇺 Como se diz "sim" em russo?', r: 'da', d: 'Да' },
    { p: '🇷🇺 O que significa "нет" em russo?', r: 'não', d: 'Nyet' },
    { p: '🇷🇺 Como se escreve "amor" em russo?', r: 'любовь', d: 'Lyubov' },
  ],
}

// Charadas
const CHARADAS = [
  { p: '🧩 Quanto mais tiro, maior fico. O que sou eu?', r: 'buraco', d: 'Pense em escavar' },
  { p: '🧩 Tenho cidades mas não tenho casas. Tenho montanhas mas não tenho árvores. Tenho água mas não tenho peixe. O que sou?', r: 'mapa', d: 'Representação do mundo' },
  { p: '🧩 O que tem dentes mas não morde?', r: 'pente', d: 'Usado no cabelo' },
  { p: '🧩 Quanto mais me tiram, maior fico. Sou encontrado na terra. O que sou?', r: 'buraco', d: 'Vazio escavado' },
  { p: '🧩 Tenho mãos mas não tenho braços, tenho rosto mas não tenho olhos. O que sou?', r: 'relógio', d: 'Indica horas' },
  { p: '🧩 O que é uma coisa que quanto mais você compartilha, mais ela cresce?', r: 'conhecimento', d: 'Também: felicidade, amor' },
  { p: '🧩 O que nunca pergunta mas recebe muitas respostas?', r: 'telefone', d: 'Toca e alguém responde' },
  { p: '🧩 Qual é a coisa que todo mundo joga fora mas ninguém quer pegar?', r: 'doença', d: 'Ou resfriado' },
  { p: '🧩 O que se quebra sem ser tocado?', r: 'silêncio', d: 'Basta falar' },
  { p: '🧩 Ando sempre na frente de você mas não posso ser tocada. O que sou?', r: 'sombra', d: 'Segue seu movimento' },
  { p: '🧩 O que tem pescoço mas não tem cabeça?', r: 'garrafa', d: 'Objeto para bebidas' },
  { p: '🧩 Fala com todo mundo mas não tem língua. Escreve para todo mundo mas não tem mãos. O que é?', r: 'jornal', d: 'Comunicação escrita' },
  { p: '🧩 O que é que tem quatro patas de manhã, duas ao meio-dia e três à tarde?', r: 'homem', d: 'Bebê, adulto, idoso com bengala' },
  { p: '🧩 Quanto maior é, menos pesa. O que é?', r: 'sombra', d: 'Ou buraco' },
  { p: '🧩 O que a gente usa mas outras pessoas usam mais?', r: 'nome', d: 'Seu nome é mais usado por outros' },
]

// Provérbios para completar
const PROVERBIOS = [
  { p: '📜 Complete: "Água mole em pedra dura, tanto bate até que..."', r: 'fura', d: 'Persistência' },
  { p: '📜 Complete: "Quem não arrisca não..."', r: 'petisca', d: 'Sem risco não há ganho' },
  { p: '📜 Complete: "Em boca fechada não entra..."', r: 'mosca', d: 'Silêncio é sabedoria' },
  { p: '📜 Complete: "Cachorro que late não..."', r: 'morde', d: 'Quem ameaça raramente age' },
  { p: '📜 Complete: "Mais vale tarde do que..."', r: 'nunca', d: 'Melhor com atraso que jamais' },
  { p: '📜 Complete: "De grão em grão a galinha enche o..."', r: 'papo', d: 'Pequenas economias somam' },
  { p: '📜 Complete: "Quem tem boca vai a..."', r: 'roma', d: 'Basta perguntar' },
]

// Emojis para adivinhar
const EMOJI_QUIZ = {
  filme: [
    { e: '🦁👑🌍', r: 'o rei leão', d: 'Animação da Disney' },
    { e: '🧊❄️👸', r: 'frozen', d: 'Elsa e Anna' },
    { e: '🕷️🏙️🦸', r: 'homem aranha', d: 'Peter Parker' },
    { e: '🚢❤️🌊💀', r: 'titanic', d: 'Jack e Rose' },
    { e: '🧙⚡🏰', r: 'harry potter', d: 'Bruxo de Hogwarts' },
    { e: '🦸🔨⚡', r: 'thor', d: 'Deus nórdico' },
    { e: '🐠🌊🔍', r: 'procurando nemo', d: 'Pai procura filho' },
    { e: '🤖🌃❤️', r: 'wall-e', d: 'Robô solitário' },
  ],
  pais: [
    { e: '🇧🇷☕⚽', r: 'brasil', d: 'Café, samba e futebol' },
    { e: '🗼🥐❤️', r: 'france', d: 'Torre Eiffel e croissant' },
    { e: '🍕🏛️🤌', r: 'itália', d: 'Pizza e Roma' },
    { e: '🌸🍣⛩️', r: 'japão', d: 'Sakura e sushi' },
    { e: '🌮🌵🎭', r: 'méxico', d: 'Tacos e mariachi' },
    { e: '🍺⚽🏆', r: 'alemanha', d: 'Cerveja e futebol' },
    { e: '🐨🦘🌞', r: 'austrália', d: 'Koala e canguru' },
    { e: '🎺🌹💃', r: 'espanha', d: 'Flamenco e touros' },
  ],
  animal: [
    { e: '🖤⬜🐾', r: 'zebra', d: 'Listras preto e branco' },
    { e: '🦒🌿🌍', r: 'girafa', d: 'Pescoço longo' },
    { e: '🐘👂🌿', r: 'elefante', d: 'Orelhas grandes' },
    { e: '🐧❄️🐟', r: 'pinguim', d: 'Veste terno' },
    { e: '🦁👑🌾', r: 'leão', d: 'Rei da selva' },
    { e: '🐬🌊😊', r: 'golfinho', d: 'Mamífero marinho inteligente' },
  ],
}

// Palavras para forca (hangman)
const PALAVRAS_FORCA = [
  'abacaxi','borboleta','chocolate','diamante','elefante',
  'fotografia','girassol','hipopótamo','internet','jacaré',
  'kaleidoscópio','lagosta','macarrão','nuvem','oceano',
  'papagaio','quadrado','rinoceronte','saboroso','tartaruga',
  'universidade','vulcão','xilofone','yakisoba','zebra',
  'arlequina','coringa','aventura','misterioso','fantasia',
  'pirâmide','telescópio','microscópio','astronauta','submarino',
]

// ─── Exports ────────────────────────────────────────────────────
module.exports = {
  sessoesQuiz, sessoesHangman, sessoesAdivinha, sessoesFrase,
  carregarScore, salvarScore, adicionarPonto, topScore, zerarScore,
  PERGUNTAS, PERGUNTAS_IDIOMA, CHARADAS, PROVERBIOS, EMOJI_QUIZ, PALAVRAS_FORCA,
}
