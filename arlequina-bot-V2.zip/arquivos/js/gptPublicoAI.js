/*
 Helper pra falar com um "GPT" usando API PÚBLICA/GRATUITA (sem
 precisar de chave própria e sem pagar nada). Usado pelo !gptzap.

 IMPORTANTE: APIs públicas gratuitas desse tipo saem e voltam do ar
 com frequência (não são mantidas pela OpenAI/Google, são projetos
 de terceiros). Se o comando começar a dar erro, troque só a
 constante API_URL abaixo por outra API pública equivalente — o
 resto do código já tenta ler os formatos de resposta mais comuns
 (result/data/message/response/answer) sozinho.
*/
const axios = require('axios')

// 👉 Ponto único pra trocar a API pública caso essa saia do ar.
const API_URL = 'https://api.siputzx.my.id/api/ai/gpt3'

async function perguntarGptPublico(pergunta) {
  try {
    const { data } = await axios.get(API_URL, {
      params: { prompt: pergunta, content: pergunta, text: pergunta, q: pergunta },
      timeout: 30000
    })

    // APIs públicas variam MUITO no formato de resposta — tenta os
    // formatos mais comuns antes de desistir.
    const resposta =
      data?.data?.message ||
      data?.data?.result ||
      data?.data ||
      data?.result ||
      data?.message ||
      data?.response ||
      data?.answer ||
      (typeof data === 'string' ? data : null)

    if (!resposta || typeof resposta !== 'string') {
      return { erro: true, mensagem: 'A API pública não retornou uma resposta válida agora (pode estar fora do ar). Tenta de novo daqui a pouco, ou peça pro dono trocar a API_URL em arquivos/js/gptPublicoAI.js.' }
    }
    return { erro: false, resposta: resposta.trim() }
  } catch (e) {
    console.log('❌ ERRO gptPublicoAI:', e?.response?.status || e?.code || e?.message)
    return { erro: true, mensagem: 'Não consegui acessar a API pública agora (ela pode ter saído do ar). Tenta de novo em instantes ou use !gpt (chave própria).' }
  }
}

module.exports = { perguntarGptPublico }
