/*
  Sistema de tabelas/listas personalizadas por grupo
  (/criartabelagp, /tabelagp, /resetetblgp)
  Armazena em: database/tabelasgp.json
*/
const fs = require('fs')
const PATH = './database/tabelasgp.json'

function carregar() {
  try {
    return fs.existsSync(PATH) ? JSON.parse(fs.readFileSync(PATH, 'utf-8')) : {}
  } catch (e) {
    return {}
  }
}

function salvar(dados) {
  try {
    fs.writeFileSync(PATH, JSON.stringify(dados, null, 2))
  } catch (e) {}
}

function criarTabela(groupJid, titulo, itens, criadoPor) {
  const dados = carregar()
  dados[groupJid] = {
    titulo,
    itens: itens || [],
    criadoPor,
    criadoEm: Date.now()
  }
  salvar(dados)
  return dados[groupJid]
}

function getTabela(groupJid) {
  const dados = carregar()
  return dados[groupJid] || null
}

function resetarTabela(groupJid) {
  const dados = carregar()
  if (dados[groupJid]) {
    delete dados[groupJid]
    salvar(dados)
    return true
  }
  return false
}

module.exports = { criarTabela, getTabela, resetarTabela }
