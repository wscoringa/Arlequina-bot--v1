/*
 Lógica de reenvio do !antidelete. Recebe a mensagem ORIGINAL (já
 achada no cache) e manda de volta pro grupo, avisando quem apagou.
*/
const { downloadContentFromMessage } = require('@whiskeysockets/baileys')

async function baixar(mediaMsg, tipo) {
  const stream = await downloadContentFromMessage(mediaMsg, tipo)
  let buffer = Buffer.from([])
  for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk])
  return buffer
}

async function reenviarMensagemApagada(sock, chatId, quemApagou, mensagemOriginal) {
  const m = mensagemOriginal?.message
  if (!m) return

  const cabecalho = `🗑️ *ANTIDELETE*\n\n@${String(quemApagou).split('@')[0]} apagou uma mensagem:\n`

  try {
    if (m.conversation || m.extendedTextMessage?.text) {
      const texto = m.conversation || m.extendedTextMessage.text
      return await sock.sendMessage(chatId, { text: `${cabecalho}\n${texto}`, mentions: [quemApagou] })
    }

    if (m.imageMessage) {
      const buffer = await baixar(m.imageMessage, 'image')
      return await sock.sendMessage(chatId, { image: buffer, caption: `${cabecalho}${m.imageMessage.caption ? `\n${m.imageMessage.caption}` : ''}`, mentions: [quemApagou] })
    }

    if (m.videoMessage) {
      const buffer = await baixar(m.videoMessage, 'video')
      return await sock.sendMessage(chatId, { video: buffer, caption: `${cabecalho}${m.videoMessage.caption ? `\n${m.videoMessage.caption}` : ''}`, gifPlayback: !!m.videoMessage.gifPlayback, mentions: [quemApagou] })
    }

    if (m.stickerMessage) {
      const buffer = await baixar(m.stickerMessage, 'sticker')
      await sock.sendMessage(chatId, { text: `${cabecalho}${'(figurinha)'}`, mentions: [quemApagou] })
      return await sock.sendMessage(chatId, { sticker: buffer })
    }

    if (m.audioMessage) {
      const buffer = await baixar(m.audioMessage, 'audio')
      await sock.sendMessage(chatId, { text: `${cabecalho}${'(áudio)'}`, mentions: [quemApagou] })
      return await sock.sendMessage(chatId, { audio: buffer, mimetype: m.audioMessage.mimetype || 'audio/ogg; codecs=opus', ptt: !!m.audioMessage.ptt })
    }

    if (m.documentMessage) {
      const buffer = await baixar(m.documentMessage, 'document')
      return await sock.sendMessage(chatId, { document: buffer, mimetype: m.documentMessage.mimetype, fileName: m.documentMessage.fileName || 'arquivo', caption: cabecalho, mentions: [quemApagou] })
    }

    // Outros tipos (localização, contato, enquete etc) — avisa sem conseguir reconstruir
    return await sock.sendMessage(chatId, { text: `${cabecalho}\n_(tipo de mídia não suportado pra reenvio)_`, mentions: [quemApagou] })
  } catch (e) {
    console.log('❌ ERRO (antidelete resend):', e?.message)
  }
}

module.exports = { reenviarMensagemApagada }
