/*
 Banco Arlequina — mini servidor web (só http nativo do Node, sem
 dependências novas) que serve o app HTML e uma API bem simples que lê
 e escreve no MESMO banco de dados dos comandos do WhatsApp
 (database/usuarios.json), então o saldo do app é sempre o saldo real.

 O link é por token: cada jogador tem um `tokenBanco` só dele (gerado
 em garantirContaBanco). Sem o token de ninguém não dá pra ver/mexer
 na conta de outra pessoa.
*/
const http = require('http')
const fs = require('fs')
const path = require('path')
const { carregarUsuarios, salvarUsuarios, getUsuario } = require('./rpgDB.js')
const { TIPOS_CONTA, podeAbrir, garantirContaBanco, lancar, acharPorPixOuNumero, ehVip } = require('./bancoRPG.js')
const donoState = require('./donoState.js')
const { CyanLog, RedLog } = require('./logger.js')
const config = JSON.parse(fs.readFileSync(path.join(__dirname, '../../database/config.json')))

const HTML_PATH = path.join(__dirname, '../webapp/banco.html')

// Estado compartilhado: guarda o link público do banco depois que o
// túnel abre. Como é o mesmo objeto (Node cacheia o require), o
// !banco 8 consegue ler esse link mesmo sendo outro arquivo.
const estadoBanco = { url: '', status: 'iniciando' }

// Abre um túnel público grátis pra quem roda o bot no próprio
// PC/Termux, sem IP público, sem precisar mexer em roteador.
// Tenta primeiro Cloudflare Quick Tunnel (não mostra nenhuma tela de
// aviso, abre direto) e só cai pro localtunnel se o Cloudflare falhar.
async function abrirTunelPublico(porta) {
  try {
    // Aceita o aviso do Cloudflare direto (sem perguntar no terminal
    // e sem imprimir aquele texto de licença) e evita brigar pelo
    // terminal com o pareamento do WhatsApp.
    process.env.UNTUN_ACCEPT_CLOUDFLARE_NOTICE = 'true'
    try {
      const consolaMod = require('consola')
      const consola = consolaMod.consola || consolaMod.default || consolaMod
      if (typeof consola?.mute === 'function') consola.mute()
      else if (typeof consola?.level === 'number') consola.level = -999
    } catch { /* consola não é obrigatório, só silencia se der */ }

    const { startTunnel } = require('untun')
    const tunnel = await startTunnel({ port: porta, acceptCloudflareNotice: true })
    const url = (tunnel.getURL ? tunnel.getURL() : tunnel.url)?.replace(/\/$/, '')
    if (!url) throw new Error('sem URL')
    estadoBanco.url = url
    estadoBanco.status = 'online'
    CyanLog?.(`💜 Banco Arlequina público (Cloudflare, sem aviso) em: ${url}`)
    return
  } catch (e) {
    console.log(`⚠️ Túnel Cloudflare não abriu (${e?.message}). Tentando localtunnel (mostra uma tela de aviso ao abrir)...`)
  }
  try {
    const localtunnel = require('localtunnel')
    const tunnel = await localtunnel({ port: porta })
    estadoBanco.url = tunnel.url
    estadoBanco.status = 'online'
    CyanLog?.(`💜 Banco Arlequina público (localtunnel) em: ${tunnel.url}`)
    tunnel.on('close', () => { estadoBanco.status = 'caiu'; CyanLog?.('⚠️ Túnel do Banco Arlequina caiu, tentando abrir outro...'); setTimeout(() => abrirTunelPublico(porta), 5000) })
    tunnel.on('error', (e) => console.log('⚠️ Túnel do banco deu erro:', e?.message))
  } catch (e) {
    estadoBanco.status = 'erro'
    console.log(`⚠️ Não consegui abrir nenhum link público pro banco (${e?.message}). Rode "npm install" de novo pra garantir que "untun" e "localtunnel" foram instalados.`)
  }
}

function acharUsuarioPorToken(usuarios, token) {
  return Object.keys(usuarios).find(jid => usuarios[jid]?.tokenBanco === token) || null
}

function json(res, status, obj) {
  const body = JSON.stringify(obj)
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' })
  res.end(body)
}

function estadoPublico(jid, u) {
  const t = TIPOS_CONTA[u.tipoConta] || TIPOS_CONTA.digital
  return {
    numero: jid.split('@')[0],
    tipoConta: u.tipoConta,
    tipoNome: t.nome,
    tipoEmoji: t.emoji,
    limitePix: t.limitePix,
    saldo: u.saldo,
    banco: u.banco,
    investimento: u.investimento,
    divida: u.divida,
    pix: u.pix,
    extrato: u.extrato,
    tiposConta: Object.values(TIPOS_CONTA)
  }
}

function lerBody(req) {
  return new Promise((resolve) => {
    let data = ''
    req.on('data', c => { data += c; if (data.length > 1e6) req.destroy() })
    req.on('end', () => { try { resolve(JSON.parse(data || '{}')) } catch { resolve({}) } })
  })
}

function iniciarBancoServer(porta, dominioConfigurado) {
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost')

      // página do app
      if (req.method === 'GET' && url.pathname.startsWith('/banco/')) {
        const token = url.pathname.split('/banco/')[1]
        if (!fs.existsSync(HTML_PATH)) { res.writeHead(404); return res.end('app não encontrado') }
        let html = fs.readFileSync(HTML_PATH, 'utf-8')
        html = html.replace('__TOKEN__', token || '')
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' })
        return res.end(html)
      }

      // estado da conta
      if (req.method === 'GET' && url.pathname === '/api/estado') {
        const usuarios = carregarUsuarios()
        const jid = acharUsuarioPorToken(usuarios, url.searchParams.get('token'))
        if (!jid) return json(res, 401, { erro: 'token inválido' })
        const u = garantirContaBanco(getUsuario(usuarios, jid))
        salvarUsuarios(usuarios)
        return json(res, 200, estadoPublico(jid, u))
      }

      // pix
      if (req.method === 'POST' && url.pathname === '/api/pix') {
        const body = await lerBody(req)
        const usuarios = carregarUsuarios()
        const jid = acharUsuarioPorToken(usuarios, body.token)
        if (!jid) return json(res, 401, { erro: 'token inválido' })
        const u = garantirContaBanco(getUsuario(usuarios, jid))

        const alvoJid = acharPorPixOuNumero(usuarios, body.destino)
        const valor = Math.floor(Number(body.valor))
        if (!alvoJid) return json(res, 400, { erro: 'chave pix ou número não encontrado' })
        if (alvoJid === jid) return json(res, 400, { erro: 'não dá pra fazer pix pra você mesmo' })
        if (!valor || valor <= 0) return json(res, 400, { erro: 'valor inválido' })
        const t = TIPOS_CONTA[u.tipoConta] || TIPOS_CONTA.digital
        if (valor > t.limitePix) return json(res, 400, { erro: `limite de pix da ${t.nome} é ${t.limitePix}` })
        if (u.banco < valor) return json(res, 400, { erro: 'saldo insuficiente no banco' })

        const outro = garantirContaBanco(getUsuario(usuarios, alvoJid))
        const descricao = body.descricao || 'Pix pelo app'
        u.banco -= valor
        outro.banco += valor
        lancar(u, 'pix_enviado', -valor, `Pra @${alvoJid.split('@')[0]} — ${descricao}`)
        lancar(outro, 'pix_recebido', valor, `De @${jid.split('@')[0]} — ${descricao}`)
        salvarUsuarios(usuarios)
        return json(res, 200, estadoPublico(jid, u))
      }

      // depositar (carteira -> banco)
      if (req.method === 'POST' && url.pathname === '/api/depositar') {
        const body = await lerBody(req)
        const usuarios = carregarUsuarios()
        const jid = acharUsuarioPorToken(usuarios, body.token)
        if (!jid) return json(res, 401, { erro: 'token inválido' })
        const u = garantirContaBanco(getUsuario(usuarios, jid))
        const valor = Math.floor(Number(body.valor))
        if (!valor || valor <= 0 || u.saldo < valor) return json(res, 400, { erro: 'valor inválido ou saldo insuficiente na carteira' })
        u.saldo -= valor; u.banco += valor
        lancar(u, 'deposito', valor, 'Depósito pelo app')
        salvarUsuarios(usuarios)
        return json(res, 200, estadoPublico(jid, u))
      }

      // sacar (banco -> carteira)
      if (req.method === 'POST' && url.pathname === '/api/sacar') {
        const body = await lerBody(req)
        const usuarios = carregarUsuarios()
        const jid = acharUsuarioPorToken(usuarios, body.token)
        if (!jid) return json(res, 401, { erro: 'token inválido' })
        const u = garantirContaBanco(getUsuario(usuarios, jid))
        const valor = Math.floor(Number(body.valor))
        if (!valor || valor <= 0 || u.banco < valor) return json(res, 400, { erro: 'valor inválido ou saldo insuficiente no banco' })
        u.banco -= valor; u.saldo += valor
        lancar(u, 'saque', -valor, 'Saque pelo app')
        salvarUsuarios(usuarios)
        return json(res, 200, estadoPublico(jid, u))
      }

      // trocar tipo de conta
      if (req.method === 'POST' && url.pathname === '/api/conta') {
        const body = await lerBody(req)
        const usuarios = carregarUsuarios()
        const jid = acharUsuarioPorToken(usuarios, body.token)
        if (!jid) return json(res, 401, { erro: 'token inválido' })
        const u = garantirContaBanco(getUsuario(usuarios, jid))
        const numero = jid.split('@')[0]
        const isVip = ehVip(numero, config, donoState)
        const check = podeAbrir(body.tipo, u, isVip)
        if (!check.ok) return json(res, 400, { erro: check.motivo })
        u.tipoConta = body.tipo
        salvarUsuarios(usuarios)
        return json(res, 200, estadoPublico(jid, u))
      }

      res.writeHead(404); res.end('não encontrado')
    } catch (e) {
      RedLog?.(`❌ bancoServer: ${e?.message}`) 
      json(res, 500, { erro: 'erro interno' })
    }
  })

  server.on('error', (e) => {
    estadoBanco.status = 'erro'
    if (e.code === 'EADDRINUSE') {
      console.log(`⚠️ Banco Arlequina: a porta ${porta} já está em uso — provavelmente uma cópia antiga do bot ainda tá rodando em outra aba/sessão. Feche TODAS as janelas do Termux/terminal e ligue o bot de novo. (O resto do bot continua funcionando normalmente pelo WhatsApp.)`)
    } else {
      console.log(`⚠️ Banco Arlequina: não consegui abrir a porta ${porta} (${e.message}). O comando !banco continua funcionando normalmente pelo WhatsApp.`)
    }
  })

  server.listen(porta, () => {
    CyanLog?.(`💜 Banco Arlequina (app web) rodando na porta ${porta}`)
    if (dominioConfigurado) {
      estadoBanco.url = dominioConfigurado.replace(/\/$/, '')
      estadoBanco.status = 'online'
    } else {
      abrirTunelPublico(porta)
    }
  })

  return server
}

module.exports = { iniciarBancoServer, estadoBanco }
