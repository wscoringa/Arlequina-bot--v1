// Converte texto de tempo em milissegundos. Aceita formato colado
// ("30m", "1h", "2d", "5segundos") e por extenso ("30 minutos", "1 hora").
// Retorna null se não conseguir entender.

const UNIDADES = {
  s: 's', sec: 's', segundo: 's', segundos: 's',
  m: 'm', min: 'm', minuto: 'm', minutos: 'm',
  h: 'h', hora: 'h', horas: 'h',
  d: 'd', dia: 'd', dias: 'd'
}
const MULTIPLICADOR = { s: 1000, m: 60000, h: 3600000, d: 86400000 }

function normalizarUnidade(txt) {
  const limpo = String(txt || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z]/g, '')
  return UNIDADES[limpo] || null
}

// Aceita um único texto tipo "30m", "1 hora", "5segundos"...
function parseTempo(tempoTexto) {
  if (!tempoTexto) return null
  const match = String(tempoTexto).trim().match(/^(\d+)\s*([a-zçãáéíóúâêô]+)$/i)
  if (!match) return null
  const numero = parseInt(match[1])
  const unidade = normalizarUnidade(match[2])
  if (!unidade || isNaN(numero) || numero <= 0) return null
  return numero * MULTIPLICADOR[unidade]
}

// Varre um array de args (ex: da mensagem digitada) procurando um tempo,
// não importa a posição, nem se veio colado ("5m") ou separado ("5 m",
// "5 minutos"), nem se tem espaço/token vazio sobrando no meio.
function extrairTempo(argsRaw) {
  const args = (argsRaw || []).map(a => (a || '').trim()).filter(Boolean)

  for (let i = 0; i < args.length; i++) {
    const direto = parseTempo(args[i])
    if (direto) return { tempoMs: direto, tempoTexto: args[i] }

    if (/^\d+$/.test(args[i]) && args[i + 1]) {
      const unidade = normalizarUnidade(args[i + 1])
      if (unidade) {
        const numero = parseInt(args[i])
        return { tempoMs: numero * MULTIPLICADOR[unidade], tempoTexto: `${args[i]} ${args[i + 1]}` }
      }
    }
  }

  return { tempoMs: null, tempoTexto: null }
}

module.exports = { parseTempo, extrairTempo }
