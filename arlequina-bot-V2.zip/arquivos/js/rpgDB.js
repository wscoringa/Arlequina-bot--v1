/*
  RPG / Economia - banco de dados compartilhado
  Arlequina Bot - coringa</>
*/
const fs = require('fs')

const dbPath = './database/usuarios.json'
const clanPath = './database/clans.json'
const missaoPath = './database/missoes_ativas.json'

function carregarJSON(p, def = {}) {
  if (!fs.existsSync('./database')) fs.mkdirSync('./database', { recursive: true })
  if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify(def, null, 2))
  try { return JSON.parse(fs.readFileSync(p, 'utf-8')) } catch { return def }
}

function salvarJSON(p, dados) {
  try { fs.writeFileSync(p, JSON.stringify(dados, null, 2)) } catch {}
}

function carregarUsuarios() { return carregarJSON(dbPath) }
function salvarUsuarios(u) { salvarJSON(dbPath, u) }
function carregarClans() { return carregarJSON(clanPath) }
function salvarClans(c) { salvarJSON(clanPath, c) }
function carregarMissoes() { return carregarJSON(missaoPath) }
function salvarMissoes(m) { salvarJSON(missaoPath, m) }

function getUsuario(usuarios, sender) {
  if (!usuarios[sender]) {
    usuarios[sender] = {
      // Economia
      saldo: 0, banco: 0, nomeBanco: null, pix: null,
      // RPG base
      xp: 0, level: 1, classe: '⚔️ Aventureiro',
      vida: 100, vidaMax: 100,
      mana: 50,  manaMax: 50,
      stamina: 100, staminaMax: 100,
      forca: 10, defesa: 10, agilidade: 10, sorte: 10,
      ouro: 0,
      // Progresso
      vitorias: 0, derrotas: 0, bosses: 0,
      // Inventário / equipamentos
      inventario: [],
      equipamento: { arma: null, armadura: null, acessorio: null },
      // Clan
      clan: null,
      // Pet
      pet: null,
      // Missão ativa
      missaoAtiva: null,
      // Batalha ativa
      batalhaAtiva: null,
      // Dungeon / exploração
      exploracoes: 0,
      // Pokémon capturados + histórico de batalhas
      pokemons: [],
      pokemonBatalhas: { vitorias: 0, derrotas: 0 },
      // Inventário de pokébolas — todo mundo começa com 5 comuns de graça
      pokebolas: { comum: 5, super: 0, ultra: 0, premier: 0, timer: 0, luxury: 0, beast: 0, mestra: 0 },
      // Itens de Pokémon: poções, revives, pedras de evolução
      pokeItens: {},
      // Arena de Pokémon (3v3): desafio pendente e batalha ativa
      desafioArenaPokemon: null,
      arenaPokemon: null,
    }
  }
  // Preenche campos novos para usuários antigos
  const u = usuarios[sender]
  if (u.vidaMax === undefined) u.vidaMax = 100
  if (u.vida === undefined) u.vida = 100
  if (u.mana === undefined) u.mana = 50
  if (u.manaMax === undefined) u.manaMax = 50
  if (u.stamina === undefined) u.stamina = 100
  if (u.staminaMax === undefined) u.staminaMax = 100
  if (u.forca === undefined) u.forca = 10
  if (u.defesa === undefined) u.defesa = 10
  if (u.agilidade === undefined) u.agilidade = 10
  if (u.sorte === undefined) u.sorte = 10
  if (u.ouro === undefined) u.ouro = u.saldo || 0
  if (u.saldo === undefined || u.saldo === null || isNaN(u.saldo)) u.saldo = 0
  if (u.banco === undefined || u.banco === null || isNaN(u.banco)) u.banco = 0

  // BUGFIX GRANDE: o sistema tinha DUAS moedas desconectadas — "saldo"
  // (usado pela loja, banco, daily, trabalhos) e "ouro" (usado por
  // aventura/combate: atacar, dungeon, explorar, criarclan, etc). Quem
  // ganhava dinheiro aventurando não conseguia gastar na loja, e
  // vice-versa. Aqui unifica as duas em UMA SÓ (soma o que cada um já
  // tinha, uma única vez, pra ninguém perder nada), e depois transforma
  // "ouro" num espelho ao vivo de "saldo" — qualquer código antigo que
  // leia/escreva em ".ouro" passa a mexer automaticamente no mesmo
  // dinheiro de ".saldo", sem precisar editar dezenas de arquivos.
  if (!u._moedaUnificada) {
    u.saldo = (Number(u.saldo) || 0) + (Number(u.ouro) || 0)
    u._moedaUnificada = true
  }
  delete u.ouro
  Object.defineProperty(u, 'ouro', {
    get() { return u.saldo },
    set(v) { u.saldo = v },
    enumerable: true,
    configurable: true
  })

  if (u.classe === undefined) u.classe = '⚔️ Aventureiro'
  if (u.inventario === undefined) u.inventario = []
  if (u.equipamento === undefined) u.equipamento = { arma: null, armadura: null, acessorio: null }
  if (u.clan === undefined) u.clan = null
  if (u.missaoAtiva === undefined) u.missaoAtiva = null
  if (u.batalhaAtiva === undefined) u.batalhaAtiva = null
  if (u.exploracoes === undefined) u.exploracoes = 0
  if (u.pokemons === undefined) u.pokemons = []
  if (u.pokemonBatalhas === undefined) u.pokemonBatalhas = { vitorias: 0, derrotas: 0 }
  if (u.pokebolas === undefined) u.pokebolas = { comum: 5, super: 0, ultra: 0, premier: 0, timer: 0, luxury: 0, beast: 0, mestra: 0 }
  // garante chaves novas em quem já tinha conta
  for (const k of ['comum','super','ultra','premier','timer','luxury','beast','mestra']) {
    if (u.pokebolas[k] === undefined) u.pokebolas[k] = 0
  }
  if (u.pokeItens === undefined) u.pokeItens = {}
  if (u.desafioArenaPokemon === undefined) u.desafioArenaPokemon = null
  if (u.arenaPokemon === undefined) u.arenaPokemon = null
  if (u.ultimaDailyPokemon === undefined) u.ultimaDailyPokemon = 0
  if (u.ultimoBossPokemon === undefined) u.ultimoBossPokemon = 0
  if (u.pokemonBossesDerrotados === undefined) u.pokemonBossesDerrotados = 0
  if (u.bosses === undefined) u.bosses = 0
  if (u.vitorias === undefined) u.vitorias = 0
  if (u.derrotas === undefined) u.derrotas = 0
  return u
}

// Verifica e sobe de level
function verificarLevel(u) {
  const xpNecessario = u.level * 500
  if (u.xp >= xpNecessario) {
    u.level++
    u.xp -= xpNecessario
    u.vidaMax += 20; u.vida = u.vidaMax
    u.manaMax += 10; u.mana = u.manaMax
    u.staminaMax += 10; u.stamina = u.staminaMax
    u.forca += 3; u.defesa += 2; u.agilidade += 2; u.sorte += 1
    return true
  }
  return false
}

// Itens da loja
const ITENS_LOJA = [
  { id: 'espada',      nome: '⚔️ Espada de Ferro',       preco: 500,   tipo: 'arma',       bonus: { forca: 5 } },
  { id: 'espada2',     nome: '🗡️ Espada de Aço',          preco: 1500,  tipo: 'arma',       bonus: { forca: 12 } },
  { id: 'arco',        nome: '🏹 Arco Longo',             preco: 800,   tipo: 'arma',       bonus: { agilidade: 8 } },
  { id: 'cajado',      nome: '🪄 Cajado Mágico',          preco: 1000,  tipo: 'arma',       bonus: { manaMax: 30 } },
  { id: 'machado',     nome: '🪓 Machado de Guerra',      preco: 1800,  tipo: 'arma',       bonus: { forca: 15 } },
  { id: 'lanca',       nome: '🔱 Lança Élfica',           preco: 2200,  tipo: 'arma',       bonus: { forca: 10, agilidade: 6 } },
  { id: 'grimorio',    nome: '📖 Grimório Ancestral',     preco: 3500,  tipo: 'arma',       bonus: { manaMax: 80 } },
  { id: 'excalibur',   nome: '👑 Excalibur',              preco: 6000,  tipo: 'arma',       bonus: { forca: 40 } },
  { id: 'escudo',      nome: '🛡️ Escudo de Madeira',      preco: 400,   tipo: 'armadura',   bonus: { defesa: 5 } },
  { id: 'armadura',    nome: '🧥 Armadura de Couro',      preco: 900,   tipo: 'armadura',   bonus: { defesa: 10 } },
  { id: 'armadura2',   nome: '🛡️ Armadura de Aço',       preco: 2500,  tipo: 'armadura',   bonus: { defesa: 20 } },
  { id: 'elmo',        nome: '⛑️ Elmo de Batalha',        preco: 1300,  tipo: 'armadura',   bonus: { defesa: 12 } },
  { id: 'armaduraouro',nome: '🏅 Armadura Dourada',       preco: 4500,  tipo: 'armadura',   bonus: { defesa: 35 } },
  { id: 'pocao',       nome: '🧪 Poção de Vida',          preco: 150,   tipo: 'consumivel', efeito: { vida: 50 } },
  { id: 'pocaomana',   nome: '💧 Poção de Mana',          preco: 200,   tipo: 'consumivel', efeito: { mana: 40 } },
  { id: 'pocaomega',   nome: '🧬 Poção Mega Cura',        preco: 350,   tipo: 'consumivel', efeito: { vida: 120 } },
  { id: 'pocaoforte',  nome: '⚗️ Elixir Supremo',        preco: 800,   tipo: 'consumivel', efeito: { vida: 200, mana: 100 } },
  { id: 'amuleto',     nome: '📿 Amuleto da Sorte',       preco: 1200,  tipo: 'acessorio',  bonus: { sorte: 15 } },
  { id: 'bota',        nome: '👢 Botas Ágeis',            preco: 700,   tipo: 'acessorio',  bonus: { agilidade: 10 } },
  { id: 'anel',        nome: '💍 Anel do Poder',          preco: 3000,  tipo: 'acessorio',  bonus: { forca: 8, sorte: 8 } },
  { id: 'capa',        nome: '🧣 Capa da Invisibilidade', preco: 2600,  tipo: 'acessorio',  bonus: { agilidade: 20 } },
  { id: 'coroa',       nome: '👑 Coroa Real',             preco: 10000, tipo: 'acessorio',  bonus: { sorte: 30, forca: 10, defesa: 10 } },
  { id: 'adaga',       nome: '🔪 Adaga Envenenada',       preco: 1600,  tipo: 'arma',       bonus: { agilidade: 14 } },
  { id: 'martelo',     nome: '🔨 Martelo Colossal',       preco: 5000,  tipo: 'arma',       bonus: { forca: 30, agilidade: -5 } },
  { id: 'armaduramitica', nome: '🌟 Armadura Mítica',     preco: 8000,  tipo: 'armadura',   bonus: { defesa: 50 } },
  { id: 'pocaotitanica', nome: '🩸 Poção Titânica',       preco: 1500,  tipo: 'consumivel', efeito: { vida: 400, mana: 200 } },
  { id: 'brincoenergia', nome: '💎 Brinco de Energia',    preco: 2000,  tipo: 'acessorio',  bonus: { manaMax: 60 } },
]

// Missões disponíveis
const MISSOES = [
  { id: 'goblin',   nome: '👺 Caçar Goblins',          dificuldade: 'Fácil',  xp: 200,  ouro: 300,  tempo: 5  },
  { id: 'lobo',     nome: '🐺 Eliminar Lobos',          dificuldade: 'Fácil',  xp: 250,  ouro: 400,  tempo: 5  },
  { id: 'ratos',    nome: '🐀 Exterminar Ratazanas',    dificuldade: 'Fácil',  xp: 180,  ouro: 250,  tempo: 4  },
  { id: 'ladrao',   nome: '🥷 Capturar Ladrão',         dificuldade: 'Fácil',  xp: 220,  ouro: 350,  tempo: 5  },
  { id: 'bandit',   nome: '🗡️ Derrotar Bandidos',      dificuldade: 'Médio',  xp: 500,  ouro: 800,  tempo: 10 },
  { id: 'dungeon',  nome: '🏰 Explorar Dungeon',        dificuldade: 'Médio',  xp: 700,  ouro: 1200, tempo: 15 },
  { id: 'orc',      nome: '👹 Invasão de Orcs',         dificuldade: 'Médio',  xp: 650,  ouro: 1000, tempo: 12 },
  { id: 'necro',    nome: '💀 Deter o Necromante',      dificuldade: 'Médio',  xp: 800,  ouro: 1400, tempo: 18 },
  { id: 'dragon',   nome: '🐉 Enfrentar Dragão',        dificuldade: 'Difícil',xp: 2000, ouro: 5000, tempo: 30 },
  { id: 'demonio',  nome: '😈 Eliminar Demônio',        dificuldade: 'Difícil',xp: 2500, ouro: 7000, tempo: 30 },
  { id: 'hidra',    nome: '🐍 Abater a Hidra',          dificuldade: 'Difícil',xp: 2200, ouro: 5500, tempo: 25 },
  { id: 'lich',     nome: '☠️ Destruir o Lich',         dificuldade: 'Difícil',xp: 2800, ouro: 7500, tempo: 35 },
  { id: 'raid',     nome: '⚔️ Raid de Fortaleza',       dificuldade: 'Épico',  xp: 5000, ouro: 15000,tempo: 60 },
  { id: 'titan',    nome: '🗿 Derrubar o Titã',         dificuldade: 'Épico',  xp: 6000, ouro: 18000,tempo: 70 },
  { id: 'deus',     nome: '⚡ Desafiar um Deus Menor',  dificuldade: 'Épico',  xp: 8000, ouro: 25000,tempo: 90 },
]

module.exports = {
  carregarUsuarios, salvarUsuarios, getUsuario, dbPath,
  carregarClans, salvarClans,
  carregarMissoes, salvarMissoes,
  verificarLevel, ITENS_LOJA, MISSOES
}
