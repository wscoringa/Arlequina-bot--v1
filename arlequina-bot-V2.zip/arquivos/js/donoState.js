/*
 Estado em memoria compartilhado pelos plugins da categoria "dono",
 convertidos a partir do connect.js (bot antigo, monolitico).

 Agora com persistência em arquivo (./database/donoState.json), pra não
 perder aluguel/modobn/etc toda vez que o bot reiniciar (o chokidar
 reinicia o bot sozinho quando algum plugin muda).
*/
const fs = require('fs')
const path = require('path')

const ARQUIVO = path.join(__dirname, '../../database/donoState.json')

const estadoPadrao = {
botStatus: { ligado: true, modoWhitelist: false, grupoOn: {}, manutencao: false, privadoOn: false, brincadeiraGrupos: {}, rpgGrupos: {}, eventorpgAutoOff: {}, gruposBanidos: {}, soDonoGrupos: {}, soAdmGrupos: {}, autoStickerGrupos: {}, modoVisualGrupos: {}, modoVisualGlobal: false },
banidosGlobal: {},
gruposPermitidos: [],
ignorados: {},
monitores: {},
vips: {},
ativos: {},
donosExtras: { "1": null, "2": null, "3": null, "4": null, "5": null },
mensagens: {},
aluguel: { grupos: {}, modoGlobalDesativado: false },
afk: {},
avisos: {},
avisosMaximo: {},
historicoMod: {},
palavroesProibidos: {},
comandosRestritos: {},
advertencias: {},
comandosDesativados: [],
logsComandos: [],
canalBot: null,
menuBotoesOn: true,
modo18Grupos: {},
menuGifPlayback: false
}

let estado = estadoPadrao

try {
if (fs.existsSync(ARQUIVO)) {
const salvo = JSON.parse(fs.readFileSync(ARQUIVO, 'utf8'))
estado = { ...estadoPadrao, ...salvo }
estado.botStatus = { ...estadoPadrao.botStatus, ...(salvo.botStatus || {}) }
estado.aluguel = { ...estadoPadrao.aluguel, ...(salvo.aluguel || {}), grupos: { ...(salvo.aluguel?.grupos || {}) } }
// donosExtras mudou de array pra objeto com 5 slots fixos ("1" a "5") — se
// tiver salvo no formato antigo (array) ou não existir, usa o padrão novo.
estado.donosExtras = (salvo.donosExtras && !Array.isArray(salvo.donosExtras))
  ? { ...estadoPadrao.donosExtras, ...salvo.donosExtras }
  : { ...estadoPadrao.donosExtras }
}
} catch (e) {
console.log('⚠️ Não consegui carregar donoState.json, usando padrão:', e?.message)
}

function salvar() {
try {
if (!fs.existsSync(path.dirname(ARQUIVO))) fs.mkdirSync(path.dirname(ARQUIVO), { recursive: true })
fs.writeFileSync(ARQUIVO, JSON.stringify(estado, null, 2))
} catch (e) {
console.log('⚠️ Não consegui salvar donoState.json:', e?.message)
}
}

// Autosave: pega qualquer mudança feita pelos comandos (mesmo sem
// chamar salvar() manualmente) e grava no disco a cada 5s.
setInterval(salvar, 5000).unref()
process.on('exit', salvar)
process.on('SIGINT', () => { salvar(); process.exit() })
process.on('SIGTERM', () => { salvar(); process.exit() })

estado.salvar = salvar

module.exports = estado
