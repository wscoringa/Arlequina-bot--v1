/*
 BUGFIX SEGURANÇA: uma parte interna da lib do WhatsApp (Baileys/
 libsignal) tem um "console.log" direto no código dela pra avisar
 quando fecha uma sessão de criptografia — e esse log NÃO respeita o
 nível do logger configurado (o bot já usa logger 'silent', mas isso
 não adianta pra esse log específico porque ele não passa pelo
 logger, é um console.log cru). O problema é que esse log despeja
 CHAVES PRIVADAS de criptografia (privKey, chainKey, etc.) direto no
 terminal/arquivo de log do servidor.

 Esse arquivo intercepta TODO console.log/console.error do processo
 e bloqueia qualquer linha que pareça ser esse despejo de sessão,
 sem mexer no restante dos logs normais do bot.

 Precisa ser importado ANTES de qualquer coisa que crie a conexão com
 o WhatsApp (Baileys), pra já estar ativo quando a lib tentar logar.
*/
const util = require('util')

const PADRAO_SENSIVEL = /Closing session:\s*SessionEntry|remoteIdentityKey|pendingPreKey|ephemeralKeyPair|currentRatchet|_chains:/i

function filtrar(metodoOriginal) {
  return (...args) => {
    try {
      const texto = args
        .map(a => (typeof a === 'string' ? a : util.inspect(a, { depth: 4 })))
        .join(' ')
      if (PADRAO_SENSIVEL.test(texto)) return
    } catch (e) {
      // se o filtro falhar por algum motivo, deixa passar o log normal
      // em vez de travar o bot
    }
    metodoOriginal(...args)
  }
}

console.log = filtrar(console.log.bind(console))
console.error = filtrar(console.error.bind(console))
console.warn = filtrar(console.warn.bind(console))
