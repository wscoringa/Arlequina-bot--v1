/**
 * Envia um mini-jogo HTML no mesmo envelope do !piano / !sinuca
 */
async function enviarJogoHtml(columbina, from, { id, titulo, texto, html }) {
  await columbina.relayMessage(
    from,
    {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2
      },
      botForwardedMessage: {
        message: {
          richResponseMessage: {
            messageType: 1,
            submessages: [
              {
                messageType: 2,
                messageText: String(titulo || 'JOGO').toUpperCase()
              }
            ],
            unifiedResponse: {
              data: Buffer.from(JSON.stringify({
                response_id: id || 'jogo-html',
                sections: [
                  {
                    view_model: {
                      primitive: {
                        text: texto || `> ${titulo}</>`,
                        __typename: 'GenAIMarkdownTextUXPrimitive'
                      },
                      __typename: 'GenAISingleLayoutViewModel'
                    }
                  }
                ],
                embedded_screens: [
                  {
                    title: String(titulo || 'JOGO').toUpperCase(),
                    content: [
                      {
                        __typename: 'FOAIDNixelButtonSheets',
                        tabs: [
                          {
                            id: 'tab_0',
                            tab_header: titulo || 'Jogo',
                            sections: [
                              {
                                __typename: 'GenAIUnifiedResponseSection',
                                view_model: {
                                  __typename: 'GenAISingleLayoutViewModel',
                                  primitive: {
                                    __typename: 'GenAIaeacdsnwHtmlPrimitive',
                                    payload: html,
                                    trusted_sources: ['columbina-apis.onrender.com']
                                  }
                                }
                              }
                            ]
                          }
                        ]
                      }
                    ]
                  }
                ]
              })).toString('base64')
            },
            contextInfo: {
              forwardingScore: 1,
              isForwarded: true,
              forwardedAiBotMessageInfo: {
                botJid: '867051314767696@bot'
              },
              forwardOrigin: 4
            }
          }
        }
      }
    },
    {}
  )
}

module.exports = { enviarJogoHtml }
