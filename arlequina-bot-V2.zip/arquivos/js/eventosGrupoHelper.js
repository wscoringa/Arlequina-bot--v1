/*
  Ajudantes para os eventos de grupo (entrada / saída / remoção).

  PROBLEMA QUE ISSO RESOLVE
  O WhatsApp identifica a mesma pessoa de dois jeitos: o número normal
  (5511999999999@s.whatsapp.net) e o "LID" (139801722376211@lid). No evento
  de saída, o participante vem com o número e o "author" (quem fez a ação)
  às vezes vem como LID. Comparar só os dígitos fazia a mesma pessoa parecer
  duas — e quem SAIU sozinho aparecia como "removido por ele mesmo".

  Aqui a comparação considera todos os formatos (número, LID, sufixo de
  dispositivo) e usa o mapa LID<->número do próprio Baileys.

  FOTO DO PERFIL
  Busca a foto de perfil da pessoa e guarda uma cópia em disco. Na saída o
  WhatsApp muitas vezes já não entrega mais a foto — nesse caso usa a cópia
  guardada quando a pessoa entrou.
*/
const fs = require('fs')
const path = require('path')
const { resolverJidReal } = require('./lidHelper.js')

const FOTOS_DIR = './midias/fotos_perfil'
const MAX_FOTOS_CACHE = 400

const numeroPuro = (jid) => String(jid || '').split('@')[0].split(':')[0]

// devolve todos os "ids" que um item pode ter (string ou objeto de participante)
function idsBrutos(x) {
  if (!x) return []
  if (typeof x === 'string') return [x]
  if (typeof x !== 'object') return []
  return [x.phoneNumber, x.id, x.jid, x.lid, x.pn].filter((v) => typeof v === 'string' && v)
}

// todos os números (telefone e LID) que identificam essa pessoa
async function numerosDaPessoa(sock, itens) {
  const numeros = new Set()
  for (const item of [].concat(itens || [])) {
    for (const id of idsBrutos(item)) {
      numeros.add(numeroPuro(id))
      try {
        const real = await resolverJidReal(sock, id)
        if (real) numeros.add(numeroPuro(real))
      } catch {}
      try {
        if (/@s\.whatsapp\.net$/.test(id) && sock?.signalRepository?.lidMapping?.getLIDForPN) {
          const lid = await sock.signalRepository.lidMapping.getLIDForPN(id)
          if (lid) numeros.add(numeroPuro(lid))
        }
      } catch {}
    }
  }
  numeros.delete('')
  return numeros
}

// true se a e b são a mesma pessoa (em qualquer formato de id)
async function mesmaPessoa(sock, a, b) {
  const A = await numerosDaPessoa(sock, a)
  const B = await numerosDaPessoa(sock, b)
  for (const n of A) if (B.has(n)) return true
  return false
}

// jid do ADM que fez a ação, preferindo o formato de número (menção aparece certinha)
async function jidDoAutor(sock, author, authorPn) {
  if (authorPn) return authorPn
  if (!author) return null
  try {
    return (await resolverJidReal(sock, author)) || author
  } catch {
    return author
  }
}

// ---------- foto de perfil ----------
const arqFoto = (numero) => path.join(FOTOS_DIR, `${numero}.jpg`)

function limparCacheFotos() {
  try {
    const arquivos = fs
      .readdirSync(FOTOS_DIR)
      .map((f) => ({ f, t: fs.statSync(path.join(FOTOS_DIR, f)).mtimeMs }))
      .sort((a, b) => b.t - a.t)
    arquivos.slice(MAX_FOTOS_CACHE).forEach((a) => fs.rmSync(path.join(FOTOS_DIR, a.f), { force: true }))
  } catch {}
}

function salvarNoCache(numeros, buffer) {
  try {
    if (!fs.existsSync(FOTOS_DIR)) fs.mkdirSync(FOTOS_DIR, { recursive: true })
    for (const n of numeros) fs.writeFileSync(arqFoto(n), buffer)
    limparCacheFotos()
  } catch {}
}

const comTimeout = (promessa, ms) =>
  Promise.race([promessa, new Promise((ok) => setTimeout(() => ok(null), ms))])

async function baixarBuffer(url) {
  const axios = require('axios')
  const r = await axios.get(url, { responseType: 'arraybuffer', timeout: 10000, maxContentLength: 8 * 1024 * 1024 })
  return Buffer.from(r.data)
}

/*
  Devolve { buffer } ou { url } com a foto de perfil da pessoa, ou null se não
  achar nenhuma. `itens` = participante(s) (string, objeto ou lista).
*/
async function obterImagemPerfil(sock, itens) {
  const ids = []
  for (const it of [].concat(itens || [])) for (const id of idsBrutos(it)) if (!ids.includes(id)) ids.push(id)
  // o jid de telefone costuma funcionar melhor que o LID
  ids.sort((a, b) => Number(b.endsWith('@s.whatsapp.net')) - Number(a.endsWith('@s.whatsapp.net')))
  const numeros = [...(await numerosDaPessoa(sock, itens))]

  // 1) foto atual do perfil
  if (sock && typeof sock.profilePictureUrl === 'function') {
    for (const id of ids) {
      for (const tipo of ['image', 'preview']) {
        try {
          const url = await comTimeout(sock.profilePictureUrl(id, tipo), 8000)
          if (!url) continue
          let buffer = null
          try {
            buffer = await baixarBuffer(url)
          } catch {}
          if (buffer && buffer.length > 500) {
            salvarNoCache(numeros, buffer)
            return { buffer }
          }
          return { url }
        } catch {}
      }
    }
  }

  // 2) cópia guardada quando a pessoa entrou (na saída o WhatsApp já não entrega a foto)
  for (const n of numeros) {
    const arq = arqFoto(n)
    try {
      if (fs.existsSync(arq)) return { buffer: fs.readFileSync(arq) }
    } catch {}
  }
  return null
}

module.exports = {
  FOTOS_DIR,
  numeroPuro,
  idsBrutos,
  numerosDaPessoa,
  mesmaPessoa,
  jidDoAutor,
  obterImagemPerfil,
}
