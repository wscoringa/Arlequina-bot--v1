/*
 Sistema de parceiros: pessoas cadastradas aqui podem mandar link de
 grupo/canal sem cair no !antilink, até um limite configurável por
 grupo (padrão: ilimitado, se não for setado).

 Diferente do adminState.js (que é só em memória e reseta a cada
 reinício do bot), esse arquivo persiste em disco de verdade — igual
 o donoState.js — porque uma lista de parceiros é uma decisão duradoura
 do admin, não faria sentido sumir sozinha.
*/
const fs = require('fs')
const path = require('path')

const ARQUIVO = path.join(__dirname, '../../database/parceiros.json')

// dados[groupId] = { parceiros: { [numero]: { adicionadoPor, quando, linksUsados } }, limiteLink: null }
let dados = {}

try {
  if (fs.existsSync(ARQUIVO)) {
    dados = JSON.parse(fs.readFileSync(ARQUIVO, 'utf8'))
  }
} catch (e) {
  console.log('⚠️ Não consegui carregar parceiros.json, começando vazio:', e?.message)
}

function salvar() {
  try {
    if (!fs.existsSync(path.dirname(ARQUIVO))) fs.mkdirSync(path.dirname(ARQUIVO), { recursive: true })
    fs.writeFileSync(ARQUIVO, JSON.stringify(dados, null, 2))
  } catch (e) {
    console.log('⚠️ Não consegui salvar parceiros.json:', e?.message)
  }
}

function grupo(groupId) {
  if (!dados[groupId]) dados[groupId] = { parceiros: {}, limiteLink: null }
  if (!dados[groupId].parceiros) dados[groupId].parceiros = {}
  return dados[groupId]
}

function normalizarNumero(jidOuNumero) {
  return String(jidOuNumero || '').split('@')[0].replace(/[^0-9]/g, '')
}

function addParceiro(groupId, jidOuNumero, adicionadoPor) {
  const numero = normalizarNumero(jidOuNumero)
  if (!numero) return false
  const g = grupo(groupId)
  g.parceiros[numero] = { adicionadoPor: normalizarNumero(adicionadoPor), quando: Date.now(), linksUsados: 0 }
  salvar()
  return true
}

function delParceiro(groupId, jidOuNumero) {
  const numero = normalizarNumero(jidOuNumero)
  const g = grupo(groupId)
  if (!g.parceiros[numero]) return false
  delete g.parceiros[numero]
  salvar()
  return true
}

function listarParceiros(groupId) {
  const g = grupo(groupId)
  return Object.entries(g.parceiros).map(([numero, info]) => ({ numero, ...info }))
}

function ehParceiro(groupId, jidOuNumero) {
  const numero = normalizarNumero(jidOuNumero)
  const g = grupo(groupId)
  return !!g.parceiros[numero]
}

function setLimiteLink(groupId, limite) {
  const g = grupo(groupId)
  g.limiteLink = (limite === null || limite === undefined) ? null : Math.max(0, parseInt(limite) || 0)
  salvar()
}

function getLimiteLink(groupId) {
  return grupo(groupId).limiteLink
}

// Verifica se o parceiro AINDA pode mandar link (dentro da cota). Se
// puder, já soma +1 no contador dele (uso único, chama só quando for
// de fato deixar o link passar).
function consumirCotaLink(groupId, jidOuNumero) {
  const numero = normalizarNumero(jidOuNumero)
  const g = grupo(groupId)
  const p = g.parceiros[numero]
  if (!p) return false // não é parceiro

  const limite = g.limiteLink
  if (limite === null || limite === undefined) {
    // sem limite configurado = parceiro pode mandar link sempre, sem restrição
    p.linksUsados = (p.linksUsados || 0) + 1
    salvar()
    return true
  }
  if ((p.linksUsados || 0) < limite) {
    p.linksUsados = (p.linksUsados || 0) + 1
    salvar()
    return true
  }
  return false // cota esgotada, cai no antilink normal
}

function resetarCotas(groupId) {
  const g = grupo(groupId)
  for (const numero in g.parceiros) g.parceiros[numero].linksUsados = 0
  salvar()
}

module.exports = {
  addParceiro, delParceiro, listarParceiros, ehParceiro,
  setLimiteLink, getLimiteLink, consumirCotaLink, resetarCotas, normalizarNumero
}
