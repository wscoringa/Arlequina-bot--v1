/*
 Sistema de Log de Atividades do Grupo (x9grupo).

 Guarda, por grupo, se o "modo x9" está ligado. Quando ligado, a Arlequina
 anuncia no próprio grupo qualquer ação de moderação feita por um ADM
 (ban/kick, promoção, rebaixamento, entrada aprovada/adicionada), incluindo
 quando é feita direto pelo WhatsApp (fora dos comandos da bot).

 Também guarda "marcas" temporárias pra evitar mensagem duplicada quando a
 própria ação já foi anunciada por um comando da bot (ex: #ban já avisa
 quem foi removido, então o listener global não precisa avisar de novo).
*/
const fs = require('fs')
const path = require('path')

const ARQUIVO = path.join(__dirname, '../../database/modlog.json')

let estado = { grupos: {} }

try {
  if (fs.existsSync(ARQUIVO)) {
    const salvo = JSON.parse(fs.readFileSync(ARQUIVO, 'utf8'))
    estado = { grupos: salvo.grupos || {} }
  }
} catch (e) {
  console.log('⚠️ Não consegui carregar modlog.json, usando padrão:', e?.message)
}

function salvar() {
  try {
    if (!fs.existsSync(path.dirname(ARQUIVO))) fs.mkdirSync(path.dirname(ARQUIVO), { recursive: true })
    fs.writeFileSync(ARQUIVO, JSON.stringify(estado, null, 2))
  } catch (e) {
    console.log('⚠️ Não consegui salvar modlog.json:', e?.message)
  }
}

function isAtivo(groupId) {
  return !!estado.grupos[groupId]
}

function setAtivo(groupId, valor) {
  estado.grupos[groupId] = !!valor
  salvar()
}

/* ---- Marcas de deduplicação (evita anúncio duplicado quando um comando
   da própria Arlequina já avisou o grupo sobre a ação) ---- */
const marcas = new Map()
const TEMPO_MARCA_MS = 8000

function chave(groupId, jid, action) {
  return `${groupId}|${jid}|${action}`
}

function marcarAcaoBot(groupId, jid, action) {
  const k = chave(groupId, jid, action)
  marcas.set(k, Date.now())
  setTimeout(() => marcas.delete(k), TEMPO_MARCA_MS + 1000).unref?.()
}

function foiAcaoRecenteDoBot(groupId, jid, action) {
  const k = chave(groupId, jid, action)
  const t = marcas.get(k)
  if (!t) return false
  return (Date.now() - t) < TEMPO_MARCA_MS
}

module.exports = { isAtivo, setAtivo, marcarAcaoBot, foiAcaoRecenteDoBot }
