/*
 Formata quanto tempo se passou (em ms) num texto tipo "2h 15min" ou
 "35 minutos" ou "40 segundos" — usado pelo sistema de AFK.
*/
function formatarDuracao(ms) {
  const segundos = Math.floor(ms / 1000)
  const minutos = Math.floor(segundos / 60)
  const horas = Math.floor(minutos / 60)
  const dias = Math.floor(horas / 24)

  if (dias > 0) return `${dias} dia(s) e ${horas % 24}h`
  if (horas > 0) return `${horas}h ${minutos % 60}min`
  if (minutos > 0) return `${minutos} minuto(s)`
  return `${segundos} segundo(s)`
}

module.exports = { formatarDuracao }
