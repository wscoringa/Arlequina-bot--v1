/*
 Helper compartilhado pelos comandos "!perfil*" (perfilzoeira, perfilgamer,
 perfilrico, perfildark, perfilgenio...). Pega a foto de perfil de quem
 foi marcado e monta uma cartela com traços aleatórios sorteados.
*/
const axios = require('axios')

async function pegarFotoPerfil(sock, jid) {
  try {
    const url = await sock.profilePictureUrl(jid, 'image')
    const { data } = await axios.get(url, { responseType: 'arraybuffer', timeout: 15000 })
    return Buffer.from(data)
  } catch {
    return null
  }
}

function sortear(lista) {
  return lista[Math.floor(Math.random() * lista.length)]
}

// Cria um comando "!perfilX" — precisa marcar alguém, monta a cartela
// com os campos sorteados de "traços" e manda com a foto de perfil dela.
function criarPerfilCard({ name, titulo, emoji, traços, aliases = [] }) {
  return {
    name,
    description: `${emoji} Cartela de perfil "${titulo}" de quem você marcar`,
    category: 'cmds-aleatorios',
    aliases,
    async execute({ arlequina, from, info, reply, reagir, sender, isGroup }) {
      if (!isGroup) return reply('❌ Use em grupos!')
      try {
        const mencionado = info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] ||
          info.message?.extendedTextMessage?.contextInfo?.participant ||
          sender // sem marcar ninguém, usa a própria pessoa que mandou o comando

        await reagir(emoji)
        const foto = await pegarFotoPerfil(arlequina, mencionado)

        const linhas = traços.map(t => `┃ ${t.emoji} ${t.label}: *${sortear(t.opcoes)}*`).join('\n')
        const legenda = `${emoji} *${titulo.toUpperCase()}* ${emoji}\n╭────── ⍟\n${linhas}\n╰────── ⍟\n\n@${mencionado.split('@')[0]}, se reconheceu? 😂`

        if (foto) {
          await arlequina.sendMessage(from, { image: foto, caption: legenda, mentions: [mencionado, sender] }, { quoted: info })
        } else {
          await arlequina.sendMessage(from, { text: legenda, mentions: [mencionado, sender] }, { quoted: info })
        }
      } catch (e) {
        console.error(`ERRO ${name}:`, e?.message)
        await reply('❌ Deu erro ao gerar o perfil.')
      }
    }
  }
}

module.exports = { criarPerfilCard }
