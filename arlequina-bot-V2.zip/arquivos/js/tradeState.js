/*
 Estado (em memória) das propostas de troca de Pokémon pendentes.
 Chave = JID de quem PRECISA responder (aceitar/recusar).
*/
const propostas = new Map()

const DURACAO_PROPOSTA_MS = 5 * 60 * 1000 // 5 minutos pra responder

function criarProposta(destinoJid, dados) {
  propostas.set(destinoJid, { ...dados, expiraEm: Date.now() + DURACAO_PROPOSTA_MS })
}

function pegarProposta(destinoJid) {
  const p = propostas.get(destinoJid)
  if (!p) return null
  if (Date.now() > p.expiraEm) {
    propostas.delete(destinoJid)
    return null
  }
  return p
}

function removerProposta(destinoJid) {
  propostas.delete(destinoJid)
}

module.exports = { criarProposta, pegarProposta, removerProposta, DURACAO_PROPOSTA_MS }
