/*
 Helper pra formatar tempo de espera/cooldown de um jeito bonito.
 Em vez de "Aguarde 125 minutos", mostra "Aguarde 2h05min".
*/

// Recebe milissegundos e devolve string tipo "2h05min", "45min" ou "30s"
function formatarTempo(ms) {
  if (ms <= 0) return '0s'
  const totalSegundos = Math.ceil(ms / 1000)
  const horas = Math.floor(totalSegundos / 3600)
  const minutos = Math.floor((totalSegundos % 3600) / 60)
  const segundos = totalSegundos % 60

  if (horas > 0) {
    return `${horas}h${String(minutos).padStart(2, '0')}min`
  }
  if (minutos > 0) {
    return segundos > 0 ? `${minutos}min${String(segundos).padStart(2, '0')}s` : `${minutos}min`
  }
  return `${segundos}s`
}

module.exports = { formatarTempo }
