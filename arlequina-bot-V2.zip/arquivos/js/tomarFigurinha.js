/*
 Helper compartilhado por !rgtake / !take / !rename — guarda a
 preferência de autor/pack de cada usuário (pra !take reaplicar depois)
 e reescreve o exif de uma figurinha já existente com pack/autor novos.
*/
const fs = require('fs')
const path = require('path')
const webp = require('node-webpmux')

const DB_PATH = path.join(__dirname, '../../database/takePrefs.json')

function carregarPrefs() {
  try {
    if (!fs.existsSync(DB_PATH)) return {}
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'))
  } catch { return {} }
}

function salvarPref(numero, autor, pack) {
  const dados = carregarPrefs()
  dados[numero] = { autor, pack }
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true })
  fs.writeFileSync(DB_PATH, JSON.stringify(dados, null, 2))
}

function pegarPref(numero) {
  return carregarPrefs()[numero] || null
}

// Regrava o exif (pack/autor) de uma figurinha .webp já pronta.
async function reescreverExif(bufferWebp, pack, autor) {
  const temp = path.join(require('os').tmpdir(), `take_${Date.now()}.webp`)
  fs.writeFileSync(temp, bufferWebp)

  const img = new webp.Image()
  await img.load(temp)

  const exifAttr = {
    'sticker-pack-id': 'arlequina-bot',
    'sticker-pack-name': pack.trim(),
    'sticker-pack-publisher': autor.trim()
  }
  const jsonBuff = Buffer.from(JSON.stringify(exifAttr), 'utf-8')
  const exif = Buffer.concat([
    Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00]),
    Buffer.from([jsonBuff.length & 0xff, (jsonBuff.length >> 8) & 0xff, (jsonBuff.length >> 16) & 0xff, (jsonBuff.length >> 24) & 0xff]),
    Buffer.from([0x16, 0x00, 0x00, 0x00]),
    jsonBuff
  ])
  img.exif = exif
  await img.save(temp)

  const resultado = fs.readFileSync(temp)
  fs.unlinkSync(temp)
  return resultado
}

module.exports = { salvarPref, pegarPref, reescreverExif }
