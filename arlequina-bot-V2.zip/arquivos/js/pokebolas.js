/*
  Definição das pokébolas: preço na loja e chance de captura por raridade.
  Bolas melhores existem pra mítico / supremo / divino.
*/
const POKEBOLAS = {
  comum: {
    label: 'Pokébola Comum',
    emoji: '🔴',
    preco: 50,
    chance: { comum: 0.85, raro: 0.30, epico: 0.08, lendario: 0.01, mitico: 0, supremo: 0, divino: 0 }
  },
  super: {
    label: 'Superbola',
    emoji: '🔵',
    preco: 200,
    chance: { comum: 0.98, raro: 0.60, epico: 0.25, lendario: 0.07, mitico: 0.02, supremo: 0, divino: 0 }
  },
  ultra: {
    label: 'Ultrabola',
    emoji: '🟡',
    preco: 600,
    chance: { comum: 1.00, raro: 0.88, epico: 0.55, lendario: 0.22, mitico: 0.10, supremo: 0.04, divino: 0.01 }
  },
  premier: {
    label: 'Premierbola',
    emoji: '⚪',
    preco: 1200,
    chance: { comum: 1.00, raro: 0.95, epico: 0.70, lendario: 0.40, mitico: 0.20, supremo: 0.08, divino: 0.03 }
  },
  timer: {
    label: 'Timerbola',
    emoji: '⏱️',
    preco: 2500,
    chance: { comum: 1.00, raro: 1.00, epico: 0.85, lendario: 0.55, mitico: 0.35, supremo: 0.18, divino: 0.08 }
  },
  luxury: {
    label: 'Luxurybola',
    emoji: '💎',
    preco: 4500,
    chance: { comum: 1.00, raro: 1.00, epico: 0.95, lendario: 0.75, mitico: 0.55, supremo: 0.35, divino: 0.18 }
  },
  beast: {
    label: 'Beastbola',
    emoji: '🖤',
    preco: 8000,
    chance: { comum: 1.00, raro: 1.00, epico: 1.00, lendario: 0.90, mitico: 0.75, supremo: 0.55, divino: 0.35 }
  },
  mestra: {
    label: 'Bola Mestra',
    emoji: '🟣',
    preco: 15000,
    chance: { comum: 1.00, raro: 1.00, epico: 1.00, lendario: 1.00, mitico: 1.00, supremo: 1.00, divino: 1.00 }
  }
}

const ORDEM_POKEBOLAS = ['comum', 'super', 'ultra', 'premier', 'timer', 'luxury', 'beast', 'mestra']

module.exports = { POKEBOLAS, ORDEM_POKEBOLAS }
