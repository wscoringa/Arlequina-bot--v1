/*
  Mensagens de boas-vindas / saída / remoção do grupo.

  Regras:
  - FOTO: se o grupo configurou uma imagem (!fundobv / !fundosair), usa ela.
          Se NÃO configurou, usa a FOTO DE PERFIL da pessoa que entrou/saiu.
          Se a pessoa não tem foto (ou esconde), usa a imagem padrão.
  - SAIU x REMOVIDO: se quem fez a ação é a própria pessoa, ela SAIU.
          Se foi outra pessoa, foi REMOVIDA e a mensagem mostra qual ADM removeu.

  O comando !bemvindo test usa as mesmas funções, então o teste mostra
  exatamente o que vai acontecer de verdade.
*/
const fs = require('fs')
const welcomeDB = require('./welcomeDB.js')
const { numeroPuro, idsBrutos, mesmaPessoa, jidDoAutor, obterImagemPerfil } = require('./eventosGrupoHelper.js')

const MAX_POR_EVENTO = 5 // evita flood se muita gente entrar de uma vez

// escolhe a imagem: fundo configurado > foto de perfil > imagem padrão
async function escolherImagem(sock, cfg, tipo, pessoa) {
  const fundoCustom = tipo === 'entrada' ? cfg.fundoEntrada : cfg.fundoSaida
  if (fundoCustom && fs.existsSync(fundoCustom)) return { image: { url: fundoCustom }, origem: 'fundo configurado' }

  const foto = await obterImagemPerfil(sock, pessoa)
  if (foto) return { image: foto.buffer ? foto.buffer : { url: foto.url }, origem: 'foto de perfil' }

  const padrao = tipo === 'entrada' ? welcomeDB.IMG_ENTRADA_PADRAO : welcomeDB.IMG_SAIDA_PADRAO
  return { image: { url: padrao }, origem: 'imagem padrão' }
}

/*
  Monta o conteúdo (imagem+legenda ou só texto) sem enviar.
  tipo: 'entrada' | 'saida'      removido: true se foi removido por um ADM
*/
async function montarConteudo(sock, { cfg, tipo, removido, pessoa, jid, adminJid, nomeGrupo, totalMembros }) {
  const numeroUsuario = numeroPuro(jid)
  const foiRemovido = tipo === 'saida' && !!removido && !!adminJid
  const nomeAdmin = foiRemovido ? numeroPuro(adminJid) : null

  let legendaBruta
  if (tipo === 'entrada') {
    legendaBruta = cfg.entrada || welcomeDB.LEGENDA_ENTRADA_PADRAO
  } else if (foiRemovido) {
    legendaBruta = cfg.saida || welcomeDB.LEGENDA_REMOVIDO_PADRAO
    // legenda personalizada de saída que não cita o ADM: acrescenta quem removeu
    if (cfg.saida && !/\{\s*adm(in)?\s*\}/i.test(cfg.saida)) legendaBruta += '\n\n🚫 Removido(a) por {admin}'
  } else {
    legendaBruta = cfg.saida || welcomeDB.LEGENDA_SAIDA_PADRAO
  }

  const legenda = welcomeDB.renderizarLegenda(legendaBruta, { numeroUsuario, nomeGrupo, totalMembros, nomeAdmin })
  const mentions = foiRemovido ? [jid, adminJid] : [jid]

  if (!cfg.comFoto) return { content: { text: legenda, mentions }, origem: 'só texto' }

  const img = await escolherImagem(sock, cfg, tipo, pessoa)
  return { content: { image: img.image, caption: legenda, mentions }, origem: img.origem }
}

async function enviar(sock, groupId, content) {
  try {
    await sock.sendMessage(groupId, content)
  } catch (e) {
    if (!content.image) throw e
    console.log('⚠️ Falha ao mandar imagem de boas-vindas/saída, caindo pra texto:', e?.message)
    await sock.sendMessage(groupId, { text: content.caption, mentions: content.mentions })
  }
}

// listener do evento group-participants.update
async function tratar(sock, update) {
  const { id, participants, action, author, authorPn } = update || {}
  if (action !== 'add' && action !== 'remove') return

  const cfg = welcomeDB.getConfig(id)
  if (!cfg.ativo) return

  const lista = (Array.isArray(participants) ? participants : []).slice(0, MAX_POR_EVENTO)
  if (!lista.length) return

  // pequena espera pra dar tempo do WhatsApp atualizar os dados do grupo
  let groupMetadata = null
  try {
    await new Promise((r) => setTimeout(r, Number(process.env.BV_ESPERA_MS ?? 800)))
    groupMetadata = await sock.groupMetadata(id)
  } catch (e) {
    console.log('⚠️ Não consegui buscar groupMetadata pro aviso de entrada/saída, seguindo com valores padrão:', e?.message)
  }
  const nomeGrupo = groupMetadata?.subject || 'grupo'
  const totalMembros = groupMetadata?.participants?.length || 0

  for (const part of lista) {
    const ids = idsBrutos(part)
    const jid = ids.find((x) => x.endsWith('@s.whatsapp.net')) || ids[0]
    if (!jid) {
      console.log('⚠️ Aviso de entrada/saída ignorado: não consegui identificar quem entrou/saiu. Dado recebido:', JSON.stringify(part))
      continue
    }

    // ignora evento gerado pela própria Arlequina entrando/saindo do grupo
    if (await mesmaPessoa(sock, part, sock.user)) continue

    const tipo = action === 'add' ? 'entrada' : 'saida'

    // SAIU sozinho (quem agiu é a própria pessoa) x REMOVIDO por um ADM (quem agiu é outra pessoa)
    let removido = false
    let adminJid = null
    if (action === 'remove' && (author || authorPn)) {
      const mesma = await mesmaPessoa(sock, part, [author, authorPn])
      if (!mesma) {
        removido = true
        adminJid = await jidDoAutor(sock, author, authorPn)
      }
    }

    try {
      const { content, origem } = await montarConteudo(sock, {
        cfg, tipo, removido, pessoa: part, jid, adminJid, nomeGrupo, totalMembros,
      })
      console.log(`[boas-vindas] ${tipo}${removido ? ' (removido por ADM)' : ''} de ${numeroPuro(jid)} — ${origem}`)
      await enviar(sock, id, content)
    } catch (e) {
      console.log('❌ ERRO ao enviar boas-vindas/saída:', e?.message)
    }

    // guarda a foto de quem entrou (a saída depois pode não conseguir buscar)
    if (action === 'add') obterImagemPerfil(sock, part).catch(() => {})
  }
}

module.exports = { tratar, montarConteudo, enviar, escolherImagem }
