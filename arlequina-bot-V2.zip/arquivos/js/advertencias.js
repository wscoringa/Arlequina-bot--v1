/*
 Sistema de advertências compartilhado — usado por antiflood,
 antipalavra e qualquer outra proteção que quiser banir depois de X
 avisos, em vez de só apagar a mensagem pra sempre.

 Guarda em memória: groupJid -> numero -> quantidade de advertências.
 Reseta se o bot reiniciar (não é histórico permanente de longo prazo).
*/
const registro = new Map()

function chave(groupJid, numero) {
  return `${groupJid}::${numero}`
}

// Adiciona 1 advertência e retorna { total, deveBanir }
function adicionarAdvertencia(groupJid, numero, maxAdvertencias) {
  const k = chave(groupJid, numero)
  const total = (registro.get(k) || 0) + 1
  registro.set(k, total)
  return { total, deveBanir: total >= maxAdvertencias }
}

function zerarAdvertencias(groupJid, numero) {
  registro.delete(chave(groupJid, numero))
}

function verAdvertencias(groupJid, numero) {
  return registro.get(chave(groupJid, numero)) || 0
}

module.exports = { adicionarAdvertencia, zerarAdvertencias, verAdvertencias }
