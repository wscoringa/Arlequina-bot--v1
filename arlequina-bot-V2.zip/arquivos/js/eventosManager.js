/*
  Sistema de eventos por grupo (/evento, /entrarnalista, /reseteev)
  Armazena em: database/eventos.json
*/
const fs = require('fs')
const PATH = './database/eventos.json'

function carregar() {
  try {
    return fs.existsSync(PATH) ? JSON.parse(fs.readFileSync(PATH, 'utf-8')) : {}
  } catch (e) {
    return {}
  }
}

function salvar(dados) {
  try {
    fs.writeFileSync(PATH, JSON.stringify(dados, null, 2))
  } catch (e) {}
}

function criarEvento(groupJid, nome, criadoPor) {
  const dados = carregar()
  dados[groupJid] = {
    nome,
    criadoPor,
    criadoEm: Date.now(),
    participantes: []
  }
  salvar(dados)
  return dados[groupJid]
}

function getEvento(groupJid) {
  const dados = carregar()
  return dados[groupJid] || null
}

function entrarEvento(groupJid, userJid) {
  const dados = carregar()
  const evento = dados[groupJid]
  if (!evento) return { ok: false, motivo: 'sem_evento' }
  if (evento.participantes.includes(userJid)) return { ok: false, motivo: 'ja_esta', evento }
  evento.participantes.push(userJid)
  salvar(dados)
  return { ok: true, evento }
}

function resetarEvento(groupJid) {
  const dados = carregar()
  if (dados[groupJid]) {
    delete dados[groupJid]
    salvar(dados)
    return true
  }
  return false
}

module.exports = { criarEvento, getEvento, entrarEvento, resetarEvento }
