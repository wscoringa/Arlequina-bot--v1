/*
 TTS com voz feminina em português — usa múltiplas APIs como fallback.
 Sem chave de API, sem dependências extras além do axios.
*/
const axios = require('axios')
const fs = require('fs')

const frases = {
  menu: 'Oi! Eu sou a Arlequina, sua assistente favorita. Aqui está o meu menu de comandos. Escolha uma opção!',
  cmdinexistente: 'Ei! Esse comando não existe. Usa o menu pra ver os comandos disponíveis!',
  bemvindo: 'Bem vindo ao grupo! Espero que você aproveite bastante.',
  saida: 'Tchau! Até mais.',
}

async function ttsArlequina(texto) {
  // Tenta API 1: VoiceRSS (gratuita, sem chave pra pt-BR curto)
  try {
    const url = `https://api.voicerss.org/?key=demo&hl=pt-br&v=Vitoria&c=MP3&f=16khz_16bit_mono&src=${encodeURIComponent(texto)}`
    const resp = await axios.get(url, {
      responseType: 'arraybuffer',
      timeout: 8000
    })
    const buf = Buffer.from(resp.data)
    if (buf.length > 2000) return buf
  } catch (e) {}

  // Tenta API 2: StreamElements TTS (sem autenticação)
  try {
    const url = `https://api.streamelements.com/kappa/v2/speech?voice=Camila&text=${encodeURIComponent(texto)}`
    const resp = await axios.get(url, {
      responseType: 'arraybuffer',
      timeout: 8000,
      headers: { 'User-Agent': 'Mozilla/5.0' }
    })
    const buf = Buffer.from(resp.data)
    if (buf.length > 2000) return buf
  } catch (e) {}

  // Tenta API 3: TikTok TTS (voz feminina)
  try {
    const url = `https://tiktok-tts.weilnet.workers.dev/api/generation`
    const resp = await axios.post(url, {
      text: texto.slice(0, 200),
      voice: 'pt_female_ht'
    }, {
      timeout: 8000,
      headers: { 'Content-Type': 'application/json' }
    })
    if (resp.data?.data) {
      return Buffer.from(resp.data.data, 'base64')
    }
  } catch (e) {}

  return null
}

module.exports = { ttsArlequina, frases }
