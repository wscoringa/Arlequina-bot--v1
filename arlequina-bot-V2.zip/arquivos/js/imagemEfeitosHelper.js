/*
 Helper compartilhado pelos comandos premium de efeito de imagem.
 Usa a lib "jimp" (já é dependência do projeto, não precisa instalar nada).
*/
const { Jimp } = require('jimp')

// Pega a imagem marcada/respondida ou mandada direto com legenda
function extrairMensagemImagem(info) {
  const quotedMsg = info.message?.extendedTextMessage?.contextInfo?.quotedMessage
  return quotedMsg?.imageMessage || info.message?.imageMessage || null
}

async function aplicarEfeito(buffer, aplicarFn, formato) {
  const imagem = await Jimp.read(buffer)
  await aplicarFn(imagem)
  return await imagem.getBuffer(formato || 'image/jpeg')
}

// Fábrica de comando: gera um module.exports padrão pra cada efeito,
// evitando repetir a mesma lógica de "pegar imagem / aplicar / enviar"
// em vários arquivos diferentes (menos chance de erro de digitação).
function criarComandoEfeito({ name, description, aliases, emoji, aplicarFn, formato }) {
  return {
    name,
    description,
    category: 'premium',
    aliases: aliases || [],
    async execute({ arlequina, from, info, args, reply, reagir, getFileBuffer }) {
      try {
        const imagemMsg = extrairMensagemImagem(info)
        if (!imagemMsg) {
          return reply(`💎 Marque/responda uma foto com *${name}* pra aplicar o efeito.`)
        }
        await reagir(emoji || '✨')
        const bufferOriginal = await getFileBuffer(imagemMsg, 'image')
        const bufferFinal = await aplicarEfeito(bufferOriginal, (img) => aplicarFn(img, args), formato)
        await arlequina.sendMessage(from, { image: bufferFinal, caption: `💎 ${description}` }, { quoted: info })
      } catch (e) {
        console.log(`❌ ERRO ${name}:`, e?.message)
        await reply('❌ Não consegui aplicar o efeito nessa imagem. Tente com outra.')
      }
    }
  }
}

module.exports = { extrairMensagemImagem, aplicarEfeito, criarComandoEfeito }
