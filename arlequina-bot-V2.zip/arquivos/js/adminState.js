/*
 Estado em memoria compartilhado pelos plugins da categoria "admin",
 convertidos a partir do connect.js (bot antigo, monolitico).
 Mesma logica que era guardada em "global.X" no bot antigo: fica na
 memoria do processo, reseta quando o bot reinicia (nao persiste em arquivo).
*/
module.exports = {
welcome: {},
antilink: {},
regras: {},
mutados: {},
antifake: {},
antiflood: {},
listanegra: {},
muteTemporario: {},
antibot: {},
antispam: {},
antiviewonce: {},
antidelete: {},
antipagamento: {},
antidoc: {},
antiloc: {},
antipalavra: {},
anticategoria: {},
antispamcmd: {},
antiimagem: {},
anticontato: {},
antinota: {}
}
