/*
  Anti-PY: combate a MENSAGEM DE PAGAMENTO / "FANTASMA" / INVISÍVEL (o spam que o WhatsApp
  mostra como "Mensagem de pagamento • Valor indisponível", com propaganda escondida).

  Quando o bot RECONHECE a mensagem (automático), ele APAGA, BANE quem mandou e MARCA a pessoa.

  Dois jeitos de agir (os dois: APAGA, BANE e MARCA):
  1) AUTOMÁTICO — o bot reconhece a mensagem assim que ela chega.
  2) RESPONDENDO — QUALQUER pessoa do grupo responde a mensagem de spam (com qualquer
     texto) e, se a mensagem respondida for confirmada como spam, o bot bane quem mandou.

  NÃO existe atalho "." (responder só com um ponto) — isso foi removido de propósito
  porque não confirma o conteúdo da mensagem e pode banir gente inocente.

  Regras:
  - Só age com o !antipy ligado no grupo.
  - Vale também para ADM (rebaixa e bane; !antipy adm off poupa ADM).
  - Nunca toca no dono do bot, no próprio bot, nem no criador do grupo (o WhatsApp
    não deixa remover o criador — nesse caso só apaga).
  - Detecta pela ESTRUTURA da mensagem (tipo de pagamento / fluxo de pagamento), por texto
    invisível e pela propaganda conhecida. Texto comum (ex: "pix") NÃO é detectado.
  - Confere o resultado do ban de verdade: o WhatsApp devolve o status ("403", "404"...)
    SEM dar erro — antes isso era tratado como sucesso.
*/
const antipyDB = require('./antipyDB.js')

// ================= DETECÇÃO =================
const PADRAO_CHAVE_PAGAMENTO = /payment/i
const PADRAO_FLUXO = /review_and_pay|payment_info|payment_status|pay_now|order_details|order_status|galaxy_message|\bmpm\b/i
const PADRAO_FLUXO_JSON = /payment_settings|payment_info|review_and_pay|"payment|pix_static_code|total_amount/i
// nunca entra nesses campos ao olhar uma mensagem que CHEGOU (mensagem respondida/citada)
const IGNORAR = new Set(['contextInfo', 'quotedMessage'])

/* Devolve o motivo (ex: "requestPaymentMessage") ou null. */
function detectarPagamento(message, profundidade = 0) {
  if (!message || typeof message !== 'object' || profundidade > 8) return null

  for (const [chave, valor] of Object.entries(message)) {
    if (IGNORAR.has(chave)) continue
    if (PADRAO_CHAVE_PAGAMENTO.test(chave) && valor) return chave

    if (chave === 'nativeFlowMessage' && valor && typeof valor === 'object') {
      // parâmetros gerais do fluxo (JSON) que falam de pagamento
      if (typeof valor.messageParamsJson === 'string' && PADRAO_FLUXO_JSON.test(valor.messageParamsJson)) return 'nativeFlow:messageParams'
    }
    if (chave === 'nativeFlowMessage' && valor && Array.isArray(valor.buttons)) {
      for (const b of valor.buttons) {
        const nome = String(b?.name || '')
        const params = String(b?.buttonParamsJson || '')
        if (PADRAO_FLUXO.test(nome) || PADRAO_CHAVE_PAGAMENTO.test(nome) || PADRAO_FLUXO.test(params)) {
          return `nativeFlow:${nome || 'pagamento'}`
        }
      }
    }

    if (valor && typeof valor === 'object') {
      const achou = detectarPagamento(valor, profundidade + 1)
      if (achou) return achou
    }
  }
  return null
}

// ---------- MENSAGEM INVISÍVEL: texto feito só de caracteres que não aparecem ----------
const RE_INVISIVEL = /[\u200B-\u200F\u202A-\u202E\u2060-\u2064\u206A-\u206F\uFEFF\u00AD\u034F\u061C\u115F\u1160\u17B4\u17B5\u180B-\u180E\u2800\u3164\uFFA0\u{E0000}-\u{E007F}\u{1D173}-\u{1D17A}]/gu
const CAMPOS_TEXTO = ['conversation', 'text', 'caption', 'title', 'description', 'note', 'contentText', 'hydratedContentText']

function coletarTextos(obj, prof = 0, acc = []) {
  if (!obj || typeof obj !== 'object' || prof > 8) return acc
  for (const [chave, valor] of Object.entries(obj)) {
    if (IGNORAR.has(chave)) continue
    if (typeof valor === 'string' && CAMPOS_TEXTO.includes(chave)) acc.push(valor)
    else if (valor && typeof valor === 'object') coletarTextos(valor, prof + 1, acc)
  }
  return acc
}

/* Texto que é (quase) só caractere invisível. Não pega emoji nem texto normal. */
function detectarInvisivel(message) {
  const texto = coletarTextos(message).join('')
  if (!texto) return null
  const invis = (texto.match(RE_INVISIVEL) || []).length
  if (invis < 30) return null
  const visivel = Array.from(texto.replace(RE_INVISIVEL, '').replace(/\s/g, '')).length
  if (visivel === 0 || (invis >= 40 && visivel <= invis * 0.15)) return `texto-invisivel(${invis})`
  return null
}

// propaganda conhecida desse spam (segunda camada: pega mesmo que o tipo da mensagem venha diferente)
const ASSINATURAS_SPAM = [/anarchy\s*zone/i, /mensagem\s+invis[ií]vel\s+gratuit/i, /t\.me\/anarchyzone/i]

function detectarAssinatura(message) {
  const texto = coletarTextos(message).join(' ')
  if (!texto) return null
  for (const re of ASSINATURAS_SPAM) if (re.test(texto)) return `assinatura(${re.source.slice(0, 24)})`
  return null
}

function detectarSpam(message) {
  return detectarPagamento(message) || detectarInvisivel(message) || detectarAssinatura(message)
}

// tipos comuns e inofensivos: qualquer outro tipo aparece no log (ajuda a diagnosticar)
const TIPOS_COMUNS = new Set([
  'conversation', 'extendedTextMessage', 'imageMessage', 'videoMessage', 'audioMessage', 'stickerMessage',
  'documentMessage', 'documentWithCaptionMessage', 'contactMessage', 'contactsArrayMessage', 'locationMessage',
  'liveLocationMessage', 'reactionMessage', 'protocolMessage', 'pollCreationMessage', 'pollCreationMessageV3',
  'pollUpdateMessage', 'editedMessage', 'senderKeyDistributionMessage', 'messageContextInfo', 'ephemeralMessage',
  'viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension', 'buttonsResponseMessage',
  'listResponseMessage', 'templateButtonReplyMessage', 'interactiveResponseMessage', 'albumMessage',
  'groupInviteMessage', 'ptvMessage', 'eventMessage', 'stickerPackMessage',
])

// resumo da estrutura de uma mensagem (para o !antipy debug): mostra as chaves, não o conteúdo
function resumirEstrutura(obj, prof = 0) {
  if (obj === null || obj === undefined) return obj
  if (typeof obj === 'string') return obj.length > 40 ? obj.slice(0, 40) + '…' : obj
  if (typeof obj !== 'object') return obj
  if (Buffer.isBuffer(obj) || obj instanceof Uint8Array) return `<bytes ${obj.length}>`
  if (prof > 5) return '…'
  if (Array.isArray(obj)) return obj.slice(0, 4).map((x) => resumirEstrutura(x, prof + 1))
  const out = {}
  for (const [k, v] of Object.entries(obj)) out[k] = resumirEstrutura(v, prof + 1)
  return out
}

// ================= IDENTIFICAÇÃO =================
const numeroPuro = (jid) => String(jid || '').split('@')[0].split(':')[0]
const dormir = (ms) => new Promise((ok) => setTimeout(ok, ms))
const idsDoMembro = (m) => [m?.id, m?.jid, m?.lid, m?.phoneNumber].filter((x) => typeof x === 'string')

// candidatos de jid para banir (o formato certo depende do grupo: número ou LID)
function candidatosBan({ info, sender, groupMembers }) {
  const lista = [info?.key?.participant, info?.key?.participantAlt, sender]
  const nums = new Set(lista.filter(Boolean).map(numeroPuro))
  try {
    for (const m of groupMembers || []) {
      const ids = idsDoMembro(m)
      if (ids.some((x) => nums.has(numeroPuro(x)))) lista.push(...ids)
    }
  } catch {}
  return [...new Set(lista.filter((x) => typeof x === 'string' && x.includes('@')))]
}

async function tentarBanir(sock, groupId, candidatos, { demotarAntes = false } = {}) {
  let ultimoErro = null
  let rebaixou = false
  for (const jid of candidatos) {
    try {
      // ADM: o WhatsApp só remove depois de tirar o cargo
      if (demotarAntes) {
        try {
          const d = await sock.groupParticipantsUpdate(groupId, [jid], 'demote')
          if (!Array.isArray(d) || d.some((r) => String(r?.status || '').startsWith('2'))) rebaixou = true
          await dormir(600)
        } catch (_) {}
      }
      const res = await sock.groupParticipantsUpdate(groupId, [jid], 'remove')
      // o Baileys devolve [{ status: '200', jid }] — "403"/"404" NÃO dá erro, só vem no status
      if (Array.isArray(res) && res.length) {
        if (res.some((r) => String(r?.status || '').startsWith('2'))) return { ok: true, jid, rebaixou }
        ultimoErro = new Error('status ' + res.map((r) => r?.status).join(','))
        continue
      }
      return { ok: true, jid, rebaixou }
    } catch (e) {
      ultimoErro = e
    }
  }
  return { ok: false, erro: ultimoErro, rebaixou }
}

// ================= AÇÃO: apagar + banir + marcar =================
const recentes = new Map() // "grupo|numero" -> timestamp (evita banir/avisar de novo)
const avisoSemAdmin = new Map() // grupo -> timestamp
const JANELA_MS = 2 * 60 * 1000

async function derrubarAlvo(sock, o) {
  const {
    from, cfg, alvo, alvoExtras = [], groupMembers, isBotGroupAdmins, ehDono, apagarChaves = [], cabecalho,
    quem = null, alvoEhAdminDica = false, autoridadeTotal = false,
  } = o

  const candidatos = candidatosBan({ info: { key: { participant: alvo } }, sender: alvoExtras.find(Boolean) || alvo, groupMembers })
  for (const x of alvoExtras) if (typeof x === 'string' && x.includes('@') && !candidatos.includes(x)) candidatos.push(x)
  const numsAlvo = new Set(candidatos.map(numeroPuro))
  const mencao = candidatos.find((x) => x.endsWith('@s.whatsapp.net')) || candidatos[0] || alvo
  const numMencao = numeroPuro(mencao)

  // nunca o próprio bot
  if (sock.user && [sock.user.id, sock.user.lid].filter(Boolean).some((x) => numsAlvo.has(numeroPuro(x)))) return false

  const membro = (groupMembers || []).find((m) => idsDoMembro(m).some((x) => numsAlvo.has(numeroPuro(x))))
  const alvoEhCriador = membro?.admin === 'superadmin'
  const alvoEhAdmin = alvoEhAdminDica || membro?.admin === 'admin' || alvoEhCriador
  const alvoEhDono = typeof ehDono === 'function' && candidatos.some((c) => ehDono(c))

  const chaveAlvo = `${from}|${numMencao}`
  const jaBaniu = recentes.has(chaveAlvo) && Date.now() - recentes.get(chaveAlvo) < JANELA_MS

  // sem ser ADM o bot não consegue apagar nem banir: avisa (no máximo 1x por minuto)
  if (!isBotGroupAdmins) {
    if (Date.now() - (avisoSemAdmin.get(from) || 0) > 60 * 1000) {
      avisoSemAdmin.set(from, Date.now())
      await sock.sendMessage(from, {
        text: [cabecalho, '⚠️ Não consigo apagar nem remover: *preciso ser ADM do grupo*.'].join('\n\n'),
        mentions: [mencao],
      }).catch(() => {})
    }
    return true
  }

  // 1) apaga
  let apagou = true
  for (const chave of apagarChaves) {
    try {
      await sock.sendMessage(from, { delete: chave })
    } catch (e) {
      apagou = false
      console.log('❌ ANTI-PY (falha ao apagar mensagem):', e?.message || e)
    }
  }
  const linhaApagou = apagou ? '🧹 A mensagem foi apagada.' : '⚠️ Não consegui apagar a mensagem.'

  // spammer que já foi banido agora há pouco: só apagou, não repete ban nem aviso
  if (jaBaniu) return true

  const avisar = (linhas) =>
    sock.sendMessage(from, { text: [cabecalho, ...linhas].join('\n\n'), mentions: [mencao, quem].filter(Boolean) }).catch(() => {})

  // 2) quem não dá para banir
  if (alvoEhDono) {
    await avisar([linhaApagou, `⚠️ @${numMencao} é o *dono do bot* e eu não posso banir.`])
    return true
  }
  if (alvoEhCriador) {
    await avisar([linhaApagou, `⚠️ @${numMencao} é o *criador do grupo* e o WhatsApp não deixa eu remover.`])
    return true
  }
  if (alvoEhAdmin && !cfg.banirAdmins && !autoridadeTotal) {
    await avisar([linhaApagou, `⚠️ @${numMencao} é ADM e o "!antipy adm" está *off*, então não removi.`])
    return true
  }

  // 3) bane (ADM: rebaixa antes)
  recentes.set(chaveAlvo, Date.now())
  if (recentes.size > 500) recentes.delete(recentes.keys().next().value)
  const resultado = await tentarBanir(sock, from, candidatos.length ? candidatos : [alvo], { demotarAntes: alvoEhAdmin })

  // 4) marca a pessoa avisando
  if (resultado.ok) {
    const linhaBan = alvoEhAdmin
      ? `🚫 @${numMencao} era ADM: foi *rebaixado(a)* e *BANIDO(A)* do grupo.`
      : `🚫 @${numMencao} foi *BANIDO(A)* do grupo.`
    await avisar([linhaApagou, linhaBan])
  } else {
    console.log('❌ ANTI-PY (ban falhou):', resultado.erro?.message || resultado.erro)
    await avisar([
      linhaApagou,
      `⚠️ Não consegui remover @${numMencao} (${resultado.erro?.message || 'erro'}). Confira se eu sou ADM e se a pessoa não é criadora do grupo.`,
    ])
  }
  return true
}

// contextInfo (com a mensagem respondida) de uma mensagem que chegou
function contextoDeResposta(message) {
  let m = message
  for (let i = 0; i < 4 && m; i++) {
    const dentro = m.ephemeralMessage?.message || m.viewOnceMessage?.message || m.viewOnceMessageV2?.message || m.documentWithCaptionMessage?.message
    if (!dentro) break
    m = dentro
  }
  for (const v of Object.values(m || {})) {
    if (v && typeof v === 'object' && v.contextInfo?.stanzaId && v.contextInfo?.participant) return v.contextInfo
  }
  return null
}

// ================= RESPONDENDO: qualquer pessoa do grupo responde a uma mensagem de spam =================
/*
  Alguém responde (cita) a mensagem de spam — com QUALQUER texto — e, SE a mensagem
  respondida for reconhecida como spam pelo detector, o bot apaga aquela mensagem,
  bane quem mandou (o autor do spam, não quem respondeu) e marca a pessoa.
  Só age se a mensagem respondida for confirmada como spam — responder mensagem normal
  não faz nada. NÃO existe atalho "." (responder só com um ponto): isso foi removido de
  propósito porque não confirma o conteúdo e pode banir gente inocente.
*/
async function tratarDenuncia(sock, { info, from, isGroup, isBotGroupAdmins, groupMembers, ehDono }) {
  if (!isGroup || !info?.message) return false
  const ci = contextoDeResposta(info.message)
  if (!ci?.quotedMessage || !ci?.participant) return false

  const cfg = antipyDB.getConfig(from)
  if (!cfg.ativo || cfg.denuncia === false) return false

  const motivo = detectarSpam(ci.quotedMessage) // olha a mensagem RESPONDIDA, não quem respondeu
  if (!motivo) return false

  const tipoMsg = String(motivo).startsWith('texto-invisivel') ? 'mensagem *invisível*' : 'mensagem de pagamento/fantasma'
  console.log(`[antipy] denúncia por resposta: ${tipoMsg.replace(/\*/g, '')} (${motivo}) — alvo ${numeroPuro(ci.participant)}`)

  return derrubarAlvo(sock, {
    from, cfg, groupMembers, isBotGroupAdmins, ehDono,
    alvo: ci.participant,
    apagarChaves: [{ remoteJid: from, id: ci.stanzaId, fromMe: false, participant: ci.participant }],
    cabecalho: `👻 *ANTI-PY* — a mensagem respondida era ${tipoMsg}!`,
  })
}


/*
  IMPORTANTE: NÃO confiar na variável "sender" do index.js. Lá ela é montada assim:
     info.key.participantAlt || info.key.remoteJidAlt || conn.user.id || info.key.participant
  e quando a mensagem NÃO traz participantAlt, "sender" vira o número do PRÓPRIO BOT — aí o
  bot achava que quem mandou o spam era ele mesmo / o dono e ignorava. Aqui a identidade de
  quem mandou vem SEMPRE da chave da mensagem (participant / participantAlt) e do que o
  grupo diz (lista de membros com o cargo de ADM).
*/
async function tratar(sock, { info, from, sender, isGroup, isGroupAdmins, isBotGroupAdmins, groupMembers, ehDono }) {
  if (!isGroup || !info?.message) return false
  const cfg = antipyDB.getConfig(from)
  if (!cfg.ativo) return false
  if (info.key?.fromMe) return false // mensagem da própria conta do bot

  const motivo = detectarSpam(info.message)
  if (!motivo) {
    // diagnóstico: mostra no terminal os tipos "diferentes" que o antipy viu e não reconheceu como spam
    const tipos = Object.keys(info.message).filter((k) => !TIPOS_COMUNS.has(k))
    if (tipos.length) console.log('[antipy][debug] tipo não reconhecido como spam:', tipos.join(', '))
    return false
  }

  // ---- quem mandou (da chave da mensagem, não do "sender" do index.js) ----
  const idsChave = [info.key?.participant, info.key?.participantAlt].filter((x) => typeof x === 'string' && x.includes('@'))
  if (!idsChave.length && sender) idsChave.push(sender) // último recurso
  const alvo = idsChave[0]
  if (!alvo) {
    console.log('[antipy] spam detectado mas não achei quem mandou (key sem participant):', JSON.stringify(info.key))
    return false
  }
  const candidatos = candidatosBan({ info: { key: { participant: idsChave[0], participantAlt: idsChave[1] } }, sender: null, groupMembers })
  const numsAlvo = new Set(candidatos.map(numeroPuro))

  // o próprio bot (mesmo que o WhatsApp mande o id em outro formato)
  const idsBot = sock.user ? [sock.user.id, sock.user.lid].filter(Boolean) : []
  if (idsBot.some((x) => numsAlvo.has(numeroPuro(x)))) return false

  const membro = (groupMembers || []).find((m) => idsDoMembro(m).some((x) => numsAlvo.has(numeroPuro(x))))
  const alvoEhAdmin = membro ? membro.admin === 'admin' || membro.admin === 'superadmin' : false
  const alvoEhDono = typeof ehDono === 'function' && candidatos.some((c) => { try { return ehDono(c) } catch (_e) { return false } })

  // o bot é ADM? (o index.js às vezes erra isso com LID — confere também pela lista de membros)
  const membroBot = (groupMembers || []).find((m) => idsDoMembro(m).some((x) => idsBot.some((b) => numeroPuro(b) === numeroPuro(x))))
  const botEhAdmin = !!isBotGroupAdmins || (!!membroBot && (membroBot.admin === 'admin' || membroBot.admin === 'superadmin'))

  const tipoMsg = String(motivo).startsWith('texto-invisivel') ? 'mensagem *invisível*' : 'mensagem de pagamento/fantasma'
  console.log(`[antipy] ${tipoMsg.replace(/\*/g, '')} (${motivo}) de ${numeroPuro(alvo)} em ${from} | ADM:${alvoEhAdmin} dono:${alvoEhDono} botADM:${botEhAdmin}`)

  // o dono do bot nunca é tocado
  if (alvoEhDono) {
    console.log('[antipy] ignorado: quem mandou é o DONO do bot')
    return false
  }
  // ADM: por padrão também é banido (!antipy adm off para poupar)
  if (alvoEhAdmin && !cfg.banirAdmins) {
    console.log('[antipy] ignorado: quem mandou é ADM e "!antipy adm" está off')
    return false
  }

  return derrubarAlvo(sock, {
    from, cfg, groupMembers, isBotGroupAdmins: botEhAdmin, ehDono,
    alvo,
    alvoExtras: [idsChave[1]],
    alvoEhAdminDica: alvoEhAdmin,
    apagarChaves: [{ remoteJid: from, id: info.key.id, fromMe: false, participant: info.key.participant || alvo }],
    cabecalho: `👻 *ANTI-PY* — ${tipoMsg} detectada!`,
  })
}

/*
  AÇÃO MANUAL: um ADM/dono responde a uma mensagem já visível no chat com
  "!antipy debug". Se (e SÓ se) o detector confirmar que aquela mensagem
  específica é spam, o bot apaga, bane quem mandou e marca a pessoa — igual
  ao automático, só que disparado na mão. Não depende do evento de chegada
  da mensagem (onde o automático pode estar falhando nalgum ambiente);
  trabalha em cima do que o WhatsApp já mostrou na tela.
*/
async function agirSobreCitada(sock, { ci, from, groupMembers, isBotGroupAdmins, ehDono }) {
  if (!ci?.quotedMessage || !ci?.participant) return { motivo: null }
  const cfg = antipyDB.getConfig(from)
  const motivo = detectarSpam(ci.quotedMessage)
  if (!motivo) return { motivo: null }

  const tipoMsg = String(motivo).startsWith('texto-invisivel') ? 'mensagem invisível' : 'mensagem de pagamento/fantasma'
  const tratou = await derrubarAlvo(sock, {
    from, cfg, groupMembers, isBotGroupAdmins, ehDono,
    alvo: ci.participant,
    apagarChaves: [{ remoteJid: from, id: ci.stanzaId, fromMe: false, participant: ci.participant }],
    cabecalho: `👻 *ANTI-PY* — confirmado: era ${tipoMsg}!`,
  })
  return { motivo, tratou }
}

module.exports = {
  tratar, tratarDenuncia, agirSobreCitada,
  detectarSpam, detectarPagamento, detectarInvisivel, detectarAssinatura,
  resumirEstrutura, contextoDeResposta, candidatosBan, tentarBanir,
}
