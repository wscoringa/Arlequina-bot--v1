/*
 Helper compartilhado do yt-dlp, extraído do play.js pra ser reusado
 pelos comandos novos (kwai, capcut, threads, gdrive). Precisa do
 yt-dlp instalado no sistema: pip install -U yt-dlp
*/
const { exec, execFile } = require('child_process')

function shell(cmd, ms = 60000) {
  return new Promise((res, rej) => {
    const c = exec(cmd, { timeout: ms, killSignal: 'SIGKILL', maxBuffer: 1024 * 1024 * 20 }, (err, out, errStr) => {
      clearTimeout(k)
      if (err) return rej(new Error(errStr?.split('\n')[0] || err.message))
      res((out || '').trim())
    })
    const k = setTimeout(() => { try { c.kill('SIGKILL') } catch (_) {} }, ms + 2000)
  })
}

function ytOk() {
  return new Promise(r => execFile('yt-dlp', ['--version'], { timeout: 5000 }, e => r(!e)))
}

/* Baixa um vídeo genérico via yt-dlp e devolve o Buffer + limpa o arquivo temp */
async function baixarComYtDlp(link, tmpPrefix, ms = 60000) {
  const fs = require('fs')
  const tmp = `./${tmpPrefix}_${Date.now()}`
  try {
    await shell(`yt-dlp --no-warnings -f "best[ext=mp4]/best" --merge-output-format mp4 -o "${tmp}.%(ext)s" "${link}"`, ms)
    const arquivo = fs.readdirSync('.').find(f => f.startsWith(`${tmpPrefix}_`) && !f.endsWith('.part'))
    if (!arquivo) return null
    const buffer = fs.readFileSync(arquivo)
    fs.unlinkSync(arquivo)
    return buffer
  } catch (e) {
    try {
      const fsx = require('fs')
      fsx.readdirSync('.').filter(f => f.startsWith(`${tmpPrefix}_`)).forEach(f => fsx.unlinkSync(f))
    } catch (_e) {}
    throw e
  }
}

module.exports = { shell, ytOk, baixarComYtDlp }
