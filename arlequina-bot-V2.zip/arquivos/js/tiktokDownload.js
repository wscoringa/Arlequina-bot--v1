const axios = require('axios')

const HEADERS = {
  'User-Agent':
    'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 ' +
    '(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
  'Accept': 'application/json, text/plain, */*',
  'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'
}

const TIMEOUT = 20000

function ehErroCloudflare(error) {
  const status = error?.response?.status

  if (status === 403 || status === 429) return true

  const msg = String(error?.message || '').toLowerCase()

  return (
    msg.includes('cloudflare') ||
    msg.includes('403') ||
    msg.includes('429') ||
    msg.includes('access denied')
  )
}

function extrairUrl(obj) {
  if (!obj) return null

  if (typeof obj === 'string') {
    return /^https?:\/\//i.test(obj) ? obj : null
  }

  const campos = [
    'play',
    'play_url',
    'playUrl',
    'download',
    'download_url',
    'downloadUrl',
    'video_url',
    'videoUrl',
    'hdplay',
    'hd_play',
    'wmplay',
    'wm_play',
    'nowm',
    'no_watermark',
    'noWatermark',
    'url'
  ]

  for (const campo of campos) {
    const valor = obj[campo]

    if (
      typeof valor === 'string' &&
      /^https?:\/\//i.test(valor)
    ) {
      return valor
    }
  }

  const filhos = [
    obj.video,
    obj.data,
    obj.result,
    obj.item
  ]

  for (const filho of filhos) {
    const url = extrairUrl(filho)

    if (url) return url
  }

  return null
}

function extrairAutor(obj) {
  if (!obj) return {}

  const author =
    obj.author ||
    obj.user ||
    obj.creator ||
    obj.owner ||
    {}

  return {
    unique_id:
      author.unique_id ||
      author.uniqueId ||
      author.username ||
      author.user_name ||
      author.unique ||
      obj.unique_id ||
      obj.username ||
      '?',

    nickname:
      author.nickname ||
      author.nickName ||
      author.name ||
      obj.nickname ||
      ''
  }
}

function normalizarVideo(obj) {
  if (!obj) return null

  const play = extrairUrl(obj)

  if (!play) return null

  return {
    play,

    title:
      obj.title ||
      obj.desc ||
      obj.description ||
      obj.caption ||
      'TikTok',

    author: extrairAutor(obj),

    cover:
      obj.cover ||
      obj.cover_url ||
      obj.coverUrl ||
      obj.thumbnail ||
      obj.thumbnail_url ||
      null,

    music:
      obj.music ||
      obj.music_info ||
      null,

    raw: obj
  }
}

function extrairLista(data) {
  if (!data) return []

  const possiveis = [
    data,
    data.data,
    data.result,
    data.results,
    data.items,
    data.videos,
    data.data?.videos,
    data.data?.items,
    data.result?.videos,
    data.result?.items
  ]

  for (const lista of possiveis) {
    if (Array.isArray(lista)) {
      return lista
    }
  }

  return []
}

/*
 * DOWNLOAD POR LINK
 */

async function tentarTikwmLink(url) {
  const hosts = [
    'https://www.tikwm.com',
    'https://tikwm.com'
  ]

  let ultimoErro = null

  for (const host of hosts) {
    try {
      console.log(`📦 Tentando TikWM: ${host}`)

      const response = await axios.get(`${host}/api/`, {
        params: {
          url,
          hd: 1
        },

        headers: HEADERS,
        timeout: TIMEOUT,
        validateStatus: () => true
      })

      console.log(`📦 TikWM status: ${response.status}`)

      if (response.status !== 200) {
        ultimoErro = new Error(
          `TikWM HTTP ${response.status}`
        )

        ultimoErro.response = response

        continue
      }

      const data =
        response.data?.data ||
        response.data

      const video = normalizarVideo(data)

      if (video) {
        return video
      }

      ultimoErro = new Error(
        'TikWM não retornou URL do vídeo'
      )

    } catch (error) {
      ultimoErro = error

      console.log(
        `⚠️ TikWM erro: ${error?.message || error}`
      )
    }
  }

  throw (
    ultimoErro ||
    new Error('TikWM indisponível')
  )
}

async function tentarVexApi(url, apiKey) {
  if (!apiKey) return null

  const endpoints = [
    'https://api.vexapi.com/api/tiktok',
    'https://api.vexapi.com/tiktok'
  ]

  for (const endpoint of endpoints) {
    try {
      const response = await axios.get(
        endpoint,
        {
          params: {
            url,
            apikey: apiKey
          },

          headers: HEADERS,
          timeout: TIMEOUT
        }
      )

      const video = normalizarVideo(
        response.data?.data ||
        response.data?.result ||
        response.data
      )

      if (video) {
        console.log(
          '✅ VexAPI encontrou o vídeo'
        )

        return video
      }

    } catch (error) {
      console.log(
        `⚠️ VexAPI: ${error?.message || error}`
      )
    }
  }

  return null
}

async function baixarPorLink(url, apiKey) {
  if (!url) {
    throw new Error(
      'Link do TikTok não informado'
    )
  }

  console.log(
    `🔗 TikTok: ${url}`
  )

  /*
   * Primeiro tenta API configurada
   */

  if (apiKey) {
    const vex = await tentarVexApi(
      url,
      apiKey
    )

    if (vex) {
      return vex
    }
  }

  /*
   * Depois TikWM
   */

  try {
    return await tentarTikwmLink(url)

  } catch (error) {

    console.log(
      `⚠️ TikWM falhou: ${error?.message || error}`
    )
  }

  throw new Error(
    'Não foi possível baixar o vídeo do TikTok.'
  )
}

/*
 * BUSCA POR NOME
 *
 * Aqui não vamos mais chamar os hosts que deram:
 *
 * 403
 * ENOTFOUND
 * certificado SSL inválido
 *
 * Em vez de fingir que encontrou um vídeo,
 * retornamos null corretamente.
 */

async function buscarPorNome(query) {
  if (!query || !String(query).trim()) {
    return null
  }

  query = String(query).trim()

  console.log(
    `🔎 Procurando no TikTok: ${query}`
  )

  /*
   * IMPORTANTE:
   *
   * Não existe aqui uma API oficial simples do TikTok
   * que aceite "edite flamengo" e devolva diretamente
   * uma URL de download.
   *
   * Portanto não vou colocar outro domínio aleatório.
   */

  return null
}

async function buscarListaPorNome(query) {
  const video = await buscarPorNome(query)

  return video ? [video] : []
}

async function buscarTrending() {
  return []
}

async function buscarTikwm(query) {
  console.log(
    `⚠️ TikWM Search indisponível para: ${query}`
  )

  return []
}

async function buscarAlternativos(query) {
  console.log(
    `⚠️ Busca alternativa indisponível para: ${query}`
  )

  return []
}

module.exports = {
  baixarPorLink,
  buscarPorNome,
  buscarListaPorNome,
  buscarTrending,
  buscarTikwm,
  buscarAlternativos,
  ehErroCloudflare,
  normalizarVideo
}
