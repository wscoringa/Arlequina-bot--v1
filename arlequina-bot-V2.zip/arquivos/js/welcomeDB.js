/*
  Sistema de Boas-vindas / Saída - banco de dados + helpers compartilhados
  Arlequina Bot

  Antes disso, o bot tinha 3 sistemas concorrentes e incompatíveis:
  - welkon.json + legendas.json (usado de fato pelo listener em conexao.js)
  - adminState.welcome (em memória, usado pelos comandos fundobv/fundosair/
    setwelcome/legendasair/resetwelcome/listfundos, mas NUNCA lido pelo listener)
  - imagens e textos fixos, sem placeholder de nome de grupo

  Esse arquivo unifica tudo em UM único JSON persistente (sobrevive a reinícios
  do bot, diferente do adminState que é só em memória).
*/
const fs = require('fs')
const path = require('path')

const dbPath = './arquivos/json/welcome.json'
const fundosDir = './midias/fundos'

const IMG_ENTRADA_PADRAO = 'https://files.catbox.moe/mjxxwp.jpeg'
const IMG_SAIDA_PADRAO = 'https://files.catbox.moe/9i38ij.jpeg'

const LEGENDA_ENTRADA_PADRAO =
`╭᯽༊·˚༊·˚˚₊‧꒰ა ᯽ ໒꒱ ‧₊˚˚༊·˚༊᯽╮
            𝗕𝗲𝗺-𝘃𝗶𝗻𝗱𝗼(𝗮):
{usuario}!

Seja bem-vindo(a) ao grupo {grupo}! 🌸
Agora somos {membros} membros.

╰᯽༊·˚༊·˚˚₊‧꒰ა ᯽ ໒꒱ ‧₊˚˚༊·˚༊᯽╯`

const LEGENDA_SAIDA_PADRAO =
`╭᯽༊·˚༊·˚˚₊‧꒰ა ᯽ ໒꒱ ‧₊˚˚༊·˚༊᯽╮
            *SAYŌNARA*
{usuario} saiu do grupo {grupo}. 🥀

Até mais, você vai fazer falta!

╰᯽༊·˚༊·˚˚₊‧꒰ა ᯽ ໒꒱ ‧₊˚˚₊‧꒰᯽╯`

// Usada quando a saída NÃO foi por vontade própria — foi um admin que
// removeu a pessoa. Diferente da saída normal, essa deixa claro que foi
// removido(a) e por quem.
const LEGENDA_REMOVIDO_PADRAO =
`╭᯽༊·˚༊·˚˚₊‧꒰ა ᯽ ໒꒱ ‧₊˚˚༊·˚༊᯽╮
        *🚫 REMOVIDO(A)*
{usuario} foi removido(a)
do grupo {grupo}.

👑 ADM que removeu: {admin}

╰᯽༊·˚༊·˚˚₊‧꒰ა ᯽ ໒꒱ ‧₊˚˚₊‧꒰᯽╯`

function carregar() {
  if (!fs.existsSync('./arquivos/json')) fs.mkdirSync('./arquivos/json', { recursive: true })
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify({}, null, 2))
  try {
    return JSON.parse(fs.readFileSync(dbPath, 'utf-8'))
  } catch {
    return {}
  }
}

function salvar(dados) {
  try {
    fs.writeFileSync(dbPath, JSON.stringify(dados, null, 2))
  } catch (e) {
    console.log('❌ Erro ao salvar welcome.json:', e?.message)
  }
}

// Pega (e cria se não existir) a config de um grupo específico
function getConfig(groupId) {
  const dados = carregar()
  if (!dados[groupId]) {
    dados[groupId] = {
      ativo: false,
      comFoto: true,
      entrada: null, // null = usa a legenda padrão de exemplo
      saida: null,
      fundoEntrada: null, // caminho local de imagem custom, ou null = usa a padrão
      fundoSaida: null
    }
    salvar(dados)
  }
  // merge com defaults, caso o json antigo não tenha algum campo novo
  return {
    ativo: false,
    comFoto: true,
    entrada: null,
    saida: null,
    fundoEntrada: null,
    fundoSaida: null,
    ...dados[groupId]
  }
}

function setConfig(groupId, patch) {
  const dados = carregar()
  dados[groupId] = { ...getConfig(groupId), ...dados[groupId], ...patch }
  salvar(dados)
  return dados[groupId]
}

function resetConfig(groupId) {
  const dados = carregar()
  const cfg = dados[groupId]

  // apaga arquivos de fundo customizados do disco, se existirem, pra não
  // deixar imagem órfã acumulando em ./midias/fundos
  for (const campo of ['fundoEntrada', 'fundoSaida']) {
    const p = cfg?.[campo]
    if (p && fs.existsSync(p)) {
      try { fs.unlinkSync(p) } catch {}
    }
  }

  delete dados[groupId]
  salvar(dados)
}

function listarComFundo() {
  const dados = carregar()
  return Object.entries(dados).filter(([_id, cfg]) => cfg.fundoEntrada || cfg.fundoSaida)
}

// Substitui os placeholders aceitos na legenda.
// Aceita tanto {usuario}/{grupo}/{membros} quanto os tokens antigos @usuario/@grupo
// (compatibilidade com as legendas já configuradas pelos comandos antigos).
function renderizarLegenda(texto, { numeroUsuario, nomeGrupo, totalMembros, nomeAdmin }) {
  return String(texto || '')
    // {usuario} / {usuário} / { usuário } / {nome} - com ou sem espaço/acento
    .replace(/\{\s*usu[aá]rio\s*\}/gi, `@${numeroUsuario}`)
    .replace(/\{\s*nome\s*\}/gi, `@${numeroUsuario}`)
    .replace(/@usuario/gi, `@${numeroUsuario}`)
    // {grupo} / { grupo } / {nomedogrupo} / {nome do grupo}
    .replace(/\{\s*grupo\s*\}/gi, nomeGrupo)
    .replace(/\{\s*nome\s*(do)?\s*grupo\s*\}/gi, nomeGrupo)
    .replace(/@grupo/gi, nomeGrupo)
    // {membros} / {membro} / {total} / { membros }
    .replace(/\{\s*membros?\s*\}/gi, String(totalMembros))
    .replace(/\{\s*total\s*\}/gi, String(totalMembros))
    // {admin} / {adm} - só faz sentido quando alguém foi removido por outra pessoa
    .replace(/\{\s*adm(in)?\s*\}/gi, nomeAdmin ? `@${nomeAdmin}` : 'um administrador')
}

function garantirPastaFundos() {
  if (!fs.existsSync(fundosDir)) fs.mkdirSync(fundosDir, { recursive: true })
}

module.exports = {
  dbPath,
  fundosDir,
  IMG_ENTRADA_PADRAO,
  IMG_SAIDA_PADRAO,
  LEGENDA_ENTRADA_PADRAO,
  LEGENDA_SAIDA_PADRAO,
  LEGENDA_REMOVIDO_PADRAO,
  carregar,
  salvar,
  getConfig,
  setConfig,
  resetConfig,
  listarComFundo,
  renderizarLegenda,
  garantirPastaFundos
}
