/*
 Cabeçalho "🃏 {nome do bot ao vivo} / 👤 Contato: {nome de quem mandou} ✓"
 injetado nas respostas do bot. Nada fixo — os dois nomes vêm direto do
 WhatsApp:

 - Nome do bot: puxado de sock.user.name, que é o nome de perfil da
   PRÓPRIA conta do bot no WhatsApp. Se o dono mudar o nome da conta,
   o cabeçalho muda sozinho, sem precisar editar nada no código.
 - Nome do contato: puxado do pushName de quem mandou a mensagem que
   está sendo respondida (o "nome de exibição" que a pessoa configurou
   no WhatsApp dela).
*/

// Guarda o pushName de quem mandou a última mensagem em cada chat, pra
// usar como contato mesmo quando a resposta não vem com "quoted".
const ultimoPushName = new Map()

function registrarPushName(from, pushName) {
  if (from && pushName) ultimoPushName.set(from, pushName)
}

function montarCabecalho(sock, from, pushNameDireto) {
  const nomeBot = sock?.user?.name || sock?.user?.verifiedName || 'Bot'
  const nomeContato = pushNameDireto || ultimoPushName.get(from) || 'Usuário'
  return `🃏 *${nomeBot}*\n👤 Contato: ${nomeContato} ✓\n\n`
}

function deveIgnorar(content, options) {
  if (global.ENABLE_CABECALHO_CONTATO === false) return true
  if (options?.__semCabecalho) return true
  if (!content || typeof content !== 'object') return true
  if ('react' in content) return true
  if ('delete' in content) return true
  if ('pin' in content) return true
  return false
}

function aplicarCabecalhoContato(sock) {
  if (!sock || sock.__cabecalhoContatoAplicado) return sock
  sock.__cabecalhoContatoAplicado = true

  const sendOriginal = sock.sendMessage.bind(sock)

  sock.sendMessage = async (jid, content, options = {}) => {
    try {
      if (!deveIgnorar(content, options)) {
        const pushNameQuoted = options?.quoted?.pushName
        const cabecalho = montarCabecalho(sock, jid, pushNameQuoted)
        // Manda o cabeçalho como uma mensagem PRÓPRIA, ANTES da
        // resposta de verdade — assim ele aparece como uma "caixinha"
        // separada em cima, e não colado dentro da legenda da foto.
        await sendOriginal(jid, { text: cabecalho.trim() })
      }
    } catch (_e) {}
    return sendOriginal(jid, content, options)
  }

  return sock
}

module.exports = { registrarPushName, montarCabecalho, aplicarCabecalhoContato }
