/*
 Metadado (pack name / author) usado em toda figurinha criada pelo bot
 (!sticker, !autosticker, !ttp, !brat, !emojimix...). Formatado igual o
 "ver detalhes" de figurinha, no estilo "CRIADA POR / NICK DONO / FEITA
 POR / GRUPO" — mas agora dinâmico: pega o nome do bot e do dono do
 config.json, e o nome de quem pediu + o grupo de verdade onde foi
 pedido (não fica mais fixo/hardcoded).
*/
function metaFigurinha({ pushname, sender, groupName, config } = {}) {
  const numeroPuro = String(sender || '').split('@')[0]
  const nomeQuemPediu = pushname || numeroPuro || 'Alguém'
  const nomeGrupoAtual = groupName || 'Privado'
  const nomeBot = config?.NomeDoBot || 'Arlequina Bot'
  const nomeDono = config?.NomeDoDono || 'coringa'

  const packname =
`*・ﾟ⤹・*・ﾟ⤹ CRIADA POR ⤸
   ↳「${nomeBot}」

*・ﾟ⤹・*・ﾟ⤹ NICK DONO ⤸
   ↳「${nomeDono}」`

  const author =
`⇨ ⋆˙🥀⋆˙ FEITA POR ⤸
   ↳「${nomeQuemPediu}」

⇨ ⋆˙💌⋆˙ GRUPO ⤸
   ↳「${nomeGrupoAtual}」`

  return { packname, author }
}

module.exports = { metaFigurinha }
