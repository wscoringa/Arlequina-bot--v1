const axios = require('axios')
const { baixarBufferUrl, converterGifParaMp4 } = require('./brincadeirasHelpers.js')
const { caixaArlequina } = require('./estiloArlequina.js')
const { checarModo18, pegarAlvo } = require('./modo18Helper.js')

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
const AX = { timeout: 18000, headers: { 'User-Agent': UA, Accept: 'application/json' } }
const BLOQUEIO = '-loli -shota -young -child -underage -toddlercon -cub'

/*
  Cada comando tem TAGS da CENA CERTA + sempre "censored".
  Ordem: tenta GIF (konachan animated) → yande (imagem censurada da cena).
*/
const CENAS = {
  // mulher fazendo boquete no homem
  mamar: {
    tags: [
      'censored fellatio',
      'censored paizuri',
      'censored oral penis'
    ],
    gifTags: ['animated censored paizuri', 'animated censored sex']
  },
  chupar: {
    tags: [
      'censored fellatio',
      'censored paizuri',
      'censored oral penis'
    ],
    gifTags: ['animated censored paizuri', 'animated censored sex']
  },
  // homem pegando peito da mulher
  peitos: {
    tags: [
      'censored breast_grab',
      'censored grabbing_breasts',
      'censored paizuri',
      'censored breasts grab'
    ],
    gifTags: ['animated censored breasts', 'animated censored paizuri']
  },
  // homem comendo a mulher
  comer: {
    tags: [
      'censored sex vaginal',
      'censored sex',
      'censored penetration',
      'censored missionary'
    ],
    gifTags: ['animated censored sex']
  },
  // homem gozando na cara
  gozar: {
    tags: [
      'censored cum_on_face',
      'censored facial',
      'censored cum face',
      'censored bukkake'
    ],
    gifTags: ['animated censored cum']
  },
  // mulher sentando no homem
  sentar: {
    tags: [
      'censored cowgirl_position',
      'censored girl_on_top',
      'censored straddling sex',
      'censored sex'
    ],
    gifTags: ['animated censored sex']
  },
  // homem e mulher fazendo sexo
  trepar: {
    tags: [
      'censored sex',
      'censored vaginal',
      'censored penetration'
    ],
    gifTags: ['animated censored sex']
  },
  // tapa/pegar bunda
  pgbunda: {
    tags: [
      'censored ass grab',
      'censored spanked',
      'censored ass',
      'censored covering_ass'
    ],
    gifTags: ['animated censored ass', 'animated censored sex']
  },
  nalgada: {
    tags: [
      'censored spanked',
      'censored spanking',
      'censored ass'
    ],
    gifTags: ['animated censored ass', 'animated censored sex']
  },
  // mulher pegando pau do homem
  pgpau: {
    tags: [
      'censored handjob',
      'censored penis',
      'censored handjob penis'
    ],
    gifTags: ['animated censored sex', 'animated censored paizuri']
  },
  // beijo de língua
  beijao18: {
    tags: [
      'censored kissing',
      'censored french_kiss',
      'censored kissing sex',
      'censored fingering'
    ],
    gifTags: ['animated censored sex']
  }
}

function embaralhar(a) {
  return [...a].sort(() => Math.random() - 0.5)
}

function postOk(p, exigirGif) {
  const t = String(p.tags || '').toLowerCase()
  if (/loli|shota|young|child|toddler|cub|underage/.test(t)) return false
  if (!/\bcensored\b/.test(t)) return false
  const ext = String(p.file_ext || '').toLowerCase()
  const url = p.file_url || p.sample_url || p.jpeg_url || ''
  if (!url) return false
  if (exigirGif) {
    return ext === 'gif' || ext === 'webm' || ext === 'mp4' || /\.(gif|webm|mp4)(\?|$)/i.test(url)
  }
  return true
}

async function buscarKonachan(tagQuery, soGif) {
  const tags = `${tagQuery} ${BLOQUEIO}`.trim()
  const { data } = await axios.get(
    `https://konachan.com/post.json?limit=25&tags=${encodeURIComponent(tags)}`,
    AX
  )
  if (!Array.isArray(data)) return null
  const ok = data.filter(p => postOk(p, soGif))
  if (!ok.length) return null
  const p = ok[Math.floor(Math.random() * ok.length)]
  return { url: p.file_url || p.sample_url, ext: p.file_ext }
}

async function buscarYandere(tagQuery) {
  const tags = `${tagQuery} ${BLOQUEIO}`.trim()
  const { data } = await axios.get(
    `https://yande.re/post.json?limit=25&tags=${encodeURIComponent(tags)}`,
    AX
  )
  if (!Array.isArray(data)) return null
  const ok = data.filter(p => postOk(p, false))
  if (!ok.length) return null
  const p = ok[Math.floor(Math.random() * ok.length)]
  // sample é menor e carrega mais rápido; file se for gif
  const ext = String(p.file_ext || '').toLowerCase()
  const url = (ext === 'gif' ? p.file_url : null) || p.sample_url || p.jpeg_url || p.file_url
  return { url, ext }
}

async function buscarCena(tipo) {
  const cena = CENAS[tipo] || CENAS.comer

  // 1) tenta GIF animado censurado da cena
  for (const tag of embaralhar(cena.gifTags || [])) {
    try {
      const r = await buscarKonachan(tag, true)
      if (r?.url) return r
    } catch (e) {
      console.log('[acao18] kona gif', tag, e?.message)
    }
  }

  // 2) yande: imagem/gif da CENA CERTA com censura
  for (const tag of embaralhar(cena.tags || [])) {
    try {
      const r = await buscarYandere(tag)
      if (r?.url) return r
    } catch (e) {
      console.log('[acao18] yande', tag, e?.message)
    }
  }

  // 3) konachan imagem/gif genérico censored sex (último recurso)
  try {
    const r = await buscarKonachan('animated censored sex', true)
    if (r?.url) return r
  } catch (_) {}
  try {
    const r = await buscarYandere('censored sex')
    if (r?.url) return r
  } catch (_) {}

  return null
}

async function enviarMidia(arlequina, from, info, media, txt, mentions) {
  const url = media.url
  const buf = await baixarBufferUrl(url)
  if (!buf || buf.length < 200) throw new Error('download vazio')

  const isGif =
    String(media.ext).toLowerCase() === 'gif' ||
    /\.(gif)(\?|$)/i.test(url) ||
    (buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46)

  if (isGif || /\.(webp)(\?|$)/i.test(url)) {
    try {
      const videoBuffer = await converterGifParaMp4(buf)
      if (videoBuffer && videoBuffer.length > 500) {
        return arlequina.sendMessage(from, {
          video: videoBuffer,
          gifPlayback: true,
          caption: txt,
          mentions
        }, { quoted: info })
      }
    } catch (e) {
      console.log('[acao18] gif->mp4:', e?.message)
    }
  }

  if (isGif || /\.(mp4|webm)(\?|$)/i.test(url)) {
    return arlequina.sendMessage(from, {
      video: buf,
      gifPlayback: true,
      caption: txt,
      mentions
    }, { quoted: info })
  }

  return arlequina.sendMessage(from, {
    image: buf,
    caption: txt,
    mentions
  }, { quoted: info })
}

async function enviarAcao18(ctx, opts) {
  const { arlequina, from, info, reply, reagir, sender, isGroup, prefix } = ctx
  const { name, emoji, title, frases, tipoApi } = opts

  if (!checarModo18({ from, isGroup, reply, prefix })) return
  const alvo = pegarAlvo(info)
  if (!alvo) return reply('❌ Marque alguém com @!\nEx: *' + (prefix || '!') + name + ' @pessoa*')

  await reagir(emoji || '🔥')

  let frase = frases[Math.floor(Math.random() * frases.length)]
  frase = frase
    .replace(/\{sender\}/g, sender.split('@')[0])
    .replace(/\{alvo\}/g, alvo.split('@')[0])
  const txt = caixaArlequina(name, `${emoji} *${title}* ${emoji}\n\n${frase}`)
  const mentions = [sender, alvo]

  try {
    const media = await buscarCena(tipoApi || name)
    if (!media?.url) throw new Error('sem mídia censurada')
    console.log('[acao18]', name, '→', media.ext, String(media.url).slice(0, 90))
    await enviarMidia(arlequina, from, info, media, txt, mentions)
  } catch (e) {
    console.error(`ERRO ${name}:`, e?.message || e)
    return arlequina.sendMessage(from, {
      text: txt + '\n\n_⚠️ Mídia censurada indisponível agora, tenta de novo._',
      mentions
    }, { quoted: info })
  }
}

function criarComando18({ name, aliases, emoji, title, frases, tipoApi }) {
  return {
    name,
    description: `${emoji} ${title} (hentai censurado — modo18)`,
    category: 'social',
    aliases: aliases || [],
    async execute(ctx) {
      return enviarAcao18(ctx, { name, emoji, title, frases, tipoApi: tipoApi || name })
    }
  }
}

module.exports = { buscarCena, enviarAcao18, criarComando18, CENAS }
