/*
  "Ver canal" / encaminhada em todas as mensagens do bot.
  Nem todo celular mostra o botão igual (limitação do app WhatsApp),
  mas o contexto é injetado em todo sendMessage possível.

  IMPORTANTE: o "newsletterJid" tem que ser o JID DE VERDADE do canal
  (tipo 120363xxxxxxxxxx@newsletter) — o código que aparece no link
  (ex: 0029VbDFppvCBtx6Qbn4nX1x) é só um CONVITE, não o JID. Por isso
  aqui a gente resolve o JID de verdade chamando a API do Baileys
  (sock.newsletterMetadata) assim que o bot conecta, e cacheia o
  resultado — sem isso o WhatsApp não sabe qual canal mostrar e o
  botão simplesmente não aparece (mesmo com o resto do contexto certo).
*/
const CODIGO_CONVITE = '0029VbDFppvCBtx6Qbn4nX1x' // código que vem depois de /channel/ no link
const NEWSLETTER_NAME = '💜 𝗔𝗥𝗟𝗘𝗤𝗨𝗜𝗡𝗔 😈'

let NEWSLETTER_JID_RESOLVIDO = null

const CTX_NL_BASE = {
  forwardingScore: 999999,
  isForwarded: true
}

function montarCtxNl() {
  if (!NEWSLETTER_JID_RESOLVIDO) return null
  return {
    ...CTX_NL_BASE,
    forwardedNewsletterMessageInfo: {
      newsletterJid: NEWSLETTER_JID_RESOLVIDO,
      newsletterName: NEWSLETTER_NAME,
      serverMessageId: 1
    }
  }
}

// Resolve o JID de verdade uma vez só e guarda em memória. Chamado
// assim que o bot conecta (dentro de aplicarVerCanal) — não precisa
// esperar isso terminar pra continuar funcionando, é "fire and forget".
async function resolverNewsletterJid(sock) {
  if (NEWSLETTER_JID_RESOLVIDO) return NEWSLETTER_JID_RESOLVIDO
  try {
    const meta = await sock.newsletterMetadata('invite', CODIGO_CONVITE)
    if (meta?.id) {
      NEWSLETTER_JID_RESOLVIDO = meta.id
      console.log(`✅ [verCanal] JID do canal resolvido: ${NEWSLETTER_JID_RESOLVIDO}`)
    } else {
      console.log('⚠️ [verCanal] Não consegui resolver o JID do canal (metadata veio vazia). O selo "ver canal" não vai aparecer até isso funcionar.')
    }
  } catch (e) {
    console.log('⚠️ [verCanal] Erro ao resolver o JID do canal:', e?.message)
  }
  return NEWSLETTER_JID_RESOLVIDO
}

function deveIgnorar(content) {
  if (global.ENABLE_CHANNEL === false) return true
  if (!content || typeof content !== 'object') return true
  if ('react' in content) return true
  if ('delete' in content) return true
  if ('pin' in content) return true
  return false
}

function aplicarVerCanal(sock) {
  if (!sock || sock.__verCanalAplicado) return sock
  sock.__verCanalAplicado = true

  resolverNewsletterJid(sock)

  const sendOriginal = sock.sendMessage.bind(sock)

  sock.sendMessage = async (jid, content, options = {}) => {
    try {
      const ctxNl = montarCtxNl()
      if (ctxNl && !deveIgnorar(content)) {
        // Mescla no content e no options (alguns caminhos do Baileys usam um ou outro)
        const prev = content.contextInfo || options.contextInfo || {}
        // preserva mentions/quoted já existentes
        content.contextInfo = {
          ...ctxNl,
          ...prev,
          forwardedNewsletterMessageInfo: {
            ...ctxNl.forwardedNewsletterMessageInfo,
            ...(prev.forwardedNewsletterMessageInfo || {})
          },
          forwardingScore: Math.max(prev.forwardingScore || 0, ctxNl.forwardingScore),
          isForwarded: true
        }
        if (options && typeof options === 'object') {
          options.contextInfo = {
            ...(options.contextInfo || {}),
            ...content.contextInfo
          }
        }
      }
    } catch (_e) {}
    return sendOriginal(jid, content, options)
  }

  return sock
}

module.exports = { montarCtxNl, CODIGO_CONVITE, NEWSLETTER_NAME, aplicarVerCanal, resolverNewsletterJid }
