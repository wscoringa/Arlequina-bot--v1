/*
  Sessões de criação de pack de figurinhas.
  Permite coletar várias fotos (1–64+) e depois gerar todas com o mesmo
  packname/author.
*/
const sessoes = new Map()

const MAX_FOTOS = 64
const TIMEOUT_MS = 5 * 1000 // 5s sem foto nova → finaliza sozinho

function chave(from, sender) {
  return `${String(from)}|${String(sender || '').split('@')[0]}`
}

function get(from, sender) {
  return sessoes.get(chave(from, sender)) || null
}

function iniciar(from, sender, nomePack, onTimeout) {
  const k = chave(from, sender)
  const antiga = sessoes.get(k)
  if (antiga?.timer) clearTimeout(antiga.timer)

  const sessao = {
    nomePack,
    midias: [], // { tipo: 'image'|'video', msg, buffer? }
    criadoEm: Date.now(),
    timer: null,
    onTimeout
  }

  const resetTimer = () => {
    if (sessao.timer) clearTimeout(sessao.timer)
    sessao.timer = setTimeout(() => {
      const s = sessoes.get(k)
      if (s && s.midias.length > 0 && typeof s.onTimeout === 'function') {
        s.onTimeout(s)
      }
      sessoes.delete(k)
    }, TIMEOUT_MS)
  }

  sessao.resetTimer = resetTimer
  resetTimer()
  sessoes.set(k, sessao)
  return sessao
}

function adicionar(from, sender, item) {
  const s = get(from, sender)
  if (!s) return null
  if (s.midias.length >= MAX_FOTOS) return { cheio: true, sessao: s }
  s.midias.push(item)
  if (s.resetTimer) s.resetTimer()
  return { cheio: false, sessao: s }
}

function finalizar(from, sender) {
  const k = chave(from, sender)
  const s = sessoes.get(k)
  if (!s) return null
  if (s.timer) clearTimeout(s.timer)
  sessoes.delete(k)
  return s
}

function cancelar(from, sender) {
  const k = chave(from, sender)
  const s = sessoes.get(k)
  if (s?.timer) clearTimeout(s.timer)
  sessoes.delete(k)
  return !!s
}

module.exports = {
  get,
  iniciar,
  adicionar,
  finalizar,
  cancelar,
  MAX_FOTOS,
  TIMEOUT_MS
}
