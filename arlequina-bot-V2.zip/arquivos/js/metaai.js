const IGNORAR = [
  'react',
  'delete',
  'forward',
  'disappearingMessagesInMessage',
  'pin',
  'edit'
]

function obterArlequinaJid(sock) {
  const id = sock?.user?.id

  if (!id || typeof id !== 'string') {
    return null
  }

  const numero = id
    .split('@')[0]
    .split(':')[0]
    .replace(/\D/g, '')

  if (!numero) {
    return null
  }

  return `${numero}@s.whatsapp.net`
}

function obterArlequinaNumero(sock) {
  const jid = obterArlequinaJid(sock)

  if (!jid) {
    return null
  }

  return jid
    .split('@')[0]
    .split(':')[0]
    .replace(/\D/g, '')
}

function criarFakeArlequina(sock) {
  const ARLEQUINA_JID = obterArlequinaJid(sock)
  const numero = obterArlequinaNumero(sock)

  if (!ARLEQUINA_JID || !numero) {
    return null
  }

  return {
    key: {
      fromMe: false,
      participant: ARLEQUINA_JID,
      remoteJid: 'status@broadcast'
    },

    message: {
      contactMessage: {
        displayName: 'AЯLΣQUINA BOT',
        vcard:
          'BEGIN:VCARD\nVERSION:3.0\nN:;AЯLΣQUINA BOT;;;\nFN:AЯLΣQUINA BOT\n' +
          `item1.TEL;waid=${numero}:+${numero}\n` +
          'item1.X-ABLabel:Celular\nEND:VCARD'
      }
    }
  }
}

function aplicarArlequinaMark(sock) {
  if (!sock || sock.__arlequinaMarkAplicado) return

  const original = sock.sendMessage.bind(sock)

  sock.sendMessage = (jid, content, options = {}) => {
    const ligado =
      global.ENABLE_ARLEQUINA_MARK !== false

    const ignorar =
      !content ||
      IGNORAR.some(k => k in content) ||
      jid === 'status@broadcast'

    if (!ligado || ignorar) {
      return original(jid, content, options)
    }

    const FAKE_ARLEQUINA = criarFakeArlequina(sock)

    if (!FAKE_ARLEQUINA) {
      return original(jid, content, options)
    }

    return original(jid, content, {
      ...options,
      quoted: FAKE_ARLEQUINA
    })
  }

  sock.__arlequinaMarkAplicado = true
}

export {
  aplicarArlequinaMark,
  criarFakeArlequina
}
