const donoState = require('./donoState.js')
const { caixaArlequina } = require('./estiloArlequina.js')
function modo18Ativo(from) {
  return !!(donoState.modo18Grupos && donoState.modo18Grupos[from])
}
function checarModo18({ from, isGroup, reply, prefix }) {
  if (!isGroup) {
    reply(caixaArlequina('+18', '❌ Esse comando só funciona em *grupos*!'))
    return false
  }
  if (!modo18Ativo(from)) {
    reply(caixaArlequina('+18', `🔞 O *modo +18* está *desativado* neste grupo.\n\nPeça pra um ADM:\n*${prefix || '!'}modo18 1*`))
    return false
  }
  return true
}
function pegarAlvo(info) {
  const msg = info?.message || {}
  const ctx = msg.extendedTextMessage?.contextInfo || msg.imageMessage?.contextInfo || msg.videoMessage?.contextInfo || {}
  return ctx.participant || (ctx.mentionedJid && ctx.mentionedJid[0]) || null
}
module.exports = { modo18Ativo, checarModo18, pegarAlvo }
