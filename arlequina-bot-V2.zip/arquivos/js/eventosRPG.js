/*
 Estado compartilhado do sistema de "Pokémon selvagem" do RPG. A cada
 spawn (manual via !eventorpg ou automático), sorteia um Pokémon com
 raridade, nível e status aleatórios. Quem digitar !pegar primeiro
 leva a recompensa (moedas + XP).
*/

// groupJid -> { evento, expiraEm, cooldownAte }
const eventosAtivos = new Map()

const { porRaridade } = require('./pokedexData.js')
const EMOJI_TIER = { mitico: '🟢', supremo: '🔴', divino: '✨' }
// Constrói a lista {nome, emoji, tipo} de uma raridade a partir da
// pokedexData.js (fonte única de espécies/tipos)
function gerarListaDe(raridadeChave) {
  return porRaridade(raridadeChave).map(p => ({
    nome: p.nome,
    emoji: EMOJI_TIER[raridadeChave] || '⭐',
    tipo: p.tipos.join(' / ')
  }))
}

const DURACAO_EVENTO_MS = 90 * 1000 // 90s pra alguém pegar
const COOLDOWN_POR_GRUPO_MS = 5 * 60 * 1000 // 5 min entre spawns no mesmo grupo

// Faixas de status por raridade — "peso" define a chance de cada uma
// (soma dá 100). Lendário é raro de propósito, comum é o mais fácil.
const RARIDADES = {
  comum:    { label: 'Comum',    peso: 40, nivel: [5, 20],  vida: [150, 600],   forca: [40, 180],   defesa: [30, 150],  velocidade: [30, 120],  xp: [30, 90],   ouro: [50, 200] },
  raro:     { label: 'Raro',     peso: 24, nivel: [18, 32], vida: [500, 1200],  forca: [150, 400],  defesa: [120, 350], velocidade: [100, 260], xp: [90, 220],  ouro: [200, 550] },
  epico:    { label: 'Épico',    peso: 14, nivel: [30, 45], vida: [1000, 2200], forca: [380, 700],  defesa: [320, 620], velocidade: [220, 450], xp: [220, 450], ouro: [550, 1200] },
  lendario: { label: 'Lendário', peso: 12, nivel: [42, 60], vida: [2000, 3600], forca: [650, 1050], defesa: [560, 950], velocidade: [400, 750], xp: [420, 750], ouro: [1100, 2200] },
  mitico:   { label: 'Mítico',   peso: 6,  nivel: [55, 70], vida: [3200, 4200], forca: [1000, 1350], defesa: [900, 1200], velocidade: [850, 1150], xp: [700, 1100], ouro: [2000, 3500] },
  supremo:  { label: 'Supremo',  peso: 3,  nivel: [65, 80], vida: [4000, 5200], forca: [1300, 1700], defesa: [1150, 1500], velocidade: [1100, 1450], xp: [1000, 1600], ouro: [3200, 5000] },
  divino:   { label: 'Divino',   peso: 1,  nivel: [75, 100],vida: [5000, 7000], forca: [1650, 2200], defesa: [1500, 2000], velocidade: [1450, 1950], xp: [1500, 2500], ouro: [5000, 9000] },
}

// Pokémons possíveis por raridade — fracos nos comuns, fortes nos lendários.
const POKEMONS = {
  comum: [
    { nome: 'Rattata',  emoji: '🐭', tipo: 'Normal' },
    { nome: 'Pidgey',   emoji: '🐦', tipo: 'Normal / Voador' },
    { nome: 'Caterpie', emoji: '🐛', tipo: 'Inseto' },
    { nome: 'Weedle',   emoji: '🐝', tipo: 'Inseto / Veneno' },
    { nome: 'Zubat',    emoji: '🦇', tipo: 'Veneno / Voador' },
    { nome: 'Magikarp', emoji: '🐟', tipo: 'Água' },
    { nome: 'Bidoof',   emoji: '🦫', tipo: 'Normal' },
    { nome: 'Sentret',  emoji: '🐿️', tipo: 'Normal' },
    { nome: 'Poochyena', emoji: '🐺', tipo: 'Sombrio' },
    { nome: 'Ekans',    emoji: '🐍', tipo: 'Veneno' },
    { nome: 'Hoothoot', emoji: '🦉', tipo: 'Normal / Voador' },
    { nome: 'Spearow',  emoji: '🐤', tipo: 'Normal / Voador' },
    { nome: 'Wurmple',  emoji: '🐛', tipo: 'Inseto' },
    { nome: 'Taillow',  emoji: '🐦', tipo: 'Normal / Voador' },
    { nome: 'Starly',   emoji: '🐦', tipo: 'Normal / Voador' },
    { nome: 'Patrat',   emoji: '🐿️', tipo: 'Normal' },
    { nome: 'Lillipup', emoji: '🐶', tipo: 'Normal' },
    { nome: 'Bunnelby', emoji: '🐇', tipo: 'Normal' },
    { nome: 'Skwovet',  emoji: '🐿️', tipo: 'Normal' },
    { nome: 'Pichu',    emoji: '⚡', tipo: 'Elétrico' },
  ],
  raro: [
    { nome: 'Charmander', emoji: '🦎', tipo: 'Fogo' },
    { nome: 'Squirtle',   emoji: '🐢', tipo: 'Água' },
    { nome: 'Bulbasaur',  emoji: '🌱', tipo: 'Grama / Veneno' },
    { nome: 'Growlithe',  emoji: '🐕', tipo: 'Fogo' },
    { nome: 'Vulpix',     emoji: '🦊', tipo: 'Fogo' },
    { nome: 'Machop',     emoji: '💪', tipo: 'Lutador' },
    { nome: 'Eevee',      emoji: '🐾', tipo: 'Normal' },
    { nome: 'Abra',       emoji: '🔮', tipo: 'Psíquico' },
    { nome: 'Gastly',     emoji: '👻', tipo: 'Fantasma / Veneno' },
    { nome: 'Ponyta',     emoji: '🔥', tipo: 'Fogo' },
    { nome: 'Chikorita',  emoji: '🌿', tipo: 'Grama' },
    { nome: 'Cyndaquil',  emoji: '🔥', tipo: 'Fogo' },
    { nome: 'Totodile',   emoji: '🐊', tipo: 'Água' },
    { nome: 'Torchic',    emoji: '🐣', tipo: 'Fogo' },
    { nome: 'Mudkip',     emoji: '🐡', tipo: 'Água' },
    { nome: 'Snorunt',    emoji: '❄️', tipo: 'Gelo' },
    { nome: 'Riolu',      emoji: '🐕', tipo: 'Lutador' },
    { nome: 'Drifloon',   emoji: '🎈', tipo: 'Fantasma / Voador' },
    { nome: 'Ralts',      emoji: '💚', tipo: 'Psíquico / Fada' },
    { nome: 'Meowth',     emoji: '🐱', tipo: 'Normal' },
  ],
  epico: [
    { nome: 'Charizard', emoji: '🔥', tipo: 'Fogo / Voador' },
    { nome: 'Gyarados',  emoji: '🌊', tipo: 'Água / Voador' },
    { nome: 'Alakazam',  emoji: '🧠', tipo: 'Psíquico' },
    { nome: 'Machamp',   emoji: '👊', tipo: 'Lutador' },
    { nome: 'Gengar',    emoji: '👻', tipo: 'Fantasma / Veneno' },
    { nome: 'Lucario',   emoji: '🐺', tipo: 'Lutador / Aço' },
    { nome: 'Salamence', emoji: '🐲', tipo: 'Dragão / Voador' },
    { nome: 'Metagross', emoji: '🤖', tipo: 'Aço / Psíquico' },
    { nome: 'Tyranitar', emoji: '🗿', tipo: 'Sombrio / Pedra' },
    { nome: 'Garchomp',  emoji: '🦈', tipo: 'Dragão / Terra' },
    { nome: 'Blastoise', emoji: '🐢', tipo: 'Água' },
    { nome: 'Venusaur',  emoji: '🌿', tipo: 'Grama / Veneno' },
    { nome: 'Dragapult', emoji: '🐉', tipo: 'Dragão / Fantasma' },
    { nome: 'Hydreigon', emoji: '🐲', tipo: 'Sombrio / Dragão' },
    { nome: 'Aggron',    emoji: '🗿', tipo: 'Aço / Pedra' },
    { nome: 'Excadrill', emoji: '⛏️', tipo: 'Terra / Aço' },
    { nome: 'Greninja',  emoji: '🐸', tipo: 'Água / Sombrio' },
    { nome: 'Infernape', emoji: '🔥', tipo: 'Fogo / Lutador' },
  ],
  lendario: [
    { nome: 'Dragonite', emoji: '🐉', tipo: 'Dragão / Voador' },
    { nome: 'Mewtwo',    emoji: '🧬', tipo: 'Psíquico' },
    { nome: 'Rayquaza',  emoji: '🐍', tipo: 'Dragão / Voador' },
    { nome: 'Giratina',  emoji: '👑', tipo: 'Fantasma / Dragão' },
    { nome: 'Lugia',     emoji: '🌫️', tipo: 'Psíquico / Voador' },
    { nome: 'Zekrom',    emoji: '⚡', tipo: 'Dragão / Elétrico' },
    { nome: 'Reshiram',  emoji: '🔥', tipo: 'Dragão / Fogo' },
    { nome: 'Arceus',    emoji: '✨', tipo: 'Normal (Deus)' },
    { nome: 'Kyogre',    emoji: '🌊', tipo: 'Água' },
    { nome: 'Groudon',   emoji: '🌋', tipo: 'Terra' },
    { nome: 'Pikachu',   emoji: '⚡', tipo: 'Elétrico' },
    { nome: 'Mew',       emoji: '💗', tipo: 'Psíquico' },
    { nome: 'Xerneas',   emoji: '🦌', tipo: 'Fada' },
    { nome: 'Yveltal',   emoji: '🦅', tipo: 'Sombrio / Voador' },
    { nome: 'Solgaleo',  emoji: '🦁', tipo: 'Psíquico / Aço' },
    { nome: 'Lunala',    emoji: '🦇', tipo: 'Psíquico / Fantasma' },
    { nome: 'Zacian',    emoji: '🐺', tipo: 'Fada' },
    { nome: 'Eternatus', emoji: '👽', tipo: 'Veneno / Dragão' },
    { nome: 'Palkia',    emoji: '💎', tipo: 'Água / Dragão' },
    { nome: 'Dialga',    emoji: '⏳', tipo: 'Aço / Dragão' },
  ],
  // As 3 raridades novas puxam nome/tipo direto da pokedexData.js (fonte
  // única) em vez de repetir a lista na mão — assim !cacapokemon,
  // !pokegacha e !pokedex nunca ficam com espécies diferentes.
  mitico: gerarListaDe('mitico'),
  supremo: gerarListaDe('supremo'),
  divino: gerarListaDe('divino'),
}

function numAleatorio([min, max]) {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

// Formata número com ponto de milhar, tipo "2.850" (padrão BR)
function formatarNumero(n) {
  return Number(n).toLocaleString('pt-BR')
}

function sortearRaridade() {
  const total = Object.values(RARIDADES).reduce((s, r) => s + r.peso, 0)
  let roll = Math.random() * total
  for (const [chave, r] of Object.entries(RARIDADES)) {
    if (roll < r.peso) return chave
    roll -= r.peso
  }
  return 'comum'
}

function sortearEvento(raridadeForcada) {
  const chaveRaridade = (raridadeForcada && RARIDADES[raridadeForcada]) ? raridadeForcada : sortearRaridade()
  const raridade = RARIDADES[chaveRaridade]
  const lista = POKEMONS[chaveRaridade]
  const base = lista[Math.floor(Math.random() * lista.length)]

  const vidaMax = numAleatorio(raridade.vida)

  return {
    nome: base.nome,
    emoji: base.emoji,
    tipo: base.tipo,
    raridadeChave: chaveRaridade,
    raridade: raridade.label,
    nivel: numAleatorio(raridade.nivel),
    vidaMax,
    vidaAtual: vidaMax,
    forca: numAleatorio(raridade.forca),
    defesa: numAleatorio(raridade.defesa),
    velocidade: numAleatorio(raridade.velocidade),
    xp: numAleatorio(raridade.xp),
    ouro: numAleatorio(raridade.ouro),
  }
}

function podeSpawnar(groupJid) {
  const atual = eventosAtivos.get(groupJid)
  if (!atual) return true
  if (atual.evento && Date.now() < atual.expiraEm) return false // já tem um rolando
  if (atual.cooldownAte && Date.now() < atual.cooldownAte) return false
  return true
}

// raridadeForcada: passa 'lendario' pra garantir que vai vir um lendário
// (usado pelo !eventorpg lendario, comando só do dono). ignorarCooldown:
// deixa o dono chamar mesmo com o grupo em cooldown.
function criarSpawn(groupJid, raridadeForcada, ignorarCooldown) {
  const evento = sortearEvento(raridadeForcada)
  const expiraEm = Date.now() + DURACAO_EVENTO_MS
  eventosAtivos.set(groupJid, { evento, expiraEm, cooldownAte: null })
  return { evento, expiraEm }
}

function pegarEvento(groupJid) {
  const atual = eventosAtivos.get(groupJid)
  if (!atual || !atual.evento) return null
  if (Date.now() > atual.expiraEm) {
    eventosAtivos.set(groupJid, { evento: null, expiraEm: 0, cooldownAte: Date.now() + COOLDOWN_POR_GRUPO_MS })
    return null
  }
  const evento = atual.evento
  eventosAtivos.set(groupJid, { evento: null, expiraEm: 0, cooldownAte: Date.now() + COOLDOWN_POR_GRUPO_MS })
  return evento
}

// Zera de vez o evento/cooldown do grupo — usado pelo "!eventorpg off"
// pra destravar quando fica um evento "preso" ou o cooldown incomoda.
function cancelarEvento(groupJid) {
  eventosAtivos.delete(groupJid)
}


function verEvento(groupJid) {
  const atual = eventosAtivos.get(groupJid)
  if (!atual || !atual.evento) return null
  if (atual.expiraEm && Date.now() > atual.expiraEm) return null
  return atual.evento
}

module.exports = { podeSpawnar, criarSpawn, pegarEvento, verEvento, cancelarEvento, DURACAO_EVENTO_MS, formatarNumero, RARIDADES, POKEMONS }

