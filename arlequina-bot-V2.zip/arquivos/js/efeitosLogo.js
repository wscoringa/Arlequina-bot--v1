/*
 Fábrica de comandos de "logo/efeito de texto" — usados no !menuefeitos.
 Duas famílias de efeito, cada uma com sua própria API:

 1) NEXFUTURE: API única que aceita o nome do efeito na própria URL.
    https://api.nexfuture.com.br/api/logos/<efeito>?texto=<texto>

 2) SIRV: cada efeito é uma URL de template pronta (fonte/cor/posição já
    fixas no link), só troca o texto no parâmetro "text.0.text".
*/
const axios = require('axios')
const { caixaArlequina } = require('./estiloArlequina')

async function baixarImagem(url) {
  const { data } = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout: 25000,
    headers: { 'DNT': '1', 'Upgrade-Insecure-Requests': '1' }
  })
  return Buffer.from(data)
}

// Cria um comando que usa a API da Nexfuture (a maioria dos efeitos)
function criarEfeitoNexfuture({ name, description, aliases = [], comandoApi }) {
  return {
    name,
    description: description || `🎨 Gera uma logo com efeito "${name}"`,
    category: 'efeitos',
    aliases,
    async execute({ arlequina, from, info, q, args, reply, reagir, prefix }) {
      const texto = (q || args.join(' ')).trim()
      if (!texto) return reply(caixaArlequina(name, `❌ Cadê o texto?\n💡 Ex: *${prefix}${name}* Meu Nome`))
      try {
        await reagir('🎨')
        await reply('🪄 Gerando sua logo, aguarde...')
        const url = `https://api.nexfuture.com.br/api/logos/${comandoApi || name}?texto=${encodeURIComponent(texto)}`
        const buffer = await baixarImagem(url)
        await arlequina.sendMessage(from, { image: buffer, caption: `🎨 *${name}* pronta!` }, { quoted: info })
      } catch (e) {
        console.log(`❌ ERRO efeito (${name}):`, e?.message)
        await reply('❌ Deu erro na geração dessa logo. Tenta de novo daqui a pouco.')
      }
    }
  }
}

// Cria um comando que usa um template de URL fixo da Sirv (efeitos tipo
// banner de Free Fire/anime). Máximo 15 caracteres (limite da API).
function criarEfeitoSirv({ name, description, aliases = [], urlTemplate }) {
  return {
    name,
    description: description || `🎮 Gera um banner com efeito "${name}"`,
    category: 'efeitos',
    aliases,
    async execute({ arlequina, from, info, q, args, reply, reagir, prefix }) {
      const texto = (q || args.join(' ')).trim()
      if (!texto) return reply(caixaArlequina(name, `❌ Cadê o texto?\n💡 Ex: *${prefix}${name}* Nick`))
      if (texto.length > 15) return reply('❌ Texto muito longo! Máximo 15 caracteres.')
      try {
        await reagir('🎮')
        await reply('🪄 Gerando sua logo, aguarde...')
        const url = urlTemplate.replace('{TEXTO}', encodeURIComponent(texto))
        const buffer = await baixarImagem(url)
        await arlequina.sendMessage(from, { image: buffer, caption: `🎮 *${name}* pronto!` }, { quoted: info })
      } catch (e) {
        console.log(`❌ ERRO efeito (${name}):`, e?.message)
        await reply('❌ Deu erro na geração dessa logo. Tenta de novo daqui a pouco.')
      }
    }
  }
}

module.exports = { criarEfeitoNexfuture, criarEfeitoSirv }
