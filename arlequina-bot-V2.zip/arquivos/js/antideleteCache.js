/*
 Cache em memória das últimas mensagens vistas pelo bot, usado pelo
 !antidelete pra conseguir reenviar o conteúdo de uma mensagem depois
 que ela é apagada "para todos".

 Por que precisa disso: quando alguém apaga uma mensagem pra todos, o
 WhatsApp NÃO manda o conteúdo apagado — só avisa "essa mensagem (por
 esse ID) foi revogada". Então o bot precisa já ter visto e guardado
 essa mensagem ANTES dela ser apagada, pra poder reenviar depois.

 Só guarda o objeto da mensagem em si (texto/mídia continuam
 criptografados, então isso é leve) — a mídia só é baixada de verdade
 no momento em que uma revogação é detectada, não pra toda mensagem.
*/

const LIMITE = 800
const cache = new Map()

function guardar(info) {
  const id = info?.key?.id
  if (!id || !info?.message) return
  // ignora a própria mensagem de revogação e reações/protocolo, não faz sentido guardar
  if (info.message.protocolMessage) return
  cache.set(id, { info, quando: Date.now() })
  if (cache.size > LIMITE) {
    const chaveAntiga = cache.keys().next().value
    cache.delete(chaveAntiga)
  }
}

function buscar(id) {
  return cache.get(id)?.info || null
}

module.exports = { guardar, buscar }
