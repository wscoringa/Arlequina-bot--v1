/*
 Acha a FOTO oficial (imagem estática, não animada) de um Pokémon PELO
 NOME — usado em qualquer lugar que mostra um Pokémon específico que
 "apareceu" (captura, fuga, batalha, troca etc), pra sempre vir a
 imagem do bicho certo, não uma genérica.

 Foto estática em vez de gif de propósito: enviar gif como vídeo pro
 WhatsApp precisa converter pra mp4 (baixar + rodar ffmpeg), o que se
 mostrou instável dependendo do servidor/rede. Foto direta é muito
 mais simples e confiável — mesma técnica que já funciona bem em
 !pokedex, !pokegacha, !evoluir e !fundir.
*/
const { porNome, imagemUrl, buscarDexIdOnline } = require('./pokedexData.js')

async function buscarFotoPokemon(nome) {
  const local = porNome(nome)
  if (local) return imagemUrl(local.id)

  const dexIdOnline = await buscarDexIdOnline(nome)
  if (dexIdOnline) return imagemUrl(dexIdOnline)

  return null
}

module.exports = { buscarFotoPokemon, buscarGifPokemon: buscarFotoPokemon }
