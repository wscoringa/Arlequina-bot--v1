/*
 Efeito de "roleta"/suspense: manda uma mensagem e vai EDITANDO ela
 várias vezes (em vez de mandar mensagem nova toda hora), até o
 resultado final. Usado no !sorteio e nas batalhas automáticas
 (!pvp, arena de Pokémon) pra dar aquele suspense de "rodando" até
 cair no resultado, sem lotar o chat de mensagem.
*/

// frames: array de textos, na ordem que devem aparecer (o último é o resultado final)
// delayMinMs/delayMaxMs: cada frame demora um pouco mais que o anterior (desacelera tipo roleta de verdade)
async function revelarComEdicoes(sock, jid, quotedInfo, frames, { delayMinMs = 450, delayMaxMs = 950, mentions = [] } = {}) {
  if (!frames.length) return null

  const msgEnviada = await sock.sendMessage(jid, { text: frames[0], mentions }, { quoted: quotedInfo })
  const key = msgEnviada?.key
  if (!key) return null

  for (let i = 1; i < frames.length; i++) {
    const progresso = i / (frames.length - 1 || 1)
    const atraso = Math.round(delayMinMs + progresso * (delayMaxMs - delayMinMs))
    await new Promise(r => setTimeout(r, atraso))
    try {
      await sock.sendMessage(jid, { text: frames[i], edit: key, mentions })
    } catch (_e) {
      // Se editar falhar (mensagem muito antiga, conexão etc), manda
      // como mensagem nova só pra garantir que o resultado final chega
      if (i === frames.length - 1) {
        try { await sock.sendMessage(jid, { text: frames[i], mentions }) } catch (_e2) {}
      }
    }
  }

  return key
}

module.exports = { revelarComEdicoes }
