/*
 Banco Arlequina — helpers compartilhados entre o comando !banco, !pix,
 !extrato.
*/
const crypto = require('crypto')

const TIPOS_CONTA = {
  digital:     { chave: 'digital',     nome: 'Conta Digital',     emoji: '💳', desc: 'Gratuita e 100% online',   requisito: null,
                 limitePix: 5000,   limiteTransf: 10000,  taxaEmprestimo: 0.15 },
  estudante:   { chave: 'estudante',   nome: 'Conta Estudante',   emoji: '🎓', desc: 'Para quem estuda',          requisito: 'level<15',
                 limitePix: 1500,   limiteTransf: 3000,   taxaEmprestimo: 0.08 },
  jovem:       { chave: 'jovem',       nome: 'Conta Jovem',       emoji: '🧒', desc: 'De 15 a 26 anos (nível)',   requisito: 'level<25',
                 limitePix: 2500,   limiteTransf: 5000,   taxaEmprestimo: 0.10 },
  empresarial: { chave: 'empresarial', nome: 'Conta Empresarial', emoji: '💼', desc: 'Para o seu negócio',        requisito: 'level>=20',
                 limitePix: 20000,  limiteTransf: 50000,  taxaEmprestimo: 0.20 },
  premium:     { chave: 'premium',     nome: 'Conta Premium',     emoji: '👑', desc: 'Mais benefícios pra você',  requisito: 'vip',
                 limitePix: 100000, limiteTransf: 200000, taxaEmprestimo: 0.05 }
}

// Verifica se o usuário cumpre o requisito do tipo de conta.
function podeAbrir(tipo, u, isVip) {
  const t = TIPOS_CONTA[tipo]
  if (!t) return { ok: false, motivo: 'Tipo de conta inválido.' }
  if (t.requisito === 'level<15' && u.level >= 15) return { ok: false, motivo: `❌ A Conta Estudante é só até o nível 15. Você já é nível ${u.level}.` }
  if (t.requisito === 'level<25' && u.level >= 25) return { ok: false, motivo: `❌ A Conta Jovem é só até o nível 25. Você já é nível ${u.level}.` }
  if (t.requisito === 'level>=20' && u.level < 20) return { ok: false, motivo: `❌ A Conta Empresarial exige nível 20 ou mais. Você é nível ${u.level}.` }
  if (t.requisito === 'vip' && !isVip) return { ok: false, motivo: '❌ A Conta Premium é exclusiva pra membros VIP.' }
  return { ok: true }
}

// Garante que o perfil do usuário tem todos os campos do banco (sem
// mexer no default global do rpgDB, pra não arriscar dado antigo).
function garantirContaBanco(u) {
  if (!u.tipoConta) u.tipoConta = 'digital'
  if (!u.pix) u.pix = String(Math.floor(10000000000 + Math.random() * 90000000000))
  if (!u.tokenBanco) u.tokenBanco = crypto.randomBytes(20).toString('hex')
  if (!Array.isArray(u.extrato)) u.extrato = []
  if (typeof u.investimento !== 'number') u.investimento = 0
  if (typeof u.investimentoData !== 'number') u.investimentoData = 0
  if (typeof u.divida !== 'number') u.divida = 0
  if (typeof u.saldo !== 'number') u.saldo = 0
  if (typeof u.banco !== 'number') u.banco = 0
  return u
}

// Registra um lançamento no extrato (mantém só os 25 mais recentes).
function lancar(u, tipo, valor, descricao) {
  u.extrato = u.extrato || []
  u.extrato.unshift({ tipo, valor, descricao, data: Date.now() })
  u.extrato = u.extrato.slice(0, 25)
}

function formatarReal(v) {
  return Number(v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
}

// Encontra um usuário pela chave pix (11 dígitos) OU pelo número de telefone.
function acharPorPixOuNumero(usuarios, entrada) {
  const limpo = String(entrada || '').replace(/[^0-9]/g, '')
  if (!limpo) return null
  for (const jid in usuarios) {
    if (usuarios[jid]?.pix === limpo) return jid
  }
  const porNumero = Object.keys(usuarios).find(jid => jid.split('@')[0] === limpo)
  return porNumero || null
}

// O dono do bot (e os donos extras) contam como VIP automaticamente,
// além de quem tá na lista de VIPs de verdade (donoState.vips).
function ehVip(numero, config, donoState) {
  const num = String(numero || '').replace(/[^0-9]/g, '')
  if (!num) return false
  const donoNum = String(config?.NumeroDoDono || '').replace(/[^0-9]/g, '')
  if (donoNum && num === donoNum) return true
  const extras = donoState?.donosExtras || {}
  if (Object.values(extras).some(n => n && String(n).replace(/[^0-9]/g, '') === num)) return true
  return !!(donoState?.vips && donoState.vips[num])
}

module.exports = { TIPOS_CONTA, podeAbrir, garantirContaBanco, lancar, formatarReal, acharPorPixOuNumero, ehVip }
