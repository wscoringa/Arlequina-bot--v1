/*
 Estado (em memória) de quem está "sob efeito" do !kurokami em cada
 grupo. groupJid -> { numero: expiraEmTimestamp }
*/
const DURACAO_MS = 90 * 1000 // 1min30s

const alvos = new Map()

function ativar(groupJid, numero) {
  if (!alvos.has(groupJid)) alvos.set(groupJid, {})
  alvos.get(groupJid)[numero] = Date.now() + DURACAO_MS
}

function estaAtivo(groupJid, numero) {
  const grupo = alvos.get(groupJid)
  if (!grupo || !grupo[numero]) return false
  if (Date.now() >= grupo[numero]) {
    delete grupo[numero]
    return false
  }
  return true
}

function tempoRestante(groupJid, numero) {
  const grupo = alvos.get(groupJid)
  if (!grupo || !grupo[numero]) return 0
  return Math.max(0, grupo[numero] - Date.now())
}

module.exports = { ativar, estaAtivo, tempoRestante, DURACAO_MS }
