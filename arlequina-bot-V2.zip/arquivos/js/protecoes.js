/*
  arquivos/js/protecoes.js

  Esse arquivo é o "motor" de verdade do antilink e do antibot.
  Antes, os comandos antilink.js/antibot.js só guardavam um ✅/❌ no
  adminState, mas nada no bot realmente OLHAVA as mensagens pra agir.
  Esse helper faz a detecção; quem aciona é o index.js, em toda
  mensagem de grupo (não só comandos).
*/
const fs = require('fs')

const PADROES_LINK = {
  grupo: /chat\.whatsapp\.com\/[A-Za-z0-9]+/i,
  canal: /whatsapp\.com\/channel\/[A-Za-z0-9]+/i,
  telegram: /(t\.me|telegram\.me|telegram\.org)\/[A-Za-z0-9_]+/i,
  youtube: /(youtube\.com|youtu\.be)\//i,
  instagram: /instagram\.com\//i,
  tiktok: /tiktok\.com\//i,
  twitter: /(twitter\.com|x\.com)\//i,
  facebook: /(facebook\.com|fb\.watch)\//i,
}
const PADRAO_GERAL = /https?:\/\/[^\s]+/i

/*
  Olha o texto da mensagem e devolve o TIPO de link mais específico
  encontrado (ex: 'youtube'), ou 'geral' se for um link qualquer sem
  bater em nenhum tipo específico, ou null se não tiver link nenhum.
*/
function detectarLink(texto) {
  if (!texto || typeof texto !== 'string') return null
  for (const tipo in PADROES_LINK) {
    if (PADROES_LINK[tipo].test(texto)) return tipo
  }
  if (PADRAO_GERAL.test(texto)) return 'geral'
  return null
}

/*
  Confere se o link encontrado deve ser bloqueado de acordo com a
  configuração do antilink daquele grupo (cfg = adminState.antilink[from]).
*/
function linkBloqueado(tipo, cfg) {
  if (!cfg || !tipo) return false
  if (cfg[tipo] === true) return true
  // "geral" ativado bloqueia qualquer link, mesmo de um tipo específico
  if (tipo !== 'geral' && cfg.geral === true) return true
  return false
}

/*
  Heurística simples de "isso parece o menu/resposta de outro bot":
  várias linhas seguidas começando com prefixo de bot (/ . $ %) — bots
  costumam mandar listas de comando assim. Não é 100% preciso, mas
  evita falso positivo em conversa normal (exige várias linhas, não 1).
*/
// Detecta se uma mensagem "parece" ter vindo de outro bot (não de uma
// pessoa de verdade). Como não dá pra saber com 100% de certeza só pelo
// texto, usamos um sistema de pontos: cada sinal suspeito soma pontos,
// e só banimos se a soma bater um limite — assim reduz o risco de banir
// gente normal só porque mandou uma mensagem parecida.
function pareceOutroBot(texto) {
  if (!texto || typeof texto !== 'string') return false
  const linhas = texto.split('\n')
  let pontos = 0

  // Sinal 1: linhas com prefixo de comando (menus de bot)
  let linhasComPrefixo = 0
  for (const linha of linhas) {
    if (/^[/.$%#*!~+=\\-][a-zA-Z]/.test(linha.trim())) linhasComPrefixo++
  }
  if (linhasComPrefixo >= 3) pontos += 3
  else if (linhasComPrefixo >= 2) pontos += 2
  else if (linhasComPrefixo >= 1 && linhas.length >= 5) pontos += 1

  // Sinal 2: moldura/caixinha decorativa de bot
  const qtdMoldura = (texto.match(/[╭╮╯╰━─│┃▭「」┌┐└┘═║┣┫]/g) || []).length
  if (qtdMoldura >= 5) pontos += 3
  else if (qtdMoldura >= 3) pontos += 2

  // Sinal 3: frases clássicas de resposta automática
  if (/comando inv[aá]lido|cmd inv[aá]lido|apenas administradores|somente admin(s)?|prefixo n[aã]o encontrado|digite o comando|menu principal|use\s*!?\w+\s*(on|off)|bot\s*(online|offline)|ping:\s*\d+\s*ms|uptime:|criador do bot|dono do bot|prefixo:\s*[^\s]/i.test(texto)) {
    pontos += 2
  }

  // Sinal 4: bloco tipo menu — muitas linhas + muitos emojis
  const qtdEmoji = (texto.match(/\p{Extended_Pictographic}/gu) || []).length
  if (linhas.length >= 6 && qtdEmoji >= 8) pontos += 2
  else if (linhas.length >= 8 && qtdEmoji >= 5) pontos += 1

  // Sinal 5: assinatura / marca típica de bot BR
  if (/\b(bot|baileys|whatsapp-web\.js)\b.*\b(menu|comando|prefixo)\b|©\s*bot|power(ed)?\s*by\s*\w*bot/i.test(texto)) {
    pontos += 2
  }

  // Sinal 6: lista numerada longa de comandos
  const linhasNum = linhas.filter(l => /^\s*\d+[.)]\s*\S/.test(l)).length
  if (linhasNum >= 5) pontos += 2

  return pontos >= 3
}

/*
  BUGFIX/MELHORIA: spammers vêm escondendo texto com link dentro de
  tipos de mensagem "exóticos" que o bot não sabia ler (ex: mensagens
  de "pagamento" tipo paymentInviteMessage/requestPaymentMessage, que o
  WhatsApp mostra como "Mensagem de pagamento • Valor indisponível").
  Como o antilink só olhava pros campos conhecidos (conversation,
  extendedTextMessage.text, caption...), esse tipo de mensagem passava
  batido mesmo tendo link/spam dentro.

  Essa função varre o objeto da mensagem inteiro procurando por
  qualquer texto (campos comuns tipo text/caption/conversation/title/
  description/matchedText) até um limite de profundidade, como último
  recurso — só é chamada quando os campos "normais" não acharam nada.
*/
function extrairTextoProfundo(obj, profundidade = 0) {
  if (!obj || typeof obj !== 'object' || profundidade > 6) return ''
  const CHAVES_TEXTO = ['text', 'caption', 'conversation', 'title', 'description', 'matchedText', 'note']
  for (const chave of CHAVES_TEXTO) {
    if (typeof obj[chave] === 'string' && obj[chave].trim()) return obj[chave]
  }
  for (const [chave, valor] of Object.entries(obj)) {
    // BUGFIX CRÍTICO: nunca entra em "contextInfo" — é ali que fica
    // guardada a mensagem RESPONDIDA (quotedMessage). Sem essa exclusão,
    // responder qualquer mensagem (até uma figurinha, sem texto nenhum
    // próprio) com uma figurinha/áudio/qualquer coisa sem legenda fazia
    // o bot "achar" o texto de dentro da mensagem citada e executar
    // ela de novo como se a PESSOA QUE RESPONDEU tivesse digitado o
    // comando — um bug sério de atribuição errada de comando.
    if (chave === 'contextInfo') continue
    if (valor && typeof valor === 'object') {
      const achado = extrairTextoProfundo(valor, profundidade + 1)
      if (achado) return achado
    }
  }
  return ''
}

/*
  Detecta se a mensagem é do tipo "pagamento" (paymentInviteMessage,
  requestPaymentMessage, sendPaymentMessage etc) — usado por spammers
  pra fugir dos filtros normais, mandando o "convite de pagamento" do
  WhatsApp só como disfarce, com o spam de verdade escondido dentro.

  BUGFIX: a primeira versão só olhava as chaves de PRIMEIRO NÍVEL da
  mensagem (ex: message.paymentInviteMessage). Só que boa parte desse
  spam vem embrulhado dentro de outro contêiner — o mesmo tipo de
  "interactiveMessage" com "nativeFlowMessage" que o próprio !play usa
  pros botões, só que com um flow de pagamento (ex: nome de flow
  "review_and_pay") — então "payment" nunca aparecia na chave de fora,
  e a detecção sempre dava falso. Agora a busca é recursiva: procura
  "payment" (ou o nome de flows de pagamento conhecidos) em QUALQUER
  chave ou valor de texto dentro da mensagem inteira, não só na raiz.
*/
const PADRAO_PAGAMENTO = /payment|pagamento|review_and_pay|payment_info|payment_status|pay_now|paynow|request_payment|pix|boleto/i
const PADRAO_FLOW_SUSPEITO = /review_and_pay|payment_info|payment_status|pay_now|galaxy_message|mpm|order_details/i

function ehMensagemPagamento(message, profundidade = 0) {
  if (!message || typeof message !== 'object' || profundidade > 8) return false

  // Tipos explícitos de convite/pagamento
  if (
    message.paymentInviteMessage ||
    message.requestPaymentMessage ||
    message.sendPaymentMessage ||
    message.cancelPaymentRequestMessage ||
    message.declinePaymentRequestMessage ||
    message.paymentLinkMessage
  ) return true

  // Native flow / interactive usado pra spam "invisível"
  try {
    const nfm = message.interactiveMessage?.nativeFlowMessage
      || message.viewOnceMessage?.message?.interactiveMessage?.nativeFlowMessage
      || message.viewOnceMessageV2?.message?.interactiveMessage?.nativeFlowMessage
      || message.ephemeralMessage?.message?.interactiveMessage?.nativeFlowMessage
    if (nfm) {
      const buttons = nfm.buttons || []
      for (const b of buttons) {
        const name = String(b?.name || '')
        const params = String(b?.buttonParamsJson || '')
        if (PADRAO_FLOW_SUSPEITO.test(name) || PADRAO_PAGAMENTO.test(name) || PADRAO_PAGAMENTO.test(params) || PADRAO_FLOW_SUSPEITO.test(params)) {
          return true
        }
      }
      // interactive sem texto útil + só native flow = clássico de msg invisível/spam
      const bodyTxt = message.interactiveMessage?.body?.text
        || message.viewOnceMessage?.message?.interactiveMessage?.body?.text
        || message.viewOnceMessageV2?.message?.interactiveMessage?.body?.text
        || ''
      if (!String(bodyTxt).trim() && buttons.length > 0) {
        const nomes = buttons.map(b => String(b?.name || '')).join(' ')
        if (PADRAO_FLOW_SUSPEITO.test(nomes) || PADRAO_PAGAMENTO.test(nomes) || /cta_url|cta_call|single_select/i.test(nomes) === false && buttons.length === 1) {
          // se for review_and_pay / payment já pegou acima; aqui pega galaxy/mpm
          if (/galaxy|mpm|order|payment|pay/i.test(nomes)) return true
        }
      }
    }
  } catch (_) {}

  // Varredura recursiva em chaves/valores
  for (const [chave, valor] of Object.entries(message)) {
    if (PADRAO_PAGAMENTO.test(chave) || PADRAO_FLOW_SUSPEITO.test(chave)) return true
    if (typeof valor === 'string' && (PADRAO_PAGAMENTO.test(valor) || PADRAO_FLOW_SUSPEITO.test(valor))) return true
    if (valor && typeof valor === 'object' && ehMensagemPagamento(valor, profundidade + 1)) return true
  }
  return false
}

// ── Contador de advertências (mesmo arquivo que o antilink.js já usa
// pra listar/zerar advertências — antipagamento soma na mesma "conta") ──
const ADV_PATH = './database/advertencias.json'
function carregarAdvertencias() {
  try { return fs.existsSync(ADV_PATH) ? JSON.parse(fs.readFileSync(ADV_PATH)) : {} } catch { return {} }
}
function salvarAdvertencias(dados) {
  try { fs.writeFileSync(ADV_PATH, JSON.stringify(dados, null, 2)) } catch (e) { console.log('❌ ERRO ao salvar advertencias.json:', e?.message) }
}
/*
  Soma +1 advertência pro número dentro do grupo. Devolve o total atual.
*/
function registrarAdvertencia(from, numero) {
  const advs = carregarAdvertencias()
  if (!advs[from]) advs[from] = {}
  advs[from][numero] = (advs[from][numero] || 0) + 1
  salvarAdvertencias(advs)
  return advs[from][numero]
}

module.exports = {
  detectarLink,
  linkBloqueado,
  pareceOutroBot,
  extrairTextoProfundo,
  ehMensagemPagamento,
  carregarAdvertencias,
  salvarAdvertencias,
  registrarAdvertencia
}
