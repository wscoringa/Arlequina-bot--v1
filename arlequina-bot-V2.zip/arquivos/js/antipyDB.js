/*
  Anti-PY (mensagem de pagamento / "fantasma") — configuração por grupo.

  Antes o !antipy ligava uma flag em memória (adminState.antipy) que NENHUM
  código lia — por isso ligar o comando não fazia nada, e ainda se perdia
  quando o bot reiniciava. Agora a configuração é salva em arquivo e é lida
  pelo detector (arquivos/js/antipyHandler.js), que roda no index.js.
*/
const fs = require('fs')

const dbPath = './database/antipy.json'

// o index.js consulta isso a cada mensagem de grupo: guarda em memória por poucos segundos
let cache = null
let cacheEm = 0
const CACHE_MS = 3000

function carregar() {
  if (cache && Date.now() - cacheEm < CACHE_MS) return cache
  let dados = {}
  try {
    if (fs.existsSync(dbPath)) dados = JSON.parse(fs.readFileSync(dbPath, 'utf-8')) || {}
  } catch {
    dados = {}
  }
  cache = dados
  cacheEm = Date.now()
  return cache
}

function salvar(dados) {
  try {
    if (!fs.existsSync('./database')) fs.mkdirSync('./database', { recursive: true })
    fs.writeFileSync(dbPath, JSON.stringify(dados, null, 2))
    cache = dados
    cacheEm = Date.now()
  } catch (e) {
    console.log('❌ Erro ao salvar antipy.json:', e?.message)
  }
}

// banirAdmins: true = também apaga e bane quando quem mandou é ADM (o dono do bot nunca é banido)
function getConfig(groupId) {
  return { ativo: false, banirAdmins: true, denuncia: true, ...(carregar()[groupId] || {}) }
}

function setAtivo(groupId, ativo) {
  const dados = carregar()
  dados[groupId] = { ...(dados[groupId] || {}), ativo: !!ativo }
  salvar(dados)
  return dados[groupId]
}

// !antipy on: liga TUDO de uma vez (automático + responder + banir ADM), mesmo que
// algo tenha sido desligado antes. NÃO existe atalho "." — foi removido de propósito.
function ligarTudo(groupId) {
  const dados = carregar()
  dados[groupId] = { ativo: true, banirAdmins: true, denuncia: true }
  salvar(dados)
  return dados[groupId]
}

function setDenuncia(groupId, valor) {
  const dados = carregar()
  dados[groupId] = { ...(dados[groupId] || {}), denuncia: !!valor }
  salvar(dados)
  return dados[groupId]
}

function setBanirAdmins(groupId, valor) {
  const dados = carregar()
  dados[groupId] = { ...(dados[groupId] || {}), banirAdmins: !!valor }
  salvar(dados)
  return dados[groupId]
}

module.exports = { dbPath, getConfig, setAtivo, ligarTudo, setBanirAdmins, setDenuncia }
