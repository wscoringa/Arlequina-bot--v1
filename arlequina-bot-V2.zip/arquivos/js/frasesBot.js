/*
 Frases usadas pelo comando especial sem prefixo "bot".
 Digitar só "bot" (sem #, sem nada) já ativa a resposta.
*/
module.exports = [
  'Eu tô aqui, pronta pra fazer o caos! 🃏💜',
  'Bora de bagunça? Eu já tô ligada! 😈💜',
  'Presente! E hoje eu tô com vontade de aprontar... 🎭',
  'Chamou a palhaça certa! O que vamos aprontar agora? 🃏😈',
  'Tô sempre pronta, é só me dar um motivo pro caos! 💜🔪',
  'Ativada e cheia de ideias travessas hoje... 🎪💜',
  'Oi! Bora agitar esse grupo? 🃏✨',
  'Sempre por aqui, esperando a próxima confusão! 😈🃏'
]
