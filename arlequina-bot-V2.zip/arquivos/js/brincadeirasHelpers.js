/*
  Helpers compartilhados pelos plugins da categoria "brincadeiras"
  Arlequina Bot - coringa</>
*/
const fs = require('fs')
const axios = require('axios')
const ff = require('fluent-ffmpeg')
const path = require('path')
const os = require('os')
const { caixaArlequina } = require('./estiloArlequina.js')

// Se o servidor não tiver o ffmpeg instalado no sistema, a conversão de gif->mp4
// falha silenciosamente e o bot cai pro fallback de texto (sem gif nenhum).
// Tentamos usar o binário embutido do pacote "ffmpeg-static" se ele estiver instalado
// (rode: npm install ffmpeg-static), senão usa o ffmpeg do sistema normalmente.
try {
  const ffmpegStaticPath = require('ffmpeg-static')
  if (ffmpegStaticPath) ff.setFfmpegPath(ffmpegStaticPath)
} catch (e) {
  console.warn('⚠️ ffmpeg-static não instalado — usando ffmpeg do sistema. Se os GIFs não aparecerem, rode: npm install ffmpeg-static')
}

// Converte um buffer de GIF em um vídeo MP4 (necessário pra o WhatsApp tocar
// como GIF animado de verdade com gifPlayback — enviar o .gif crú como "video"
// só mostra uma prévia borrada parada, nunca anima).
async function converterGifParaMp4(gifBuffer) {
  const { execFile } = require('child_process')
  const execFileP = (cmd, args) => new Promise((resolve, reject) => {
    execFile(cmd, args, { timeout: 60000 }, (err, stdout, stderr) => {
      if (err) reject(new Error((stderr || err.message || '').toString().slice(0, 300)))
      else resolve(stdout)
    })
  })

  let ext = 'gif'
  if (gifBuffer && gifBuffer.length >= 12) {
    if (gifBuffer[0] === 0x47 && gifBuffer[1] === 0x49 && gifBuffer[2] === 0x46) ext = 'gif'
    else if (gifBuffer[0] === 0x52 && gifBuffer[1] === 0x49 && gifBuffer[2] === 0x46 && gifBuffer[8] === 0x57) ext = 'webp'
    else if (gifBuffer[4] === 0x66 && gifBuffer[5] === 0x74) return gifBuffer
  }

  const id = Date.now() + '_' + Math.random().toString(36).slice(2)
  const tmpIn = path.join(os.tmpdir(), 'gif_in_' + id + '.' + ext)
  const tmpGif = path.join(os.tmpdir(), 'gif_mid_' + id + '.gif')
  const tmpOut = path.join(os.tmpdir(), 'gif_out_' + id + '.mp4')
  fs.writeFileSync(tmpIn, gifBuffer)

  try {
    let inputForFfmpeg = tmpIn

    if (ext === 'webp') {
      let ok = false
      for (const cmd of ['convert', 'magick']) {
        try {
          const args = cmd === 'magick' ? [tmpIn, '-coalesce', tmpGif] : [tmpIn, '-coalesce', tmpGif]
          await execFileP(cmd, args)
          if (fs.existsSync(tmpGif) && fs.statSync(tmpGif).size > 500) {
            inputForFfmpeg = tmpGif
            ok = true
            break
          }
        } catch (e) {
          console.error(cmd + ' webp:', e?.message)
        }
      }
      if (!ok) throw new Error('webp: instale imagemagick (sudo apt install imagemagick)')
    }

    await new Promise((resolve, reject) => {
      ff(inputForFfmpeg)
        .on('error', reject)
        .on('end', () => resolve(true))
        .addOutputOptions([
          '-movflags', 'faststart',
          '-pix_fmt', 'yuv420p',
          '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2',
          '-an',
          '-t', '15'
        ])
        .save(tmpOut)
    })

    const out = fs.readFileSync(tmpOut)
    if (!out || out.length < 500) throw new Error('mp4 vazio')
    return out
  } finally {
    try { if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn) } catch (_) {}
    try { if (fs.existsSync(tmpGif)) fs.unlinkSync(tmpGif) } catch (_) {}
    try { if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut) } catch (_) {}
  }
}
async function baixarBufferUrl(url) {
  const headers = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0 Mobile Safari/537.36'
  }
  if (/tiktok\.com/i.test(url)) headers.Referer = 'https://www.tiktok.com/'
  if (/pinimg\.com|pinterest\./i.test(url)) headers.Referer = 'https://www.pinterest.com/'
  if (/tenor\.com/i.test(url)) headers.Referer = 'https://tenor.com/'

  const resp = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout: 30000,
    headers
  })
  const buffer = Buffer.from(resp.data)
  if (!buffer || buffer.length < 1000) throw new Error('Arquivo vazio.')
  return buffer
}

// Pega imagem direto de um link (Pinterest, ou qualquer site com og:image).
// Funciona com link de pin (https://pin.it/xxxx ou pinterest.com/pin/xxxx)
// e também com link direto de imagem (.jpg/.png/etc).
async function imagemDeLink(url) {
  try {
    // Foto já embutida direto no código (data:image/...;base64,XXXX) —
    // não é link de verdade, é a própria foto. Não usa rede, não toca
    // em disco/galeria, só decodifica o base64 na hora.
    if (/^data:image\/[a-z0-9.+-]+;base64,/i.test(url)) {
      return Buffer.from(url.split(',')[1], 'base64')
    }

    // Se já for link direto de imagem, baixa direto
    if (/\.(jpg|jpeg|png|webp|gif)(\?|$)/i.test(url)) {
      return await baixarBufferUrl(url)
    }

    // Pinterest (pin.it ou pinterest.com/pin/...): usa a API oficial de
    // oEmbed do Pinterest, que devolve a foto de verdade do pin. Fazer
    // scraping do og:image em link curto (pin.it) só pega o card
    // genérico de "abrir no app" — por isso toda foto saía igual.
    if (/pin\.it\/|pinterest\.[a-z.]+\/pin\//i.test(url)) {
      try {
        const { data } = await axios.get('https://www.pinterest.com/oembed/', {
          params: { url },
          timeout: 15000,
          headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36' }
        })
        let img = data?.thumbnail_url
        if (img) {
          // troca o tamanho pequeno (ex: /236x/) pela versão original em alta qualidade
          const imgOriginal = img.replace(/\/\d+x\d*\//, '/originals/')
          const buffer = await baixarBufferUrl(imgOriginal).catch(() => baixarBufferUrl(img))
          if (buffer) return buffer
        }
      } catch (e) {
        console.error('imagemDeLink: oEmbed do Pinterest falhou para', url, '->', e?.message)
      }
    }

    // Senão, busca o HTML da página
    const resp = await axios.get(url, {
      timeout: 20000,
      maxRedirects: 5,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml'
      }
    })
    const html = resp.data

    // 1ª tentativa: tag og:image
    let match = html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)
      || html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i)

    // 2ª tentativa (Pinterest): pega direto a URL da imagem original no HTML/JSON embutido
    if (!match) {
      const pin = html.match(/https:\\?\/\\?\/i\.pinimg\.com\\?\/originals\\?\/[^\s"'\\]+\.(?:jpg|jpeg|png|gif)/i)
      if (pin) match = [null, pin[0].replace(/\\\//g, '/')]
    }

    if (!match) {
      console.error('imagemDeLink: og:image não encontrado para', url)
      return null
    }
    return await baixarBufferUrl(match[1])
  } catch (e) {
    console.error('ERRO imagemDeLink:', url, '->', e?.message)
    return null
  }
}

// Imagem aleatória da internet como fallback
async function buscarImagemAleatoria() {
  try {
    const { data } = await axios.get('https://meme-api.com/gimme', { timeout: 10000 })
    if (data?.url) return await baixarBufferUrl(data.url)
  } catch (e) {}
  try {
    return await baixarBufferUrl(`https://picsum.photos/512?random=${Date.now()}`)
  } catch (e) { return null }
}

// ───────────────────────────────────────────────────────────────────
// FOTO FIXA — o jeito definitivo é rodar "node tools/embutir_fotos.js"
// uma vez (veja o arquivo): ele troca o LINK_FOTO de cada comando por
// um data:image/...;base64 embutido DIRETO NO CÓDIGO. A partir daí
// imagemDeLink (acima) já devolve a foto na hora, sem rede e sem
// gravar nada em disco — nunca mais passa perto da galeria.
//
// Esse cache aqui embaixo é só uma rede de segurança EM MEMÓRIA (RAM)
// pra quem ainda não rodou o script, ou pra foto nova que ainda não
// foi embutida: evita ficar batendo no Pinterest toda hora enquanto o
// bot está ligado, mas NUNCA escreve arquivo — zera sozinho quando o
// bot reinicia, e não cria pasta nenhuma em midias/.
// ───────────────────────────────────────────────────────────────────
const _cacheFotosMemoria = new Map()

async function imagemFixa(chave, link, fallbackFn) {
  if (_cacheFotosMemoria.has(chave)) return _cacheFotosMemoria.get(chave)
  if (link) {
    const buf = await imagemDeLink(link)
    if (buf && buf.length > 500) {
      _cacheFotosMemoria.set(chave, buf)
      return buf
    }
  }
  return fallbackFn ? await fallbackFn() : null
}

// Atalho pra brincadeiras comuns (!linda, !gostosa, etc — cai pro
// fallback de midias/brincadeiras/<nome>.ext se o link falhar)
async function imagemFixaDaBrincadeira(nome, link) {
  return imagemFixa(nome, link, () => imagemDaBrincadeira(nome))
}

// Atalho pros rankings (!rankgostosa, etc — cai pro fallback de
// midias/rank/<nome>.ext se o link falhar)
async function imagemFixaDoRank(nome, link) {
  return imagemFixa(nome, link, () => imagemDoRank(nome))
}

// Tenta imagem local em midias/brincadeiras/NOME.ext, senão busca online
async function imagemDaBrincadeira(nomeArquivo) {
  const extensoes = ['jpg', 'png', 'jpeg', 'webp', 'gif']
  for (const ext of extensoes) {
    const caminho = `./midias/brincadeiras/${nomeArquivo}.${ext}`
    if (fs.existsSync(caminho)) return fs.readFileSync(caminho)
  }
  return await buscarImagemAleatoria()
}

// Tenta imagem local em midias/rank/NOME.ext, senão busca online
async function imagemDoRank(nomeArquivo) {
  const extensoes = ['jpg', 'png', 'jpeg', 'webp', 'gif']
  for (const ext of extensoes) {
    const caminho = `./midias/rank/${nomeArquivo}.${ext}`
    if (fs.existsSync(caminho)) return fs.readFileSync(caminho)
  }
  return await buscarImagemAleatoria()
}

// Medalhas para os 3 primeiros
function medalha(i) {
  if (i === 0) return '🥇'
  if (i === 1) return '🥈'
  if (i === 2) return '🥉'
  return `${i + 1}°`
}

// Rank padrão: 5 pessoas, @menciona, ordem decrescente de %, medalhas top 3
// fotoNome = nome do arquivo em midias/rank/ (ex: 'rankgostoso')
async function enviarRank(sock, from, info, titulo, emoji, fotoNome, frase, linkFoto) {
  const metadata = await sock.groupMetadata(from)
  const participantes = metadata.participants
    .map(p => p.id)
    .sort(() => Math.random() - 0.5)
    .slice(0, 5)

  // Gera porcentagens e ordena do maior pro menor
  const lista = participantes.map(id => ({
    id,
    pct: Math.floor(Math.random() * 101)
  })).sort((a, b) => b.pct - a.pct)

  let corpo = ''
  lista.forEach(({ id, pct }, i) => {
    corpo += `${medalha(i)} @${id.split('@')[0]}\n`
    corpo += `📊 ${pct}%\n\n`
  })
  corpo += `\n✨ ${frase}`
  const texto = caixaArlequina(titulo, corpo.trim())

  const imgBuffer = linkFoto ? await imagemFixaDoRank(fotoNome, linkFoto) : await imagemDoRank(fotoNome)
  const mentions = lista.map(l => l.id)

  if (imgBuffer) {
    await sock.sendMessage(from, { image: imgBuffer, caption: texto, mentions }, { quoted: info })
  } else {
    await sock.sendMessage(from, { text: texto, mentions }, { quoted: info })
  }
}

// Rank casal: 10 casais (20 pessoas), @menciona, com frases e porcentagem
async function enviarRankCasal(sock, from, info, linkFoto) {
  const metadata = await sock.groupMetadata(from)
  const todos = metadata.participants.map(p => p.id).sort(() => Math.random() - 0.5)

  // Pega 20 pessoas pra formar 10 casais (ou menos se grupo menor)
  const qtd = Math.min(20, todos.length % 2 === 0 ? todos.length : todos.length - 1)
  const selecionados = todos.slice(0, qtd)

  const casais = []
  for (let i = 0; i < selecionados.length - 1; i += 2) {
    casais.push({
      p1: selecionados[i],
      p2: selecionados[i + 1],
      pct: Math.floor(Math.random() * 101) // 0 a 100% — quanto maior, melhor o casal
    })
  }
  casais.sort((a, b) => b.pct - a.pct)

  const frasesRuim = [
    '💔 Esse casal não dura nem 1 dia.',
    '🥲 Melhor serem só amigos.',
    '😬 Química passou longe.',
    '🙈 Nem o cupido ajudou.',
    '💀 Casal em perigo.'
  ]
  const frasesDuvidoso = [
    '😊 Tem futuro... talvez.',
    '🥺 Ainda precisa de um empurrãozinho.',
    '😅 Dá pra tentar, mas sem garantias.',
    '🤔 Compatibilidade incerta.'
  ]
  const frasesBoa = [
    '💞 Dá pra investir.',
    '✨ Casal interessante.',
    '🥰 Combinação bonita.',
    '💜 O grupo aprovou.',
    '🌹 Que casal lindo demais!'
  ]
  const frasesPerfeita = [
    '🔥 Casal perfeito!',
    '💍 Já pode casar.',
    '🃏 Arlequina e Coringa aprovaram.',
    '💘 Destinados um ao outro.',
    '👑 Casal lendário do grupo.',
    '😍 Feitos um pro outro!',
    '❤️‍🔥 Amor que não tem explicação.',
    '💫 Combinação rara no grupo.',
    '🎭 Coringa e Arlequina teriam inveja.'
  ]

  function fraseDoCasal(pct) {
    if (pct <= 25) return frasesRuim[Math.floor(Math.random() * frasesRuim.length)]
    if (pct <= 50) return frasesDuvidoso[Math.floor(Math.random() * frasesDuvidoso.length)]
    if (pct <= 75) return frasesBoa[Math.floor(Math.random() * frasesBoa.length)]
    return frasesPerfeita[Math.floor(Math.random() * frasesPerfeita.length)]
  }

  let corpo = ''
  const mentions = []

  casais.forEach(({ p1, p2, pct }, i) => {
    const frase = fraseDoCasal(pct)
    corpo += `${medalha(i)} ❤️ @${p1.split('@')[0]}\n`
    corpo += `     💜 @${p2.split('@')[0]}\n`
    corpo += `     📊 Compatibilidade: *${pct}%*\n`
    corpo += `     ${frase}\n`
    corpo += `     ━━━━━━━━━━\n\n`
    mentions.push(p1, p2)
  })
  const texto = caixaArlequina('RANK CASAIS DO GRUPO', corpo.trim())

  const imgBuffer = linkFoto ? await imagemFixaDoRank('rankcasal', linkFoto) : await imagemDoRank('rankcasal')
  if (imgBuffer) {
    await sock.sendMessage(from, { image: imgBuffer, caption: texto, mentions }, { quoted: info })
  } else {
    await sock.sendMessage(from, { text: texto, mentions }, { quoted: info })
  }
}

// Busca um GIF temático (qualquer assunto: gato, cachorro, dragão, roleta, segredo...)
// via GIPHY (chave pública beta oficial da GIPHY, gratuita e sem cadastro).
// Pega até 15 resultados e escolhe um aleatório, pra não repetir sempre o mesmo gif.
const GIPHY_KEY = 'dc6zaTOxFJmzC' // chave pública beta da GIPHY (rate-limited, trocar por uma própria em produção: https://developers.giphy.com)
async function gifPorTema(query) {
  try {
    const { data } = await axios.get('https://api.giphy.com/v1/gifs/search', {
      params: { api_key: GIPHY_KEY, q: query, limit: 15, rating: 'pg-13', lang: 'pt' },
      timeout: 10000
    })
    const lista = data?.data || []
    if (!lista.length) return null
    const escolhido = lista[Math.floor(Math.random() * lista.length)]
    const url = escolhido?.images?.downsized?.url || escolhido?.images?.original?.url
    if (!url) return null
    return await baixarBufferUrl(url)
  } catch (e) {
    console.error('ERRO gifPorTema:', query, '->', e?.message)
    return null
  }
}

// Envia uma brincadeira com GIF buscado por tema (GIPHY). Cai pra imagem local/aleatória
// e por último pra só texto, caso a API falhe ou não tenha resultado.
async function enviarComGifTema(sock, from, info, tema, nomeFallback, texto, mentions) {
  const textoFinal = texto.includes('╭─━━─🃏💜') ? texto : caixaArlequina(nomeFallback, texto)
  let videoBuffer = null
  try {
    const gifBuffer = await gifPorTema(tema)
    if (gifBuffer) videoBuffer = await converterGifParaMp4(gifBuffer)
  } catch (e) {
    console.error('ERRO enviarComGifTema (gif->mp4):', e?.message)
  }
  if (videoBuffer) {
    return sock.sendMessage(from, { video: videoBuffer, gifPlayback: true, caption: textoFinal, mentions }, { quoted: info })
  }
  const imgBuffer = await imagemDaBrincadeira(nomeFallback)
  if (imgBuffer) {
    return sock.sendMessage(from, { image: imgBuffer, caption: textoFinal, mentions }, { quoted: info })
  }
  return sock.sendMessage(from, { text: textoFinal, mentions }, { quoted: info })
}

// Busca um GIF de reação (estilo anime) via API gratuita otakugifs.xyz
// reaction = nome em inglês da reação (ex: 'slap', 'kiss', 'hug', 'punch', 'pat'...)
async function gifDeReacao(reaction) {
  try {
    const { data } = await axios.get(
      `https://api.otakugifs.xyz/gif?reaction=${encodeURIComponent(reaction)}&format=gif`,
      { timeout: 10000 }
    )
    if (data?.url) return await baixarBufferUrl(data.url)
  } catch (e) {
    console.error('ERRO gifDeReacao:', reaction, '->', e?.message)
  }
  return null
}

// Envia uma ação (tapa, beijo, abraço...) com GIF de reação.
// Tenta GIF da otakugifs.xyz primeiro (anima de verdade no WhatsApp via gifPlayback),
// se falhar cai pra imagem local/aleatória, se falhar cai pra só texto.
async function enviarComGif(sock, from, info, reaction, nomeFallback, texto, mentions) {
  const textoFinal = texto.includes('╭─━━─🃏💜') ? texto : caixaArlequina(nomeFallback, texto)
  let videoBuffer = null
  try {
    const gifBuffer = await gifDeReacao(reaction)
    if (gifBuffer) videoBuffer = await converterGifParaMp4(gifBuffer)
  } catch (e) {
    console.error('ERRO enviarComGif (gif->mp4):', e?.message)
  }
  if (videoBuffer) {
    return sock.sendMessage(from, { video: videoBuffer, gifPlayback: true, caption: textoFinal, mentions }, { quoted: info })
  }
  const imgBuffer = await imagemDaBrincadeira(nomeFallback)
  if (imgBuffer) {
    return sock.sendMessage(from, { image: imgBuffer, caption: textoFinal, mentions }, { quoted: info })
  }
  return sock.sendMessage(from, { text: textoFinal, mentions }, { quoted: info })
}

// Envia uma ação (tapa, beijo, abraço...) usando um link de GIF FIXO (direto, hospedado no Tenor).
// Baixa o buffer do link e envia como vídeo com gifPlayback (anima de verdade no WhatsApp).
// Se o link falhar por qualquer motivo, cai pra imagem local/aleatória, e por último só texto.
async function enviarGifFixo(sock, from, info, urlGif, nomeFallback, texto, mentions) {
  const textoFinal = texto.includes('╭─━━─🃏💜') ? texto : caixaArlequina(nomeFallback, texto)
  let videoBuffer = null

  function isMp4Buf(buf) {
    return buf && buf.length > 12 && buf[4] === 0x66 && buf[5] === 0x74 && buf[6] === 0x79
  }
  function carregarLocal(nome) {
    if (!nome) return null
    const locais = [
      path.join(__dirname, '../../midias/social18/' + nome + '.mp4'),
      path.join(__dirname, '../midias/social18/' + nome + '.mp4'),
      path.join(process.cwd(), 'midias/social18/' + nome + '.mp4'),
    ]
    for (const p of locais) {
      try {
        if (fs.existsSync(p)) {
          const b = fs.readFileSync(p)
          if (b && b.length > 1000) return b
        }
      } catch (_) {}
    }
    return null
  }

  const urlStr = String(urlGif || '')

  // 1) LINK_GIF → baixa → converte → gifPlayback (GIF animado no WhatsApp)
  if (urlStr && /^https?:\/\//i.test(urlStr)) {
    try {
      const buf = await baixarBufferUrl(urlStr)
      if (/\.(mp4|webm)(\?|$)/i.test(urlStr) || isMp4Buf(buf)) {
        videoBuffer = buf
      } else {
        videoBuffer = await converterGifParaMp4(buf)
      }
    } catch (e) {
      console.error('ERRO enviarGifFixo link:', e?.message)
    }
  }

  // 2) fallback MP4 local (mesmo efeito de GIF no WhatsApp)
  if ((!videoBuffer || videoBuffer.length < 500) && nomeFallback) {
    videoBuffer = carregarLocal(nomeFallback)
    if (videoBuffer) console.log('[enviarGifFixo] fallback local', nomeFallback)
  }

  if (videoBuffer && videoBuffer.length > 500) {
    return sock.sendMessage(from, {
      video: videoBuffer,
      gifPlayback: true,
      mimetype: 'video/mp4',
      caption: textoFinal,
      mentions
    }, { quoted: info })
  }

  return sock.sendMessage(from, {
    text: textoFinal + '\n\n_⚠️ GIF falhou. No servidor rode:\n`sudo apt install -y ffmpeg imagemagick`_',
    mentions
  }, { quoted: info })
}

module.exports = { baixarBufferUrl, imagemDeLink, buscarImagemAleatoria, imagemDaBrincadeira, imagemDoRank, imagemFixa, imagemFixaDaBrincadeira, imagemFixaDoRank, enviarRank, enviarRankCasal, medalha, gifDeReacao, enviarComGif, enviarGifFixo, gifPorTema, enviarComGifTema, converterGifParaMp4 }
