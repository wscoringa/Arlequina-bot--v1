/*
 Helper pra falar com a API OFICIAL da OpenAI (ChatGPT).
 Usado pelo comando !gpt.

 COMO CONFIGURAR (obrigatório):
 1. Crie uma conta em https://platform.openai.com
 2. Gere uma chave em https://platform.openai.com/api-keys
 3. Adicione crédito na conta (essa API é PAGA, diferente do Gemini)
 4. Cole a chave no database/config.json assim:
    "OpenAiApiKey": "SUA_CHAVE_AQUI"

 Se você não quer pagar, use o comando !gptzap (API pública/gratuita,
 veja arquivos/js/gptPublicoAI.js) em vez deste.
*/
const axios = require('axios')

async function perguntarGpt(pergunta, apiKey, modelo = 'gpt-4o-mini') {
  if (!apiKey) {
    return { erro: true, mensagem: 'Chave da OpenAI não configurada. Adicione "OpenAiApiKey" no database/config.json (veja como pegar em https://platform.openai.com/api-keys). Se preferir uma opção grátis, use !gptzap.' }
  }

  try {
    const { data } = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: modelo,
      messages: [{ role: 'user', content: pergunta }],
      max_tokens: 800
    }, {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      timeout: 30000
    })

    const resposta = data?.choices?.[0]?.message?.content
    if (!resposta) {
      return { erro: true, mensagem: 'O ChatGPT não retornou nenhuma resposta pra essa pergunta. Tenta reformular.' }
    }
    return { erro: false, resposta: resposta.trim() }
  } catch (e) {
    const status = e?.response?.status
    console.log('❌ ERRO openaiAI:', status || e?.code || e?.message, e?.response?.data ? JSON.stringify(e.response.data).slice(0, 300) : '')
    if (status === 401) return { erro: true, mensagem: 'Chave da OpenAI inválida.' }
    if (status === 429) return { erro: true, mensagem: 'Limite/saldo da OpenAI atingido. Verifique seu plano em platform.openai.com.' }
    return { erro: true, mensagem: 'Não consegui falar com o ChatGPT agora. Tenta de novo em instantes.' }
  }
}

module.exports = { perguntarGpt }
