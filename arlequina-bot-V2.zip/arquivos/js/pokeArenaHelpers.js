/*
 Helpers compartilhados pela arena de Pokémon (3v3): montar o time
 (snapshot de status, não trava o Pokémon de verdade na coleção) e
 calcular dano com vantagem de tipo.
*/
const { multiplicadorTipo } = require('./pokedexData.js')

// Monta um "time de batalha" (snapshot) a partir da coleção da pessoa.
// indices: array de 3 números 1-based escolhidos por ela, ou null pra
// pegar automaticamente os 3 de maior nível.
function construirTime(pokemons, indices) {
  let selecionados
  if (Array.isArray(indices) && indices.length === 3) {
    selecionados = indices.map(i => pokemons[i - 1]).filter(Boolean)
    if (selecionados.length !== 3) return null
  } else {
    selecionados = [...pokemons].sort((a, b) => (b.nivel || 1) - (a.nivel || 1)).slice(0, 3)
  }
  if (selecionados.length < 3) return null

  return selecionados.map(p => ({
    nome: p.nome,
    emoji: p.emoji || '❔',
    tiposArr: String(p.tipo || '').split(' / ').filter(Boolean),
    raridade: p.raridade,
    nivel: p.nivel || 1,
    hpMax: p.vidaMax || 100,
    hp: p.vidaMax || 100,
    forca: p.forca || 10,
    defesa: p.defesa || 10,
    velocidade: p.velocidade || 10,
  }))
}

// Índice do próximo pokémon vivo (hp > 0) a partir de "desde" (inclusive)
function proximoVivo(time, desde = 0) {
  for (let i = desde; i < time.length; i++) {
    if (time[i].hp > 0) return i
  }
  return -1
}

function timeDerrotado(time) {
  return time.every(p => p.hp <= 0)
}

function calcularDano(atacante, defensor) {
  const mult = multiplicadorTipo(atacante.tiposArr, defensor.tiposArr)
  const variancia = Math.floor(Math.random() * Math.round(atacante.forca * 0.25))
  const baseDano = atacante.forca + variancia
  const mitigacao = Math.floor(defensor.defesa / 4)
  const dano = Math.max(Math.round((baseDano - mitigacao) * mult), 5)
  return { dano, mult }
}

function barraHp(hp, hpMax, tamanho = 10) {
  const cheio = Math.max(0, Math.min(tamanho, Math.round((hp / hpMax) * tamanho)))
  return '🟩'.repeat(cheio) + '⬛'.repeat(tamanho - cheio)
}

// Simula a arena INTEIRA automaticamente, sem precisar de !atacar manual
// — narra cada troca de golpe numa lista de linhas de texto, e diz quem
// venceu no final. Máximo de rounds pra nunca rodar pra sempre.
function simularBatalhaAutomatica(timeA, nomeA, timeB, nomeB) {
  const log = []
  let ativoA = proximoVivo(timeA, 0)
  let ativoB = proximoVivo(timeB, 0)
  let rodada = 0
  const MAX_RODADAS = 40

  log.push(`🏟️ A batalha começou!\n${timeA[ativoA].emoji} ${timeA[ativoA].nome} (${nomeA}) vs ${timeB[ativoB].emoji} ${timeB[ativoB].nome} (${nomeB})`)

  while (rodada < MAX_RODADAS) {
    rodada++
    const pokA = timeA[ativoA]
    const pokB = timeB[ativoB]

    // Quem tem mais velocidade ataca primeiro nessa rodada
    const ordem = pokA.velocidade >= pokB.velocidade ? ['A', 'B'] : ['B', 'A']

    for (const quem of ordem) {
      const atacante = quem === 'A' ? timeA[ativoA] : timeB[ativoB]
      const defensorTime = quem === 'A' ? timeB : timeA
      const idxDefensor = quem === 'A' ? ativoB : ativoA
      const defensor = defensorTime[idxDefensor]
      if (!atacante || !defensor || atacante.hp <= 0 || defensor.hp <= 0) continue

      const { dano, mult } = calcularDano(atacante, defensor)
      defensor.hp = Math.max(defensor.hp - dano, 0)
      log.push(`${atacante.emoji} ${atacante.nome} atacou ${defensor.emoji} ${defensor.nome}${mult > 1 ? ' (SUPER EFETIVO! 🔥)' : ''} — 💥 ${dano} de dano (❤️ ${defensor.hp}/${defensor.hpMax})`)

      if (defensor.hp <= 0) {
        log.push(`💀 ${defensor.emoji} ${defensor.nome} desmaiou!`)
        if (quem === 'A') {
          if (timeDerrotado(timeB)) { return finalizar('A') }
          ativoB = proximoVivo(timeB, idxDefensor + 1)
          log.push(`➡️ ${nomeB} manda ${timeB[ativoB].emoji} ${timeB[ativoB].nome}!`)
        } else {
          if (timeDerrotado(timeA)) { return finalizar('B') }
          ativoA = proximoVivo(timeA, idxDefensor + 1)
          log.push(`➡️ ${nomeA} manda ${timeA[ativoA].emoji} ${timeA[ativoA].nome}!`)
        }
      }
    }

    if (timeDerrotado(timeA)) return finalizar('B')
    if (timeDerrotado(timeB)) return finalizar('A')
  }

  // Empatou no limite de rodadas — decide por % de HP total restante
  const hpTotalA = timeA.reduce((s, p) => s + Math.max(p.hp, 0), 0) / timeA.reduce((s, p) => s + p.hpMax, 0)
  const hpTotalB = timeB.reduce((s, p) => s + Math.max(p.hp, 0), 0) / timeB.reduce((s, p) => s + p.hpMax, 0)
  return finalizar(hpTotalA >= hpTotalB ? 'A' : 'B')

  function finalizar(vencedor) {
    log.push(vencedor === 'A' ? `🏆 ${nomeA} venceu a batalha!` : `🏆 ${nomeB} venceu a batalha!`)
    return { log, vencedor }
  }
}

module.exports = { construirTime, proximoVivo, timeDerrotado, calcularDano, barraHp, simularBatalhaAutomatica }
