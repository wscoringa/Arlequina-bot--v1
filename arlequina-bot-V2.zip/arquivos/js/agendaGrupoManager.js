/*
  Sistema de agendamento de abertura/fechamento automático de grupo.
  Comandos: !fechagp HH:MM  e  !abrirgp HH:MM  (qualquer horário, 24h)

  Guarda em ./database/agendaGrupo.json um horário fixo por grupo pra
  fechar (announcement) e/ou abrir (not_announcement) o grupo todo dia,
  automaticamente. Um checador roda a cada 20s comparando a hora atual
  (HH:MM) com os horários salvos; quando bate, dispara a ação e marca
  a data de hoje como "já disparado" pra não repetir várias vezes
  dentro do mesmo minuto.
*/
const fs = require('fs')
const path = require('path')

const ARQUIVO = path.join(__dirname, '../../database/agendaGrupo.json')

function carregarAgenda() {
  try {
    if (!fs.existsSync(ARQUIVO)) {
      fs.writeFileSync(ARQUIVO, JSON.stringify({}, null, 2))
      return {}
    }
    return JSON.parse(fs.readFileSync(ARQUIVO, 'utf-8'))
  } catch (e) {
    return {}
  }
}

function salvarAgenda(dados) {
  try {
    fs.writeFileSync(ARQUIVO, JSON.stringify(dados, null, 2))
  } catch (e) {
    console.log('❌ ERRO ao salvar agendaGrupo.json:', e?.message)
  }
}

function getEntrada(agenda, groupJid) {
  if (!agenda[groupJid]) {
    agenda[groupJid] = { fechar: null, abrir: null, ultimoFechar: null, ultimoAbrir: null }
  }
  return agenda[groupJid]
}

// horario: string "HH:MM" (24h) ou null pra desativar
function definirFechamento(groupJid, horario) {
  const agenda = carregarAgenda()
  const entrada = getEntrada(agenda, groupJid)
  entrada.fechar = horario
  salvarAgenda(agenda)
}

function definirAbertura(groupJid, horario) {
  const agenda = carregarAgenda()
  const entrada = getEntrada(agenda, groupJid)
  entrada.abrir = horario
  salvarAgenda(agenda)
}

function obterAgenda(groupJid) {
  const agenda = carregarAgenda()
  return agenda[groupJid] || { fechar: null, abrir: null }
}

// Valida "HH:MM" (aceita H:MM também, tipo "9:40")
function validarHorario(texto) {
  const m = String(texto || '').trim().match(/^([0-1]?\d|2[0-3]):([0-5]\d)$/)
  if (!m) return null
  const hh = String(m[1]).padStart(2, '0')
  const mm = m[2]
  return `${hh}:${mm}`
}

// Roda a cada tick (chamado de tempos em tempos pelo index.js). Recebe
// o sock (columbina) já conectado.
async function verificarAgendamentos(sock) {
  if (!sock) return
  const agora = new Date()
  const hhmm = `${String(agora.getHours()).padStart(2, '0')}:${String(agora.getMinutes()).padStart(2, '0')}`
  const hoje = agora.toISOString().slice(0, 10)

  const agenda = carregarAgenda()
  let mudou = false

  for (const groupJid of Object.keys(agenda)) {
    const entrada = agenda[groupJid]

    if (entrada.fechar && entrada.fechar === hhmm && entrada.ultimoFechar !== hoje) {
      entrada.ultimoFechar = hoje
      mudou = true
      try {
        await sock.groupSettingUpdate(groupJid, 'announcement')
        await sock.sendMessage(groupJid, {
          text: `╭─━━─🃏💜「 🔒💜 *GRUPO FECHADO* 💜🔒 」💜🃏─━━─╮\n┃ ⏰ Fechamento automático agendado (${entrada.fechar}).\n┃ ❌ Só administradores podem enviar mensagens agora.\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n      🃏 *Arlequina Bot* 💜😈`
        })
      } catch (e) {
        console.log(`❌ ERRO agenda (fechar automático) no grupo ${groupJid}:`, e?.message)
      }
    }

    if (entrada.abrir && entrada.abrir === hhmm && entrada.ultimoAbrir !== hoje) {
      entrada.ultimoAbrir = hoje
      mudou = true
      try {
        await sock.groupSettingUpdate(groupJid, 'not_announcement')
        await sock.sendMessage(groupJid, {
          text: `╭─━━─🃏💜「 🔓💜 *GRUPO ABERTO* 💜🔓 」💜🃏─━━─╮\n┃ ⏰ Abertura automática agendada (${entrada.abrir}).\n┃ ✅ Todos podem enviar mensagens agora!\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯\n      🃏 *Arlequina Bot* 💜😈`
        })
      } catch (e) {
        console.log(`❌ ERRO agenda (abrir automático) no grupo ${groupJid}:`, e?.message)
      }
    }
  }

  if (mudou) salvarAgenda(agenda)
}

function iniciarAgendaGrupoScheduler(getSock) {
  setInterval(() => {
    try {
      const sock = typeof getSock === 'function' ? getSock() : getSock
      verificarAgendamentos(sock)
    } catch (e) {
      console.log('❌ ERRO no scheduler de agendaGrupo:', e?.message)
    }
  }, 20 * 1000)
}

module.exports = {
  definirFechamento,
  definirAbertura,
  obterAgenda,
  validarHorario,
  verificarAgendamentos,
  iniciarAgendaGrupoScheduler
}
