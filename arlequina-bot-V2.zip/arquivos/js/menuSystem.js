/*
SAIBA QUE AQUI VC PODE ALTERAR O ESTILO DO MENU! SÓ FAÇA ISSO SE SOUBER OQ VC MESMO ESTÁ FAZENDO.
*/
const fs = require('fs')
const path = require('path')

class MenuSystem {
constructor(commandManager) {
this.commandManager = commandManager
this.hiddenCommandsFile = './arquivos/json/commandos_ocultos.json'
this.carregarComandosOcultos()
}

carregarComandosOcultos() {
try {
if (fs.existsSync(this.hiddenCommandsFile)) {
this.hiddenCommands = JSON.parse(fs.readFileSync(this.hiddenCommandsFile))
} else {
this.hiddenCommands = {}
fs.writeFileSync(this.hiddenCommandsFile, JSON.stringify({}, null, 2))
}
} catch (e) {
this.hiddenCommands = {}
}
}

salvarComandosOcultos() {
fs.writeFileSync(this.hiddenCommandsFile, JSON.stringify(this.hiddenCommands, null, 2))
}

ocultarComando(categoria, nomeComando) {
if (!this.hiddenCommands[categoria]) {
this.hiddenCommands[categoria] = []
}
if (!this.hiddenCommands[categoria].includes(nomeComando)) {
this.hiddenCommands[categoria].push(nomeComando)
this.salvarComandosOcultos()
return true
}
return false
}

restaurarComando(categoria, nomeComando) {
if (this.hiddenCommands[categoria]) {
const index = this.hiddenCommands[categoria].indexOf(nomeComando)
if (index !== -1) {
this.hiddenCommands[categoria].splice(index, 1)
this.salvarComandosOcultos()
return true
}
}
return false
}

isComandoOculto(categoria, nomeComando) {
return this.hiddenCommands[categoria] && this.hiddenCommands[categoria].includes(nomeComando)
}

getCommandsByFolder(folderName) {
const todosComandos = this.commandManager.ObterComandosPorCategoria(folderName)
return todosComandos.filter(cmd => {
const nomeCmd = cmd.name || cmd.originalName
return !this.isComandoOculto(folderName, nomeCmd)
})
}

gerarMenuCustom(commands, prefix, titulo, icone) {
const div = '◈─━─━─━─━─━─━─━─━─━─━─◈'
if (!commands || commands.length === 0) {
return `╭─━━─🃏💜「 *${titulo}* 」💜🃏─━━─╮
${div}
${icone} ‹ *COMANDOS* ›
${div}
│ ❌ Nenhum comando aqui ainda.
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
      🃏 *Arlequina Bot* 💜😈`
}

let output = `╭─━━─🃏💜「 *${titulo}* 」💜🃏─━━─╮
${div}
${icone} ‹ *COMANDOS* ›
${div}`

for (let i = 0; i < commands.length; i++) {
const cmd = commands[i]
const nomeComando = cmd.name || cmd.originalName
output += `\n│ ✦ ${prefix}${nomeComando}`
}

output += `\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
      🃏 *Arlequina Bot* 💜😈`

return output
}

gerarMenuDesigner(commands, prefix, titulo, iconeEsq = '🌸', iconeDir = '🌸') {
const div = '◈─━─━─━─━─━─━─━─━─━─━─◈'
if (!commands || commands.length === 0) {
return `╭─━━─🃏💜「 *${titulo}* 」💜🃏─━━─╮
${div}
${iconeEsq} ‹ *COMANDOS* ›
${div}
│ ❌ Nenhum comando aqui ainda.
╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
      🃏 *Arlequina Bot* 💜😈`
}

let output = `╭─━━─🃏💜「 *${titulo}* 」💜🃏─━━─╮
${div}
${iconeEsq} ‹ *COMANDOS* ›
${div}`

for (let i = 0; i < commands.length; i++) {
const cmd = commands[i]
const nomeComando = cmd.name || cmd.originalName
output += `\n│ ✦ ${prefix}${nomeComando}`
}

output += `\n╰─━━━━━━━━━━━━━━━━━━━━━━━━━━━─╯
      🃏 *Arlequina Bot* 💜😈`

return output
}
}

module.exports = MenuSystem