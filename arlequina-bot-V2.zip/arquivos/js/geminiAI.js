/*
 Helper compartilhado pra falar com a IA (Google Gemini). Usado pelo
 !systemai e !multiai.

 Por que trocamos: a API antiga (systemzone.store) tava devolvendo erro
 500 nos testes — fora do ar do lado deles, sem solução possível do
 nosso lado. O Gemini tem plano grátis de verdade (sem cartão), é
 mantido pelo Google e muito mais estável.

 COMO CONFIGURAR (obrigatório pra esses comandos funcionarem):
 1. Entre em https://aistudio.google.com/apikey
 2. Faça login com uma conta Google e clique em "Create API Key" (grátis)
 3. Copie a chave e cole no database/config.json assim:
    "GeminiApiKey": "SUA_CHAVE_AQUI"
*/
const axios = require('axios')

async function perguntarGemini(pergunta, apiKey) {
  if (!apiKey) {
    return { erro: true, mensagem: 'Chave da IA não configurada. Adicione "GeminiApiKey" no database/config.json (veja como pegar grátis em https://aistudio.google.com/apikey).' }
  }

  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=${apiKey}`
    const { data } = await axios.post(url, {
      contents: [{ parts: [{ text: pergunta }] }]
    }, { timeout: 30000 })

    const resposta = data?.candidates?.[0]?.content?.parts?.[0]?.text
    if (!resposta) {
      return { erro: true, mensagem: 'A IA não retornou nenhuma resposta pra essa pergunta. Tenta reformular.' }
    }
    return { erro: false, resposta: resposta.trim() }
  } catch (e) {
    const status = e?.response?.status
    console.log('❌ ERRO geminiAI:', status || e?.code || e?.message, e?.response?.data ? JSON.stringify(e.response.data).slice(0, 300) : '')
    if (status === 400) return { erro: true, mensagem: 'Chave da IA inválida ou pergunta rejeitada pelo filtro de segurança do Google.' }
    if (status === 429) return { erro: true, mensagem: 'Limite gratuito diário da IA foi atingido. Tenta de novo mais tarde.' }
    return { erro: true, mensagem: 'Não consegui falar com a IA agora. Tenta de novo em instantes.' }
  }
}

module.exports = { perguntarGemini }
