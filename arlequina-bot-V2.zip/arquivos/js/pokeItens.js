/*
 Catálogo de itens de Pokémon (fora as pokébolas, que já têm o próprio
 arquivo em pokebolas.js): poções, revives e pedras de evolução.
 Usado por !pokeshop (comprar), !mochila (ver quantidade) e !usar
 (efeito) e !evoluir (checa se a pedra certa está na mochila).
*/

const POKE_ITENS = {
  pocao:        { label: '🧪 Poção',          preco: 100,  tipo: 'cura',    cura: 80 },
  superpocao:   { label: '💊 Superpoção',      preco: 300,  tipo: 'cura',    cura: 200 },
  pocaototal:   { label: '🩹 Poção Total',     preco: 700,  tipo: 'cura',    cura: 99999 }, // cura tudo
  revive:       { label: '💠 Revive',          preco: 500,  tipo: 'revive' },

  'pedra-fogo':    { label: '🔥 Pedra Fogo',    preco: 1200, tipo: 'pedra' },
  'pedra-agua':    { label: '💧 Pedra Água',    preco: 1200, tipo: 'pedra' },
  'pedra-trovao':  { label: '⚡ Pedra Trovão',  preco: 1200, tipo: 'pedra' },
  'pedra-lua':     { label: '🌙 Pedra Lua',     preco: 1500, tipo: 'pedra' },
  'pedra-folha':   { label: '🍃 Pedra Folha',   preco: 1200, tipo: 'pedra' },
}

const ORDEM_ITENS = ['pocao', 'superpocao', 'pocaototal', 'revive', 'pedra-fogo', 'pedra-agua', 'pedra-trovao', 'pedra-lua', 'pedra-folha']

module.exports = { POKE_ITENS, ORDEM_ITENS }
