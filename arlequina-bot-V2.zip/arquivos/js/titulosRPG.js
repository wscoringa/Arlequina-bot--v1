/*
 Lista central de títulos cosméticos do RPG. Cada um tem uma condição
 (requisito) calculada em cima dos dados já existentes do jogador —
 não precisa de nenhum campo novo pra "desbloquear", só verifica.
*/
const TITULOS = [
  { id: 1, nome: '🃏 Novato da Gangue', descricao: 'Todo mundo começa assim.', requisito: () => true },
  { id: 2, nome: '⚔️ Aventureiro', descricao: 'Alcance o level 10.', requisito: (u) => u.level >= 10 },
  { id: 3, nome: '🏆 Veterano de Batalha', descricao: 'Vença 10 duelos/PvP.', requisito: (u) => (u.vitorias || 0) >= 10 },
  { id: 4, nome: '👑 Rei/Rainha do Caos', descricao: 'Alcance o level 30.', requisito: (u) => u.level >= 30 },
  { id: 5, nome: '🎭 Segunda Piada do Coringa', descricao: 'Faça seu primeiro Prestígio.', requisito: (u) => (u.prestigio || 0) >= 1 },
  { id: 6, nome: '💀 Lenda de Gotham', descricao: 'Alcance 3 Prestígios.', requisito: (u) => (u.prestigio || 0) >= 3 },
  { id: 7, nome: '💰 Bilionário do Caos', descricao: 'Tenha R$ 100.000 em saldo.', requisito: (u) => (u.saldo || 0) >= 100000 },
  { id: 8, nome: '🐉 Caçador de Chefes', descricao: 'Derrote 20 bosses.', requisito: (u) => (u.bosses || 0) >= 20 },
]

module.exports = { TITULOS }
