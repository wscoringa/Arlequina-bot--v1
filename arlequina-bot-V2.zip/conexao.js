/*
            ARLEQUINA BOT

[=====/=====/=====/=====/=====/=====/=====/]
Bot criado e personalizado por 『𝙒𝙮𝙡𝙡𝙮𝙖𝙢』, com foco em desempenho,
organização e facilidade na criação de comandos via plugins.

Cada comando funciona em módulos/plugins independentes, deixando a
base mais limpa, rápida e fácil de editar.

Criador: 『𝙒𝙮𝙡𝙡𝙮𝙖𝙢』
Número: +55 31 9335-8417

Faça um bom proveito da base 🃏💜
[=====/=====/=====/=====/=====/=====/=====/]
*/
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  Browsers
} = require('@whiskeysockets/baileys')
const { Boom } = require('@hapi/boom')
const NodeCache = require('node-cache')
const readline = require('readline')
const pino = require('pino')
const fs = require('fs')
const path = require('path')
const colors = require('colors')
const moment = require('moment')
const { CyanLog, GreenLog, RedLog, MagentaLog } = require('./arquivos/js/logger.js')

const msgRetryCounterCache = new NodeCache()
const groupCache = new NodeCache({ stdTTL: 300, useClones: false })
const AUTH_DIR = './database/Arlequina-QR'

if (!fs.existsSync('./temp')) fs.mkdirSync('./temp', { recursive: true })
if (!fs.existsSync('./database/users')) fs.mkdirSync('./database/users', { recursive: true })
if (!fs.existsSync('./arquivos/json')) fs.mkdirSync('./arquivos/json', { recursive: true })
if (!fs.existsSync('./plugins')) {
for (const cat of ['admin', 'dono', 'cmds-aleatorios', 'resenha', 'downloads', 'efeitos', 'midias', 'inteligencia-ia', 'rpg']) {
fs.mkdirSync(`./plugins/${cat}`, { recursive: true })
}
}

const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (text) => new Promise((resolve) => rl.question(text, resolve))

/*VARIAVEL PARA CONTROLAR REINICIALIZACAO*/
let isReconnecting = false
let reconnectTimer = null

async function startConnection(NucleoDeCmds, config) {

if (isReconnecting) {
CyanLog('💜🃏Reconexão já em andamento, aguarde...')
return null
}

isReconnecting = true
  
const usePairingCode = process.argv.includes('--code')
const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR)
const { version } = await fetchLatestBaileysVersion()
const logger = pino({ level: 'silent' })

const columbina = makeWASocket({
version, logger,
auth: {
creds: state.creds,
keys: makeCacheableSignalKeyStore(state.keys, logger)
},
printQRInTerminal: !usePairingCode,
browser: Browsers.ubuntu('Chrome'),
msgRetryCounterCache,
connectTimeoutMs: 60000,
defaultQueryTimeoutMs: 60000, // 0 = sem limite: se a conexão travasse "zumbi" (sem avisar), ficava esperando pra sempre, travado, sem erro nenhum
keepAliveIntervalMs: 10000,
emitOwnEvents: true,
fireInitQueries: false,
generateHighQualityLinkPreview: true,
markOnlineOnConnect: true,
syncFullHistory: false,
cachedGroupMetadata: async (jid) => groupCache.get(jid),
getMessage: async (key) => {
return undefined
}
})


if (usePairingCode && !state.creds.registered) {
  console.log(colors.cyan('\n========== CONEXAO POR CODIGO =========='))
  console.log(colors.yellow('1) No celular: WhatsApp > Aparelhos conectados > Conectar um aparelho'))
  console.log(colors.yellow('2) Escolha: Conectar com numero de telefone'))
  console.log(colors.yellow('3) Digite o codigo que aparecer aqui (valido por poucos minutos)'))
  console.log(colors.cyan('==========================================\n'))
  console.log(colors.magenta('Dica: numero do BR com DDD e o 9 do celular.'))
  console.log(colors.magenta('Exemplo: 5531996294483  (55 + 31 + 9 + 96294483)\n'))

  let phoneNumber = await question('Digite o numero do WhatsApp (so numeros, com DDI 55): ')
  phoneNumber = phoneNumber.replace(/\D/g, '')

  // Normaliza celular BR: 55 + DDD(2) + 8 digitos -> insere o 9
  if (phoneNumber.startsWith('55') && phoneNumber.length === 12) {
    const ddd = phoneNumber.slice(2, 4)
    const resto = phoneNumber.slice(4)
    phoneNumber = '55' + ddd + '9' + resto
    console.log(colors.yellow(`Ajustei o numero (adicionei o 9 do celular): ${phoneNumber}`))
  }

  if (!phoneNumber || phoneNumber.length < 12 || phoneNumber.length > 15) {
    console.log(colors.red('Numero invalido! Use formato: 5531999999999 (13 digitos no BR)'))
    process.exit(0)
  }

  // Espera o socket estabilizar antes de pedir o codigo
  await new Promise(r => setTimeout(r, 2500))

  try {
    console.log(colors.yellow(`Solicitando codigo para: ${phoneNumber}`))
    let code = await columbina.requestPairingCode(phoneNumber)
    code = code?.match(/.{1,4}/g)?.join('-') || code
    console.log(colors.green('\n========================================'))
    console.log(colors.green(`  CODIGO DE PAREAMENTO:  ${code}`))
    console.log(colors.green('========================================\n'))
    console.log(colors.cyan('Digite esse codigo no WhatsApp do celular AGORA.'))
    console.log(colors.cyan('Se der erro, apague a pasta database/Arlequina-QR e tente de novo.\n'))
  } catch (e) {
    console.log(colors.red('Falha ao gerar codigo: ' + (e?.message || e)))
    console.log(colors.yellow('Apague database/Arlequina-QR e rode novamente: bash start.sh cod'))
    process.exit(1)
  }
  // Nao fecha o rl aqui — deixa o processo vivo ate conectar
}

columbina.ev.on('creds.update', saveCreds)

columbina.ev.on('connection.update', async (update) => {
const { connection, lastDisconnect, qr } = update
if (qr && !usePairingCode) {
console.log(colors.yellow('QR Code gerado, escaneie com o WhatsApp:'))
const qrcode = require('qrcode-terminal')
qrcode.generate(qr, { small: true })
}

if (connection === 'open') {
GreenLog(`✅ ${config.NomeDoBot} conectado com sucesso!`)
const botNumber = columbina.user.id.split(':')[0]
GreenLog(`📱 Bot Numero: ${botNumber}`)
  
/*Reseta flag de reconexao quando conecta*/
isReconnecting = false
if (reconnectTimer) {
clearTimeout(reconnectTimer)
reconnectTimer = null
}
}

if (connection === 'close') {
const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode
RedLog(`Conexao fechada - Codigo: ${statusCode}`)

if (statusCode !== DisconnectReason.loggedOut) {
RedLog('💜 Reiniciando a Arlequina Bot em 3 segundos devido a falha na conexao... 🔄')

/*Isso aqui abaixo foi uma tentativa de enviar uma mensagem de aviso para o dono se possivel. Mas falhou miseravelmente... Claro, dava pra eu arrumar pra isso de fato acontecer, mas deu preguiça! então vai ficar assim msm.*/
try {
const donoJid = config.NumeroDoDono?.replace(/\D/g, '') + '@s.whatsapp.net'
await columbina.sendMessage(donoJid, {text: `⚠️ *ARLEQUINA BOT REINICIANDO*\n\nMotivo: Conexao fechada (codigo ${statusCode})\n⏰ A Arlequina sera reiniciada automaticamente em 3 segundos.`
}).catch(() => {})
} catch(e) {}

/*se existir, limpa timer anterior*/
if (reconnectTimer) clearTimeout(reconnectTimer)

/*Aguarda 3 segundos e REINICIA O PROCESSO INTEIRO*/
reconnectTimer = setTimeout(() => {
CyanLog('💜🃏Encerrando processo para reiniciar completamente...')
process.exit(0)/* sai do processo - o start.sh reiniciara automaticamente*/
}, 3000)
} else {
RedLog('💜🃏 Sessao expirada! Exclua a pasta Arlequina-QR e reinicie a Arlequina manualmente.')
RedLog('❤️‍🩹Reiniciando para gerar novo QR Code em 5 segundos...')

if (reconnectTimer) clearTimeout(reconnectTimer)
reconnectTimer = setTimeout(() => {
process.exit(0)
}, 5000)
}
}
})

/*EVENTO DE GRUPO - Boas-vindas / Saída*/
const welcomeDB = require('./arquivos/js/welcomeDB.js')
const modLogDB = require('./arquivos/js/modLogDB.js')
const adminStateConexao = require('./arquivos/js/adminState.js')
const boasVindasHandler = require('./arquivos/js/boasVindasHandler.js')
const { mesmaPessoa } = require('./arquivos/js/eventosGrupoHelper.js')

// BUGFIX: o comando !antifake só guardava a flag ligada/desligada, mas
// nada no bot chegava a OLHAR quem entrava no grupo pra agir. Esse
// listener é o que faltava: se antifake tiver ativado no grupo, expulsa
// automaticamente quem entrar com DDI diferente de 55 (Brasil).
columbina.ev.on('group-participants.update', async (update) => {
const { id, participants, action } = update
if (action !== 'add') return
if (!adminStateConexao.antifake[id]) return

const meuNumero = columbina.user?.id?.split(':')[0]

for (const part of participants) {
  const jid = part?.phoneNumber || part?.id || part?.jid || part
  if (!jid || typeof jid !== 'string') continue
  const numero = jid.split('@')[0]
  if (numero === meuNumero) continue
  if (!numero.startsWith('55')) {
    try {
      await columbina.groupParticipantsUpdate(id, [jid], 'remove')
      await columbina.sendMessage(id, {
        text: `🕵️ *ANTIFAKE* — @${numero} foi removido(a) automaticamente (número de fora do Brasil).`,
        mentions: [jid]
      })
    } catch (e) {
      console.log('❌ ERRO antifake (remoção):', e?.message)
    }
  }
}
})

// Boas-vindas / saída / remoção (foto do perfil, "saiu" x "removido por ADM"):
// toda a lógica está em arquivos/js/boasVindasHandler.js
columbina.ev.on('group-participants.update', (update) => {
  boasVindasHandler.tratar(columbina, update).catch((e) => console.log('❌ ERRO no aviso de entrada/saída:', e?.message))
})

/*EVENTO DE GRUPO - Log de Atividades (x9grupo)
  Denuncia no grupo qualquer ação de moderação feita por um ADM
  (ban/remove, promoção, rebaixamento, entrada adicionada/aprovada),
  inclusive quando feita direto pelo WhatsApp, fora dos comandos da bot.
  Quando a própria Arlequina é o alvo (promovida/rebaixada/removida),
  a frase troca pra falar dela mesma. */
columbina.ev.on('group-participants.update', async (update) => {
const { id, participants, action, author } = update
if (!modLogDB.isAtivo(id)) return
if (!author) return

const meuNumero = columbina.user?.id?.split(':')[0]
const autorEuMesma = await mesmaPessoa(columbina, [author, update.authorPn], columbina.user)

for (const part of participants) {
  const alvo = part?.phoneNumber || part?.id || part?.jid || part
  if (!alvo || typeof alvo !== 'string') continue

  // ação feita pela própria Arlequina (ex: comando #ban) já foi anunciada
  // pelo próprio comando, então o log fica quieto pra não duplicar.
  if (modLogDB.foiAcaoRecenteDoBot(id, alvo, action)) continue
  if (autorEuMesma) continue

  // saída/entrada por vontade própria: o WhatsApp manda "author" igual
  // ao próprio "alvo" nesse caso (não foi nenhum ADM que agiu). Isso
  // fica por conta do sistema de boas-vindas/saída, não do x9grupo.
  if (await mesmaPessoa(columbina, part, [author, update.authorPn])) continue

  const alvoEuMesma = alvo.split('@')[0] === meuNumero
  const nomeAlvo = alvoEuMesma ? 'a Arlequina' : `@${alvo.split('@')[0]}`
  const nomeAutor = `@${author.split('@')[0]}`
  const mentions = [alvo, author]

  let texto = null

  if (action === 'remove') {
    texto = `╭━━〔 🕵️💜 *LOG DE ATIVIDADES* 💜🕵️ 〕━━⬣\n┃ 🚫 ${nomeAlvo} foi removido(a) do grupo\n┃ 👑 ADM responsável: ${nomeAutor}\n╰━━━━━━━━━━━━━━━━━━━━━━━⬣\n💜🃏 _Registro de moderação._`
  } else if (action === 'promote') {
    texto = `╭━━〔 🕵️💜 *LOG DE ATIVIDADES* 💜🕵️ 〕━━⬣\n┃ ⭐ ${nomeAlvo} foi promovido(a) a ADM\n┃ 👑 Promovido(a) por: ${nomeAutor}\n╰━━━━━━━━━━━━━━━━━━━━━━━⬣\n💜🃏 _Promoção feita._`
  } else if (action === 'demote') {
    texto = `╭━━〔 🕵️💜 *LOG DE ATIVIDADES* 💜🕵️ 〕━━⬣\n┃ 📉 ${nomeAlvo} foi rebaixado(a) a membro\n┃ 👑 Rebaixado(a) por: ${nomeAutor}\n╰━━━━━━━━━━━━━━━━━━━━━━━⬣\n💜🃏 _Caiu do trono... 😈_`
  } else if (action === 'add') {
    texto = `╭━━〔 🕵️💜 *LOG DE ATIVIDADES* 💜🕵️ 〕━━⬣\n┃ ✅ ${nomeAlvo} entrou no grupo\n┃ 👑 Adicionado(a)/aprovado(a) por: ${nomeAutor}\n╰━━━━━━━━━━━━━━━━━━━━━━━⬣\n💜🃏 _Chegou mais um(a) pra festa... 🎉_`
  }

  if (!texto) continue

  try {
    await columbina.sendMessage(id, { text: texto, mentions })
  } catch (e) {
    console.log('❌ ERRO ao enviar log de atividades (x9grupo):', e?.message)
  }
}
})

/*Notifica o dono quando a própria Arlequina é removida de um grupo
  (nesse caso ela não tem mais como avisar dentro do grupo).*/
columbina.ev.on('group-participants.update', async (update) => {
const { id, participants, action, author } = update
if (action !== 'remove') return
const meuNumero = columbina.user?.id?.split(':')[0]
const fuiEuRemovida = participants.some(p => {
  const alvo = p?.phoneNumber || p?.id || p?.jid || p
  return typeof alvo === 'string' && alvo.split('@')[0] === meuNumero
})
if (!fuiEuRemovida) return

try {
  const donoId = columbina.user.id?.split(':')[0] + '@s.whatsapp.net'
  let nomeGrupo = id
  try { nomeGrupo = (await columbina.groupMetadata(id))?.subject || id } catch (_) {}
  const quemRemoveu = author ? `@${author.split('@')[0]}` : 'alguém'
  await columbina.sendMessage(donoId, {
    text: `🌑💜 *ARLEQUINA FOI REMOVIDA DE UM GRUPO* 💜🌑\n\n┃ 📛 Grupo: ${nomeGrupo}\n┃ 👑 Removida por: ${quemRemoveu}`,
    mentions: author ? [author] : []
  })
} catch (e) {}
})

isReconnecting = false
return columbina
}

module.exports = startConnection